import * as THREE from 'three';
import {mergeGeometries} from './utils/BufferGeometryUtils.js';
// Original synthetic rear habitat. Demo units, not a captured site extension.
// NOAA Coral Species Framework growth-form references remain morphological only.
export const REAR_PLAN=Object.freeze([
 {id:'near_offset_patch',x:-5,z:16,sx:6.3,sz:6.1,height:2.4,yaw:-.48,color:'#788875',seed:11,blocks:7,colonies:68},
 {id:'back_right_islet',x:9,z:27,sx:7.4,sz:6.2,height:3.0,yaw:.63,color:'#718674',seed:17,blocks:8,colonies:64},
 {id:'left_receding_patch',x:-13,z:34,sx:8.2,sz:7.2,height:3.2,yaw:-.7,color:'#698176',seed:23,blocks:6,colonies:50},
 {id:'rear_broken_outline',x:0,z:48,sx:10,sz:7.3,height:4.0,yaw:.24,color:'#617e76',seed:31,blocks:7,colonies:34},
 {id:'left_open_flank',x:-27,z:5,sx:7.2,sz:6.1,height:2.6,yaw:.8,color:'#738572',seed:41,blocks:6,colonies:40},
 {id:'right_open_flank',x:27,z:7,sx:6.1,sz:7,height:2.2,yaw:-.3,color:'#748873',seed:47,blocks:5,colonies:34}
]);
export function installRearHabitat({world,ground,parent,stoneMaterial}){
 if(world.rearHabitat)throw Error('Rear habitat already installed');
 const root=new THREE.Group();root.name='Synthetic_Rear_Reef_Habitat';parent.add(root);
 const meshes=[],ownedGeometries=[],obstacles=[],records=[],contacts=[];
 const borrowed=new Set(),down=new THREE.Vector3(0,-1,0),up=new THREE.Vector3(0,1,0),ray=new THREE.Raycaster(),dummy=new THREE.Object3D();
 let seed=937421;const rnd=()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296;};
 ground.updateMatrixWorld(true);
 const cache=new Map();function sand(x,z){const key=x.toFixed(5)+','+z.toFixed(5);if(cache.has(key))return cache.get(key);ray.set(new THREE.Vector3(x,30,z),down);const hit=ray.intersectObject(ground,false)[0];if(!hit)throw Error('Rear habitat outside original sand');cache.set(key,hit.point.y);return hit.point.y;}
 function terrain(spec) {
  const positions=[],colors=[],indices=[],co=new THREE.Color(spec.color),c=Math.cos(spec.yaw),s=Math.sin(spec.yaw);
  // Each shoulder is an interlocking, unequal fracture assemblage. No radial
  // mound heightfield, closed contour terraces, repeated dome, or single summit.
  const blocks=[
   [-.15,-.30,.48,.43,.96,-.23],[-.49,-.02,.39,.39,.72,.42],
   [.28,-.20,.36,.38,.77,.61],[.06,.36,.43,.34,.49,-.58],
   [-.48,.39,.35,.28,.37,.22],[.53,.16,.28,.34,.34,-.51],
   [-.56,-.49,.28,.30,.52,-.33],[.37,-.59,.31,.27,.54,.28],
   [.22,.64,.30,.21,.22,.68]
  ];
  const toWorld=(u,v)=>[spec.x+u*spec.sx*c-v*spec.sz*s,spec.z+u*spec.sx*s+v*spec.sz*c];
  for(let blockIndex=0;blockIndex<(spec.blocks||7);blockIndex++){
   const [cx,cz,rx,rz,height,yaw]=blocks[blockIndex],N=18,offset=positions.length/3;
   // Staggered fracture bands, slanting irregular roofs, undercut ledges. The
   // gaps between crossing blocks become the readable diagonal gullies.
   const levels=[[0,1.18],[.18,1.04],[.53,.85],[.78,.65],[.95,.36]];
   const thetaOffset=spec.seed*.37+blockIndex*.41;
   for(let j=0;j<levels.length;j++)for(let k=0;k<N;k++){
    const angle=2*Math.PI*k/N,polygon=1+.14*Math.sin(3*angle+thetaOffset)+.075*Math.cos(5*angle-thetaOffset);
    const cut=1-.20*Math.pow(Math.max(0,Math.cos(angle-.6-blockIndex*.7)),6);
    const width=levels[j][1]*polygon*cut;
    const u0=Math.cos(angle)*rx*width,v0=Math.sin(angle)*rz*width;
    const leanX=(j/4)*.045*Math.sin(blockIndex*2+spec.seed),leanZ=(j/4)*.06*Math.cos(blockIndex+spec.seed);
    const u=cx+u0*Math.cos(yaw)-v0*Math.sin(yaw)+leanX,v=cz+u0*Math.sin(yaw)+v0*Math.cos(yaw)+leanZ;
    const [x,z]=toWorld(u,v),bottom=sand(x,z)-.18;
    const tilt=.08*Math.sin(angle+thetaOffset)+.055*Math.sin(angle*3+blockIndex);
    const y=bottom+height*spec.height*(levels[j][0]+tilt*(j/4));
    positions.push(x,y,z);const shade=.84+.12*(j/4)+.045*Math.sin(blockIndex*2+angle);colors.push(co.r*shade,co.g*shade,co.b*shade);
   }
   for(let j=0;j<levels.length-1;j++)for(let k=0;k<N;k++){let a=offset+j*N+k,b=offset+j*N+(k+1)%N,d=offset+(j+1)*N+k,e=offset+(j+1)*N+(k+1)%N;indices.push(a,d,b,b,d,e);}
   const [mx,mz]=toWorld(cx+.03,cz-.045),roof=positions.length/3;positions.push(mx,sand(mx,mz)-.18+height*spec.height*.91,mz);colors.push(co.r*.94,co.g*.94,co.b*.94);
   for(let k=0;k<N;k++)indices.push(roof,offset+4*N+(k+1)%N,offset+4*N+k);
   const base=positions.length/3;positions.push(mx,-2.2,mz);colors.push(co.r*.7,co.g*.7,co.b*.7);for(let k=0;k<N;k++)indices.push(base,offset+k,offset+(k+1)%N);
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.setIndex(indices);g.computeVertexNormals();g.computeBoundingBox();return g;
 }
 const geos=REAR_PLAN.map(spec=>{const g=terrain(spec),box=g.boundingBox.clone();obstacles.push({name:'Rear_'+spec.id,box});records.push({...spec,bounds:{min:box.min.toArray(),max:box.max.toArray()}});return g;});
 const g=mergeGeometries(geos);geos.forEach(g=>g.dispose());ownedGeometries.push(g);
 const stone=new THREE.Mesh(g,stoneMaterial);stone.name='Rear_Broken_Reef_Islands';stone.receiveShadow=true;root.add(stone);meshes.push(stone);borrowed.add(stoneMaterial);root.updateMatrixWorld(true);
 const colonies=[[],[],[]],grass=[],rubble=[],used=[];
 function seat(x,z){ray.set(new THREE.Vector3(x,30,z),down);return ray.intersectObject(stone,false)[0];}
 const palette=[['#71836b','#87917a','#8d8877'],['#92947b','#7f8d79','#a09b82'],['#839580','#98917b']];
 for(const p of REAR_PLAN){let accepted=0;
  // Unequal separated patches, with lower growth between them, rather than rows.
  const patches=[[-.36,-.16,.27],[.27,-.26,.23],[-.1,.34,.29],[.41,.13,.19]];
  for(let attempt=0;attempt<2400&&accepted<p.colonies;attempt++){
   const patch=patches[Math.floor(rnd()*patches.length)],a=rnd()*Math.PI*2,r=Math.sqrt(rnd())*patch[2],u=patch[0]+Math.cos(a)*r,v=patch[1]+Math.sin(a)*r;
   const x=p.x+u*p.sx*Math.cos(p.yaw)-v*p.sz*Math.sin(p.yaw),z=p.z+u*p.sx*Math.sin(p.yaw)+v*p.sz*Math.cos(p.yaw);
   const hit=seat(x,z);if(!hit||hit.face.normal.y<.70||hit.point.y<sand(x,z)+.4)continue;
   const size=.50+rnd()*.42,type=accepted%13<10?0:accepted%13<12?1:2,spacing=type===0?.60:.82;
   if(used.some(v=>Math.hypot(x-v.x,z-v.z)<Math.max(spacing,v.r)))continue;
   const yaw=rnd()*Math.PI*2,q=new THREE.Quaternion().setFromUnitVectors(up,hit.face.normal.clone().normalize()).multiply(new THREE.Quaternion().setFromAxisAngle(up,yaw));
   const item={p:[x,hit.point.y-.035,z],q:q.toArray(),s:[size,size*(.86+rnd()*.2),size*(.83+rnd()*.22)],color:palette[type][Math.floor(rnd()*palette[type].length)]};
   colonies[type].push(item);used.push({x,z,r:spacing});contacts.push({island:p.id,type,point:hit.point.toArray(),normal:hit.face.normal.toArray(),item});accepted++;
  }
  // Low, broken peripheral grass patches rooted in the unchanged sand surface.
  for(let i=0;i<380;i++){
   const a=rnd()*Math.PI*2,rr=.55+rnd()*.75,x=p.x+Math.cos(a)*p.sx*rr,z=p.z+Math.sin(a)*p.sz*rr;
   if(seat(x,z)||z<12&&Math.abs(x-(4+4*Math.sin((-z+8)*.055)))<5.5)continue;
   if(Math.sin(x*.7+z*.3)+Math.cos(z*.6-x*.2)<-.2)continue;
   const y=sand(x,z),s=.55+rnd()*.65;grass.push({p:[x,y-.015,z],s:[s,s,s],yaw:rnd()*6.28,color:rnd()<.5?'#82936a':'#6b805a'});
   if(i%7===0)rubble.push({p:[x+.14,y-.02,z],s:[.8+rnd()*.9,.7+rnd()*.4,.7+rnd()*.8],yaw:rnd()*6.28,color:'#7d8572'});
  }
 }
 // Targeted contact safety repair. IDs refer to the deterministic pre-prune lists.
 // The seat is deliberately embedded .035 units. Lower-skin tolerance is .12;
 // upper skin/branches tolerate .08, conservatively including mesh interpolation.
 // Only flagged new instances are omitted; survivors retain every transform/color.
 const contactExclusions=[[6, 14, 19, 27, 34, 44, 56, 60, 67, 70, 78, 80, 90, 94, 102, 122, 125, 126, 141, 142, 143, 145, 166, 181, 189], [7], []];
 const pruned=[];for(let t=0;t<3;t++){const excluded=new Set(contactExclusions[t]);colonies[t]=colonies[t].filter((item,i)=>{if(excluded.has(i)){pruned.push({type:t,originalIndex:i,item});return false;}return true;});}
 const retained=new Set(colonies.flat());for(let i=contacts.length-1;i>=0;i--)if(!retained.has(contacts[i].item))contacts.splice(i,1);
 function instances(name,source,items){if(!source||!items.length)throw Error('Missing reusable rear habitat source '+name);const m=new THREE.InstancedMesh(source.geometry,source.material,items.length);borrowed.add(source.geometry);borrowed.add(source.material);m.name=name;m.castShadow=false;m.receiveShadow=true;
  items.forEach((p,i)=>{dummy.position.fromArray(p.p);dummy.rotation.set(0,p.yaw||0,0);if(p.q)dummy.quaternion.fromArray(p.q);dummy.scale.fromArray(p.s);dummy.updateMatrix();m.setMatrixAt(i,dummy.matrix);m.setColorAt(i,new THREE.Color(p.color));});m.computeBoundingSphere();root.add(m);meshes.push(m);return m;
 }
 for(let i=0;i<3;i++){const name=['Attached_Lobes','Branch_Thicket','Crown_Branches'][i];instances('Rear_'+name,world.group.getObjectByName('Visible_Habitat_'+name+'_Stable'),colonies[i]);}
 instances('Rear_Low_Grass',world.group.getObjectByName('Synthetic_Transition_grass0'),grass);
 instances('Rear_Buried_Rubble',world.group.getObjectByName('Synthetic_Transition_rubble'),rubble);
 const triangles=meshes.reduce((n,m)=>n+(m.geometry.index?.count||m.geometry.attributes.position.count)/3*(m.isInstancedMesh?m.count:1),0);
 if(triangles>200000||meshes.length>6)throw Error('Rear habitat budget exceeded');
 world.budget.triangles+=triangles;world.budget.drawCalls+=meshes.length;if(parent.visible)world.obstacles.push(...obstacles);
 root.userData={synthetic:true,measuredHabitat:false,metricCalibration:false,sourceScanCopies:0,triangles,drawCalls:meshes.length,newTextures:0,animated:false,contactRepair:{pruned,lowerTolerance:.12,upperTolerance:.08,intendedEmbed:.035},records,contacts,colonies:colonies.map(a=>a.length),grass:grass.length,rubble:rubble.length};
 let disposed=false;const api={root,meshes,obstacles,borrowed,triangles,setEnabled(value){if(disposed)return;for(const o of obstacles){const i=world.obstacles.indexOf(o);if(value&&i<0)world.obstacles.push(o);else if(!value&&i>=0)world.obstacles.splice(i,1);}},getState:()=>({disposed,triangles,drawCalls:meshes.length}),dispose(){if(disposed)return;disposed=true;root.removeFromParent();for(const o of obstacles){const i=world.obstacles.indexOf(o);if(i>=0)world.obstacles.splice(i,1);}meshes.forEach(m=>{if(m.isInstancedMesh)m.dispose();});ownedGeometries.forEach(g=>g.dispose());world.budget.triangles-=triangles;world.budget.drawCalls-=meshes.length;if(world.rearHabitat===api)delete world.rearHabitat;}};world.rearHabitat=api;return api;
}
