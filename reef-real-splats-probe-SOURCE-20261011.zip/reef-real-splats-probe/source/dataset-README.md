---
license: cc-by-4.0
tags:
  - coral reef
  - coral restoration
  - 3d gaussian splatting
  - photogrammetry
  - time-series
  - 3d
  - wildflow
  - orthomosaic
pretty_name: Soneva Coral Reef Time-Series Photogrammetry
---

# Soneva Coral Reef Time-Series Photogrammetry

The [Soneva Conservation and Sustainability Maldives](https://www.instagram.com/soneva.coral) team and [Wildflow](https://wildflow.ai) are sharing an open time-series 3D photogrammetry dataset from coral restoration and monitoring plots in the Maldives.

![Soneva coral reef 3D dataset](https://huggingface.co/datasets/wildflow/soneva-corals/resolve/main/more/thumbnail.jpg?download=true)

Right now it is hard to find high-quality open time-series 3D photogrammetry data of coral reefs. Coral reefs support over a quarter of all marine life and up to a billion people, yet they are disappearing fast. A lot of people are working hard to protect and restore them; we hope open access to real reef data helps more teams build useful tools, compare methods, and learn from each other.

This release contains **23 surveys across 6 coral reef plots**, captured between **2025-06-02 and 2026-03-04** following the [protocol](https://wildflow.ai/protocol). It includes **22,422 raw GoPro images** plus processed reconstruction assets: COLMAP cameras and poses, dense point clouds, orthomosaic PMTiles, coordinate transforms, and multi-LOD Gaussian splat PLYs.

The surveys were co-registered so individual coral colonies can be followed through time. You can use the data for coral reef monitoring, time-series 3D reconstruction, SLAM, semantic segmentation, species identification, AR/VR, education, games, visualisation, or anything else that benefits from real underwater 3D data.

You can also explore the surveys in the browser-based viewer: [wildflow.ai/soneva](https://wildflow.ai/soneva).

## License

This dataset is licensed under [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/). You can use it for research, education, and commercial work as long as attribution is provided.

## Structure

Each survey is stored as:

```text
maldives_soneva_<plot>_<yyyymmdd>/
├── raw/                         # Raw GoPro images
├── colmap/                      # COLMAP reconstruction files
│   ├── cameras.bin
│   ├── images.bin
│   ├── points3D.bin
│   └── image_mapping.csv        # Raw image path to COLMAP image mapping
├── ortho/
│   ├── ortho.pmtiles            # Browser/GIS-friendly tiled orthomosaic
│   └── world_to_pixel.json      # Coordinate transform metadata
├── splats/
│   └── ply/
│       ├── lod0.ply
│       ├── lod1.ply
│       ├── lod2.ply
│       ├── lod3.ply
│       └── lod4.ply
└── point_cloud.ply              # Dense exported point cloud, XYZ only

metadata.json                    # Survey-level metadata
```

## Metadata

[`metadata.json`](https://huggingface.co/datasets/wildflow/soneva-corals/resolve/main/metadata.json) contains per-survey metadata:

- capture date
- scale bar length and measured scale bar depths
- SW corner coordinates where available from the source spreadsheet
- raw image counts and sizes
- reference scalebar endpoint projections for the 6 base surveys where alignment annotations are available

Scale bars are 0.5 m long. Projection references use survey-relative raw image paths and COLMAP image IDs, for example:

```json
{
  "image": "raw/10.07.25 RHS/G0016051.JPG",
  "colmap_image_id": 494,
  "pixel_x": 2403.375,
  "pixel_y": 2996.55688
}
```

## Survey Summary

| Plot      | Surveys |
| --------- | ------: |
| HB        |       4 |
| OOTBM     |       3 |
| OOTBR     |       4 |
| OOTSL1    |       4 |
| OOTSR2    |       4 |
| OOTSR3    |       4 |
| **Total** |  **23** |

## Available Assets

| Asset               | Notes                                                            |
| ------------------- | ---------------------------------------------------------------- |
| Raw images          | 22,422 images, ~67 GB                                            |
| COLMAP              | `cameras.bin`, `images.bin`, `points3D.bin`, `image_mapping.csv` |
| Orthomosaics        | PMTiles plus `world_to_pixel.json`                               |
| Dense point clouds  | One XYZ-only `point_cloud.ply` per survey                        |
| Gaussian splat PLYs | 5 LODs per survey                                                |

## Contributors

This dataset was made possible by the Soneva Conservation and Sustainability Maldives team:

- Ben Yuen
- Ayla Kroon
- Tom Freer
- Ashley Wallis
- the Soneva CSM coral interns
- Johanna Leonhardt

Processed and published with support from [Wildflow](https://wildflow.ai/).

For questions about the dataset, contact Sergei Nozdrenkov at sergei@wildflow.ai or Ben Yuen at benedict@soneva.com.

## Cite

```bibtex
@misc{wildflow_soneva_corals_2026,
  author       = {Ben Yuen and Ayla Kroon and Tom Freer and Ashley Wallis and Johanna Leonhardt and Wildflow},
  title        = {Soneva CSM Coral Reef Time-Series Photogrammetry Dataset},
  year         = {2026},
  url          = {https://huggingface.co/datasets/wildflow/soneva-corals},
  publisher    = {Hugging Face}
}
```

Links:

- [huggingface.co/datasets/wildflow/soneva-corals](https://huggingface.co/datasets/wildflow/soneva-corals) -- this dataset
- [wildflow.ai/soneva](https://wildflow.ai/soneva) -- explore in the browser
- [instagram.com/soneva.coral](https://www.instagram.com/soneva.coral) -- Soneva CSM
- [protocol](https://wildflow.ai/protocol) -- how to collect the data
- Announcement in [LinkedIn](https://www.linkedin.com/feed/update/urn:li:activity:7464829592503996417/), [Twitter/X](https://x.com/nozdrenkov/status/2059065521077621120), [BlueSky](https://bsky.app/profile/nozdrenkov.com/post/3mmpppxesfk25).
