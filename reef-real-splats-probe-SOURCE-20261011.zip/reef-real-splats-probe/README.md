# 真实礁坡 Gaussian 探针（本地独立，GPU 待验）

2026-10-11。此包保留现有人工 enriched 世界不变。没有发布、改入口、修改 150/149 主线、创建 CI 或使用云浏览器。不是大世界成品，也不代表真实 GPU 或美术验收通过。

## 已完成

- 一次下载官方 Soneva OOTSL1 2026-02-18 的最低 LOD4 原始 Gaussian PLY，7,171,392 字节 / 30,381 Gaussian，校验官方 LFS SHA256。59 个 float 属性包括中心、各向尺度、四元数、opacity、SH3；无三角面。未下载其他 LOD、图像、点云、COLMAP 大文件或 Tabuhan 数据。
- Spark 2.3.1 MIT 官方 npm 包；Three 0.186.0 / r186 直接沿用 enriched 的字节一致版本，满足 Spark >=0.180.0 peer。补入同版本官方 Pass.js。完整性、文件 SHA 和 package-lock 固定。运行时全部本地，无 CDN 或线上资产请求。
- 一个 THREE.Scene / WebGLRenderer 同时挂载 Spark 和仅作诊断的范围线框、1 m 标尺，证明使用现有 Three 结构的接入方式；实际同场景绘制仍待 GPU 验证。原始 PLY 未改写，没有将 Gaussian 转成 surfel/三角模型或照片地板。
- 鼠标拖动转向，W/S 前后、A/D 横移、Q/E 升降，Shift 慢行，移动方向随视线；触屏按钮、概览重置、侧面/背面/低角度预设、参考范围开关、卸载/重载、报告导出。
- 明确展示扫描限制与来源，没有水雾、鱼、假远景、补面或复制延展。超时隔离、缺文件、模块、WebGL、shader 与 context-loss 错误路径；实际行为仍需合同验证。

## 运行

只需 Python 3 静态服务器，无需 npm install 或联网：

    cd reef-real-splats-probe
    npm start

也可 `python3 -m http.server 8768 --bind 127.0.0.1 --directory page`。打开 `http://127.0.0.1:8768/`。要求有 WebGL2 的本地/既有 GPU 浏览器，localhost 或 HTTPS 以校验 SHA256。该命令不创建可分享网址。

CPU 复查：Node 22+、Python 3、已有 NumPy，运行 `npm run verify`。它只验证原文件/schema/哈希、真实 npm 模块导入、语法与 6 个坐标/控制/来源测试，不启动浏览器，不测试渲染。

## 尺寸与坐标

官方 world_to_pixel.json 的 XY 包围矩形为 9.396 × 9 m = 84.564 m²。它不是连续扫描面积；27 个 Gaussian 中心略越过该框。原始中心范围：X -4.05284..5.27249、Y -7.56349..1.49769、Z -9.97230..-4.41394 m。官方场地备注为礁坡，靠近垂直壁段；3 个标尺深度为 7.5/5.0/7.1 m。

渲染作单位尺度刚性变换：X=x-cx，Y=z-cz，Z=-(y-cy)，以 Gaussian 中心中位数为原点；整体沿 X 旋转 -π/2。XY 为正射平面有 metadata 支持，源 +Z 向上由负深度推断，必须真实目视确认。未改变每个点、填充空洞或非均匀拉伸。Spark 的内部 GPU 编码仍有自己的压缩/显示语义，不能称原始参数无损呈现。

## GPU 交接与停止条件

先读 GPU-TEST-CONTRACT.md。它要求加载与实际 Gaussian draw 分开，3 个侧面/背面/低角度视角，操作、边界、3 次释放/重载、缺文件错误、真实设备性能。提供可接受既有 Playwright Page 的辅助函数；本轮未运行。

若普通游动距离仍明显糊、源视角外广泛缺失，或 GPU/资源不适配，停止此源路线并报告，不能加雾/补面掩盖。仅当 LOD4 证明管线却细节不足时，可向主控说明理由申请一次 LOD3；本包不自动升级。小块成功仍不构成辽阔海底目标成功。

## 文件

- page/：完整离线静态页面、固定 runtime、原始 LOD4、metadata
- source/：官方原 metadata、文件目录、PLY header、npm 来源与完整性、原 npm 包及其内容
- licenses/ 与 page/credits.html：许可和署名
- verification/：可复跑 CPU 检查、结果、独立审阅、GPU 合同辅助函数
- GPU-TEST-CONTRACT.md：下一步唯一有限 GPU 验收范围

## 资料

- [Soneva 官方 dataset](https://huggingface.co/datasets/wildflow/soneva-corals)，固定 commit 200aaf30cda920bd9b0e5d5da8838d4165c9e289，获取日 2026-10-11
- [Spark 官方文档](https://sparkjs.dev/docs/)、[Gaussian PLY 加载](https://sparkjs.dev/docs/loading-splats/)、[SplatMesh API](https://sparkjs.dev/docs/splat-mesh/)、[SparkRenderer API](https://sparkjs.dev/docs/spark-renderer/)
- [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
