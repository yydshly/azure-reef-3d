# One bounded real-GPU check: raw Soneva Gaussian probe

Status: NOT RUN. This package has only CPU identity, API import, syntax, and math checks. No browser pixels, real GPU draw, mobile performance, or source-side coverage has passed.

## Scope and gate

- Use this isolated page, never the existing live world or mainline 150/149.
- Serve `page/` from localhost or the publisher's already authorized isolated GPU test environment. `npm start` binds only 127.0.0.1:8768. It does not publish.
- Reuse the publisher's existing browser/device and testing workflow. Do not start new CI, buy services, create credentials, change Three, or use the known no-WebGL cloud browser.
- Fixed asset: 7,171,392 bytes, 30,381 Gaussian splats, SHA256 bdf77330d5a4df5c92aa2bb0f0dcc800ccebbc471903429703309c955fd82499. No further download is authorized by this contract.
- Original input LOD4 is already the coarsest dataset level. Spark's additional automatic LOD is disabled. Extended coordinate encoding is enabled. The renderer uses actual anisotropic Gaussian rendering and SH3, not Points, surfels, or triangulated PLY.
- Three 0.186.0 is byte-identical to the enriched baseline. Spark 2.3.1 npm (MIT) imports the same Three instance. It and a 3D reference box/ruler share one THREE.Scene and WebGLRenderer.

## Required evidence, in order

1. Load within 30 s, assert report.source.count = 30381 and expected SHA. This is parse evidence only.
2. Actual GPU: report.gl must name WebGL2, isContextLost=false, error=0; no shader/runtime/unhandled errors. report.draw.hookInstalled=true and nonzeroSplatDraws>0 must be observed after load. The hook wraps actual gl.drawElementsInstanced/drawArraysInstanced inside Spark's draw phase; renderer.info calls alone are insufficient because reference lines also draw. Record activeSplats and lastInstances. These can be below 30381 because of view culling and are not input count.
3. At fixed 1120×712 viewport and DPR 1, render overview, side, back, low using reefProbe.setView(name). Allow at most 5 s settling per view. For each, call reefProbe.captureEvidence(name), save report and a screenshot. Readback hides reference geometry and counts non-background pixels; this proves nonempty output only, never scene completeness. Do not substitute screenshot from another renderer/version or cloud fallback. The 3 mandatory acceptance views are side/back/low; overview is orientation context.
4. Visually inspect all 3 low/side/rear views at normal size and magnification. Confirm upright reef slope and coral structure, inspect missing underside/backfaces, stretched thin splats, low-LOD blur, floaters, holes, and periphery. Source XY is established by orthomosaic metadata; +Z up is an inference consistent with negative depths, still requiring this visual check. No geometry was filled. Record pass/fail for each view separately.
5. Controls: reset -> hold W 0.5 s -> release -> drag camera -> hold S -> reset. Position/quaternion must change and reset exactly. Pointer cancellation, blur, and tab hiding must stop movement. On-screen buttons must release on pointercancel/lost capture. Arrow/WASD navigation should not move while a button has focus.
6. Boundary: reference box toggle works, outsideReference warning appears when leaving metadata XY extent. It must not imply every point inside is scanned. The raw 3D Gaussian centers have a ~5.56 m Z range, and 27 centers slightly exceed the ortho rectangle. Confirm no invented seabed outside.
7. Lifecycle: do 3 load/unload cycles. Await each promise. After unload meshCleared=true, sceneChildren=0, sortWorkerCleared=true; calls/frames stop. Compare renderer.info.memory before/after, record JS/GPU heap if device exposes it; these counters do not guarantee zero driver memory. Repeated loads return to the same source count without stale models. Test unload while loading and rapid repeated load. For a GPU/worker operation stuck >10 s, stop and report; do not stack more loads.
8. Error: block only the local PLY request in the test browser; attempt load and require visible error without a running stale scene; unblock and reload once. Do not edit the input or fetch other LODs. Bootstrap import failure and absent WebGL should present truthful error UI. Optional context-loss simulation must stop the loop; restoring may require refresh, no automatic recovery promise.
9. Performance: record device/browser/GPU and at least 10 s of actual RAF cadence while moving. The built-in frameWork timings are CPU/update elapsed work, not FPS and not GPU timings. No production performance claim from parse speed, source size, one screenshot, or renderer.info alone.

## Stop conditions

- Stop this source route if side, back, or low view exposes broad absent structure (roughly one-third of the intended inspected reef body or more), upside-down orientation not explained by the rigid mapping, or unreadable coral structure at ordinary exploration distance. Do not patch holes, add fog, fabricate missing surfaces, or iteratively beautify until the test seems acceptable.
- If LOD4 proves the pipeline but is too blurry to judge, report that narrow finding. Request a justified, single LOD3 download from the parent before doing it. Do not independently escalate to LOD2/1/0.
- Stop compatibility work after a clear WebGL/shader/worker failure is reproduced once; return logs and exact dependency pins. No silent renderer substitution or all-site Three change.
- Stop for OOM, recurring context loss, stalled teardown, sustained unsuitable motion cadence, or obvious memory growth over the 3 cycles. Record device and resource evidence instead of looping.
- A technically successful 84.564 m² reference patch cannot establish the user's large, rich sea-world goal. Even visually successful output remains a small proof before larger-source selection.

## Result categories

Return one of `TECHNICAL_FAIL`, `TECHNICAL_PASS_VISUAL_FAIL`, `TECHNICAL_PASS_VISUAL_INCONCLUSIVE_LOD4`, or `TECHNICAL_PASS_VISUAL_PASS_SMALL_PATCH_ONLY`, plus raw reports and 4 labeled frames. Publication and replacing the main world require separate parent approval. The helper `verification/gpu-contract.mjs` accepts an already available Playwright Page; it never launches a browser or CI and never declares visual acceptance.
