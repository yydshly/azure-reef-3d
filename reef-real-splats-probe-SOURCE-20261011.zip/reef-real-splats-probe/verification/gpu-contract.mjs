// Optional helper for the existing publisher's real-GPU browser Page.
// Never invoked by CPU verification. Never launches a browser or runs CI.
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
async function bounded(promise,ms,label){let timer;try{return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(label+' timed out; underlying browser operation may still be pending. Stop this run.')),ms);})]);}finally{clearTimeout(timer);}}
export async function runGpuContract(page,{url,outputDir}){
  assert(url&&outputDir,'An authorized isolated URL and output directory are required');
  await fs.mkdir(outputDir,{recursive:true});const consoleErrors=[];
  const onError=e=>consoleErrors.push(String(e));page.on('pageerror',onError);
  try{
    await page.setViewportSize({width:1120,height:712});await page.goto(url,{waitUntil:'domcontentloaded',timeout:30000});
    const dpr=await page.evaluate(()=>devicePixelRatio);assert.equal(dpr,1,'Use the existing test context with deviceScaleFactor 1; viewport size alone does not set DPR');
    await page.waitForFunction(()=>window.reefProbe?.getState()==='ready'||window.reefProbe?.getState()==='error',{},{timeout:30000});
    let r=await page.evaluate(()=>reefProbe.report());assert.equal(r.status,'ready',JSON.stringify(r.errors));assert.equal(r.source.count,30381);assert.equal(r.source.sha256,'bdf77330d5a4df5c92aa2bb0f0dcc800ccebbc471903429703309c955fd82499');
    await page.waitForFunction(()=>reefProbe.report().draw?.nonzeroSplatDraws>0,{},{timeout:10000});
    for(const view of ['overview','side','back','low']){
      await page.evaluate(v=>reefProbe.setView(v),view);
      await page.waitForTimeout(1500);const evidence=await bounded(page.evaluate(v=>reefProbe.captureEvidence(v),view),12000,'capture '+view);
      assert(evidence.draw.hookInstalled&&evidence.activeSplats>0&&evidence.draw.lastInstances>0,`No real splat draw: ${view}`);assert.equal(evidence.glError,0);assert(evidence.coverage>.005,`Almost-empty raw splat image: ${view}`);
      await fs.writeFile(path.join(outputDir,`${view}.json`),JSON.stringify(evidence,null,2));await page.screenshot({path:path.join(outputDir,`${view}.png`)});
    }
    const cycles=[];for(let i=0;i<3;i++){
      await bounded(page.evaluate(()=>reefProbe.unload()),12000,'unload');r=await page.evaluate(()=>reefProbe.report());assert.equal(r.status,'unloaded');assert(r.stats.lastDispose.meshCleared&&r.stats.lastDispose.sortWorkerCleared);assert.equal(r.stats.lastDispose.sceneChildren,0);cycles.push(r.stats.lastDispose);
      await bounded(page.evaluate(()=>reefProbe.load()),30000,'load');await page.waitForFunction(()=>reefProbe.report().draw?.nonzeroSplatDraws>0,{},{timeout:30000});
    }
    r=await page.evaluate(()=>reefProbe.report());assert.equal(r.source.count,30381);assert.equal(r.gl.error,0);assert.equal(r.gl.isContextLost,false);assert.equal(r.errors.length,0,JSON.stringify(r.errors));assert.equal(consoleErrors.length,0,consoleErrors.join('\n'));
    const result={status:'AUTOMATED_TECHNICAL_SUBSET_ONLY',visualStatus:'PENDING_MANUAL_3_VIEW_REVIEW',devicePixelRatio:dpr,remaining:['control tests','boundary warning','load cancellation and repeated actions','missing-asset error and retry','10-second real RAF/device performance check'],cycles,report:r,consoleErrors};await fs.writeFile(path.join(outputDir,'gpu-subset-report.json'),JSON.stringify(result,null,2));return result;
  }catch(error){const result={status:'TECHNICAL_FAIL',message:String(error?.stack||error),consoleErrors,report:await bounded(page.evaluate(()=>window.reefProbe?.report()),2000,'failure report').catch(()=>null)};await fs.writeFile(path.join(outputDir,'gpu-failure-report.json'),JSON.stringify(result,null,2));throw error;
  }finally{page.off('pageerror',onError);}
}
