import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
const root=path.resolve(import.meta.dirname,'..'),page=path.join(root,'page');
const files=['bootstrap.js','probe.js','probe-core.js','vendor/three.module.js','vendor/three.core.js','vendor/spark-2.3.1.module.js','vendor/postprocessing/Pass.js'];
for(const file of files){const result=spawnSync(process.execPath,['--check',path.join(page,file)],{encoding:'utf8'});assert.equal(result.status,0,result.stderr);}
const maps={'three':path.join(page,'vendor/three.module.js'),'@sparkjsdev/spark':path.join(page,'vendor/spark-2.3.1.module.js'),'three/addons/postprocessing/Pass.js':path.join(page,'vendor/postprocessing/Pass.js')};
await fs.writeFile(path.join(root,'verification/node-loader.mjs'),`export async function resolve(specifier,context,nextResolve){const map=${JSON.stringify(maps)};return map[specifier]?{url:new URL('file://'+map[specifier]).href,shortCircuit:true}:nextResolve(specifier,context);}\n`);
const result=spawnSync(process.execPath,['--no-warnings','--loader',path.join(root,'verification/node-loader.mjs'),'--input-type=module','-e',`import * as THREE from 'three';import { SparkRenderer,SplatMesh } from '@sparkjsdev/spark';if(THREE.REVISION!=='186')throw Error('wrong Three');if(typeof SparkRenderer!=='function'||typeof SplatMesh!=='function')throw Error('missing Spark API');console.log('Actual official module imports resolve, Three '+THREE.REVISION+'. No renderer created.');`],{encoding:'utf8'});assert.equal(result.status,0,result.stderr);console.log(result.stdout.trim());
// All browser imports are local after import-map resolution. No hotlinked data/runtime CDN.
const html=await fs.readFile(path.join(page,'index.html'),'utf8');assert(html.includes('"three/addons/":"./vendor/"'));assert(html.includes('"@sparkjsdev/spark":"./vendor/spark-2.3.1.module.js"'));assert(!html.includes('https://cdn'));
const outcome={at:new Date().toISOString(),syntax:'PASS',actualModuleImports:'PASS',gpu:'NOT_RUN',verifiedFiles:files};await fs.writeFile(path.join(root,'verification/module-report.json'),JSON.stringify(outcome,null,2));console.log(JSON.stringify(outcome));
