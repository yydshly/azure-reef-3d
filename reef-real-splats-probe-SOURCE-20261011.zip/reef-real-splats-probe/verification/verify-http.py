import http.server,threading,functools,pathlib,urllib.request,hashlib,json
base=pathlib.Path(__file__).resolve().parents[1]
handler=functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(base/'page'))
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
paths=['index.html','probe.css','bootstrap.js','probe.js','probe-core.js','credits.html','assets/manifest.json','assets/soneva-ootsl1-20260218-lod4.ply','vendor/spark-2.3.1.module.js','vendor/three.module.js','vendor/three.core.js','vendor/postprocessing/Pass.js'];results=[]
try:
 for path in paths:
  with urllib.request.urlopen(f'http://127.0.0.1:{server.server_port}/{path}',timeout=5) as r:data=r.read();status=r.status;mime=r.headers.get('Content-Type')
  assert status==200;assert data==(base/'page'/path).read_bytes();results.append({'path':path,'status':status,'bytes':len(data),'mime':mime,'sha256':hashlib.sha256(data).hexdigest()})
 report={'status':'HTTP_BYTES_ONLY_PASS','gpu':'NOT_RUN','resources':results};(base/'verification/http-report.json').write_text(json.dumps(report,indent=2));print('All 12 local HTTP resources: exact bytes, 200. No browser/GPU executed.')
finally:server.shutdown();server.server_close()
