// All coordinates are fictional scene units. No survey geometry or scientific scale.
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const smooth=(a,b,v)=>{const t=clamp((v-a)/(b-a),0,1);return t*t*(3-2*t)};
export const EXPLORATION_BOUNDS=Object.freeze({minX:-150,maxX:150,minZ:-420,maxZ:30,surfaceY:11});
export function legacyGroundHeight(x,z){const w=smooth(3,11,Math.hypot(x,z));return -.98+w*(.16*Math.sin(x*.22+z*.1)+.09*Math.sin(z*.35));}
export function floorHeight(x,z){
 const join=smooth(120,163,-z),depth=smooth(238,370,-z);
 const drop=smooth(275,385,-z)*smooth(-5,60,x)*28+smooth(390,560,-z)*22;
 const shelf=-1.2-16*depth-5*smooth(0,100,x)*depth-drop;
 const channel=-1.25*Math.exp(-Math.pow((x-12-12*Math.sin(z*.012))/24,2))*smooth(180,270,-z);
 const ripple=.12*Math.sin(x*.2+z*.065)+.07*Math.sin(z*.29);
 return legacyGroundHeight(x,z)*(1-join)+(shelf+channel+ripple)*join;
}
// Five asymmetric, broad stratified outcrops, not a repeating corridor or boulder field.
export const REEF_MASSES=Object.freeze([
 {x:-43,z:-176,rx:18,rz:12,h:3.1,seed:2},
 {x:57,z:-227,rx:26,rz:18,h:4.6,seed:5},
 {x:-46,z:-296,rx:34,rz:24,h:9.1,seed:11},
 {x:-75,z:-350,rx:39,rz:33,h:13,seed:17},
 {x:-26,z:-400,rx:26,rz:21,h:6.7,seed:23}
]);
export const DISTANT_MASSES=Object.freeze([{x:130,z:-335,rx:44,rz:37,h:8,seed:31},{x:-140,z:-220,rx:43,rz:31,h:7,seed:37},{x:-62,z:-462,rx:30,rz:24,h:14,seed:41}]);
export function resolvePosition(position,radius=.65){const p=Array.isArray(position)?position.slice():[position.x,position.y,position.z];p[0]=clamp(p[0],-150+radius,150-radius);p[2]=clamp(p[2],-420+radius,30-radius);for(const r of [...REEF_MASSES,...DISTANT_MASSES]){const dx=(p[0]-r.x)/(r.rx+radius),dz=(p[2]-r.z)/(r.rz+radius),d=Math.hypot(dx,dz);if(d<1.16&&p[1]<floorHeight(p[0],p[2])+r.h+radius){const a=Math.atan2(dz,dx);p[0]=r.x+Math.cos(a)*(r.rx+radius)*1.16;p[2]=r.z+Math.sin(a)*(r.rz+radius)*1.16;if(p[0]>150-radius)p[0]=r.x-(r.rx+radius)*1.16;if(p[0]<-150+radius)p[0]=r.x+(r.rx+radius)*1.16;}}p[0]=clamp(p[0],-150+radius,150-radius);p[2]=clamp(p[2],-420+radius,30-radius);p[1]=clamp(p[1],floorHeight(p[0],p[2])+radius,11-radius);return p;}
export function regionAt(position){const z=Array.isArray(position)?position[2]:position.z;return z> -120?'原生扫描礁区':z> -245?'开阔海草浅湾':'大陆架与深水边缘';}
export const EXPLORATION_TOUR_STOPS=Object.freeze([
 {label:'原生扫描礁区',position:[4,3.2,10],target:[3,1,-15]},
 {label:'穿过原礁盆',position:[6,6,-85],target:[-5,1,-118]},
 {label:'海草浅湾入口',position:[4,3,-164],target:[-5,.4,-192]},
 {label:'横游开放浅湾',position:[-6,3.2,-227],target:[0,-1,-259]},
 {label:'大陆架断崖',position:[12,-3,-310],target:[-36,-5,-326]},
 {label:'深水蓝境',position:[8,-10,-393],target:[-16,-12,-417]}
]);
