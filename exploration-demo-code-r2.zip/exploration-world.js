import * as T from 'three';
import {REAR_CONNECTED_DATA as SCAN_FORMS} from './rear-connected-data.js';
import {floorHeight,legacyGroundHeight,resolvePosition,regionAt,EXPLORATION_BOUNDS,EXPLORATION_TOUR_STOPS,REEF_MASSES,DISTANT_MASSES} from './exploration-world-data.js';
export {floorHeight,resolvePosition,regionAt,EXPLORATION_TOUR_STOPS} from './exploration-world-data.js';
// Procedural synthetic scenery only: no downloads, imported surveys, or changes to existing support surfaces.
export function createExplorationWorld({scene,configure=()=>{},ground}){
 const group=new T.Group();group.name='Synthetic_Continuous_Exploration_Regions';scene.add(group);
 const geometries=new Set(),materials=new Set(),instances=[],animated=[];let disposed=false,paused=false,reduced=false,hidden=false,lastTime=0;
 const dummy=new T.Object3D(),color=new T.Color();let seed=814273;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
 const smooth=(a,b,v)=>T.MathUtils.smoothstep(v,a,b);
 const mat=(color,opts={})=>{const m=new T.MeshStandardMaterial({color,roughness:1,...opts});configure(m);materials.add(m);return m};
 function mesh(name,g,m){geometries.add(g);const o=new T.Mesh(g,m);o.name=name;o.receiveShadow=true;group.add(o);return o;}
 function batch(name,g,m,items){geometries.add(g);const o=new T.InstancedMesh(g,m,items.length);o.name=name;o.receiveShadow=true;items.forEach((p,i)=>{dummy.position.fromArray(p.p);dummy.rotation.set(0,p.a||0,0);dummy.scale.fromArray(p.s||[1,1,1]);dummy.updateMatrix();o.setMatrixAt(i,dummy.matrix);if(p.c)o.setColorAt(i,color.set(p.c));});o.computeBoundingSphere();group.add(o);instances.push(o);return o;}
 // Connected shelf: actual bottom extends far outside navigable bounds. It is not a scaled copy of the reef.
 // A narrow new transition tongue begins beyond all retained scan supports.
 const sand=mat('#ffffff',{vertexColors:true});
 const prior=sand.onBeforeCompile;sand.onBeforeCompile=shader=>{prior.call(sand,shader);shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
float micro=.5+.5*sin(vExhibitWorld.x*7.+sin(vExhibitWorld.z*.73));
float grain=fract(sin(dot(floor(vExhibitWorld.xz*140.),vec2(127.1,311.7)))*43758.5453);
diffuseColor.rgb*=.90+.07*micro+.07*grain;`)};
 sand.customProgramCacheKey=()=>'exploration-sand-ocean-v1';
 const tile=50,step=2.5;
 for(let z=-620;z<80;z+=tile)for(let x=-300;x<300;x+=tile){
  const p=[],c=[],ind=[];const n=tile/step;
  for(let j=0;j<=n;j++)for(let i=0;i<=n;i++){
   const px=x+i*step,pz=z+j*step;let h=floorHeight(px,pz);
   // Do not cover the retained reef, its original seabed, or its support aprons.
   const newRegion=pz<=-125||Math.abs(px)>=75;
   if(pz>-145&&pz<=-125)h=legacyGroundHeight(px,pz)+.012;
   p.push(px,h,pz);const d=smooth(230,390,-pz),patch=.5+.5*Math.sin(px*.031+pz*.027)*Math.sin(px*.077-pz*.018);color.set('#b1aa88').lerp(new T.Color('#557b78'),d*.53).multiplyScalar(.91+.10*patch);c.push(color.r,color.g,color.b);
  }
  for(let j=0;j<n;j++)for(let i=0;i<n;i++){const px=x+(i+.5)*step,pz=z+(j+.5)*step;if(pz>-125&&Math.abs(px)<75&&pz<65)continue;const a=j*(n+1)+i,b=a+1,d=a+n+1;ind.push(a,d,b,b,d,d+1);}
  if(!ind.length)continue;const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('color',new T.Float32BufferAttribute(c,3));g.setIndex(ind);g.computeVertexNormals();mesh('Continuous_Shelf_Sediment_'+x+'_'+z,g,sand);
 }
 // Angular layered erosional limestone, each unique footprint and stratigraphy.
 const rock=mat('#ffffff',{vertexColors:true});const outcrops=new Map();
 const rockPrevious=rock.onBeforeCompile;rock.onBeforeCompile=shader=>{rockPrevious.call(rock,shader);shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
float strata=.5+.5*sin(vExhibitWorld.y*5.+sin(vExhibitWorld.x*.21)*1.3+sin(vExhibitWorld.z*.18));
float pores=fract(sin(dot(floor(vExhibitWorld*20.),vec3(127.1,311.7,74.7)))*43758.5453);
float mineral=.5+.5*sin(vExhibitWorld.x*1.7+sin(vExhibitWorld.z*2.1))*sin(vExhibitWorld.y*2.9);
diffuseColor.rgb*=.77+.17*strata+.16*mineral+.07*pores;
diffuseColor.rgb=mix(diffuseColor.rgb,diffuseColor.rgb*vec3(1.13,.91,.85),smoothstep(.68,.9,mineral)*.35);`);};

 rock.customProgramCacheKey=()=>'exploration-strata-ocean-v1';
 // Reuse four distinct, already-tested CC0 scan-derived compositions as sparse
 // landmarks. Original arrays are read-only; only these copies are normalized.
 const formGroups=['near_offset_patch','back_right_islet','left_receding_patch','rear_broken_outline'];
 function outcrop(r){
  const sourceGroup=formGroups[(r.seed+Math.floor(r.seed/3))%formGroups.length];
  const forms=Object.values(SCAN_FORMS.meshes).filter(d=>d.group===sourceGroup);
  const box=new T.Box3();forms.forEach(d=>d.vertices.forEach(p=>box.expandByPoint(new T.Vector3(...p))));const size=box.getSize(new T.Vector3()),center=box.getCenter(new T.Vector3());
  const p=[],c=[],idx=[];
  for(let f=0;f<forms.length;f++){const d=forms[f],off=p.length/3;for(const v of d.vertices){
    let nx=(v[0]-center.x)/size.x*2,nz=(v[2]-center.z)/size.z*2;
    // Mirror selected entire compositions, never perturb individual source vertices.
    if(r.seed%2)nx=-nx;
    const x=r.x+nx*r.rx*.82,z=r.z+nz*r.rz*.84;
    const y=floorHeight(x,z)+((v[1]-box.min.y)/size.y)*r.h-.18;
    p.push(x,y,z);color.set(f===0?'#829087':f===1?'#7a8981':'#9a9d87');c.push(color.r,color.g,color.b);
   }for(const triangle of d.triangles){const t=triangle.map(i=>i+off);idx.push(...(r.seed%2?[t[0],t[2],t[1]]:t));}}
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('color',new T.Float32BufferAttribute(c,3));g.setIndex(idx);g.computeVertexNormals();
  const o=mesh('Broken_Scan_Derived_Reef_'+r.seed,g,rock);o.userData={synthetic:true,terrestrialScanArt:true,source:'https://polyhaven.com/a/boulder_01',license:'CC0',sourceComposition:sourceGroup,sourceUnmodified:true};outcrops.set(r.seed,o);
 }
 REEF_MASSES.forEach(outcrop);
 // Remote singular mesas make the world extend past the route rather than forming two walls.
 DISTANT_MASSES.forEach(outcrop);
 // Bent tapered ribbons, six leaves per tuft. No model loads and no alpha textures.
 const blades=[];for(let j=0;j<6;j++){const a=j*2.399,h=.65+(j%3)*.22,bend=.18+(j%2)*.17;for(let k=0;k<4;k++){const t=k/4,u=(k+1)/4;const vertex=(q,s)=>{const w=.065*(1-q);return [Math.cos(a)*bend*q*q+Math.sin(a)*w*s,h*q,Math.sin(a)*bend*q*q-Math.cos(a)*w*s]};blades.push(...vertex(t,-1),...vertex(t,1),...vertex(u,-1),...vertex(t,1),...vertex(u,1),...vertex(u,-1));}}
 const grassG=new T.BufferGeometry();grassG.setAttribute('position',new T.Float32BufferAttribute(blades,3));grassG.computeVertexNormals();
 const grassM=mat('#ffffff',{side:T.DoubleSide});const grassTime={value:0};const grassPrior=grassM.onBeforeCompile;grassM.onBeforeCompile=shader=>{grassPrior.call(grassM,shader);shader.uniforms.explorationTime=grassTime;shader.vertexShader='uniform float explorationTime;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
transformed.x+=sin(explorationTime*.6+instanceMatrix[3].x*.23+instanceMatrix[3].z*.14)*position.y*position.y*.075;`)};
 grassM.customProgramCacheKey=()=>'exploration-blades-ocean-v1';
 // Broad meadows with sinuous open lanes; density varies by ecological patch, not random clutter.
 const meadowPatches=[[-8,-178,15,19],[25,-191,18,19],[-24,-204,20,20],[26,-224,16,23],[-9,-239,20,15],[-45,-228,20,17]];
 let grassCount=0;
 for(let k=0;k<meadowPatches.length;k++){const [cx,cz,rx,rz]=meadowPatches[k],items=[];
  for(let i=0;i<550;i++){const a=random()*Math.PI*2,rad=Math.sqrt(random()),x=cx+Math.cos(a)*rx*rad,z=cz+Math.sin(a)*rz*rad;
   const lane=5+5*Math.sin((-z-150)*.034);if(Math.abs(x-lane)<4.3)continue;
   // Scalloped patch margins and a few inner openings make readable meadows.
   const edge=.84+.13*Math.sin(a*5+k);if(rad>edge)continue;
   if(REEF_MASSES.some(r=>Math.hypot((x-r.x)/r.rx,(z-r.z)/r.rz)<1.02))continue;
   const scale=.85+random()*.55;items.push({p:[x,floorHeight(x,z)-.025,z],a:random()*6.28,s:[scale,scale*(1.05+random()*.45),scale],c:i%4?'#617c4d':'#929465'});
  }grassCount+=items.length;batch('Open_Bay_Seagrass_Meadow_'+k,grassG,grassM,items);
 }
 // Colonies are sparse shelf-top plate gardens and branching fans, not endless stones.
 const plateG=new T.SphereGeometry(1,13,6);const pa=plateG.attributes.position;for(let i=0;i<pa.count;i++){const a=Math.atan2(pa.getZ(i),pa.getX(i)),w=1+.13*Math.sin(a*5);pa.setXYZ(i,pa.getX(i)*w,pa.getY(i)*.13,pa.getZ(i)*w);}plateG.computeVertexNormals();
 const seatRay=new T.Raycaster(),down=new T.Vector3(0,-1,0);group.updateMatrixWorld(true);
 const plates=[],fans=[];for(const r of REEF_MASSES){for(let i=0;i<16;i++){const a=random()*6.28,rad=.13+random()*.28,x=r.x+Math.cos(a)*r.rx*rad,z=r.z+Math.sin(a)*r.rz*rad,yBase=floorHeight(r.x,r.z)+r.h;seatRay.set(new T.Vector3(x,40,z),down);const hit=seatRay.intersectObject(outcrops.get(r.seed),false)[0];if(!hit)continue;const y=hit.point.y-.04;plates.push({p:[x,y,z],a,s:[1.1+random()*1.4,.7+random(),.8+random()],c:i%2?'#899083':'#a48f7c'});if(i%2===0)fans.push({p:[x,y,z],a,s:[1+random(),1.4+random()*1.2,1],c:'#ad9185'});}}
 batch('Shelf_Top_Encrusting_Colonies',plateG,mat('#ffffff'),plates);
 const fp=[];function limb(x,y,xx,yy,w){fp.push(x-w,y,0,x+w,y,0,xx,yy,0)}limb(0,0,0,1,.04);for(let i=0;i<11;i++){const y=.16+i*.065,w=.75*Math.sin((i+1)/12*Math.PI);for(const s of[-1,1]){limb(0,y,w*s,y+.48,.026);for(let j=1;j<5;j++)limb(w*s*j/5,y+.48*j/5,s*(w*j/5+.16),y+.48*j/5+.26,.012);}}const fanG=new T.BufferGeometry();fanG.setAttribute('position',new T.Float32BufferAttribute(fp,3));fanG.computeVertexNormals();batch('Deep_Edge_Sea_Fans',fanG,mat('#ffffff',{side:T.DoubleSide}),fans);
 // Native fish silhouettes form schools in each region, with restrained motion.
 const bodyG=new T.SphereGeometry(1,9,6).toNonIndexed(),fishPositions=[];const bodyP=bodyG.attributes.position;for(let i=0;i<bodyP.count;i++)fishPositions.push(bodyP.getX(i)*.48-.12,bodyP.getY(i)*.15,bodyP.getZ(i)*.11);bodyG.dispose();fishPositions.push(.27,0,0,.60,.23,0,.60,-.23,0,.27,0,0,.60,0,.08,.60,.23,0);
 const fishG=new T.BufferGeometry();fishG.setAttribute('position',new T.Float32BufferAttribute(fishPositions,3));fishG.computeVertexNormals();
 const fishM=mat('#aac4b8',{side:T.DoubleSide});for(const [j,c]of [[0,[-10,4,-174]],[1,[22,-1,-278]],[2,[18,-9,-375]]]){const items=Array.from({length:38},(_,i)=>({p:[c[0]+(i%8)*1.4,c[1]+Math.sin(i)*1.3,c[2]+Math.floor(i/8)*1.8],s:[.5,.5,.5]}));const f=batch('Regional_Silver_School_'+j,fishG,fishM,items);animated.push({mesh:f,center:c,items});}
 // A separate broad overhead sheet covers only new zones. The existing ocean is untouched.
 const surfaceM=new T.MeshBasicMaterial({color:'#2e777e',transparent:true,opacity:.12,side:T.DoubleSide,depthWrite:false});materials.add(surfaceM);const sg=new T.PlaneGeometry(600,520);sg.rotateX(Math.PI/2);const overhead=mesh('Extended_Overhead_Water',sg,surfaceM);overhead.position.set(0,12,-390);
 group.userData={synthetic:true,measuredSite:false,scanChanges:0,bounds:EXPLORATION_BOUNDS,regions:['原生扫描礁区','开阔海草浅湾','大陆架与深水边缘'],newDownloads:0,grassInstances:grassCount,landmarkSource:'https://polyhaven.com/a/boulder_01',landmarkLicense:'CC0',scanDerivedSource:'existing rear-connected-data.js; read-only; fictional composition'};
 const meshes=[];group.traverse(o=>{if(o.isMesh)meshes.push(o)});const budget={meshes:meshes.length,drawCalls:meshes.length,triangles:meshes.reduce((s,o)=>s+(o.geometry.index?.count||o.geometry.attributes.position.count)/3*(o.isInstancedMesh?o.count:1),0),instances:instances.reduce((s,o)=>s+o.count,0),geometryBytes:[...geometries].reduce((s,g)=>s+Object.values(g.attributes).reduce((a,b)=>a+b.array.byteLength,0)+(g.index?.array.byteLength||0),0),newTextureBytes:0,newModelBytes:0};group.userData.budget=budget;
 function update(time,camera){if(disposed||paused||reduced||hidden)return;lastTime=Number.isFinite(time)?time:lastTime;grassTime.value=lastTime;for(const school of animated){school.items.forEach((item,i)=>{dummy.position.fromArray(item.p);dummy.position.x+=Math.sin(lastTime*.09)*7;dummy.position.z+=Math.cos(lastTime*.09+i*.02)*4;dummy.position.y+=Math.sin(lastTime*.7+i)*.13;dummy.rotation.set(0,Math.sin(lastTime*.09)*.5,0);dummy.scale.setScalar(.5);dummy.updateMatrix();school.mesh.setMatrixAt(i,dummy.matrix);});school.mesh.instanceMatrix.needsUpdate=true;}}
 function dispose(){if(disposed)return;disposed=true;group.removeFromParent();instances.forEach(o=>o.dispose());geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());}
 return {group,budget,bounds:EXPLORATION_BOUNDS,floorHeight,sampleGroundHeight:floorHeight,resolvePosition,regionAt,tourStops:EXPLORATION_TOUR_STOPS,update,dispose,setPaused(v){paused=!!v},setReducedMotion(v){reduced=!!v},setHidden(v){hidden=!!v},getState:()=>({disposed,paused,reduced,hidden,lastTime,budget})};
}
