import * as THREE from 'three';
import {strokeAt} from './turtle-motion.js?v=turtle-20261009-r1';
// Code-synthesized demonstration, not a scan or an identified site species.
export const TURTLE_INFO=Object.freeze({bytes:184868,triangles:4504,scale:.56,period:180,center:[4.8,2.15,-15.2],radii:[1.05,4.5],phase:.35,direction:-1});
export function turtlePose(time){const q=.35-Math.PI*2*time/180;return {position:[4.8+1.05*Math.sin(q),2.15,-15.2+4.5*Math.cos(q)],forward:[-1.05*Math.cos(q),0,4.5*Math.sin(q)],bank:0};}
export function disposeTurtleModel(model){const geometries=new Set(),materials=new Set();model?.traverse(o=>{if(!o.isMesh)return;geometries.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:[o.material])materials.add(m);});for(const g of geometries)g.dispose();for(const m of materials)m.dispose();model?.removeFromParent();}
export function createTurtleRuntime({parent,load,configure,getTime=()=>0,isEnabled=()=>true,onState=()=>{}}){
 let status='idle',pending=null,error=null,disposed=false,model=null,mesh=null,controller=null;
 const group=new THREE.Group();group.name='Synthetic_Code_Turtle';group.matrixAutoUpdate=false;group.visible=isEnabled();group.userData={synthetic:true,recordedFauna:false,identifiedSpecies:false,metricCalibration:false,triangles:TURTLE_INFO.triangles,resourceBytes:TURTLE_INFO.bytes};
 const f=new THREE.Vector3(),r=new THREE.Vector3(),u=new THREE.Vector3(),right=new THREE.Vector3(),up=new THREE.Vector3(),back=new THREE.Vector3(),axis=new THREE.Vector3(0,1,0),uniformScale=new THREE.Vector3(.56,.56,.56);
 function getState(){return {status,error,bytes:TURTLE_INFO.bytes,installed:!!mesh,disposed};}
 function notify(){onState(getState());}
 function update(time){if(disposed||!mesh)return;const p=turtlePose(time);f.fromArray(p.forward).normalize();r.copy(f).cross(axis).normalize();u.copy(r).cross(f).normalize();right.copy(r).multiplyScalar(Math.cos(p.bank)).addScaledVector(u,Math.sin(p.bank));up.copy(u).multiplyScalar(Math.cos(p.bank)).addScaledVector(r,-Math.sin(p.bank));back.copy(f).negate();group.matrix.makeBasis(right,up,back).scale(uniformScale).setPosition(...p.position);group.matrixWorldNeedsUpdate=true;
  const w=strokeAt(time);mesh.morphTargetInfluences[mesh.morphTargetDictionary.StrokeUp]=Math.max(0,w);mesh.morphTargetInfluences[mesh.morphTargetDictionary.StrokeDown]=Math.max(0,-w);
 }
 function validate(root){const all=[];root.traverse(o=>{if(o.isMesh)all.push(o);});if(all.length!==1)throw Error('Turtle must contain exactly one mesh');const m=all[0],g=m.geometry;if((g.index?.count||g.attributes.position.count)/3!==4504||Array.isArray(m.material)||!g.attributes.color||!m.material.vertexColors||g.morphAttributes.position?.length!==2||g.morphAttributes.normal?.length!==2)throw Error('Turtle asset budget or morph/color contract failed');for(const n of ['StrokeUp','StrokeDown'])if(!(n in m.morphTargetDictionary))throw Error('Missing turtle morph '+n);return m;}
 function ensure(){if(disposed)return Promise.resolve(false);if(pending)return pending;if(status==='ready')return Promise.resolve(true);status='loading';error=null;controller=new AbortController();notify();pending=Promise.resolve().then(()=>load(controller.signal)).then(value=>{const root=value.scene||value;if(disposed){disposeTurtleModel(root);return false;}try{const part=validate(root);configure(part.material);part.castShadow=false;part.receiveShadow=true;part.frustumCulled=false;mesh=part;model=root;group.add(root);group.visible=isEnabled();parent.add(group);update(getTime());status='ready';notify();return true;}catch(e){disposeTurtleModel(root);throw e;}}).catch(e=>{if(!disposed){status='error';error=String(e.message||e);notify();}return false;}).finally(()=>{pending=null;});return pending;}
 function setEnabled(v){group.visible=!!v&&!disposed;}
 function dispose(){if(disposed)return;disposed=true;controller?.abort();group.removeFromParent();disposeTurtleModel(model);model=null;mesh=null;status='disposed';notify();}
 return {group,getState,ensure,update,setEnabled,dispose};
}
