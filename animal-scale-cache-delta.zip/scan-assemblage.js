import * as THREE from 'three';
import {channelX} from './scan-world.js?v=animal-scale-20261010-r1';
export const ASSEMBLAGE_INFO=Object.freeze({bytes:1174872,source:'Reefs4D C4 2019 cropped A derivative',trianglesPerInstance:11506,instances:4,syntheticReassembly:true,completeOrganisms:false});
export function installAssemblage(world,fragment,c4){
 if(world.group.getObjectByName('Synthetic_C4_A_Reassemblage'))return world.group.getObjectByName('Synthetic_C4_A_Reassemblage');
 let source,atlas;c4.traverse(o=>{if(o.isMesh&&!atlas)atlas=o.material;});fragment.traverse(o=>{if(o.isMesh&&!source)source=o;});if(!source||!atlas?.map)throw Error('C4 photo atlas unavailable for fragment');
 const geometry=source.geometry;geometry.computeBoundingBox();const box=geometry.boundingBox,mesh=new THREE.InstancedMesh(geometry,atlas,4),dummy=new THREE.Object3D(),ray=new THREE.Raycaster(),down=new THREE.Vector3(0,-1,0),placements=[],obstacles=[];
 mesh.name='Synthetic_C4_A_Reassemblage';mesh.receiveShadow=true;mesh.castShadow=false;
 const plan=[{z:-6.4,side:-1,offset:5.5,scale:2.8,yaw:.65},{x:13.7,z:-19.5,side:1,offset:0,scale:2.15,yaw:2.2},{x:-2.3,z:-47.8,side:-1,offset:0,scale:2.55,yaw:4.15},{x:4.7,z:-69.5,side:1,offset:0,scale:2.2,yaw:2.9}];
 world.group.updateMatrixWorld(true);
 for(let i=0;i<plan.length;i++){
  const p=plan[i],x=p.x??(channelX(p.z)+p.side*p.offset);dummy.position.set(x,0,p.z);dummy.rotation.set(0,p.yaw,0);dummy.scale.setScalar(p.scale);dummy.updateMatrix();
  // Support sampled low native substrate vertices, keeping the photographic crop perimeter
  // readable. No cap/skirt/repair, major-form burial, UV edits or recolouring.
  const a=geometry.attributes.position;let contact=null,raise=-Infinity,baseSamples=0,supportedBaseSamples=0;
  for(let j=0;j<a.count;j++){
   if(a.getY(j)>box.min.y+.065)continue;baseSamples++;
   const v=new THREE.Vector3().fromBufferAttribute(a,j).applyMatrix4(dummy.matrix);ray.set(new THREE.Vector3(v.x,30,v.z),down);const hit=ray.intersectObjects(world.bankMeshes,false)[0];if(!hit)continue;supportedBaseSamples++;
   const required=hit.point.y-v.y;if(required>raise){raise=required;contact={hit,vertex:j};}
  }
  if(!contact||supportedBaseSamples/baseSamples<.7)throw Error('A fragment missing broad substrate support '+i);
  dummy.position.y=raise-.035;dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);const bounds=box.clone().applyMatrix4(dummy.matrix),hit=contact.hit;
  const record={...p,position:dummy.position.toArray(),supportPoint:hit.point.toArray(),supportObject:hit.object.name,substrateEmbed:.035,supportVertex:contact.vertex,baseSamples,supportedBaseSamples,bounds:{min:bounds.min.toArray(),max:bounds.max.toArray()}};placements.push(record);obstacles.push({name:mesh.name+'_'+i,box:bounds});
 }
 mesh.computeBoundingSphere();mesh.userData={...ASSEMBLAGE_INFO,placements,sourceAtlasShared:true,sourceGeometryUnedited:true,sourceUvUnedited:true};world.group.add(mesh);world.obstacles.push(...obstacles);world.batches.push(mesh);world.budget.triangles+=11506*4;world.budget.drawCalls++;world.budget.instancedObjects+=4;world.budget.derivedFragmentTriangles=11506*4;world.budget.additionalGeometryBytes=1174872;world.group.userData.croppedSourceAssemblage=mesh.userData;
 for(const m of Array.isArray(source.material)?source.material:[source.material])if(m!==atlas)m.dispose();return mesh;
}
export function createAssemblageLoader(load,install){
 let status='idle',pending=null,error=null,disposed=false,object=null;const controller=new AbortController();
 return {getState:()=>({status,error,bytes:ASSEMBLAGE_INFO.bytes,instances:status==='ready'?4:0}),
 dispose(){disposed=true;controller.abort();status='disposed';if(object){object.removeFromParent();object.geometry.dispose();object=null;}},
 ensure(c4){if(disposed||!c4)return Promise.resolve(false);if(status==='ready')return Promise.resolve(true);if(pending)return pending;status='loading';error=null;pending=Promise.resolve().then(()=>load(controller.signal)).then(value=>{if(disposed){value.scene?.traverse(o=>{if(o.isMesh){o.geometry.dispose();o.material?.dispose();}});return false;}try{object=install(value,c4);}catch(error){value.scene?.traverse(o=>{if(o.isMesh){o.geometry.dispose();for(const m of Array.isArray(o.material)?o.material:[o.material])m?.dispose();}});throw error;}status='ready';return true;}).catch(e=>{if(!disposed){status='error';error=String(e.message||e);}return false;}).finally(()=>{pending=null;});return pending;}
 };
}
