import {createScanMeadow} from './scan-meadow.js';
import * as THREE from 'three';
import {createAprons} from './scan-aprons.js?v=basin-20261009-r1';
import {OWNED_MOUNDS} from './scan-habitat-mounds.js?v=closed-shells-20261009-r1';
import {softenSharedNormals} from './scan-surface.js?v=surface-20261008-r1';
// Composed fictional dive landscape. Coordinates are demo units, not surveyed metres.
export const WORLD_REGIONS=Object.freeze([
 {id:'shelves',label:'日光珊瑚台地',z:[12,-22]},
 {id:'valley',label:'开放礁盆',z:[-22,-55]},
 {id:'passage',label:'远端暗礁',z:[-55,-88]}
]);
export const channelX=z=>4+4*Math.sin((-z+8)*.055);
export function createScanWorld(scene,corals,configure,surface,ground){
 const group=new THREE.Group();group.name='Synthetic_Connected_Reef_World';group.userData={synthetic:true,metricCalibration:false,regions:WORLD_REGIONS,sourceScanCopies:0};scene.add(group);
 const obstacles=[],batches=[];let seed=8023;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};
 const dummy=new THREE.Object3D(),color=new THREE.Color();
 function batch(name,geometry,material,items,{solid=false}={}){
  configure(material);const mesh=new THREE.InstancedMesh(geometry,material,items.length);mesh.name=name;mesh.receiveShadow=true;mesh.castShadow=false;
  items.forEach((o,i)=>{dummy.position.set(...o.p);dummy.rotation.set(...(o.r||[0,rnd()*Math.PI*2,0]));if(o.q)dummy.quaternion.fromArray(o.q);dummy.scale.set(...o.s);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);if(o.c)mesh.setColorAt(i,color.set(o.c));if(solid){geometry.computeBoundingBox();obstacles.push({name,box:geometry.boundingBox.clone().applyMatrix4(dummy.matrix)});}});
  mesh.computeBoundingSphere();group.add(mesh);batches.push(mesh);return mesh;
 }
 const stone=new THREE.IcosahedronGeometry(1,1),a=stone.attributes.position;for(let i=0;i<a.count;i++){const x=a.getX(i),y=a.getY(i),z=a.getZ(i),n=1+.11*Math.sin(x*11+z*7)*Math.cos(y*9);a.setXYZ(i,x*n,y*(1+.1*Math.sin(z*8)),z*n);}stone.computeVertexNormals();softenSharedNormals(stone);
 const shelves=[],walls=[],distant=[],plates=[],sponges=[],fans=[];
 // Alternating buttresses leave a deliberate sinuous negative-space corridor.
 for(let k=0;k<22;k++){
  const z=10-k*4.6,c=channelX(z),valley=z< -22,passage=z< -55;
  for(const side of [-1,1]){
   const x=c+side*(valley?10:12)+(rnd()-.5)*1.2;
   const h=passage?5.7+rnd()*2:valley?3.8+rnd()*2:1.1+rnd()*1.5;
   (valley?walls:shelves).push({p:[x,-.8+h*.52,z],s:[valley?5:6,h*.68,3.5+rnd()],c:passage?'#435c62':valley?'#637c73':'#8f9781'});
   // Colonies occupy outward shelves and wall ledges, rather than the swim lane.
   for(let j=0;j<(passage?2:4);j++){
    const px=x+side*(rnd()*3-1),pz=z+(rnd()-.5)*4,py=-.8+h*.8+rnd()*.25;
    plates.push({p:[px,py,pz],s:[.65+rnd()*.9,.10+rnd()*.12,.6+rnd()*.8],r:[(rnd()-.5)*.22,rnd()*6.28,(rnd()-.5)*.25],c:passage?'#77728f':j%2?'#ad8c75':'#8e9d87'});
    if(j<2&&!passage)sponges.push({p:[px+side*.8,py+.3,pz+.4],s:[.12+rnd()*.13,.55+rnd()*.5,.12+rnd()*.13],c:j?'#ad916a':'#927c93'});
   }
   if(valley&&k%2===0)fans.push({p:[x-side*2,-.2+h*.62,z],s:[1.2,1.8,1],r:[0,side*.55,side*.12],c:passage?'#767399':'#b29484'});
  }
 }
 // Consume original far-ridge generation so the retained foreground is identical.
 for(let i=0;i<18;i++){const z=8-i*6;for(const side of [-1,1])distant.push({p:[channelX(z)+side*(24+rnd()*7),1.2,z-3],s:[8+rnd()*5,3+rnd()*5,7+rnd()*4],c:'#496d70'});}
 // Macro layout: finite two-dimensional reef masses, never channel-following rows.
 // Preserve the four original left foreground supports and their original seeded rotations.
 for(const items of [shelves,walls,distant])for(const o of items)o.r=[0,rnd()*Math.PI*2,0];
 const near=shelves.filter((o,i)=>i%2===0&&i>=6);
 shelves.length=0;walls.length=0;distant.length=0;shelves.push(...near);
 ground.updateMatrixWorld(true);
 const sandRay=new THREE.Raycaster(),sandDown=new THREE.Vector3(0,-1,0);
 function rock(x,z,sx,sy,sz,yaw,c='#788575'){
  sandRay.set(new THREE.Vector3(x,30,z),sandDown);const hit=sandRay.intersectObject(ground,false)[0];if(!hit)throw Error('Reef mass outside sand');
  return {p:[x,hit.point.y+sy*.30,z],s:[sx,sy,sz],r:[0,yaw,0],c};
 }
 // A: low foreground shoulder, retaining the already-grounded left apron.
 shelves.push(rock(-9,-5,4.8,1.2,3.8,.6),rock(-10,-16,4.1,1.4,3.5,-.5));
 // B: a compact right-middle island. The living shoulder faces the opening.
 shelves.push(rock(14,-19,4.2,1.1,3.4,.8),rock(19,-25,6,2.8,4.2,.65),rock(16,-29,4.5,1.8,3.2,-.5),rock(22,-23,3.6,1.6,4.2,-.9),rock(11.8,-22,3, .65,3.5,.4));
 // C: a transverse left reef mass behind the untouched C4 scan.
 walls.push(rock(-4,-37,5,1.3,3.2,-.4),rock(-8,-43,6,3.3,5,.8),rock(-2,-48,5,1.5,3.2,.5),rock(-12,-38,4,2,5,-.6),rock(1,-45,3,.7,3,.2));
 // D: one-sided remote shelter, no bridge or second enclosing wall.
 walls.push(rock(5.2,-64,4,1,3,.1),rock(12.2,-73,6,3.5,5,-.6),rock(4.2,-78,5,2,3,.8),rock(3.2,-71,4,.8,4,-.3));
 for(const v of [[-24,-65,11,4,8,.4],[-32,-75,8,6,6,-.6],[-19,-78,6,3,6,1.1],[28,-91,12,6,10,-.3],[38,-100,8,4,8,.5],[24,-105,7,3,6,.7],[-10,-108,11,3,7,.6],[-21,-116,7,5,6,-.8]])distant.push(rock(...v,'#496d70'));
 batch('Sunlit_Broken_Coral_Shelves',stone,surface.limestone(new THREE.MeshStandardMaterial({roughness:1})),shelves,{solid:true});
 batch('Valley_And_Passage_Buttresses',stone,surface.limestone(new THREE.MeshStandardMaterial({roughness:1})),walls,{solid:true});
 batch('Overlapping_Distant_Ridges',stone,surface.limestone(new THREE.MeshStandardMaterial({roughness:1})),distant,{solid:true});
 const aprons=createAprons(channelX,ground);
 const apronMesh=batch('Connected_Broken_Bedrock_Aprons',aprons.geometry,surface.limestone(new THREE.MeshStandardMaterial({roughness:1})),[{p:[0,0,0],s:[1,1,1],r:[0,0,0],c:'#788575'}]);
 obstacles.push(...aprons.boxes);
 const apronRubble=batch('Partly_Buried_Apron_Stones',stone,surface.limestone(new THREE.MeshStandardMaterial({roughness:1})),aprons.rubble,{solid:true});
 group.updateMatrixWorld(true);
 const ray=new THREE.Raycaster(),down=new THREE.Vector3(0,-1,0),up=new THREE.Vector3(0,1,0);
 const bankMeshes=[...batches.slice(0,2),apronMesh,apronRubble],contacts=[];
 function seat(x,z,{tilt=1,embed=.06,yaw=0}={}){
  const desired=[x,z],side=Math.sign(x-channelX(z));let hit,normal;
  for(const dx of [0,.5,1,1.5,2,2.5]){
   for(const dz of [0,-.5,.5,-1,1]){
    ray.set(new THREE.Vector3(desired[0]+side*dx,30,desired[1]+dz),down);const candidate=ray.intersectObjects(bankMeshes,false)[0];if(!candidate)continue;
    const matrix=new THREE.Matrix4();candidate.object.getMatrixAt(candidate.instanceId,matrix);matrix.premultiply(candidate.object.matrixWorld);
    const n=candidate.face.normal.clone().applyNormalMatrix(new THREE.Matrix3().getNormalMatrix(matrix));
    if(n.y>=.48){hit=candidate;normal=n;x=hit.point.x;z=hit.point.z;break;}
   }if(hit)break;
  }
  if(!hit)throw new Error('Habitat needs a shallow actual bank at '+x+','+z);
  const axis=up.clone().lerp(normal,tilt).normalize();
  const q=new THREE.Quaternion().setFromUnitVectors(up,axis).multiply(new THREE.Quaternion().setFromAxisAngle(up,yaw));
  contacts.push({x,z,y:hit.point.y,normal:normal.toArray(),bank:hit.object.name,instance:hit.instanceId});
  return {p:[x,hit.point.y-embed,z],q:q.toArray()};
 }
 // Discard the old even rows of detached discs and cylinder stubs. Preserve the
 // seeded terrain above, then compose a few broad, deliberately unequal gardens.
 plates.length=0;sponges.length=0;fans.length=0;
 const branches=[[],[]],mounds=[[],[]];
 const gardens=[
  {id:'foreground',x:channelX(-6)-6.6,z:-6,side:-1,branches:[[-.3,.7,1.2],[.6,-1.7,.95]],mounds:3,plates:10,fans:4},
  {id:'middle_island',x:14,z:-20,side:1,branches:[[.3,.8,1.2]],mounds:3,plates:10,fans:5},
  {id:'c4_backreef',x:-3.8,z:-40,side:-1,branches:[[.2,.5,1.15]],mounds:2,plates:8,fans:4},
  {id:'far_shelter',x:4.2,z:-69,side:1,branches:[],mounds:2,plates:8,fans:6}
 ];
 let branchIndex=0;
 for(let g=0;g<gardens.length;g++){
  const garden=gardens[g],{x,z,side}=garden;
  for(const [dx,dz,size]of garden.branches){
   branches[branchIndex%2].push({...seat(x+side*dx,z+dz,{tilt:.65,embed:.22,yaw:g*1.13+branchIndex*.93}),s:[size,size*(.87+(branchIndex%3)*.12),size*(.82+(branchIndex%2)*.24)]});branchIndex++;
  }
  for(let i=0;i<garden.mounds;i++){
   const px=x+side*(1.5+i*.7),pz=z+1.4-i*1.7,scale=1.6+(i%2)*.7;
   mounds[(g+i)%2].push({...seat(px,pz,{embed:.2,yaw:g+i*.7}),s:[scale,scale*1.4,scale]});
  }
  for(let i=0;i<garden.plates;i++){
   // Short overlapping lobes form patches hugging the ledge, not isolated tables.
   const t=i*.74,px=x+side*(2+Math.sin(t)*.9),pz=z-1.6+Math.cos(t)*1.25-i*.16;
   const size=.48+(i%3)*.16;
   plates.push({...seat(px,pz,{embed:.06,yaw:g*.8+i*1.7}),s:[size,.12+(i%2)*.055,size*.78],c:g>4?'#756e86':g%2?'#a48a73':'#8f9e84'});
  }
  for(let i=0;i<garden.fans;i++){
   const px=x+side*(1.25+(i%2)*1.25),pz=g===0&&i>=2?z-4-(i-2)*1.5:z-2.5+i*1.5;
   fans.push({...seat(px,pz,{tilt:.4,embed:.04,yaw:.45+g*.73+i*.65}),s:[1.1+(i%3)*.4,1.1+(i%2)*.9,.9],c:g>4?'#74758a':g%2?'#b09a84':'#929d85'});
  }
 }
 const plate=new THREE.SphereGeometry(1,12,6),pa=plate.attributes.position;
 for(let i=0;i<pa.count;i++){const x=pa.getX(i),z=pa.getZ(i),w=1+.14*Math.sin(Math.atan2(z,x)*5)+.08*Math.sin(x*7+z*9);pa.setXYZ(i,x*w,pa.getY(i)+.12*Math.sin(x*3+z*4),z*w);}plate.computeVertexNormals();
 batch('Layered_Plate_Colonies',plate,surface.coral(new THREE.MeshStandardMaterial({roughness:.98})),plates);
 // A sparse branching fan silhouette, represented by connected tapered limbs.
 const fanPositions=[];function limb(x1,y1,x2,y2,w){const dx=x2-x1,dy=y2-y1,l=Math.hypot(dx,dy),nx=-dy/l*w,ny=dx/l*w;fanPositions.push(x1+nx,y1+ny,0,x1-nx,y1-ny,0,x2, y2,0);}
 limb(0,0,0,1,.05);for(let j=0;j<9;j++){const y=.22+j*.075,w=.6*Math.sin((j+1)/10*Math.PI);for(const s of [-1,1]){limb(0,y,s*w,y+.45,.025);for(let k=1;k<4;k++)limb(s*w*k/4,y+.45*k/4,s*(w*k/4+.13),y+.45*k/4+.24,.012);}}
 const fanGeo=new THREE.BufferGeometry();fanGeo.setAttribute('position',new THREE.Float32BufferAttribute(fanPositions,3));fanGeo.computeVertexNormals();batch('Branching_Sea_Fan_Forms',fanGeo,new THREE.MeshStandardMaterial({roughness:1,side:THREE.DoubleSide}),fans);
 for(let j=0;j<2;j++){
  const source=corals.children[j],geo=source.geometry.clone();geo.computeBoundingBox();const b=geo.boundingBox,center=b.getCenter(new THREE.Vector3());geo.translate(-center.x,-b.min.y,-center.z);
  batch('Existing_Branching_Colony_Variant_'+j,geo,surface.coral(source.material.clone()),branches[j]);
  const data=OWNED_MOUNDS[j],mound=new THREE.BufferGeometry();
  for(const [key,name,size]of[['POSITION','position',3],['NORMAL','normal',3],['TEXCOORD_0','uv',2],['COLOR_0','color',3]])if(data[key])mound.setAttribute(name,new THREE.Float32BufferAttribute(data[key],size));
  mound.setIndex(data.index);
  // Frozen contact-tested poses of the restored original closed shells.
  const verifiedMoundPoses=[[{"p":[-0.6654590368270874,1.165806770324707,-3.950000047683716],"q":[-0.19808973606290817,5.733693107742728e-10,-0.2851817339368751,0.9377802701913515]},{"p":[-2.715459108352661,1.0522570610046387,-8],"q":[0.04134355292734888,0.643651934803695,0.006806996692616526,0.7641705059626014]},{"p":[14.899999618530273,0.6667563319206238,-19.649999618530273],"q":[0,0.6614982113501424,0,0.749946742362791]},{"p":[-5.300000190734863,0.8069332513809204,-38.599998474121094],"q":[0,0.5397527580480509,0,0.8418235920782466]},{"p":[6.400000095367432,0.1551332026720047,-69.30000305175781],"q":[0,-0.2752005768156407,0,0.9613868329243638]}],[{"p":[-1.3654590845108032,1.1689428091049194,-6.949999809265137],"q":[0.06339475529963301,0.3420948930784009,-0.02566582836523255,0.9371731187064466]},{"p":[15.5,0.5763757228851318,-18.600000381469727],"q":[0,0.47247877002836336,0,0.8813420515738966]},{"p":[16.899999618530273,2.2732765674591064,-22],"q":[0.056060067459407545,0.9135586179846336,0.1900529156911923,0.3551729302741832]},{"p":[-6,2.8093905448913574,-40.95000076293945],"q":[0.15220739336792832,0.9596700574500787,0.09730185457571257,0.21540343375907933]},{"p":[5.699999809265137,0.2150062918663025,-67.5999984741211],"q":[0,0.07064074189969662,0,0.9975018223461352]}]];
  mounds[j].forEach((o,i)=>Object.assign(o,verifiedMoundPoses[j][i]));
  batch('Existing_Low_Mound_Garden_'+j,mound,surface.coral(new THREE.MeshStandardMaterial({vertexColors:true,roughness:.98})),mounds[j]);
 }
 group.userData.habitat={synthetic:true,gardens:gardens.map(({id,x,z,side,branches,mounds,plates,fans})=>({id,x,z,side,branches:branches.length,mounds,plates,fans})),contacts,removedCylinderStubs:true,ownedMoundSubsetBytes:855443,ownedMoundBuffers:189748};
 // Original roof slabs removed: remote space remains laterally open.
 const meadow=createScanMeadow(configure);group.add(meadow.group);batches.push(...meadow.batches);
 const triangles=batches.reduce((n,m)=>n+(m.geometry.index?.count||m.geometry.attributes.position.count)/3*m.count,0);
 group.userData.budget={triangles,drawCalls:batches.length,newTextureBytes:0,additionalOwnedGeometryBytes:189748,instancedObjects:batches.reduce((n,m)=>n+m.count,0),extractedCoralBytes:1229292,surface:surface.budget};
 let schools=[];
 function addFish(template){
  for(const part of ['body','tail']){
   const source=template.getObjectByName('fish_01_'+part);const mat=source.material.clone();
   const mesh=batch('World_School_'+part,source.geometry,mat,Array.from({length:12},()=>({p:[0,4,-35],s:[.15,.15,.15]})));
   schools.push({mesh,part});group.userData.budget.triangles+=(source.geometry.index?.count||source.geometry.attributes.position.count)/3*12;group.userData.budget.drawCalls++;group.userData.budget.instancedObjects+=12;
  }
  // Six reused body/tail fish, two small lower-water schools.
  for(const part of ['body','tail']){
   const source=template.getObjectByName('fish_01_'+part),mesh=batch('Lower_Water_School_'+part,source.geometry,source.material.clone(),Array.from({length:6},()=>({p:[12,1.8,-7],s:[.28,.28,.28]})));
   schools.push({mesh,part,lower:true});group.userData.budget.triangles+=(source.geometry.index?.count||source.geometry.attributes.position.count)/3*6;group.userData.budget.drawCalls++;group.userData.budget.instancedObjects+=6;
  }
  update(0);
 }
 function update(time){for(const {mesh,part,lower}of schools){if(lower){for(let i=0;i<6;i++){
  const near=i<3,a=time*(near?.16:.13)+(i%3)*.65,rx=near?3.7:3,rz=near?2.8:3,cx=near?12:1,cz=near?-7:-27;
  dummy.position.set(cx+rx*Math.cos(a), (near?1.65:2.05)+.12*Math.sin(a*1.4+i),cz+rz*Math.sin(a));dummy.rotation.set(0,-Math.atan2(rz*Math.cos(a),-rx*Math.sin(a)),0);dummy.scale.setScalar(.25+(i%3)*.018);if(part==='tail')dummy.rotation.y+=Math.sin(time*4+i)*.14;dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);
 }mesh.instanceMatrix.needsUpdate=true;mesh.computeBoundingSphere();continue;}for(let i=0;i<12;i++){
  const base=i<6?-34:-65,a=time*.12+i*.27,center=channelX(base);
  dummy.position.set(center+3.5*Math.cos(a),4.4+Math.sin(i*2)*.35,base+6*Math.sin(a));dummy.rotation.set(0,-Math.atan2(6*Math.cos(a),-3.5*Math.sin(a)),0);dummy.scale.setScalar(.15+(i%3)*.014);if(part==='tail')dummy.rotation.y+=Math.sin(time*4+i)*.14;dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);
 }mesh.instanceMatrix.needsUpdate=true;mesh.computeBoundingSphere();}}
 let ecologyDisposed=false;
 function disposeAddedEcology(){if(ecologyDisposed)return;ecologyDisposed=true;meadow.dispose();for(let i=schools.length-1;i>=0;i--)if(schools[i].lower){const {mesh}=schools[i];mesh.dispose();mesh.material.dispose();mesh.removeFromParent();schools.splice(i,1);} }
 return {group,obstacles,batches,bankMeshes,aprons,disposeAddedEcology,regions:WORLD_REGIONS,budget:group.userData.budget,addFish,update};
}
