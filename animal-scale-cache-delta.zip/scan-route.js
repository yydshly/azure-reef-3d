// A bounded, synthetic swim route. Units are deliberately not presented as metres.
import {channelX} from './scan-world.js?v=animal-scale-20261010-r1';
export const ROUTE_STOPS=Object.freeze([
 {progress:0,label:'日光珊瑚台地',position:[channelX(10),3.2,10],target:[channelX(-10),1.9,-10]},
 {progress:.5,label:'开放礁盆',position:[channelX(-25),3.4,-25],target:[channelX(-44),3,-44]},
 {progress:1,label:'远端暗礁',position:[channelX(-60),3.1,-60],target:[channelX(-79),3.7,-79]}
]);
export const clampProgress=value=>Math.min(1,Math.max(0,Number.isFinite(value)?value:0));
export function routePose(value,yaw=0,pitch=0){
 const p=clampProgress(value),z=10-70*p;
 const position=[channelX(z),3.2+.25*Math.sin(p*Math.PI*1.4),z],center=[channelX(z-19),p>.7?3.7:2.4,z-19];
 const delta=center.map((v,i)=>v-position[i]),r=Math.hypot(...delta),angle=Math.atan2(delta[0],delta[2])+Math.max(-Math.PI/3,Math.min(Math.PI/3,yaw));
 const elevation=Math.max(-.7,Math.min(.6,Math.asin(delta[1]/r)+Math.max(-.4,Math.min(.4,pitch))));
 return {position,target:[position[0]+Math.sin(angle)*Math.cos(elevation)*r,position[1]+Math.sin(elevation)*r,position[2]+Math.cos(angle)*Math.cos(elevation)*r]};
}
export function createRouteState(){
 let progress=0,goal=0,active=false,yaw=0,pitch=0;
 return {
  getState:()=>({active,progress,goal,yaw,pitch}),
  enter(){active=true;goal=progress;},leave(){active=false;goal=progress;},stop(){goal=progress;},
  request(value,instant=false){goal=clampProgress(value);if(instant)progress=goal;},
  look(x,y){yaw=Math.max(-Math.PI/3,Math.min(Math.PI/3,yaw+x));pitch=Math.max(-.4,Math.min(.4,pitch+y));},
  resetLook(){yaw=0;pitch=0;},
  tick(dt,reduced=false){if(!active)return false;const before=progress;if(reduced)progress=goal;else{const step=Math.min(.05,Math.max(0,dt))*.032;progress+=Math.sign(goal-progress)*Math.min(step,Math.abs(goal-progress));}return before!==progress;},
  pose:()=>routePose(progress,yaw,pitch)
 };
}
