# Bounded scan color/contact candidate

Local candidate built on baseline 498cc09 plus the frozen candidate-1 ZIP. This patch applies **on top of candidate 1**, not directly on baseline. No public write, upload, dispatch, main update, or deployment was performed.

## Visible result and boundaries

The paired focus-before-offline.png / focus-after-offline.png are Cycles renders at 1120×700, identical camera [-0.8,3.5,-11] → [-6.5,1.5,-17], 47° vertical field of view. Cyan is visibly reduced without flattening texture detail. The cut perimeter is seated farther into existing terrain; this is a small contact change, not a complete realism solution.

These offline renders use the original full scene geometries and neutral approximation lighting, **not the browser water shader, animation, tone mapping, or UI**. They do not establish WebGL visual acceptance. Browser reference inspected: candidate-1 actual hosted Chromium run 37719408252, especially scan-in-world-focus.png and departure/look-back. No local browser workaround was attempted.

## Exact changes

- Scan material only: linear sampled albedo mixes 30% toward Rec.709 luminance (.2126/.7152/.0722). Brightness is preserved in linear RGB; chroma is reduced. This is a bounded presentation adjustment, not calibrated white balance or true-color recovery.
- 原纹理 toggles the uniform to zero at runtime. It preserves the current camera and original texture, while scene water/light still apply. The original-scene button retains its previous meaning (hide scan).
- Only the scan root moves down 0.12973902106285117 scene units. Largest welded outer cut loop: 1,114 vertices; before 228 were above the four unchanged seabed meshes, maximum gap .12473902106285117. After, all sampled vertices are below by at least .005. This vertex audit is not a continuous mathematical contact proof.
- No added geometry, caps, skirts, pedestals or synthetic hole filling. Small interior holes and the source's abrupt relief remain. No accepted scene anchors, cameras, routes, fish, skeleton, or either previous grounding repair changed.
- GLB stays 149,822 triangles. Original JPEG remains embedded byte-for-byte. Source and frozen candidate hashes are in source-hashes.json. The GLB is intentionally absent from the small delta.

## Checks

PASS after final changes: npm test; npm run test:scan (including seating and raw-uniform tests); reduced-motion guide integration; motion, life, inhabited, route-rebalance, fish-surface, tour-clock, specimen, branch-grounding, sibling-grounding suites. These are CPU geometry/source/simulated-DOM checks, not GPU or browser-native behavior.

One initial aggregate run failed because the no-WebGL fixture did not include the new scanRaw button. The fixture was updated and the full aggregate rerun passed. No product bug was hidden by weakening an assertion.

## Required browser QA before acceptance

Apply onto candidate 1 in the authorized QA branch. Verify served hashes from CANDIDATE2-MANIFEST.json. Capture matched default softened / raw modes at the same focused and ordinary cameras, review cyan/contact in actual WebGL, confirm no shader compile errors. Exercise the 原纹理 toggle repeatedly, including hidden scan, focus/return, low quality, guide and load failure; check small mobile panel layout. Retain candidate-1 control results only for unchanged behavior; added toggle and visual refinement need fresh verification. User-device GPU/performance and whole-scene realism remain unaccepted.
