import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import * as THREE from 'three';
import {GLTFLoader} from './dist/vendor/GLTFLoader.js';
import {placeReefScan, REEF_SCAN, setScanRawTexture} from './dist/reef-scan.js';
import {composeReef} from './dist/inhabited-reef.js';
import {seatBranchColony,seatSiblingColony} from './dist/branch-grounding.js';
import {placeSpecimen,SPECIMEN} from './dist/specimen.js';
import {GUIDE_STOPS} from './dist/guide-data.js';
import {samplePassage} from './dist/passage.js';
import {sampleSwimRoute} from './dist/fish-motion.js';
import {addCompanionFish} from './dist/fish-population.js';
import {refineFish03} from './dist/fish-surface.js';
import {applyWaterLight} from './dist/water-light.js';

const require=createRequire(import.meta.url),{loadImage}=require('@napi-rs/canvas');
globalThis.self=globalThis;
globalThis.createImageBitmap=async blob=>loadImage(Buffer.from(await blob.arrayBuffer()));
async function load(path){
 const bytes=fs.readFileSync(path);
 return (await new Promise((resolve,reject)=>new GLTFLoader().parse(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),'',resolve,reject))).scene;
}
const world=new THREE.Scene(),baseline=await load('source-model.glb');
composeReef(baseline,await load('dist/assets/inhabited/bf93ec504f8f2fc3/pilot.glb'));
seatBranchColony(baseline);seatSiblingColony(baseline);
placeSpecimen(baseline,await load('dist/'+SPECIMEN.url));addCompanionFish(baseline);refineFish03(baseline,{configureMaterial:()=>{}});world.add(baseline);world.updateMatrixWorld(true);
const original=[];baseline.traverse(object=>original.push({object,parent:object.parent,matrix:object.matrixWorld.toArray(),geometry:object.geometry,material:object.material}));
let prepared=0,triangles=0,textured=0;const compiled=[];
const scan=placeReefScan(world,await load('dist/'+REEF_SCAN.url),material=>{
 prepared++;if(material.map)textured++;
 applyWaterLight(material,new THREE.Texture(),compiled);
 const shader={uniforms:{},vertexShader:THREE.ShaderLib.standard.vertexShader,fragmentShader:THREE.ShaderLib.standard.fragmentShader};
 material.onBeforeCompile(shader);assert.ok(shader.uniforms.reefTime&&shader.uniforms.reefCaustics);
 assert.ok(shader.fragmentShader.includes('outgoingLight*transmission'));
});
scan.traverse(object=>{if(!object.isMesh)return;triangles+=(object.geometry.index?.count||object.geometry.attributes.position.count)/3;assert.ok(object.geometry.attributes.normal);assert.ok(object.geometry.attributes.uv);assert.ok(object.geometry.attributes.position.array.every(Number.isFinite));});
scan.traverse(object=>{if(!object.isMesh)return;const m=object.material,shader={uniforms:{},vertexShader:THREE.ShaderLib.standard.vertexShader,fragmentShader:THREE.ShaderLib.standard.fragmentShader};const map=m.map,geometry=object.geometry;m.onBeforeCompile(shader);assert.equal(shader.uniforms.scanDisplayAmount.value,.3);assert.ok(shader.fragmentShader.includes('scanLuminance'));assert.ok(shader.fragmentShader.includes('outgoingLight*transmission'));setScanRawTexture(scan,true);assert.equal(shader.uniforms.scanDisplayAmount.value,0);setScanRawTexture(scan,false);assert.equal(shader.uniforms.scanDisplayAmount.value,.3);assert.equal(m.map,map);assert.equal(object.geometry,geometry);});
assert.ok(triangles>50000&&triangles<250000);assert.ok(prepared>0&&textured===prepared);
assert.equal(scan.parent,world);assert.notEqual(scan.parent,baseline);
assert.equal(scan.scale.x,scan.scale.y);assert.equal(scan.scale.x,scan.scale.z);assert.equal(scan.userData.scaleIsDemonstrative,true);
world.updateMatrixWorld(true);
for(const item of original){assert.equal(item.object.parent,item.parent);assert.deepEqual(item.object.matrixWorld.toArray(),item.matrix);assert.equal(item.object.geometry,item.geometry);assert.equal(item.object.material,item.material);}
const bounds=new THREE.Box3().setFromObject(scan),cameraClearances=[];
for(let i=0;i<=500;i++)cameraClearances.push(bounds.distanceToPoint(samplePassage(i/500).p));
assert.ok(Math.min(...cameraClearances)>1,'Scan must not intersect the native passage camera');
// Conservative swept sphere against the entire scan box, dense route samples.
// 0.9 exceeds the present fish body extent in every direction; no continuous proof.
const routeChecks=[];
const fishRadii={};
baseline.traverse(fish=>{if(!/^fish_\d+$/.test(fish.name))return;const origin=new THREE.Vector3().setFromMatrixPosition(fish.matrixWorld);let radius=0;fish.traverse(mesh=>{if(!mesh.isMesh)return;const p=mesh.geometry.attributes.position;for(let i=0;i<p.count;i++)radius=Math.max(radius,new THREE.Vector3().fromBufferAttribute(p,i).applyMatrix4(mesh.matrixWorld).distanceTo(origin));});fishRadii[fish.name]=radius;assert.ok(radius+.1<.9,fish.name+' no longer fits conservative animated sphere');});
for(const [i,route] of JSON.parse(fs.readFileSync('dist/assets/swim-routes.json')).entries()){
 const curve=new THREE.CatmullRomCurve3(route.points.map(p=>new THREE.Vector3(...p)),true,'centripetal');curve.arcLengthDivisions=640;curve.updateArcLengths();
 let min=Infinity;for(let t=0;t<=180;t+=.1)min=Math.min(min,bounds.distanceToPoint(sampleSwimRoute(curve,t,i,route.behavior).position));
 assert.ok(min>.9,route.name+' approaches scan bounds: '+min);routeChecks.push({fish:route.name,minimumCenterToScanBox:min,conservativeBodyRadius:.9,measuredRestPoseRadius:fishRadii[route.name]});
}
const anchorChecks=[];
for(const stop of GUIDE_STOPS.filter(s=>s.anchors))for(const anchor of stop.anchors){
 const p=new THREE.Vector3(...anchor.point),camera=new THREE.Vector3(...stop.position),ray=new THREE.Raycaster(camera,p.clone().sub(camera).normalize(),0,p.distanceTo(camera)+.01);
 const hit=ray.intersectObject(world,true)[0];assert.equal(hit?.object.name,anchor.mesh);anchorChecks.push({label:anchor.label,firstHit:hit.object.name});
}
const specimenRay=new THREE.Raycaster(new THREE.Vector3(...SPECIMEN.focus.position),new THREE.Vector3(...SPECIMEN.focus.target).sub(new THREE.Vector3(...SPECIMEN.focus.position)).normalize(),0,2);
assert.equal(specimenRay.intersectObject(scan,true).length,0);
const report={scope:'Real GLB parsing, source-logic/shader assembly and sampled conservative geometry. Not actual WebGL rendering, biological or continuous collision validation.',triangles,preparedMaterials:prepared,texturedMaterials:textured,baselineObjectsPreserved:original.length,placement:{position:REEF_SCAN.position,yaw:REEF_SCAN.yaw,uniformScale:REEF_SCAN.scale,metricCalibration:false},worldBounds:{min:bounds.min.toArray(),max:bounds.max.toArray()},minimumPassageCameraToScanBox:Math.min(...cameraClearances),routeChecks,anchorChecks,specimenInspectionUnoccludedByScan:true};
fs.mkdirSync('evidence/reefs4d-oct8',{recursive:true});fs.writeFileSync('evidence/reefs4d-oct8/integration-check.json',JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
