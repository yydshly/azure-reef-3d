// Build-time public gallery assets only. Never downloads past CI artifacts.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {checkC4} from './qa-c4-browser.mjs';
import {checkHud,nativeHudClick,openHudControl} from './qa-hud.mjs';
import {checkSeagrassHosted} from './qa-seagrass-hosted.mjs';
import {FRAME_PLAN,renderGallery,validateManifest,computeContentVersion} from './current-scene-gallery.mjs';
async function checkRayMotion(page){
 const sample=()=>page.evaluate(()=>{const a=reefExhibit,m=a.ray.group.getObjectByProperty('isMesh',true),t=a.turtle.group.getObjectByProperty('isMesh',true);const rock=a.world.group.getObjectByName('Synthetic_Terrestrial_Boulder_Reference');let rockVisible=!!rock;for(let p=rock;p;p=p.parent)rockVisible=rockVisible&&p.visible;return {naturalRock:rock?{visible:rockVisible,copies:a.world.group.children.filter(o=>o.name==='Synthetic_Terrestrial_Boulder_Reference').length,status:a.naturalRock.getState().status}:null,turtle:{matrix:a.turtle.group.matrix.toArray(),weights:[...t.morphTargetInfluences],dictionary:{...t.morphTargetDictionary},visible:a.turtle.group.visible,copies:a.scene.children.filter(o=>o.name==='Synthetic_Code_Turtle').length},time:a.getState().ambient.time,paused:a.getState().ambient.paused,matrix:a.ray.group.matrix.toArray(),weights:[...m.morphTargetInfluences],dictionary:{...m.morphTargetDictionary},visible:a.ray.group.visible,selectedPatch:a.getState().selectedPatch,waterMode:a.getState().waterMode,copies:a.scene.children.filter(o=>o.name==='Synthetic_Code_Ray').length,camera:a.getState().camera,target:a.getState().target}});
 const weights=s=>{const p=s.time*Math.PI*2/3.5;for(const [n,v]of Object.entries({FinSin:Math.sin(p),FinCos:Math.cos(p),TailSin:Math.sin(p-.6),TailCos:Math.cos(p-.6)}))assert(Math.abs(s.weights[s.dictionary[n]]-v)<1e-7,'Ray morph formula mismatch '+n);assert.equal(s.copies,1);assert.equal(s.turtle.copies,1);for(const n of ['StrokeUp','StrokeDown'])assert(n in s.turtle.dictionary);const t=((s.time%6)+6)%6;let w=0;if(t<4.2){const [a,b,start,end]=t<1.4?[0,1,0,1.4]:t<2.8?[1,-1,1.4,2.8]:[-1,0,2.8,4.2];const q=(t-start)/(end-start);w=a+(b-a)*q*q*(3-2*q);}assert(Math.abs(s.turtle.weights[s.turtle.dictionary.StrokeUp]-Math.max(0,w))<1e-7&&Math.abs(s.turtle.weights[s.turtle.dictionary.StrokeDown]-Math.max(0,-w))<1e-7,'Turtle morph formula mismatch');};
 const checkpoints=[];const record=(name,data)=>{checkpoints.push({name,...data});console.log('RAY_CHECKPOINT '+JSON.stringify({name,...data}));};
 const start=await sample();assert(start.paused&&start.waterMode);weights(start);
 await page.emulateMedia({reducedMotion:'no-preference'});
 await nativeHudClick(page,'#pauseAmbient');
 await page.waitForFunction(t=>reefExhibit.getState().ambient.time>=t+.6,start.time,{timeout:15000,polling:250});
 const moved=await sample();weights(moved);assert(moved.time>start.time);assert.notDeepEqual(moved.matrix,start.matrix);assert.notDeepEqual(moved.weights,start.weights);assert.notDeepEqual(moved.turtle.matrix,start.turtle.matrix);assert.notDeepEqual(moved.turtle.weights,start.turtle.weights);record('natural-ambient-morph-and-path',{start,moved});
 await nativeHudClick(page,'#pauseAmbient');const paused=await sample();assert(paused.paused);weights(paused);
 await page.waitForTimeout(700);const frozen=await sample();assert.deepEqual(frozen,paused,'Paused ray changed');record('native-pause-freezes-time-path-morph',{state:frozen});
 await page.emulateMedia({reducedMotion:'reduce'});
 for(const patch of ['C1','C4']){
  const view=patch==='C1'?'#nearView':'#observeC4';await openHudControl(page,view);await nativeHudClick(page,view);const before=await sample();assert.equal(before.selectedPatch,patch);
  await openHudControl(page,'#toggleOcean');await nativeHudClick(page,'#toggleOcean');const raw=await sample();assert(!raw.waterMode&&!raw.visible&&!raw.turtle.visible);assert.equal(raw.turtle.copies,1);assert.equal(raw.selectedPatch,patch);assert.equal(raw.copies,1);
  await nativeHudClick(page,'#toggleOcean');const restored=await sample();assert(restored.waterMode&&restored.visible&&restored.turtle.visible);assert.deepEqual(restored.turtle,before.turtle,'Raw turtle restore');for(const k of ['camera','target'])assert(restored[k].every((v,i)=>Math.abs(v-before[k][i])<1e-7),'Raw pose restore '+k);for(const k of ['matrix','weights'])assert.deepEqual(restored[k],before[k],'Raw ray restore '+k);assert.equal(restored.copies,1);if(before.naturalRock){assert(before.naturalRock.visible);assert.equal(raw.naturalRock.visible,false);assert.deepEqual(restored.naturalRock,before.naturalRock);assert.equal(restored.naturalRock.copies,1);}record('raw-'+patch+'-hides-and-restores-single-ray',{raw,restored});
 }
 await nativeHudClick(page,'#closeHudMore');return {passed:true,checkpoints,limitations:['Actual natural clock/morph/path and native pause/raw input proof; not a motion-video or user-GPU performance acceptance.','Optional load failure/retry/disposal remain Node simulation coverage in this run.']};
}

// CAPTURE_CLIP_HELPERS_BEGIN
function inspectCaptureFrame(world){
 const canvas=document.querySelector(world==='scan'?'#scanCanvas':'#reef');
 const app=world==='scan'?window.reefExhibit:window.reef3d;
 if(!canvas||!app)return {visible:false};
 const rect=canvas.getBoundingClientRect();let visible=true;
 for(let node=canvas;node;node=node.parentElement){const style=getComputedStyle(node);if(node.hidden||style.display==='none'||style.visibility==='hidden'||style.visibility==='collapse'||Number(style.opacity)===0)visible=false;}
 const loading=document.querySelector(world==='scan'?'#scanLoading':'#loading'),failure=document.querySelector(world==='scan'?'#scanError':'#unsupported');
 const selectors=world==='scan'?['.stage-label','.stage-controls']:['header','footer','.legacy-version','.view-label','.exhibit-entry','#help','#focusMarker','#focusMarkerSecondary','#guideCard'];
 const hudRects=[];for(const selector of selectors)for(const node of document.querySelectorAll(selector)){let shown=true;for(let n=node;n;n=n.parentElement){const c=getComputedStyle(n);if(n.hidden||c.display==='none'||c.visibility==='hidden'||c.visibility==='collapse'||Number(c.opacity)===0)shown=false;}const r=node.getBoundingClientRect();if(shown&&r.width>0&&r.height>0)hudRects.push({selector,x:r.x,y:r.y,width:r.width,height:r.height});}
 const animal=a=>{const m=a?.group.getObjectByProperty('isMesh',true);return m?{matrix:a.group.matrix.toArray(),weights:[...m.morphTargetInfluences],dictionary:{...m.morphTargetDictionary},visible:a.group.visible}:null;};
 return {clip:{x:rect.x,y:rect.y,width:rect.width,height:rect.height},viewport:{width:innerWidth,height:innerHeight},dpr:devicePixelRatio,projection:app.camera.projectionMatrix.toArray(),cameraQuaternion:app.camera.quaternion.toArray(),hudRects,animals:world==='scan'?{ray:animal(app.ray),turtle:animal(app.turtle)}:null,scroll:{x:scrollX,y:scrollY},visible,loadingHidden:!!loading?.hidden,failureHidden:!!failure?.hidden,state:app.getState()};
}
function verifyCaptureFrame(frame,world,expectedState){
 const expectedHeight=world==='scan'?712:780;
 assert(frame.visible&&frame.loadingHidden&&frame.failureHidden&&frame.state?.ready,'Canvas hidden/loading/error during capture');
 assert.deepEqual(frame.viewport,{width:1120,height:780},'Capture viewport changed');
 assert.deepEqual(frame.scroll,{x:0,y:0},'Capture must not scroll or resize the scene');
 const r=frame.clip;assert(r&&Object.values(r).every(Number.isFinite),'Invalid canvas rectangle');
 assert(r.x>=0&&r.y>=0&&r.x+r.width<=1120&&r.y+r.height<=780,'Canvas clip outside viewport');
 assert.equal(r.x,0);assert.equal(r.y,world==='scan'?68:0);assert.equal(r.width,1120);assert.equal(r.height,expectedHeight);
 for(const key of ['camera','target'])assert(frame.state[key].length===3&&frame.state[key].every((v,i)=>Number.isFinite(v)&&Math.abs(v-expectedState[key][i])<1e-7),'Capture camera/target changed');
 const signature=state=>({waterMode:state.waterMode,softened:state.softened,route:state.route,low:state.low,tour:state.tour,simulationTime:state.simulationTime,ambient:state.ambient});
 assert.deepEqual(signature(frame.state),signature(expectedState),'Camera, route, material or motion state changed during capture');
 return r;
}
// CAPTURE_CLIP_HELPERS_END
const root=path.resolve(process.env.REEF_PREVIEW_DIR||'dist/preview/independent-scan');
const capturePath=process.env.REEF_CAPTURE_PATH||'/preview/independent-scan/';
assert(['/preview/independent-scan/','/preview/natural-rock-candidate/'].includes(capturePath),'Unsupported capture path');
assert.equal(root,path.resolve('dist'+capturePath),'Capture output and URL must refer to the same preview');
const target='http://127.0.0.1:4173'+capturePath;
const hash=b=>createHash('sha256').update(b).digest('hex');
const here=path.dirname(fileURLToPath(import.meta.url));
const scriptHash=hash(await fs.readFile(fileURLToPath(import.meta.url))),galleryHash=hash(await fs.readFile(path.join(here,'current-scene-gallery.mjs')));
const dependency=path.resolve('tests/browser/node_modules/playwright/index.mjs');
const {chromium}=await import(pathToFileURL(dependency).href);
async function sourceInventory(dir=root,prefix=''){
 const out=[];for(const e of (await fs.readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
  const rel=prefix+e.name;if(rel==='current-scene.html'||rel==='assets/current-scene')continue;
  assert(!e.isSymbolicLink(),'Symlinks are not build inputs');
  if(e.isDirectory())out.push(...await sourceInventory(path.join(dir,e.name),rel+'/'));
  else if(e.isFile()){const b=await fs.readFile(path.join(dir,e.name));out.push({path:rel,bytes:b.length,sha256:hash(b)});}
 }return out;
}
const sourceFiles=await sourceInventory();const contentVersion=computeContentVersion({sourceFiles,captureScriptSha256:scriptHash,galleryScriptSha256:galleryHash,viewport:{width:1120,height:780}});
const out=path.join(root,'assets/current-scene',contentVersion);
const manifest={schema:1,contentVersion,capturedAt:new Date().toISOString(),checkoutCommit:process.env.GITHUB_SHA,candidateSourceCommit:process.env.REEF_CANDIDATE_SOURCE_COMMIT,candidateArchiveSha256:process.env.REEF_CANDIDATE_ARCHIVE_SHA256,captureScriptSha256:scriptHash,galleryScriptSha256:galleryHash,sourceFiles,viewport:{width:1120,height:780},frames:[],limitations:['Five static runtime captures only; no native-input, transition, mobile, user-GPU or overall aesthetic acceptance.','Reduced motion and default, unsoftened materials; synthetic surroundings are not collection-site reconstruction.','Original artificial world and separate expanded scan world are distinct scenes.'],browser:{sandbox:true,unsafeGraphicsFlags:false}};
for(const [key,re]of [['checkoutCommit',/^[a-f0-9]{40}$/],['candidateSourceCommit',/^[a-f0-9]{40}$/],['candidateArchiveSha256',/^[a-f0-9]{64}$/]])assert(re.test(manifest[key]||''),'Missing build identity '+key);
let browser,context;const errors=[];const inventory=new Map(sourceFiles.map(f=>[f.path,f]));const fetched=new Map();
const timer=setTimeout(()=>{console.error('CURRENT_SCENE_CAPTURE_FAILED: bounded 450-second capture deadline; no gallery accepted');process.exit(2)},450000);
try{
 browser=await chromium.launch({channel:'chromium',headless:true,chromiumSandbox:true,timeout:30000,args:['--enable-automation'],ignoreDefaultArgs:['--enable-unsafe-swiftshader','--disable-gpu-sandbox','--ignore-gpu-blocklist']});
 const cdp=await browser.newBrowserCDPSession();const cmd=await cdp.send('Browser.getBrowserCommandLine');assert(!cmd.arguments.some(x=>['--no-sandbox','--disable-gpu-sandbox','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'].includes(x)),'Security-weakening browser flag');manifest.browser.version=browser.version();
 context=await browser.newContext({viewport:manifest.viewport,deviceScaleFactor:1,reducedMotion:'reduce'});
 // Local candidate only. Source/attribution links are visible but never followed.
 await context.route('**/*',r=>r.request().url().startsWith(target)?r.continue():r.abort('blockedbyclient'));
 const page=await context.newPage();page.setDefaultTimeout(15000);
 page.on('request',r=>{if(/\/assets\/(?:current-scene\/|front\.webp|back\.webp)/.test(new URL(r.url()).pathname))errors.push('Unexpected still-image request in working 3D: '+r.url())});
 page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});page.on('requestfailed',r=>errors.push(r.url()+': '+r.failure()?.errorText));
 page.on('response',r=>{try{assert(r.ok(),'HTTP '+r.status()+' '+r.url());const url=new URL(r.url()),rel=decodeURIComponent(url.pathname.slice(new URL(target).pathname.length));const expected=inventory.get(rel);assert(expected,'Unexpected served input '+rel);fetched.set(rel,expected.sha256);}catch(e){errors.push(String(e))}});

 await page.goto(new URL('index.html',target).href,{waitUntil:'domcontentloaded',timeout:30000});
 await page.waitForFunction(()=>window.reef3d?.getState().ready||document.querySelector('#unsupported')?.hidden===false,null,{timeout:85000,polling:250});assert(await page.evaluate(()=>!!window.reef3d?.getState().ready),'Artificial scene failed to start');
 const seagrass=await checkSeagrassHosted(page);console.log('SEAGRASS_READY '+JSON.stringify(seagrass));
 await page.evaluate(()=>{scrollTo(0,0);reef3d.preset(0);reef3d.setTour(false)});
 await fs.mkdir(out,{recursive:true});
 for(const plan of FRAME_PLAN){
  if(plan.id==='scan-terrace'){
   await page.goto(new URL('scan-exhibit.html',target).href,{waitUntil:'domcontentloaded',timeout:30000});
   await page.waitForFunction(()=>window.reefExhibit?.getState().ready||document.querySelector('#scanError')?.hidden===false,null,{timeout:65000,polling:250});assert(await page.evaluate(()=>!!window.reefExhibit?.getState().ready),'Expanded scene failed to start');
   assert(await page.evaluate(()=>reefExhibit.ensureAssemblage()),'A assemblage load failed');
   assert(await page.evaluate(()=>reefExhibit.ensureRay()),'Ray load failed');
   assert(await page.evaluate(()=>reefExhibit.ensureTurtle()),'Turtle load failed');
   if(capturePath==='/preview/natural-rock-candidate/')assert(await page.evaluate(()=>reefExhibit.ensureNaturalRock()),'Natural rock candidate failed to load');
   const c4Started=Date.now();console.log('C4_SMOKE '+JSON.stringify(await checkC4(page)));console.log('C4_SMOKE_ELAPSED_MS '+(Date.now()-c4Started));
   const idle=await page.evaluate(async()=>{
    const a=reefExhibit;
    const first=await a.observeNextRender(receipt=>({receipt,ambient:a.getState().ambient}));
    await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
    const after=a.getRenderDemandState(),ambient=a.getState().ambient;
    if(after.sequence!==first.receipt.sequence||ambient.time!==first.ambient.time)throw Error('Static reduced-motion scan rendered or advanced during idle check');
    return {passed:true,sequence:after.sequence,skips:after.skips,ambient,scope:'Two real RAF boundaries after a fresh render, fully loaded reduced-motion route start'};
   });console.log('DEMAND_IDLE '+JSON.stringify(idle));
   const hudStarted=Date.now();console.log('HUD_SMOKE '+JSON.stringify(await checkHud(page)));console.log('HUD_SMOKE_ELAPSED_MS '+(Date.now()-hudStarted));
  }
  if(plan.world==='scan')await page.evaluate(p=>{scrollTo(0,0);reefExhibit.setAmbientPaused(true);reefExhibit.enterRoute();reefExhibit.goRoute(p,true)},plan.routeProgress);
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  const data=await page.evaluate(async world=>{
   const app=world==='scan'?window.reefExhibit:window.reef3d,canvas=document.querySelector(world==='scan'?'#scanCanvas':'#reef');
   const sample=freshRender=>{
    const gl=canvas.getContext('webgl2');if(!gl||gl.isContextLost())return {graphics:{available:false}};
    const w=gl.drawingBufferWidth,h=gl.drawingBufferHeight,pixels=new Uint8Array(w*h*4);gl.readPixels(0,0,w,h,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
    const colors=new Set();for(let y=1;y<16;y++)for(let x=1;x<20;x++){const i=(Math.floor(y*h/16)*w+Math.floor(x*w/20))*4;colors.add([pixels[i],pixels[i+1],pixels[i+2],pixels[i+3]].join(','));}
    const ext=gl.getExtension('WEBGL_debug_renderer_info'),state=app.getState(),stats=world==='scan'?app.renderer.info.render:app.getRenderStats().render;
    return {freshRender,state,camera:state.camera,target:state.target,graphics:{renderStats:{...stats},memory:world==='scan'?{...app.renderer.info.memory}:app.getRenderStats().memory,available:true,contextLost:gl.isContextLost(),sampleColors:colors.size,pixelError:gl.getError(),drawCalls:stats.calls,triangles:stats.triangles,renderer:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),vendor:ext?gl.getParameter(ext.UNMASKED_VENDOR_WEBGL):gl.getParameter(gl.VENDOR),version:gl.getParameter(gl.VERSION)}};
   };
   if(world==='scan'){const before=app.getRenderDemandState().sequence;return app.observeNextRender(receipt=>{if(receipt.sequence<=before)throw Error('Fresh render sequence did not advance');return sample(receipt);});}
   return new Promise(resolve=>requestAnimationFrame(()=>resolve(sample(null))));
  },plan.world);
  if(plan.world==='scan'){
   assert(Number.isInteger(data.freshRender?.sequence)&&data.freshRender.sequence>0,'Missing fresh scan render receipt');
   const geometry=await page.evaluate(()=>{
    const app=reefExhibit;let triangles=0,meshDraws=0,pointClouds=0;
    app.scene.traverse(o=>{if(o.isMesh){triangles+=(o.geometry.index?.count??o.geometry.attributes.position.count)/3*(o.isInstancedMesh?o.count:1);meshDraws++;}if(o.isPoints)pointClouds++;});
    const meadow=app.world.group.getObjectByName('Synthetic_Open_Basin_Meadow'),blades=meadow?.children.filter(o=>o.isInstancedMesh)||[];
    const count=n=>app.world.group.getObjectByName(n)?.count??null;
    return {triangles,meshDraws,pointClouds,meadowBatches:blades.length,meadowTufts:blades.reduce((n,o)=>n+o.count,0),lowerBody:count('Lower_Water_School_body'),lowerTail:count('Lower_Water_School_tail'),worldBody:count('World_School_body'),worldTail:count('World_School_tail'),nearFish:app.life.fish.length,countMethod:'Constructed scene traversal including hidden meshes; independent of renderer frustum counts'};
   });
   const candidateRock=capturePath==='/preview/natural-rock-candidate/';assert.equal(geometry.triangles,candidateRock?657484:624504);assert(geometry.triangles<=(candidateRock?660000:625000));assert.equal(geometry.meshDraws,candidateRock?64:63);assert.equal(geometry.pointClouds,1);assert.equal(geometry.meadowBatches,8);assert.equal(geometry.meadowTufts,720);assert.equal(geometry.lowerBody,6);assert.equal(geometry.lowerTail,6);assert.equal(geometry.worldBody,12);assert.equal(geometry.worldTail,12);assert.equal(geometry.nearFish,4);
   if(candidateRock){
    const rockBinding=await page.evaluate(()=>{
     const a=reefExhibit,root=a.world.group.getObjectByName('Synthetic_Terrestrial_Boulder_Reference'),meshes=[];root?.traverse(o=>{if(o.isMesh)meshes.push(o)});const mesh=meshes[0],m=mesh?.material,g=mesh?.geometry,gl=a.renderer.getContext(),program=m&&a.renderer.properties.get(m).currentProgram?.program;
     const value=name=>{if(!program)return null;const loc=gl.getUniformLocation(program,name);return loc===null?null:gl.getUniform(program,loc)};
     return {state:a.naturalRock.getState(),parent:root?.parent===a.world.group,copies:a.world.group.children.filter(o=>o.name==='Synthetic_Terrestrial_Boulder_Reference').length,meshes:meshes.length,triangles:(g?.index?.count??g?.attributes.position.count)/3,positions:g?.attributes.position.count,uv:g?.attributes.uv?.count,normals:g?.attributes.normal?.count,castShadow:mesh?.castShadow,receiveShadow:mesh?.receiveShadow,standard:m?.isMeshStandardMaterial,maps:[m?.map,m?.normalMap,m?.roughnessMap,m?.metalnessMap].map(t=>t?{width:t.image?.width,height:t.image?.height}:null),programLinked:program?gl.getProgramParameter(program,gl.LINK_STATUS):false,waterMode:value('exhibitOceanMode'),waterTime:value('exhibitOceanTime'),ambient:a.getState().ambient.time,remainingOriginal:a.world.group.getObjectByName('Sunlit_Broken_Coral_Shelves')?.count};
    });
    assert.equal(rockBinding.state.status,'ready');assert(rockBinding.state.installed&&!rockBinding.state.disposed);assert(rockBinding.parent);assert.equal(rockBinding.copies,1);assert.equal(rockBinding.meshes,1);assert.equal(rockBinding.triangles,33060);assert.equal(rockBinding.positions,19773);assert.equal(rockBinding.uv,19773);assert.equal(rockBinding.normals,19773);assert(!rockBinding.castShadow&&rockBinding.receiveShadow&&rockBinding.standard);assert(rockBinding.maps.every(t=>t?.width===1024&&t?.height===1024));assert(rockBinding.programLinked);assert.equal(rockBinding.waterMode,1);assert.equal(rockBinding.waterTime,rockBinding.ambient);assert.equal(rockBinding.remainingOriginal,10);data.naturalRockBinding=rockBinding;
   }
   const ray=await page.evaluate(()=>{const a=reefExhibit,r=a.ray,meshes=[];r.group.traverse(o=>{if(o.isMesh)meshes.push(o)});const m=meshes[0],g=m?.geometry;return {state:r.getState(),meshes:meshes.length,copies:a.scene.children.filter(o=>o.name==='Synthetic_Code_Ray').length,triangles:(g?.index?.count??g?.attributes.position.count)/3,positions:g?.attributes.position.count,colors:g?.attributes.color?.count,normalMorphs:g?.morphAttributes.normal?.length,positionMorphs:g?.morphAttributes.position?.length,morphNormalCounts:g?.morphAttributes.normal?.map(x=>x.count),morphPositionCounts:g?.morphAttributes.position?.map(x=>x.count),vertexColors:m?.material.vertexColors,castShadow:m?.castShadow,visible:r.group.visible,weights:m?.morphTargetInfluences,dictionary:m?.morphTargetDictionary};});
   assert.equal(ray.state.status,'ready');assert(ray.state.installed&&!ray.state.disposed&&ray.visible);assert.equal(ray.meshes,1);assert.equal(ray.copies,1);assert.equal(ray.triangles,4988);assert.equal(ray.colors,ray.positions);assert.equal(ray.normalMorphs,4);assert.equal(ray.positionMorphs,4);assert(ray.morphNormalCounts.every(n=>n===ray.positions)&&ray.morphPositionCounts.every(n=>n===ray.positions));assert(ray.vertexColors&&!ray.castShadow);for(const n of ['FinSin','FinCos','TailSin','TailCos'])assert(n in ray.dictionary);data.rayBinding=ray;
   const turtle=await page.evaluate(()=>{const a=reefExhibit,r=a.turtle,meshes=[];r.group.traverse(o=>{if(o.isMesh)meshes.push(o)});const m=meshes[0],g=m?.geometry;return {state:r.getState(),meshes:meshes.length,copies:a.scene.children.filter(o=>o.name==='Synthetic_Code_Turtle').length,triangles:(g?.index?.count??g?.attributes.position.count)/3,positions:g?.attributes.position.count,colors:g?.attributes.color?.count,normalMorphs:g?.morphAttributes.normal?.length,positionMorphs:g?.morphAttributes.position?.length,morphNormalCounts:g?.morphAttributes.normal?.map(x=>x.count),morphPositionCounts:g?.morphAttributes.position?.map(x=>x.count),vertexColors:m?.material.vertexColors,castShadow:m?.castShadow,visible:r.group.visible,weights:m?.morphTargetInfluences,dictionary:m?.morphTargetDictionary,diagnostic:a.getTurtleDiagnostics()};});
   assert.equal(turtle.state.status,'ready');assert(turtle.state.installed&&!turtle.state.disposed&&turtle.visible);assert.equal(turtle.meshes,1);assert.equal(turtle.copies,1);assert.equal(turtle.triangles,4504);assert.equal(turtle.colors,turtle.positions);assert.equal(turtle.normalMorphs,2);assert.equal(turtle.positionMorphs,2);assert(turtle.morphNormalCounts.every(n=>n===turtle.positions)&&turtle.morphPositionCounts.every(n=>n===turtle.positions));assert(turtle.vertexColors&&!turtle.castShadow);for(const n of ['StrokeUp','StrokeDown'])assert(n in turtle.dictionary);assert(turtle.diagnostic.ready);data.turtleBinding=turtle;assert.equal(data.state.ambient.time,0,'Fixed captures must remain actual paused t0');
   data.constructedGeometry=geometry;console.log('BASIN_GEOMETRY '+JSON.stringify({id:plan.id,...geometry}));
  }
  assert(data.graphics.available&&!data.graphics.contextLost&&data.graphics.sampleColors>=2&&data.graphics.drawCalls>0&&data.graphics.pixelError===0,'Actual frame unavailable/blank: '+plan.id);
  assert(await page.evaluate(world=>{const loading=document.querySelector(world==='scan'?'#scanLoading':'#loading'),failure=document.querySelector(world==='scan'?'#scanError':'#unsupported');return loading.hidden&&failure.hidden},plan.world),'Loading/error panel visible during capture');
  assert.equal(data.state.ready,true);if(plan.world==='scan'){assert.equal(data.state.assemblage.status,'ready','A assemblage must be loaded');assert.equal(data.state.assemblage.instances,4);assert.equal(data.state.c4.status,'ready','C4 must be loaded in all scan captures');assert.equal(data.state.selectedPatch,'C1');assert(data.state.waterMode&&!data.state.softened);assert.equal(data.state.route.progress,plan.routeProgress)}else assert.equal(data.state.passageProgress,0);
  assert.deepEqual(errors,[],'Runtime/asset errors');
  const temporaryFile=plan.id+'.pending.png';
  // No locator/actionability/scroll-into-view or protocol element geometry calls
  // in the software-renderer path. Read the existing DOM rectangle directly and
  // capture that viewport clip without changing the viewport, pose or materials.
  const beforeFrame=await page.evaluate(inspectCaptureFrame,plan.world);
  const clip=verifyCaptureFrame(beforeFrame,plan.world,data.state);
  console.log('CURRENT_SCENE_DIAGNOSTIC '+JSON.stringify({id:plan.id,graphics:data.graphics,rafTiming:{collected:false,reason:"Historical extra RAF timing omitted to fund explicit fifth view within unchanged deadline"}}));
  console.log('CURRENT_SCENE_FRAME_READY '+JSON.stringify({id:plan.id,clip,sampleColors:data.graphics.sampleColors}));
  await page.screenshot({path:path.join(out,temporaryFile),type:'png',clip,fullPage:false,timeout:25000,animations:'disabled'});
  const afterFrame=await page.evaluate(inspectCaptureFrame,plan.world);
  assert.deepEqual(verifyCaptureFrame(afterFrame,plan.world,data.state),clip,'Canvas rectangle changed during screenshot');
  const b=await fs.readFile(path.join(out,temporaryFile));assert(b.length>10000,'Unexpectedly empty capture');
  assert(b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))&&b.readUInt32BE(16)===clip.width&&b.readUInt32BE(20)===clip.height,'Screenshot PNG dimensions differ from canvas clip');
  console.log('FRAME_NUMERIC_STATE '+JSON.stringify({id:plan.id,freshRender:data.freshRender??null,before:beforeFrame,after:afterFrame}));
  const file=plan.id+'-'+hash(b).slice(0,16)+'.png';await fs.rename(path.join(out,temporaryFile),path.join(out,file));
  manifest.frames.push({...plan,numericCapture:{before:beforeFrame,after:afterFrame},...(plan.world==='artificial'?{seagrass}:{}),file,sha256:hash(b),bytes:b.length,width:clip.width,height:clip.height,captureClip:clip,...data,materialMode:'default-unsoftened',motion:'reduced-motion-still',interactionAcceptance:false,framing:'Visible canvas rectangle including any overlapping scene controls; no geometry/material edits.'});
  console.log('CURRENT_SCENE_FRAME '+JSON.stringify({id:plan.id,bytes:b.length,sha256:hash(b),sampleColors:data.graphics.sampleColors}));
 }
 assert.deepEqual(errors,[]);
 manifest.rayMotion=await checkRayMotion(page);console.log('RAY_SMOKE '+JSON.stringify(manifest.rayMotion));
 assert.deepEqual(errors,[],'Runtime errors during ray smoke');
 // Independent same-origin served-byte verification, not a browser inspector-cache
 // body read and not proof of the first/cold transfer. Large models can be evicted
 // from Chromium's response cache, so intentionally never call response.body().
 for(const [rel,expectedHash]of fetched){const response=await fetch(new URL(rel,target),{redirect:'error',signal:AbortSignal.timeout(20000)});assert(response.ok,'Served hash check HTTP '+response.status+' '+rel);const bytes=Buffer.from(await response.arrayBuffer());assert.equal(bytes.length,inventory.get(rel).bytes,'Served size mismatch '+rel);assert.equal(hash(bytes),expectedHash,'Served input mismatch '+rel);}
 manifest.servedHashMethod='Independent same-origin fetch after browser captures; not original response-body, cold-load, wire-byte or timing evidence.';
 assert.deepEqual(await sourceInventory(),sourceFiles,'Candidate changed during capture');
 manifest.fetchedAssets=[...fetched].map(([path,sha256])=>({path,sha256})).sort((a,b)=>a.path.localeCompare(b.path));
 for(const required of ['app.js','scan-exhibit.js','scan-render-demand.js','scan-world.js','scan-ocean.js','scan-route.js','assets/reefs4d/C12019-web.glb','assets/reefs4d/C42019-web-150k.glb','assets/reefs4d/C4-A-rounded-knobby.glb','scan-ray.js','assets/synthetic-reef-ray.glb','scan-turtle.js','turtle-motion.js','assets/synthetic-reef-turtle.glb'])assert(fetched.has(required),'Missing live asset '+required);
 validateManifest(manifest);
 await fs.writeFile(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
 await fs.writeFile(path.join(root,'current-scene.html'),renderGallery(manifest));
 console.log('CAPTURE_ELAPSED '+JSON.stringify({capturedAt:manifest.capturedAt,completedAt:new Date().toISOString(),elapsedMs:Date.now()-Date.parse(manifest.capturedAt)}));
 console.log('CURRENT_SCENE_COMPLETE '+JSON.stringify({contentVersion,frames:manifest.frames.length,manifest:`assets/current-scene/${contentVersion}/manifest.json`,sourceFiles:sourceFiles.length,rootFilesNotModifiedByCapture:true}));
}catch(e){console.error('CURRENT_SCENE_CAPTURE_FAILED',e);process.exitCode=1;}finally{clearTimeout(timer);await context?.close().catch(()=>{});await browser?.close().catch(()=>{});}
