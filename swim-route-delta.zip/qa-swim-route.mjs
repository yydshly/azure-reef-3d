import assert from 'node:assert/strict';
import fs from 'node:fs';
import {routePose,createRouteState} from './dist/scan-route.js';
import * as T from 'three';
import {createScanOcean} from './dist/scan-ocean.js';
const scan=new T.Box3(new T.Vector3(-1.455185,-.966001,-1.657036),new T.Vector3(1.455108,.966157,1.658251));
const ocean=createScanOcean(new T.Scene(),new T.Texture());
const rocks=ocean.rocks.map(r=>new T.Box3().setFromObject(r));
let minScan=Infinity,minRock=Infinity,minFloor=Infinity,minSurface=Infinity;
for(let i=0;i<=10000;i++){
 const p=routePose(i/10000),v=new T.Vector3(...p.position);minScan=Math.min(minScan,scan.distanceToPoint(v));minRock=Math.min(minRock,...rocks.map(b=>b.distanceToPoint(v)));
 // Entire seabed is bounded above by -.98 + .16 + .09 = -.73.
 minFloor=Math.min(minFloor,v.y+.73);minSurface=Math.min(minSurface,6.2-v.y);
 for(const yaw of [-10,0,10])for(const pitch of [-10,0,10])assert.deepEqual(routePose(i/10000,yaw,pitch).position,p.position);
 if(i){const prev=routePose((i-1)/10000);assert.ok(Math.hypot(...p.position.map((v,j)=>v-prev.position[j]))<.003);}
}
assert.ok(minScan>2.3&&minRock>4&&minFloor>2&&minSurface>4);
// Analytic coverage: every segment's x >= 3.8 > scan.max.x + 2.34;
// z >= -3.5 excludes the two northern rocks, x >= 3.8 excludes western rock.
assert.ok(3.8-scan.max.x>2.34);
const route=createRouteState();route.enter();route.request(1);let last=0;for(let i=0;i<1300;i++){route.tick(.016);const p=route.getState().progress;assert.ok(p>=last&&p-last<.003);last=p;}assert.equal(last,1);
route.request(0);route.tick(.016);route.stop();const stopped=route.getState().progress;for(let i=0;i<100;i++)route.tick(.016);assert.equal(route.getState().progress,stopped);
route.request(-100,true);assert.equal(route.getState().progress,0);route.request(100,true);assert.equal(route.getState().progress,1);route.request(.5);route.tick(.016,true);assert.equal(route.getState().progress,.5);route.leave();route.request(0);route.tick(10);assert.equal(route.getState().progress,.5);route.enter();route.request(0);route.tick(100);assert.ok(route.getState().progress>=.492); // tab-resume dt capped
const report={passed:true,scope:'CPU route geometry and movement-state checks, not rendered visual acceptance',samples:10001,minScanClearance:minScan,minRockClearance:minRock,minSeabedClearance:minFloor,minSurfaceClearance:minSurface,analyticScanClearance:3.8-scan.max.x,checks:['continuous two-segment path','entire path outside source bounds','entire path above maximum seabed and below surface','remote rock exclusion','look cannot translate camera','no frame-time jump','stop cancels destination','progress bounds','reduced motion instant step','inactive route cannot move']};fs.mkdirSync('evidence/route',{recursive:true});fs.writeFileSync('evidence/route/cpu.json',JSON.stringify(report,null,2));console.log(report);
