"""Exploration publication guards. Local receipts and QA tools stay outside dist."""
import hashlib
import json
import math
import os
import pathlib
import re
import stat
import struct
import time
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
DIST = pathlib.Path('dist')
INPUTS = pathlib.Path('.exploration-inputs')
ENTRY_NAMES = ('index.html', 'world.css', 'current-world.json')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(pathlib.Path(path).read_text())


def save_json(path, value):
    pathlib.Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n')


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()


def safe_name(name):
    require(isinstance(name, str) and bool(name), 'Missing relative path')
    p = pathlib.PurePosixPath(name)
    require(not p.is_absolute() and '..' not in p.parts and '\\' not in name and p.as_posix() == name and name != '.', 'Unsafe path: ' + name)
    return p


def inventory(root):
    root = pathlib.Path(root)
    require(root.is_dir() and not root.is_symlink(), 'Missing/linked directory: ' + str(root))
    result = {}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink() and (p.is_file() or p.is_dir()), 'Linked/special path: ' + str(p))
        if p.is_file():
            result[p.relative_to(root).as_posix()] = sha(p.read_bytes())
    return result


def file_record(path, relative=None):
    p = pathlib.Path(path)
    b = p.read_bytes()
    return {'path': relative or p.name, 'bytes': len(b), 'sha256': sha(b)}


def validate_bytes(data, record, label):
    require(len(data) == record['bytes'] and sha(data) == record['sha256'], 'Size/SHA mismatch: ' + label)


def checked_archive(path, archive, expected):
    p = pathlib.Path(path)
    require(p.is_file() and not p.is_symlink(), 'Missing/linked archive: ' + str(p))
    validate_bytes(p.read_bytes(), archive, str(p))
    with zipfile.ZipFile(p) as z:
        require(len(z.namelist()) == len(set(z.namelist())) == len(expected) and set(z.namelist()) == set(expected), 'Unexpected archive file set: ' + str(p))
        files = {}
        for info in z.infolist():
            safe_name(info.filename)
            mode = info.external_attr >> 16
            require(not info.is_dir() and not stat.S_ISLNK(mode) and stat.S_IFMT(mode) in (0, stat.S_IFREG), 'Nonregular archive member')
            data = z.read(info)
            validate_bytes(data, expected[info.filename], info.filename)
            files[info.filename] = data
    return files


def contract():
    c = read_json(HERE / 'exploration-contract.json')
    require(c['candidatePath'] == 'preview/exploration-demo-candidate' and c['basePath'] == 'preview/rear-layout-candidate' and c['entryPath'] == 'preview/world', 'Destination changed')
    require(c['baseMainCommit'] == '2eac3e4d699fd497bb421bad455bdd7765d86158', 'Published baseline changed')
    require([c[k] for k in ('oldAssemblyProtectedFiles', 'oldAssemblyFiles', 'oldSiteFiles', 'protectedFiles', 'rootFiles', 'newSourceFiles', 'newGalleryFiles', 'stagedSiteFiles', 'finalSiteFiles')] == [1662, 1811, 1817, 1814, 79, 149, 6, 1966, 1972], 'Exact publication counts changed')
    require(c['totalBudgetMs'] == 450000 and c['captureTimeoutMs'] == 25000, '450/25-second budgets changed')
    require(c['mutableEntryPaths'] == [c['entryPath'] + '/' + n for n in ENTRY_NAMES], 'Exact three-entry allowlist changed')
    require(len(c['sourceFiles']) == len(c['sourceHashes']) == 149 and len(c['baseSourceFiles']) == len(c['baseSourceHashes']) == 146, 'Source counts changed')
    for hashes, records in ((c['sourceHashes'], c['sourceFiles']), (c['baseSourceHashes'], c['baseSourceFiles'])):
        require({f['path']: f['sha256'] for f in records} == hashes, 'Source manifest mismatch')
        for n, h in hashes.items():
            safe_name(n)
            require(re.fullmatch('[0-9a-f]{64}', h), 'Invalid source hash')
    require(sha(''.join(n + '\0' + c['sourceHashes'][n] + '\n' for n in sorted(c['sourceHashes'])).encode()) == c['sourceHashAggregate'], 'Source aggregate mismatch')
    changes = {f['path']: f for f in c['changes']}
    require(len(c['changes']) == 6 and set(changes) == {'scan-exhibit.js', 'scan-exhibit.html', 'scan-exhibit.css', 'exploration-navigation.js', 'exploration-world.js', 'exploration-world-data.js'}, 'Exact six-file delta required')
    predicted = dict(c['baseSourceHashes'])
    for n, f in changes.items():
        require(predicted.get(n) == f['baseSha256'], 'Delta baseline mismatch: ' + n)
        predicted[n] = f['sha256']
    require(predicted == c['sourceHashes'] and sum(c['sourceHashes'].get(n) == h for n, h in c['baseSourceHashes'].items()) == 143, '143 unchanged source files required')
    require(c['frames'] == ['tour-initial', 'tour-grass-bay', 'tour-completed'], 'Three natural tour stages required')
    return c


def assembly_protection(c):
    # Reuse the pinned, unchanged previous checker to authenticate its complete
    # 1662-file chain back through the grounded and original-root inventories.
    import rear_layout_common as previous
    old = previous.contract()
    require(old['candidatePath'] == c['basePath'] and old['sourceHashes'] == c['baseSourceHashes'], 'Old assembly identity mismatch')
    protected, _ = previous.check_old(old)
    require(len(protected) == c['oldAssemblyProtectedFiles'], 'Old assembly protection mismatch')
    return protected


def baseline_hashes(c):
    protected = assembly_protection(c)
    public = {f['path']: f['sha256'] for f in c['oldPublicFiles']}
    require(len(c['oldPublicFiles']) == len(public) == 155 and not set(public) & set(protected), 'Published baseline records overlap old protection')
    expected = dict(protected, **public)
    require(len(expected) == c['oldSiteFiles'], '1817 published baseline files required')
    return expected


def snapshot(c):
    records = {f['path']: f for f in c['snapshotFiles']}
    require(len(records) == len(c['snapshotFiles']) == 9, 'Six old gallery and three world products required')
    files = checked_archive(INPUTS / c['snapshotArchive']['path'], c['snapshotArchive'], records)
    public = {f['path']: f for f in c['oldPublicFiles']}
    require(all(public.get(n) == f for n, f in records.items()), 'Snapshot differs from published receipt')
    require(set(public) == {c['basePath'] + '/' + n for n in c['baseSourceHashes']} | set(files), 'Published file set mismatch')
    require({n for n in files if n.startswith(c['entryPath'] + '/')} == set(c['mutableEntryPaths']), 'World snapshot allowlist mismatch')
    for f in c['baseSourceFiles']:
        require(public[c['basePath'] + '/' + f['path']] == dict(f, path=c['basePath'] + '/' + f['path']), 'Published baseline source record mismatch')
    p = json.loads(files[c['entryPath'] + '/current-world.json'])
    require(p['mainCommit'] == c['baseMainCommit'] and p['candidateSourceCommit'] == c['baseSourceCommit'] and p['sourceHashAggregate'] == c['baseSourceHashAggregate'], 'Old pointer identity mismatch')
    return files


def candidate_sources(c):
    return {c['candidatePath'] + '/' + n for n in c['sourceHashes']}


def check_sources(c):
    for f in c['sourceFiles']:
        p = DIST / c['candidatePath'] / f['path']
        require(p.is_file() and not p.is_symlink(), 'Missing/linked candidate source: ' + f['path'])
        validate_bytes(p.read_bytes(), f, f['path'])


def check_old(c):
    baseline = baseline_hashes(c)
    require(read_json('.exploration-baseline.json') == baseline, 'Published baseline inventory changed')
    protected = {n: h for n, h in baseline.items() if n not in c['mutableEntryPaths']}
    require(len(protected) == c['protectedFiles'] and read_json('.exploration-protected.json') == protected, 'Exact 1814 protected files required')
    current = inventory(DIST)
    for n, h in protected.items():
        require(current.get(n) == h, 'Old file changed/missing: ' + n)
    root = read_json('.root-site-hashes.json')
    require(len(root) == c['rootFiles'] and {n: h for n, h in current.items() if not n.startswith('preview/')} == root, 'Original root bytes changed')
    return protected, current


def check_deadline(segment='free-compat', current=True):
    require(segment in ('tour', 'free-compat'), 'Unknown QA segment')
    d = read_json('.exploration-' + segment + '-deadline.json')
    require(d['totalBudgetMs'] == 450000 and isinstance(d['startedAtMs'], (int, float)) and isinstance(d['expiresAtMs'], (int, float)), 'Invalid shared deadline')
    require(d['expiresAtMs'] - d['startedAtMs'] == 450000, 'Shared deadline extended')
    require(d['startedAtMs'] <= time.time() * 1000, 'QA segment starts in the future')
    require(not current or time.time() * 1000 < d['expiresAtMs'], 'QA segment 450-second deadline expired')
    return d


def source_identity(c):
    identity = {'candidateSourceCommit': os.environ.get('EXPLORATION_SOURCE_COMMIT', ''), 'checkoutCommit': os.environ.get('GITHUB_SHA', ''),
                'candidatePath': c['candidatePath'], 'sourceHashAggregate': c['sourceHashAggregate'], 'sourceFiles': 149, 'baseMainCommit': c['baseMainCommit']}
    for k in ('candidateSourceCommit', 'checkoutCommit'):
        require(re.fullmatch('[0-9a-f]{40}', identity[k]), 'Missing exact commit: ' + k)
    return identity


def run_identity():
    value = {'runId': os.environ.get('GITHUB_RUN_ID', ''), 'runAttempt': os.environ.get('GITHUB_RUN_ATTEMPT', ''), 'qaCommit': os.environ.get('GITHUB_SHA', '')}
    require(re.fullmatch('[0-9]+', value['runId']) and re.fullmatch('[0-9]+', value['runAttempt']) and re.fullmatch('[0-9a-f]{40}', value['qaCommit']), 'Exact same CI run/attempt and QA commit required')
    return value


def check_qa_segments(c, reports):
    require(set(reports) == {'tour', 'free-compat'}, 'Both distinct QA reports are required')
    for segment, report in reports.items():
        require(report.get('schemaVersion') == 2 and report.get('segment') == segment and report.get('status') == 'PASS' and report.get('syntheticFixture') is False, 'Both genuine complete segment PASS reports are required')
        require(report['sourceIdentity'] == source_identity(c) and report['runIdentity'] == run_identity(), 'Cross-segment source/main/QA/run identity mismatch')
        deadline = check_deadline(segment, current=segment == 'free-compat')
        require(all(report[k] == deadline[k] for k in ('startedAtMs', 'expiresAtMs', 'totalBudgetMs')), 'Report belongs to another segment deadline')
        completed = report['completedAtMs']
        require(isinstance(completed, (int, float)) and not isinstance(completed, bool) and math.isfinite(completed) and deadline['startedAtMs'] <= completed <= time.time() * 1000 and completed < deadline['expiresAtMs'], 'QA segment completed outside its own 450-second deadline')
    require(reports['tour']['completedAtMs'] < reports['free-compat']['startedAtMs'], 'Tour must complete before independent free/compat starts')


def png_bytes(path, record):
    p = pathlib.Path(path)
    require(p.is_file() and not p.is_symlink(), 'Missing/linked PNG')
    b = p.read_bytes()
    validate_bytes(b, record, str(p))
    require(len(b) > 32 and b[:8] == b'\x89PNG\r\n\x1a\n' and b[12:16] == b'IHDR', 'Invalid PNG')
    w, h = struct.unpack('>II', b[16:24])
    require((w, h) == (1120, 712), 'Original 1120x712 canvas PNG required')
    return b, w, h


def expected_entry(c, identity, old_snapshot):
    old_base, new_base = '../rear-layout-candidate/', '../exploration-demo-candidate/'
    index = old_snapshot[c['entryPath'] + '/index.html'].decode()
    require(index.count(old_base) == 4, 'Unexpected old world link count')
    replacements = {
        old_base: new_base,
        '进入后选择“回起点并游览”。可 360° 环顾，W / S 沿固定路线前后移动；目前不能向任意方向自由游。': '进入后默认自由游动：拖动环顾，W / S 随视线前后游动，A / D 横移，Q / E 升降；也可点击开始导览。',
        '游览时，拖动或使用方向键环顾；按住 W / S，或使用场景内的前进 / 后退按钮沿路线移动。移动方向不会随视线改变。': '自由模式下可拖动或使用方向键环顾，W / S 随视线移动，A / D 横移，Q / E 升降。导览可以暂停、继续、重新播放，或切回自由游动；减少动态效果模式提供逐站查看。',
        '当前入口指向局部后方布局候选，未通过整体美术验收。<br>候选源码：<code>' + c['baseSourceCommit'] + '</code><br>发布构建：<code>' + c['baseMainCommit'] + '</code>':
        '当前入口指向自由探索演示候选，整体真实感与最终美术效果尚未验收。<br>候选源码：<code>' + identity['candidateSourceCommit'] + '</code><br>发布构建：<code>' + identity['checkoutCommit'] + '</code>'}
    for old, new in replacements.items():
        require(index.count(old) == (4 if old == old_base else 1), 'Unexpected old entry text')
        index = index.replace(old, new)
    pointer = {'schemaVersion': 3, 'entryPublishPath': c['entryPath'] + '/', 'version': 'exploration-demo-' + c['sourceHashAggregate'],
        'selection': 'manually-selected-pinned-exploration-demo-after-technical-qa', 'candidateSourceCommit': identity['candidateSourceCommit'],
        'mainCommit': identity['checkoutCommit'], 'sourceHashAggregate': c['sourceHashAggregate'], 'candidatePath': c['candidatePath'],
        'world': new_base + 'scan-exhibit.html', 'procedural': new_base + 'index.html', 'stills': new_base + 'current-scene.html',
        'sources': new_base + 'scan-exhibit.html#scanProvenance', 'technicalStatus': 'PASS', 'appearanceAccepted': False,
        'acceptance': c['acceptance'], 'acceptanceChinese': c['acceptanceChinese'], 'unverified': c['unverified'],
        'entryEvidence': c['oldEntryEvidencePolicy'], 'updatePolicy': 'Manual exact source and QA build only; never follow newest commit.'}
    return {'index.html': index.encode(), 'world.css': old_snapshot[c['entryPath'] + '/world.css'], 'current-world.json': json_bytes(pointer)}, pointer


def gallery_records(c):
    receipt = read_json('.exploration-finalized.json')
    records = receipt['galleryFiles']
    require(len(records) == len({f['path'] for f in records}) == 6, 'Exactly six new evidence files required')
    base = c['candidatePath'] + '/'
    prefix = base + 'assets/current-scene/' + c['sourceHashAggregate'] + '/'
    static = {base + 'current-scene.html', prefix + 'manifest.json', prefix + 'actual-navigation-frames.jsonl'}
    require(static <= {f['path'] for f in records}, 'Evidence file paths changed')
    actual = set()
    for f in records:
        safe_name(f['path'])
        if f['path'] in static:
            continue
        require(f['path'].startswith(prefix), 'Evidence escaped candidate directory')
        suffix = '-' + f['sha256'][:16] + '.png'
        require(f['path'].endswith(suffix), 'PNG content-address mismatch')
        actual.add(f['path'][len(prefix):-len(suffix)])
    require(actual == set(c['frames']), 'Tour frame allowlist mismatch')
    return receipt, records

