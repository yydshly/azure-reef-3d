"""Verify all old bytes, exactly 149 sources, six evidence files and three products."""
import sys
from exploration_common import *


def verify(c, source_only=False):
    protected, current = check_old(c)
    check_sources(c)
    expected = candidate_sources(c) | set(c['mutableEntryPaths'])
    old = snapshot(c)
    if source_only:
        require(not pathlib.Path('.exploration-finalized.json').exists(), 'Already finalized')
        for n in c['mutableEntryPaths']:
            require((DIST / n).read_bytes() == old[n], 'Old world changed before finalization: ' + n)
        require(len(current) == c['stagedSiteFiles'], '1966 staged files required')
    else:
        check_deadline()
        receipt, gallery = gallery_records(c)
        identity = source_identity(c)
        require(receipt['sourceIdentity'] == identity and receipt['appearanceAccepted'] is False, 'Final identity/acceptance mismatch')
        require(receipt['state'] in ('QA_PASS_WORLD_UNCHANGED', 'QA_PASS_EXACT_WORLD_UPDATE'), 'Invalid final state')
        for f in gallery:
            validate_bytes((DIST / f['path']).read_bytes(), f, f['path'])
            expected.add(f['path'])
        manifest = read_json(DIST / c['candidatePath'] / 'assets/current-scene' / c['sourceHashAggregate'] / 'manifest.json')
        reports = manifest['segmentReports']
        check_qa_segments(c, reports)
        require(receipt['runIdentity'] == run_identity() and receipt['segments'] == {name: {k: value[k] for k in ('segment', 'startedAtMs', 'expiresAtMs', 'completedAtMs', 'totalBudgetMs', 'status')} for name, value in reports.items()}, 'Final receipt differs from independent segment evidence')
        if receipt['state'] == 'QA_PASS_EXACT_WORLD_UPDATE':
            entry, pointer = expected_entry(c, identity, old)
            require(receipt['pointer'] == pointer, 'Final pointer mismatch')
        else:
            entry = {n: old[c['entryPath'] + '/' + n] for n in ENTRY_NAMES}
            require(receipt['pointer'] is None, 'Unchanged pointer must have no replacement receipt')
        require(len(receipt['entryFiles']) == 3 and {f['path'] for f in receipt['entryFiles']} == set(ENTRY_NAMES), 'Exact world products required')
        for n, b in entry.items():
            require((DIST / c['entryPath'] / n).read_bytes() == b, 'World file differs from exact approved output: ' + n)
        for f in receipt['entryFiles']:
            validate_bytes(entry[f['path']], f, f['path'])
        require(len(current) == c['finalSiteFiles'], '1972 final files required')
        check_deadline()
    require(set(current) - set(protected) == expected, 'Unexpected/missing output files')
    print('EXPLORATION_PRESERVATION_PASS', json.dumps({'sourceOnly': source_only, 'oldSiteFiles': 1817, 'protectedFiles': 1814, 'oldEntryPNGsPreserved': 2, 'newEntryScreenshots': 0, 'totalFiles': len(current), 'newCandidateFiles': len(current) - 1817}))
    if not source_only:
        print('EXPLORATION_PUBLIC_RECEIPT', json.dumps({'status': 'PASS_EXACT_155_ADDITIONS_3_ENTRY_PRODUCTS', 'oldSiteFiles': 1817, 'protectedFiles': 1814,
            'protectedFilesByteIdentical': True, 'rootFilesByteIdentical': 79, 'oldEntryPNGsByteIdentical': 2, 'newEntryScreenshots': 0,
            'newFiles': 155, 'totalFiles': 1972, 'sourceIdentity': identity, 'appearanceAccepted': False,
            'files': [file_record(DIST / n, n) for n in sorted(expected)]}, ensure_ascii=False))


if __name__ == '__main__':
    require(sys.argv[1:] in ([], ['--source-only'], ['--deadline-only']), 'Unexpected arguments')
    if '--deadline-only' in sys.argv:
        check_deadline()
        print('FREE_COMPAT_FINALIZATION_DEADLINE_PASS')
    else:
        verify(contract(), '--source-only' in sys.argv)
