"""Revalidate all old bytes and allow only this comparison's exact additions."""
from lod_common import *
def verify(c,source_only=False):
    check_sources(c);protected,current=check_old(c);expected=candidate_sources(c)
    if not source_only:
        r=read_json('.lod-finalized.json')
        require(r['state']=='TECHNICAL_PASS_INDEPENDENT_PREVIEW_WORLD_UNCHANGED' and r['worldEntryChanged'] is False and r['appearanceAccepted'] is False and r['visualStatus']==c['visualStatus'],'Unauthorized world/appearance claim')
        require(r['protectedFiles']==2304 and r['sourceIdentity']==source_identity(c) and r['runIdentity']==run_identity(),'Receipt identity/protection changed')
        records=r['galleryFiles'];names={f['path'] for f in records};require(len(records)==len(names)==10,'Exactly8PNG+report+gallery required')
        prefix=c['candidatePath']+'/assets/gpu/'+c['sourceHashAggregate']+'/'
        static={c['candidatePath']+'/current-scene.html',prefix+'report.json'};require(static<=names,'Missing report/gallery');views=set()
        for f in records:
            safe_name(f['path']);p=DIST/f['path'];require(p.is_file() and not p.is_symlink(),'Missing/linked evidence');validate_bytes(p.read_bytes(),f,f['path'])
            if f['path'] not in static:
                suffix='-'+f['sha256'][:16]+'.png';require(f['path'].startswith(prefix) and f['path'].endswith(suffix),'Evidence path/hash mismatch');views.add(f['path'][len(prefix):-len(suffix)])
        require(views==set(c['frames']),'Paired evidence frame set changed')
        report_path=DIST/(prefix+'report.json');report=read_json(report_path);require(report['status']==r['status'] and report['scope']==r['scope'],'Report acceptance mismatch')
        import importlib.util
        spec=importlib.util.spec_from_file_location('lod_finalizer',HERE/'finalize-lod.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.validate_gpu(c,report,report_path)
        expected|=names
    require(set(current)-set(protected)==expected and len(current)==(2320 if source_only else 2330),'Unexpected/omitted published paths')
    result=dict(status='PASS_SOURCE_ONLY' if source_only else 'PASS_EXACT_INDEPENDENT_ADDITIONS_WORLD_UNCHANGED',oldSiteFiles=2304,protectedFiles=2304,protectedFilesByteIdentical=True,rootFilesByteIdentical=79,newFiles=len(expected),totalFiles=len(current),worldEntryChanged=False,appearanceAccepted=False)
    if not source_only:
        result.update(sourceIdentity=source_identity(c),runIdentity=run_identity(),files=[file_record(DIST/n,n) for n in sorted(expected)]);save_json(pathlib.Path(os.environ.get('LOD_OUTPUT','lod-qa'))/'public-receipt.json',result)
    print(json.dumps(result,indent=2));return result
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--source-only',action='store_true');args=p.parse_args();verify(contract(),args.source_only)
