"""Local synthetic bookkeeping only. No browser, GPU, publication or world write."""
from pathlib import Path
import contextlib,copy,gzip,importlib.util,io,json,os,struct,sys,tempfile,time,zipfile,zlib
T=Path(__file__).resolve().parent;P=T.parent;sys.path.insert(0,str(T))
import lod_common as common
def module(name,file):
    spec=importlib.util.spec_from_file_location(name,T/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
stage=module('stage','stage-lod.py');final=module('final','finalize-lod.py');verify=module('verify','verify-lod-preserved.py')
checks=[]
def rec(n,b):return dict(path=n,bytes=len(b),sha256=common.sha(b))
def write(n,b):
    p=Path(n);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def quiet(fn,*a,**kw):
    with contextlib.redirect_stdout(io.StringIO()):return fn(*a,**kw)
def rejects(label,fn):
    try:quiet(fn)
    except (ValueError,KeyError,AssertionError,FileNotFoundError):checks.append(label);return
    raise AssertionError('Did not reject: '+label)
def png():
    def chunk(n,b):return struct.pack('>I',len(b))+n+b+struct.pack('>I',zlib.crc32(n+b))
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',1120,712,8,2,0,0,0))+chunk(b'IDAT',zlib.compress((b'\0'+b'\x20\x50\x60'*1120)*712))+chunk(b'IEND',b'')
def fixture(c):
    for i in range(79):write('dist/root-'+str(i),str(i).encode())
    common.save_json('.root-site-hashes.json',common.inventory('dist'))
    for i in range(2201):write('dist/preview/older/'+str(i),str(i).encode())
    world={n:('world:'+n).encode() for n in c['immutableWorldPaths']}
    for n,b in world.items():write('dist/'+n,b)
    c['worldEntryFiles']=[rec(n,b) for n,b in world.items()];protected=common.inventory('dist');assert len(protected)==2283
    common.save_json('.fixture-upstream.json',protected)
    common.assembly_protection=stage.assembly_protection=lambda _:common.read_json('.fixture-upstream.json')
    base={n:('old-source:'+n).encode() for n in c['baseSourceHashes']};c['baseSourceFiles']=[rec(n,b) for n,b in base.items()];c['baseSourceHashes']={n:common.sha(b) for n,b in base.items()}
    for n,b in base.items():write('dist/'+c['basePath']+'/'+n,b)
    saved={f['path']:('old-gallery:'+f['path']).encode() for f in c['snapshotFiles']};c['snapshotFiles']=[rec(n,b) for n,b in saved.items()]
    c['oldPublicFiles']=[dict(f,path=c['basePath']+'/'+f['path']) for f in c['baseSourceFiles']]+c['snapshotFiles']
    candidate={n:('candidate:'+n).encode() for n in c['sourceHashes']}
    for lod in ('4','3'):
        a=c['assets'][lod];raw=('raw original LOD'+lod).encode();wire=gzip.compress(raw,mtime=0);a.update(bytes=len(raw),sha256=common.sha(raw));a['transport'].update(bytes=len(wire),sha256=common.sha(wire));candidate[a['url'].removeprefix('./')]=wire
    c['sourceFiles']=[rec(n,b) for n,b in candidate.items()];c['sourceArchiveFiles']=copy.deepcopy(c['sourceFiles']);c['sourceHashes']={n:common.sha(b) for n,b in candidate.items()};c['sourceHashAggregate']=common.sha(''.join(n+'\0'+c['sourceHashes'][n]+'\n' for n in sorted(candidate)).encode())
    for key,files in [('sourceArchive',candidate),('snapshotArchive',saved)]:
        p=Path('.lod-inputs')/c[key]['path'];p.parent.mkdir(exist_ok=True)
        with zipfile.ZipFile(p,'w') as z:
            for n,b in files.items():z.writestr(n,b)
        c[key]=rec(p.name,p.read_bytes())
    return c

def main():
    actual=common.contract();checks.append('frozen16file-static-v1-source-and-two-original-gzip-identities')
    original=Path.cwd();envkeys=['LOD_SOURCE_COMMIT','GITHUB_SHA','GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT','LOD_OUTPUT'];env={k:os.environ.get(k) for k in envkeys}
    os.environ.update(LOD_SOURCE_COMMIT='1'*40,GITHUB_SHA='2'*40,GITHUB_RUN_ID='12345',GITHUB_RUN_ATTEMPT='1',LOD_OUTPUT='lod-qa')
    try:
        with tempfile.TemporaryDirectory(prefix='lod-bookkeeping-',dir=P) as tmp:
            os.chdir(tmp);c=fixture(copy.deepcopy(actual));before=common.inventory('dist')
            for key in ('sourceArchive','snapshotArchive'):
                p=Path('.lod-inputs')/c[key]['path'];raw=p.read_bytes();p.write_bytes(raw+b'tampered')
                rejects(key+'-tampering-blocks-all-writes',lambda:stage.stage(c));assert common.inventory('dist')==before;p.write_bytes(raw)
            original_sha=c['assets']['3']['sha256'];c['assets']['3']['sha256']='0'*64
            rejects('decompressed-original-sha-mismatch-before-writes',lambda:stage.stage(c));assert common.inventory('dist')==before;c['assets']['3']['sha256']=original_sha
            quiet(stage.stage,c);quiet(verify.verify,c,True);assert len(common.inventory('dist'))==2320 and len(common.read_json('.lod-protected.json'))==2304
            checks.append('restore2298-to2304then16sources-no-existing-byte-changes')
            for label,path in [('root',Path('dist/root-0')),('old-preview',Path('dist/preview/older/0')),('old-probe',Path('dist/preview/real-splats-probe/probe.js')),('old-gallery',Path('dist/preview/real-splats-probe/current-scene.html')),('new-source',Path('dist/preview/real-splats-lod-compare/probe.js')),('world-index',Path('dist/preview/world/index.html')),('world-css',Path('dist/preview/world/world.css')),('world-pointer',Path('dist/preview/world/current-world.json')),('extra',Path('dist/preview/extra'))]:
                raw=path.read_bytes() if path.exists() else None;path.write_bytes(b'bad');rejects(label+'-mutation-rejected',lambda:verify.verify(c,True));path.unlink() if raw is None else path.write_bytes(raw)
            p=Path('.lod-protected.json');raw=p.read_bytes();v=json.loads(raw);v.pop('root-0');common.save_json(p,v);rejects('protected-map-shrink-rejected',lambda:verify.verify(c,True));p.write_bytes(raw)
            rejects('repeat-stage-rejected',lambda:stage.stage(c))
            Path('lod-qa').mkdir();now=int(time.time()*1000);report=dict(schemaVersion=1,status='TECHNICAL_FAIL',syntheticFixture=True,frames=[])
            common.save_json('lod-qa/report.json',report);staged=common.inventory('dist');rejects('technical-fail-blocks-evidence',lambda:final.finalize(c));assert common.inventory('dist')==staged
            report['status']='TECHNICAL_PASS_VISUAL_PENDING';common.save_json('lod-qa/report.json',report);rejects('synthetic-pass-blocks-evidence',lambda:final.finalize(c));assert common.inventory('dist')==staged
            report.update(syntheticFixture=False,visualStatus='VISUAL_PASS',publicationAllowed=True);common.save_json('lod-qa/report.json',report);rejects('visual-publication-overclaim-blocked',lambda:final.finalize(c));assert common.inventory('dist')==staged
            frames=[]
            for name in c['frames']:
                b=png();write('lod-qa/'+name+'.png',b);lod,view=name.split('-',1);frames.append(dict(rec(name+'.png',b),name=name,file=name+'.png',lod=int(lod[-1]),view=view,width=1120,height=712))
            segments={}
            for i,name in enumerate(('A','B')):
                deadline=dict(startedAtMs=now-10000+i*5000,expiresAtMs=now+440000+i*5000,totalBudgetMs=450000)
                common.save_json('.lod-deadline-'+name+'.json',deadline);segments[name]=dict(deadline,segment=name,fixture=True);common.save_json('lod-qa/report-'+name+'.json',segments[name])
            report.update(status='TECHNICAL_PASS_LOW_CADENCE_VISUAL_PENDING',visualStatus=c['visualStatus'],publicationAllowed=False,scope='STATIC_COMPARE_LOW_CADENCE',performanceChecks=[{'lod':3,'status':'SKIPPED_STOP_SUSTAINED_PRESSURE','reason':'CPU bookkeeping fixture only'}],frames=frames,segments=segments,segmentReportHashes={name:common.sha(Path('lod-qa/report-'+name+'.json').read_bytes()) for name in ('A','B')},limitations=['Synthetic bookkeeping only; GPU gate explicitly mocked.'])
            common.save_json('lod-qa/report.json',report);final.validate_gpu=lambda *_:None
            p=Path('lod-qa/lod3-side.png');raw=p.read_bytes();p.write_bytes(raw+b'tampered');rejects('png-hash-tamper-before-evidence-writes',lambda:final.finalize(c));assert common.inventory('dist')==staged;p.write_bytes(raw)
            quiet(final.finalize,c);current=common.inventory('dist');assert len(current)==2330 and all(current[n]==h for n,h in common.read_json('.lod-protected.json').items())
            receipt=common.read_json('.lod-finalized.json');assert len(receipt['galleryFiles'])==10 and not receipt['appearanceAccepted'] and not receipt['worldEntryChanged']
            report_path=Path('dist')/c['candidatePath']/'assets/gpu'/c['sourceHashAggregate']/'report.json';assert report_path.read_bytes()==Path('lod-qa/report.json').read_bytes()
            gallery=(Path('dist')/c['candidatePath']/'current-scene.html').read_text();assert 'STATIC_COMPARE_LOW_CADENCE' in gallery and 'SKIPPED_STOP_SUSTAINED_PRESSURE' in gallery and 'sustained motion was not measured' in gallery
            checks.append('mocked-packaging8PNG-exactreport-gallery2330-all2304oldbytesunchanged')
            rejects('repeat-finalization-blocked',lambda:final.finalize(c))
    finally:
        os.chdir(original)
        for k,v in env.items():os.environ.pop(k,None) if v is None else os.environ.__setitem__(k,v)
    import yaml
    text=(P/'pages-lod.template.yml').read_text();old=(P.parent/'reef-real-splats-publish/pages-splats.yml').read_text();assert text.startswith(old.split('      - name: Set up existing pinned capture dependency\n')[0])
    w=yaml.safe_load(text);previous=yaml.safe_load(old);assert w['permissions']==previous['permissions'] and w['jobs']['deploy']['timeout-minutes']==20
    steps=w['jobs']['deploy']['steps'];qa=[s for s in steps if 'node .lod-tools/browser-check-splat-lods.mjs\n' in s.get('run','')];assert len(qa)==2 and [s['env']['LOD_SEGMENT'] for s in qa]==['A','B'] and all(s['timeout-minutes']==8 for s in qa)
    assert 'node .splats-tools/browser-check-splats.mjs' not in text and 'verify-pages.mjs probe' not in text and '--update-world' not in text
    artifacts=[s for s in steps if s.get('uses')=='actions/upload-artifact@v4'];assert len(artifacts)==1 and artifacts[0]['if']=='always()' and artifacts[0]['with']['path'].split()==['lod-qa/**/*.png','lod-qa/**/*.json']
    tail=steps[steps.index(artifacts[0])+1:];assert [s['uses'] for s in tail]==['actions/configure-pages@v5','actions/upload-pages-artifact@v4','actions/deploy-pages@v4'] and all(s.get('if') in (None,'success()') for s in tail)
    checks.extend(['immutable33644byte-prior-assembly-prefix','two-sequential450s-segments8min-each-job20min','old-browser-QA-not-rerun','no-new-permissions-and-failure-artifact-only-no-deploy'])
    for name in ('lod_common.py','stage-lod.py','finalize-lod.py','verify-lod-preserved.py'):compile((T/name).read_text(),str(T/name),'exec')
    result=dict(status='PASS_LOCAL_TINYFIXTURE_TESTS',browserRun=False,gpuRun=False,note='Bookkeeping/fail-closed fixtures only; upstream chain is mocked and positive finalization bypasses GPU validation explicitly.',checks=checks)
    common.save_json(P/'local-stage-test-result.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':main()
