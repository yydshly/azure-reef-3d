"""Fail-closed publication of eight paired originals, exact combined report, gallery."""
import html
import subprocess
from lod_common import *
PASS_STATUSES=('TECHNICAL_PASS_VISUAL_PENDING','TECHNICAL_PASS_LOW_CADENCE_VISUAL_PENDING')

def validate_gpu(c,report,report_path):
    require(report['schemaVersion']==1 and report['status'] in PASS_STATUSES and report['syntheticFixture'] is False,'Complete genuine technical PASS required')
    require(report['visualStatus']==c['visualStatus'] and report['publicationAllowed'] is False,'Technical evidence cannot grant visual/publication approval')
    require(report['sourceIdentity']==source_identity(c) and report['runIdentity']==run_identity(),'Source/checkout/current run mismatch')
    require(report['scope'] in ('FULL_MOTION_COMPARED','STATIC_COMPARE_LOW_CADENCE'),'Explicit motion/static scope required')
    require(isinstance(report['limitations'],list) and report['limitations'],'Explicit limitations required')
    segments=report['segments'];require(set(segments)=={'A','B'},'Exactly independent A/B segment reports required')
    for name,r in segments.items():
        require(r['segment']==name and r['status'] in PASS_STATUSES and r['syntheticFixture'] is False,'Both complete technical segment PASS reports required')
        require(r['sourceIdentity']==report['sourceIdentity'] and r['runIdentity']==report['runIdentity'],'Cross-source/main/QA/run evidence forbidden')
        require(r['publicationAllowed'] is False and r['visualStatus']==c['visualStatus'],'Segment acceptance scope changed')
        require(r['totalBudgetMs']==450000 and all(finite(r[k]) for k in ('startedAtMs','completedAtMs','expiresAtMs')) and r['expiresAtMs']-r['startedAtMs']==450000,'Each segment requires its own450s deadline')
        require(r['startedAtMs']<=r['completedAtMs']<r['expiresAtMs'] and r['completedAtMs']<=time.time()*1000,'Segment completed outside bounded deadline')
        require(r['errors']==[] and r['failures']==[],'Technical errors/failures remain')
    require(segments['A']['completedAtMs']<=segments['B']['startedAtMs'],'Segments must be sequential, with fresh-page lifecycle')
    require(report['frames']==segments['A']['frames'] and [f['name'] for f in report['frames']]==c['frames'],'Eight original same-page A frames required')
    for f in report['frames']:
        require(f['name']==f"lod{f['lod']}-{f['view']}" and f['file']==f['name']+'.png' and [f['width'],f['height']]==[1120,712],'Frame identity/dimensions changed')
    # The same pure, adversarially tested validator is used by combine and finalization.
    # This import-only path never starts Playwright or writes evidence.
    script="import fs from 'node:fs';import {pathToFileURL} from 'node:url';const [runner,reportPath,contractPath]=process.argv.slice(2);const {validateCombined}=await import(pathToFileURL(runner));const r=JSON.parse(fs.readFileSync(reportPath));const c=JSON.parse(fs.readFileSync(contractPath));const expected=await validateCombined(r.segments.A,r.segments.B,c);const actual={...r};delete actual.segmentReportHashes;const {default:assert}=await import('node:assert/strict');assert.deepEqual(actual,expected);"
    subprocess.run(['node','--input-type=module','-e',script,'lod-finalizer-validation',str((HERE/'browser-check-splat-lods.mjs').resolve()),str(pathlib.Path(report_path).resolve()),str((HERE/'lod-contract.json').resolve())],check=True,timeout=15,capture_output=True,text=True)

def gallery(c,report,frames):
    indexed={f['name']:f for f in frames};pairs=[]
    for view in c['views']:
        figures=[]
        for lod in (4,3):
            f=indexed[f'lod{lod}-{view}'];figures.append('<figure><img loading="lazy" src="'+html.escape(f['relative'])+'" width="1120" height="712" alt="'+html.escape(f['name'])+'"><figcaption>LOD'+str(lod)+' · '+html.escape(view)+'</figcaption></figure>')
        pairs.append('<section><h2>'+html.escape(view)+'</h2><div class="pair">'+''.join(figures)+'</div><p>Detail gain, remaining coverage defects and ordinary exploration usability: human paired review pending.</p></section>')
    performance=[]
    for sample in report.get('performanceChecks',[]):
        label='LOD'+str(sample['lod'])+': '+sample['status']
        if sample['status']=='MEASURED':
            cadence=sample['cadence'];label+='; completed render submissions '+format(cadence['renderHz'],'.3f')+'/s; independent RAF callbacks '+format(cadence['rafHz'],'.3f')+'/s; sample '+format(cadence['elapsedMs']/1000,'.3f')+'s'
        else:
            label+='; sustained motion was not measured. '+sample.get('reason','Earlier measured rate below2 submissions/s stopped further sustained movement pressure.')
        performance.append('<li>'+html.escape(label)+'</li>')
    performance_html='<ul>'+''.join(performance)+'</ul>'
    scope=('STATIC_COMPARE_LOW_CADENCE: sustained motion comparison was stopped or skipped after low cadence. These static frames and safe lifecycle checks do not establish full motion performance.' if report['scope']=='STATIC_COMPARE_LOW_CADENCE' else 'FULL_MOTION_COMPARED: both bounded input samples were completed. Submission cadence is not GPU presentation FPS or client hardware performance.')
    return ('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Real splats LOD4/LOD3 paired evidence</title><style>body{max-width:2300px;margin:30px auto;padding:0 20px;font:16px/1.6 system-ui;background:#111920;color:#e8edf1}a{color:#8ad7e5}.pair{display:grid;grid-template-columns:1fr 1fr;gap:16px}figure{margin:0}img{display:block;width:100%;height:auto;border:1px solid #566}section{margin:32px 0}@media(max-width:800px){.pair{grid-template-columns:1fr}}</style><h1>Real splats LOD4 / LOD3</h1><p><a href="index.html">Independent comparison</a> · <a href="credits.html">Source and attribution</a> · <a href="assets/gpu/'+c['sourceHashAggregate']+'/report.json">Exact technical report including both bounded segments</a></p><p><strong>'+html.escape(report['status'])+' · paired visual review pending</strong></p><p>'+html.escape(scope)+'</p>'+performance_html+'<p>'+html.escape(c['acceptance'])+'</p><p>Soneva / Wildflow, capture 2026-02-18, CC BY 4.0. LOD4:30,381 original splats. LOD3:135,471 original splats. The reference rectangle is not certified continuous reef coverage. All2304 prior published files, including the world entry, remain byte-identical.</p><p>'+html.escape('; '.join(map(str,report['limitations'])))+'</p>'+''.join(pairs)+'</html>').encode()

def finalize(c):
    require(c['allowWorldUpdate'] is False and not pathlib.Path('.lod-finalized.json').exists(),'No world update or repeated finalization allowed')
    check_sources(c);protected,before=check_old(c)
    require(set(before)-set(protected)==candidate_sources(c) and len(before)==2320,'Unexpected staged files')
    out=pathlib.Path(os.environ.get('LOD_OUTPUT','lod-qa'));report_path=out/'report.json'
    require(report_path.is_file() and not report_path.is_symlink(),'Missing/linked combined report')
    raw=report_path.read_bytes();report=json.loads(raw);validate_gpu(c,report,report_path)
    # Require byte-equivalent current-run originals for both embedded segment reports.
    require(set(report['segmentReportHashes'])=={'A','B'},'Exactly two original segment byte hashes required')
    for name in ('A','B'):
        p=out/f'report-{name}.json';require(p.is_file() and not p.is_symlink() and read_json(p)==report['segments'][name],'Combined segment differs from current-run report')
        require(report['segmentReportHashes'][name]==sha(p.read_bytes()),'Original segment report byte hash mismatch')
        deadline=read_json(f'.lod-deadline-{name}.json');require(all(deadline[k]==report['segments'][name][k] for k in ('startedAtMs','expiresAtMs','totalBudgetMs')),'Current-run segment deadline mismatch')
    prefix='assets/gpu/'+c['sourceHashAggregate']+'/';products={};frames=[]
    for f in report['frames']:
        b=png_bytes(out/f['file'],f);relative=prefix+f['name']+'-'+f['sha256'][:16]+'.png';products[c['candidatePath']+'/'+relative]=b;frames.append(dict(f,relative=relative))
    products[c['candidatePath']+'/'+prefix+'report.json']=raw
    products[c['candidatePath']+'/current-scene.html']=gallery(c,report,frames)
    require(len(products)==10 and not set(products)&set(before),'Evidence collision or unexpected count')
    # Both reports and all eight PNGs validate before any public write.
    for n,b in products.items():
        p=DIST/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    records=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(products.items())]
    save_json('.lod-finalized.json',dict(schemaVersion=1,state='TECHNICAL_PASS_INDEPENDENT_PREVIEW_WORLD_UNCHANGED',status=report['status'],scope=report['scope'],sourceIdentity=source_identity(c),runIdentity=run_identity(),galleryFiles=records,protectedFiles=2304,worldEntryChanged=False,visualStatus=c['visualStatus'],appearanceAccepted=False))
    protected,current=check_old(c);check_sources(c);require(set(current)-set(protected)==candidate_sources(c)|set(products) and len(current)==2330,'Unexpected final paths')
    print('LOD_FINALIZED',json.dumps(dict(protectedFiles=2304,totalFiles=2330,newEvidenceFiles=10,status=report['status'],scope=report['scope'],appearanceAccepted=False)))
if __name__=='__main__':
    import sys
    require(len(sys.argv)==1,'No finalizer flags/world promotion supported');finalize(contract())
