# One bounded LOD4/LOD3 comparison

Status: NOT RUN for this candidate. CPU checks and synthetic lifecycle fixtures do not establish WebGL, decoder, appearance, hardware performance, or true driver-memory release. The separately archived earlier LOD4 was actually drawn using software WebGL (SwiftShader); its reported 3.233 render/s was not user-GPU performance. The user confirmed the URL opened, not visual/performance acceptance.

## Frozen comparison

- Only this independent candidate. No mainline or published probe changes and no automatic publication.
- Soneva OOTS L1, capture 2026-02-18, commit 200aaf30cda920bd9b0e5d5da8838d4165c9e289. CC BY 4.0 attribution remains visible.
- LOD4: 30,381, 7,171,392 original bytes, SHA bdf77330d5a4df5c92aa2bb0f0dcc800ccebbc471903429703309c955fd82499.
- LOD3: 135,471, 31,972,633 original bytes, SHA 85c0f7b5bdae524c47fb91dbafcfefa5365186f0be75fba52c01923f547f9b67.
- Runtime transports are single standard gzip files (3,021,212 / 13,527,171 B). Both compressed SHA and decompressed original SHA are checked. Serve as ordinary `.gz` bytes, without an extra `Content-Encoding:gzip` header; otherwise browser auto-decompression would correctly fail the wire check. No chunked files, new format, SH stripping, or transformed PLY.
- Same Spark 2.3.1 and Three 0.186.0 bytes. Same enableLod:false / enableDriveLod:false / autoUpdate:false, extSplats:true, original SH3 and baseline accumulation defaults. No opacity/color/blur/exposure changes.
- Exact original LOD4 origin `[0.45850688219070435,-2.624598979949951,-6.687568664550781]`; rigid mapping X=x−cx, Y=z−cz, Z=−(y−cy), unit scale. LOD3's own median must not recenter it.
- Fixed 1120×712, DPR1, FOV65, near0.03, far80, NoToneMapping, exposure1, sRGB, background #151920. Same reference box and guides state.
- Presets: overview `[0,8,8]`→`[0,0,0]`; side `[7.1,1.2,0]`, back `[0,1,-7.8]`, low `[-4.9,.65,5]` all target `[0,-.2,0]`.

## Required run

Use the publisher's existing, authorized browser/device route. Do not launch CI, rent GPU, create credentials, occupy cloud browser, or silently substitute renderer. `verification/gpu-contract.mjs` accepts an existing Playwright Page, never launches one. Whole run ≤450 seconds; fetch≤30s, decode≤15s, GPU update/teardown≤10s, settling≤5s, PNG≤25s. An external timeout does not cancel work; stop the page rather than layering retries.

1. Record device, browser, WebGL2 renderer/vendor, software-vs-hardware and drawing buffer dimensions. A software renderer may establish actual WebGL draw and paired pixels, but cannot establish client smoothness. The failed local-browser initialization has not tested the user's computer.
2. Verify both levels' counts, raw and transport SHA, parsed SH degree3 / effective SH degree3, no generated automatic lodSplats, exactly one active SplatMesh. Parsing alone is insufficient: require the Spark-phase actual gl instanced draw hook, positive instances, no GL/shader/runtime errors or lost context.
3. Capture eight full PNGs and JSON reports, named lod4-overview/side/back/low and lod3-overview/side/back/low. Use all four exact presets and same viewport, projection matrix, quaternion, exposure, SH and guides. Allow ≤5s settling per frame. Capture readback hides guides only to count nonbackground pixels; then restores them for screenshot. Pixel coverage does not prove completeness. Save PNG SHA and dimensions.
4. Inspect each pair at identical scale, with matching unaltered crops if needed. Separate coral-detail/readability gains from absent/back/underside coverage. Original LOD4 baseline has overview morphology, blurred near-side detail, thin rear sheet and broad blurred low-angle band. Those observations do not predetermine LOD3. Record `gain: clear/minor/none`, `remaining defects`, and `ordinary exploration usable: yes/no/uncertain` for every preset. No beauty-only camera, fog, overlays that conceal defects, arbitrary exposure, inpainting or new geometry.
5. For each level, use real W key input for ≥10s and real pointer drag/backward/reset. Record completed renderer.render submissions/s separately from an independent RAF callback count. Built-in frameWork is CPU/await time, not FPS. In-motion render<20/s must retain a low-cadence label; <2/s over the sample, stalled GPU operation, OOM or recurring context-loss ends the run. Do not claim the independent RAF cadence is render FPS. These are submit rates, not direct GPU presentation timings.
6. Switching preserves camera and projection exactly, unloads the old mesh/Spark/guides/renderer and sort worker before fetching/decoding the new LOD. Execute 3 unload/reload cycles (3→4→3→4); record object counts and available heap, not an invented zero VRAM claim. After unload: no active LOD, count/bytes zero, hash null, scene children0, meshCleared, sortWorkerCleared, frame callbacks stopped. The global decoder/WASM pool can remain resident.
7. Real-browser regression: rapid LOD3→4→3; unload during fetch, decoding and evidence capture; missing gzip file then one retry; pointercancel/lostcapture/blur/hidden must release movement; guides/boundary warning must remain honest. Only the final successful token may change current LOD. A pending decoder is awaited; timeout quarantines the page and blocks every new load until full reload. Do not dispose in-flight decoder data and then start another mesh. Synthetic CPU tests cover control flow but do not replace these checks.
8. Resource report: source-array payload and Three object counts are partial. JS heap only if supported. GPU/WASM/driver peak totals are unknown unless actually measured. The source/accumulator/order payload estimate and conservative planning envelope are not OOM guarantees. Compare memory growth across cycles only after settling and with device caveats.

## Decision and stop

- If LOD3 remains unreadable at the same ordinary viewpoints, or the rear/low structural defect does not meaningfully improve, stop upgrading. No automatic LOD2/1/0, Tabuhan, more scenes, or hidden source replacement.
- Detail can improve while geometry/coverage still fails; report both. A detail improvement is not approval for a complete world or public/mainline integration.
- Classify final result as TECHNICAL_FAIL, DETAIL_GAIN_BUT_COVERAGE_FAIL_STOP, INSUFFICIENT_DETAIL_GAIN_STOP, or DETAIL_GAIN_SMALL_PATCH_ONLY. If source coverage remains uncertain, state it; don't infer missing faces from center bounds alone.
- Publisher may prepare one bounded real comparison only after parent coordination. Returning source/Library backups is not publication approval.
