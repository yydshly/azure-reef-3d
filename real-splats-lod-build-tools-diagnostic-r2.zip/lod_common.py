"""Independent paired LOD evidence; all 2304 old bytes remain immutable."""
import gzip
import hashlib
import json
import math
import os
import pathlib
import re
import stat
import struct
import time
import zipfile
HERE=pathlib.Path(__file__).resolve().parent
DIST=pathlib.Path('dist')
INPUTS=pathlib.Path('.lod-inputs')
def require(ok,message):
    if not ok: raise ValueError(message)
def sha(data): return hashlib.sha256(data).hexdigest()
def read_json(path): return json.loads(pathlib.Path(path).read_text())
def json_bytes(value): return (json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def save_json(path,value): pathlib.Path(path).write_bytes(json_bytes(value))
def finite(value): return type(value) in (int,float) and math.isfinite(value)
def safe_name(name):
    require(isinstance(name,str) and bool(name),'Missing path')
    p=pathlib.PurePosixPath(name)
    require(not p.is_absolute() and '..' not in p.parts and '\\' not in name and p.as_posix()==name and name!='.','Unsafe path: '+name)
    return p
def inventory(root):
    root=pathlib.Path(root);require(root.is_dir() and not root.is_symlink(),'Missing or linked root')
    result={}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink() and (p.is_file() or p.is_dir()),'Linked or special path')
        if p.is_file(): result[p.relative_to(root).as_posix()]=sha(p.read_bytes())
    return result
def file_record(path,relative=None):
    p=pathlib.Path(path);b=p.read_bytes();return dict(path=relative or p.name,bytes=len(b),sha256=sha(b))
def validate_bytes(data,record,label):require(len(data)==record['bytes'] and sha(data)==record['sha256'],'Size/SHA mismatch: '+label)
def checked_archive(path,archive,expected):
    p=pathlib.Path(path);require(p.is_file() and not p.is_symlink(),'Missing/linked archive');validate_bytes(p.read_bytes(),archive,str(p))
    require(p.stat().st_size<=25000000,'Archive exceeds authorized 25 MB upload limit')
    with zipfile.ZipFile(p) as z:
        require(len(z.namelist())==len(set(z.namelist()))==len(expected) and set(z.namelist())==set(expected),'Archive file set mismatch')
        result={}
        for info in z.infolist():
            safe_name(info.filename);mode=info.external_attr>>16
            require(not info.is_dir() and not stat.S_ISLNK(mode) and stat.S_IFMT(mode) in (0,stat.S_IFREG),'Nonregular archive member')
            data=z.read(info);validate_bytes(data,expected[info.filename],info.filename);result[info.filename]=data
    return result

def contract():
    c=read_json(HERE/'lod-contract.json')
    require(c['schemaVersion']==1 and c['candidatePath']=='preview/real-splats-lod-compare' and c['basePath']=='preview/real-splats-probe' and c['entryPath']=='preview/world','Destination changed')
    require(c['baseMainCommit']=='25e3da0d85a2d3f19b1201bc72379aa57f3e31b9' and c['baseSourceCommit']=='c20a49ce1b69f1d248aef77d425726516e3a9ff5','Baseline changed')
    require([c[k] for k in ('oldAssemblyProtectedFiles','oldAssemblyFiles','oldSiteFiles','protectedFiles','rootFiles','newSourceFiles','newGalleryFiles','stagedSiteFiles','finalSiteFiles')]==[2283,2298,2304,2304,79,16,10,2320,2330],'File count contract changed')
    require(c['frames']==[f'lod{l}-{v}' for l in [4,3] for v in ['overview','side','back','low']] and c['frameSize']==[1120,712],'Paired frame contract changed')
    require(c['allowWorldUpdate'] is False and c['technicalPassAllows']=='INDEPENDENT_PREVIEW_ONLY' and c['visualStatus']=='PENDING_HUMAN_PAIRED_4_VIEW_REVIEW','No world/visual acceptance allowed')
    require(c['immutableWorldPaths']==['preview/world/current-world.json','preview/world/index.html','preview/world/world.css'],'World protection changed')
    require(len(c['sourceFiles'])==len(c['sourceHashes'])==16 and {f['path']:f['sha256'] for f in c['sourceFiles']}==c['sourceHashes'],'Source manifest changed')
    require(sha(''.join(n+'\0'+c['sourceHashes'][n]+'\n' for n in sorted(c['sourceHashes'])).encode())==c['sourceHashAggregate']=='8a9e28c3c1baef1b7cd35cb5ded1244f80f0bb2c2b0c5c59444d2e85fb187a9e','Frozen source aggregate changed')
    require(c['sourceArchive']=={'path':'reef-real-splats-LOD3-STATIC-WEB.zip','bytes':17831987,'sha256':'15c8e639616cea236010011d51cc7ee5decbacdd8d5c376682c6557f479bbcf0'},'Frozen static v1 changed')
    require(c['stopSustainedPressureBelowHz']==2 and c['lowCadenceBelowHz']==20 and c['motionScopes']==['FULL_MOTION_COMPARED','STATIC_COMPARE_LOW_CADENCE'],'Authorized static low-cadence policy changed')
    require(c['limits']=={'totalMs':450000,'pngMs':25000,'fetchMs':30000,'decodeMs':15000,'loadMs':45000,'gpuMs':10000,'settleMs':5000,'performanceMs':10000} and c['segmentBudgetsMs']=={'A':450000,'B':450000},'Authorized A/B operation bounds changed')
    require(c['dependencyPins']=={'spark':'2.3.1','three':'0.186.0','threeRevision':'186','sameThreeAsBaseline':'verified-live'},'Dependency pins changed')
    require(c['source']['commit']=='200aaf30cda920bd9b0e5d5da8838d4165c9e289' and c['source']['license']=='CC BY 4.0','Dataset provenance changed')
    expected={4:(30381,7171392,'bdf77330d5a4df5c92aa2bb0f0dcc800ccebbc471903429703309c955fd82499',3021212,'309e7d40ab38ce3afb1ba7359fe97439de8e363643730ff6c401f62fdfeee816'),3:(135471,31972633,'85c0f7b5bdae524c47fb91dbafcfefa5365186f0be75fba52c01923f547f9b67',13527171,'d7ed8dd3d67aa29610ca5c9a085985629a6d4c0617d177dabadd874dccd51345')}
    for lod,values in expected.items():
        a=c['assets'][str(lod)];require((a['count'],a['bytes'],a['sha256'],a['transport']['bytes'],a['transport']['sha256'])==values and a['shDegree']==3 and a['transport']['encoding']=='gzip','Original LOD identity changed')
    require(set(c['assets'])=={'4','3'} and c['coordinates']['rawOrigin']==[0.45850688219070435,-2.624598979949951,-6.687568664550781] and c['coordinates']['uniformScale']==1,'LOD set/original mapping changed')
    return c

def assembly_protection(c):
    import splats_common as previous
    old=previous.contract()
    require(old['candidatePath']==c['basePath'] and old['sourceHashes']==c['baseSourceHashes'] and old['sourceHashAggregate']==c['baseSourceHashAggregate'],'Immutable upstream identity changed')
    protected,_=previous.check_old(old);previous.check_sources(old)
    require(len(protected)==2283,'Upstream protected count changed')
    return protected

def baseline_hashes(c):
    protected=assembly_protection(c);public={f['path']:f['sha256'] for f in c['oldPublicFiles']}
    require(len(c['oldPublicFiles'])==len(public)==21 and not set(public)&set(protected),'Prior publication overlap/incomplete')
    baseline=dict(protected,**public);require(len(baseline)==2304,'2304 old bytes required')
    require(all(baseline[f['path']]==f['sha256'] for f in c['worldEntryFiles']),'World identity changed')
    return baseline

def snapshot(c):
    records={f['path']:f for f in c['snapshotFiles']}
    require(len(records)==6 and all(n.startswith(c['basePath']+'/') for n in records),'Exactly six old probe evidence products required')
    result=checked_archive(INPUTS/c['snapshotArchive']['path'],c['snapshotArchive'],records)
    public={f['path']:f for f in c['oldPublicFiles']}
    require(all(public.get(n)==f for n,f in records.items()) and set(public)=={c['basePath']+'/'+n for n in c['baseSourceHashes']}|set(records),'Old published snapshot mismatch')
    require(not set(records)&set(c['immutableWorldPaths']),'World restoration forbidden')
    return result

def candidate_sources(c):return {c['candidatePath']+'/'+n for n in c['sourceHashes']}
def check_sources(c):
    for f in c['sourceFiles']:
        p=DIST/c['candidatePath']/f['path'];require(p.is_file() and not p.is_symlink(),'Missing/linked source');validate_bytes(p.read_bytes(),f,f['path'])
def check_old(c):
    baseline=baseline_hashes(c);require(read_json('.lod-baseline.json')==baseline and read_json('.lod-protected.json')==baseline,'Exact protected baseline changed')
    current=inventory(DIST)
    for n,h in baseline.items(): require(current.get(n)==h,'Old file changed/missing: '+n)
    root=read_json('.root-site-hashes.json');require(len(root)==79 and {n:h for n,h in current.items() if not n.startswith('preview/')}==root,'Original root bytes changed')
    return baseline,current

def source_identity(c):
    identity=dict(candidateSourceCommit=os.environ.get('LOD_SOURCE_COMMIT',''),checkoutCommit=os.environ.get('GITHUB_SHA',''),candidatePath=c['candidatePath'],sourceHashAggregate=c['sourceHashAggregate'],sourceFiles=16,baseMainCommit=c['baseMainCommit'])
    require(all(re.fullmatch('[0-9a-f]{40}',identity[k]) for k in ('candidateSourceCommit','checkoutCommit')),'Exact source/checkout commits required');return identity

def run_identity():
    result=dict(runId=os.environ.get('GITHUB_RUN_ID',''),runAttempt=os.environ.get('GITHUB_RUN_ATTEMPT',''),qaCommit=os.environ.get('GITHUB_SHA',''))
    require(re.fullmatch('[0-9]+',result['runId']) and re.fullmatch('[0-9]+',result['runAttempt']) and re.fullmatch('[0-9a-f]{40}',result['qaCommit']),'Exact run/attempt identity required');return result

def png_bytes(path,record):
    p=pathlib.Path(path);require(p.is_file() and not p.is_symlink(),'Missing/linked PNG');b=p.read_bytes();validate_bytes(b,record,str(p))
    require(len(b)>32 and b[:8]==b'\x89PNG\r\n\x1a\n' and b[12:16]==b'IHDR','Invalid PNG')
    require(struct.unpack('>II',b[16:24])==(1120,712) and (record['width'],record['height'])==(1120,712),'1120x712 original PNG required');return b
