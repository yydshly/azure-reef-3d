"""Pure synthetic schema mutations. Does not create browser or publish evidence."""
from pathlib import Path
import copy,importlib.util,json,os,subprocess,sys,tempfile,time
T=Path(__file__).resolve().parent;P=T.parent;sys.path.insert(0,str(T))
import lod_common as common
spec=importlib.util.spec_from_file_location('finalizer',T/'finalize-lod.py');final=importlib.util.module_from_spec(spec);spec.loader.exec_module(final)
checks=[]
def main():
    c=common.contract()
    script="import fs from 'node:fs';import {pathToFileURL} from 'node:url';const [fixtures,runner,contract]=process.argv.slice(1);const {makeValidReports}=await import(pathToFileURL(fixtures));const {validateCombined,cadenceSummary}=await import(pathToFileURL(runner));const c=JSON.parse(fs.readFileSync(contract));const {a,b}=makeValidReports(c);const full=validateCombined(a,b,c);const x=makeValidReports(c);x.a.performanceChecks[0].cadence=cadenceSummary({elapsedMs:10000,renderedFrames:10,rafCallbacks:600});x.a.performanceChecks[1]={lod:3,status:'SKIPPED_STOP_SUSTAINED_PRESSURE'};x.a.scope=x.b.scope='STATIC_COMPARE_LOW_CADENCE';x.a.status=x.b.status='TECHNICAL_PASS_LOW_CADENCE_VISUAL_PENDING';process.stdout.write(JSON.stringify({full,static:validateCombined(x.a,x.b,c)}));"
    result=subprocess.run(['node','--input-type=module','-e',script,str(T/'lod-test-fixtures.mjs'),str(T/'browser-check-splat-lods.mjs'),str(T/'lod-contract.json')],check=True,capture_output=True,text=True)
    fixtures=json.loads(result.stdout);good=fixtures['full']
    envkeys=['LOD_SOURCE_COMMIT','GITHUB_SHA','GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT'];original={k:os.environ.get(k) for k in envkeys}
    os.environ.update(LOD_SOURCE_COMMIT=good['sourceIdentity']['candidateSourceCommit'],GITHUB_SHA=good['runIdentity']['qaCommit'],GITHUB_RUN_ID=good['runIdentity']['runId'],GITHUB_RUN_ATTEMPT=good['runIdentity']['runAttempt'])
    try:
        with tempfile.TemporaryDirectory(prefix='lod-schema-',dir=P) as tmp:
            p=Path(tmp)/'SYNTHETIC-TEST-ONLY.json'
            def validate(r):
                common.save_json(p,r);final.validate_gpu(c,r,p)
            validate(good);checks.append('synthetic-full-schema-accepted-only-as-validator-unit-fixture')
            validate(fixtures['static']);checks.append('approved-below2-static-scope-with-skipped-second-motion-accepted')
            def rejects(label,change):
                r=copy.deepcopy(good);change(r)
                try:validate(r)
                except (ValueError,KeyError,AssertionError,subprocess.CalledProcessError):checks.append(label);return
                raise AssertionError('Accepted bad report: '+label)
            rejects('synthetic-marker-rejected',lambda r:r.update(syntheticFixture=True))
            rejects('subset-status-rejected',lambda r:r.update(status='TECHNICAL_SUBSET_PASS_VISUAL_PENDING'))
            rejects('visual-pass-rejected',lambda r:r.update(visualStatus='VISUAL_PASS'))
            rejects('publication-approval-rejected',lambda r:r.update(publicationAllowed=True))
            rejects('foreign-current-source-rejected',lambda r:r['sourceIdentity'].update(candidateSourceCommit='f'*40))
            rejects('cross-run-segment-rejected',lambda r:r['segments']['B']['runIdentity'].update(runId='99999999'))
            rejects('cross-source-segment-rejected',lambda r:r['segments']['B']['sourceIdentity'].update(sourceHashAggregate='0'*64))
            rejects('unbounded-segment-rejected',lambda r:r['segments']['A'].update(totalBudgetMs=900000))
            rejects('late-segment-rejected',lambda r:r['segments']['B'].update(completedAtMs=r['segments']['B']['expiresAtMs']+1))
            rejects('overlapping-segments-rejected',lambda r:r['segments']['B'].update(startedAtMs=r['segments']['A']['startedAtMs']))
            rejects('missing-lifecycle-rejected',lambda r:r['segments']['B']['checks'].pop('captureCancellation'))
            rejects('unobserved-decoder-rejected',lambda r:r['segments']['B']['checks']['decodeCancellation'].update(status='UNSUPPORTED_ACTUAL_STAGE'))
            rejects('missing-short-native-input-rejected',lambda r:r['segments']['A']['checks'].pop('controls3'))
            rejects('missing-eighth-image-rejected',lambda r:r['frames'].pop())
            rejects('top-level-motion-scope-tamper-rejected',lambda r:r.update(scope='STATIC_COMPARE_LOW_CADENCE' if r['scope']=='FULL_MOTION_COMPARED' else 'FULL_MOTION_COMPARED'))
            rejects('top-level-checks-tamper-rejected',lambda r:r.update(checks={}))
            rejects('paired-frame-filename-rejected',lambda r:r['frames'][0].update(file='../stale.png'))
            rejects('remaining-error-rejected',lambda r:r['segments']['B']['errors'].append('late runtime error'))
            # The runner tests below2/skip acceptance, actual draw/SH/pair checks and lifecycle internals.
    finally:
        for k,v in original.items():os.environ.pop(k,None) if v is None else os.environ.__setitem__(k,v)
    result=dict(status='PASS_SYNTHETIC_SCHEMA_TESTS',browserRun=False,gpuRun=False,note='Validator tests only with manufactured in-memory reports; no real GPU evidence or publication.',checks=checks)
    common.save_json(P/'local-finalizer-test-result.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':main()
