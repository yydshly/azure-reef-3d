"""Restore six old probe products, freeze2304oldfiles, stage16newfiles."""
from lod_common import *
def stage(c):
    require(not (DIST/c['candidatePath']).exists(),'Candidate destination exists')
    require(not any(pathlib.Path(n).exists() for n in ('.lod-protected.json','.lod-baseline.json','.lod-build.json')),'Stage already attempted')
    before=inventory(DIST);protected=assembly_protection(c)
    staged={c['basePath']+'/'+f['path']:f['sha256'] for f in c['baseSourceFiles']}
    require(not set(staged)&set(protected) and before==dict(protected,**staged) and len(before)==2298,'Exact immutable2298-file prior assembly required')
    restore=snapshot(c);require(not set(restore)&set(before),'Restoration must only add missing evidence')
    baseline=dict(before,**{n:sha(b) for n,b in restore.items()});require(baseline==baseline_hashes(c),'Cannot reproduce exact2304-file publication')
    candidate=checked_archive(INPUTS/c['sourceArchive']['path'],c['sourceArchive'],{f['path']:f for f in c['sourceArchiveFiles']})
    require({n:sha(b) for n,b in candidate.items()}==c['sourceHashes'],'Frozen source extraction mismatch')
    # Full wire and original payload identity check precedes any write.
    for lod in ('4','3'):
        a=c['assets'][lod];wire=candidate[a['url'].removeprefix('./')];validate_bytes(wire,a['transport'],'LOD'+lod+' gzip');raw=gzip.decompress(wire);validate_bytes(raw,a,'LOD'+lod+' original PLY')
    for n,b in restore.items():
        p=DIST/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    require(inventory(DIST)==baseline,'Old gallery restoration failed')
    save_json('.lod-baseline.json',baseline);save_json('.lod-protected.json',baseline)
    for n,b in candidate.items():
        p=DIST/c['candidatePath']/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    save_json('.lod-build.json',dict(schemaVersion=1,state='STAGED_ALL_2304_OLD_FILES_PROTECTED',protectedFiles=2304,sourceFiles=16,sourceHashAggregate=c['sourceHashAggregate'],worldEntryChanged=False))
    check_sources(c);protected,current=check_old(c);require(set(current)-set(protected)==candidate_sources(c) and len(current)==2320,'Unexpected stage output')
    print('LOD_STAGED',json.dumps(dict(protectedFiles=2304,sourceFiles=16,totalFiles=2320)))
if __name__=='__main__':stage(contract())
