# Independent real-splat LOD comparison publication preparation

Local preparation only. No repository upload, workflow dispatch, browser/GPU run, paid compute, new permissions, additional LOD downloads, or public changes were made by this preparation.

## Immutable inputs and chain

- The frozen Library v1 static web archive is used unchanged: reef-real-splats-LOD3-STATIC-WEB.zip,17,831,987B,SHA25615c8e639616cea236010011d51cc7ee5decbacdd8d5c376682c6557f479bbcf0. It contains16runtime files. The46,034,720B full source archive is not an upload input.
- Dataset revision200aaf30cda920bd9b0e5d5da8838d4165c9e289; Soneva OOTS L1,2026-02-18,CC BY4.0. LOD4 has30,381 splats and7,171,392 original bytes; LOD3 has135,471 splats and31,972,633 original bytes.
- Gzip transports remain3,021,212B /13,527,171B, with original SHA and wire SHA verified independently. Gzip must be served as ordinary .gz bytes, without a second Content-Encoding:gzip response header. No transformed PLY, SH stripping, chunking, new renderer or appearance change is allowed.
- Prior main25e3da0d85a2d3f19b1201bc72379aa57f3e31b9 and prior QA c20a49ce1b69f1d248aef77d425726516e3a9ff5. The complete33,644-byte immutable assembly prefix from pages-splats.yml is retained byte for byte, including all existing pinned archives/tools and stage-splats.py. Prior browser QA is not rerun.
- Stage-lod restores exactly six saved published probe products (four old PNGs, exact old report and gallery), reproduces all2304 old files, verifies the three world entry hashes, freezes all2304 hashes and adds only16 new source files at preview/real-splats-lod-compare. Finalization adds only eight new PNGs, one exact combined report and a gallery:2330 total files.

## Parent-coordinated bounded execution amendment

The candidate GPU-TEST-CONTRACT remains frozen. The publisher's authorized test orchestration was subsequently narrowed into two sequential, separately bounded segments to make mandatory coverage explicit:

- Segment A: one page, matched eight original1120x712 PNGs, both source identities/actual Spark-phase GL draws/SH3, exact paired camera and render policy, camera-preserving switch, required brief native movement/drag/backward/reset for both levels, and bounded10-second W performance samples.
- Segment B: fresh page, safe lifecycle checks including3 unload/reload cycles, rapidLOD3→4→3, unload during fetch/decoding/capture, one missing-asset failure/retry, honest reference boundary/guides, movement release, final teardown. No movement trajectory may be spliced across pages or segments.
- Each segment has its own450,000ms hard deadline and8-minute workflow step. The existing overall job limit remains20minutes. Both reports must agree on frozen source/main/QA/run/attempt and pass required technical checks before evidence can be finalized.
- Completed render submission rate below20/s retains LOW_CADENCE. Below2/s stops extra sustained movement pressure; it alone is not a technical failure. If LOD4 causes that stop, LOD3 sustained W can be SKIPPED_STOP_SUSTAINED_PRESSURE. Its short necessary controls, eight static frames and safe lifecycle checks still must pass. The final scope must be FULL_MOTION_COMPARED or STATIC_COMPARE_LOW_CADENCE; a skipped sample must never be represented as measured motion performance.
- Missing identity, actual draw, safe switching, required inputs or lifecycle evidence fails closed. OOM, stalled/quarantined GPU operation, recurring context loss or unsafe teardown cannot publish.
- Performance is completed renderer.render submissions, separately from independent RAF callbacks. Neither is hardware presentation FPS. Software rendering cannot establish user-GPU performance. Driver/WASM/total memory release remains unknown unless measured.

## Acceptance

TECHNICAL_PASS_VISUAL_PENDING or TECHNICAL_PASS_LOW_CADENCE_VISUAL_PENDING is eligible only for the separately authorized independent preview. The finalizer validates both original reports through the runner's pure combined validator, independently checks source/run identity/deadlines/frame dimensions, checks all8 PNG hashes, checks all protected old bytes and rejects mismatched or incomplete evidence before writes.

Visual review remains PENDING_HUMAN_PAIRED_4_VIEW_REVIEW. Each same-scale pair needs clear/minor/none detail gain, remaining defects and ordinary exploration usability yes/no/uncertain. Detail gain and rear/underside coverage are separate judgments. No world promotion, new data download or appearance acceptance follows from this result.

Failure retains only current lod-qa PNG/JSON artifacts for7days; GitHub Pages steps remain success-only. No new permissions or fees are added.
