// LOCAL ONLY. CPU/controller and mocked DOM regressions; never a browser/GPU result.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createExplorationNavigation} from '../../reef-exploration-demo-candidate/page/exploration-navigation.js';
import {EXPLORATION_TOUR_STOPS as stops,resolvePosition,regionAt} from '../../reef-exploration-demo-candidate/page/exploration-world-data.js';
import {validateTimeline,FRAME_COLUMNS,assertDirectional,validateCollisionObservation,validateCollisionToggle,assertTourCaptureCoverage,validateExplorationBinding,validateSegmentPair} from './exploration-qa-math.mjs';
import {nativeClick,nativeRect,nativeHeadingDrag} from './browser-observe-exploration.mjs';
import {runExplorationQA} from './browser-check-exploration.mjs';
assert.equal(typeof runExplorationQA,'function');
const fixtures=[];
for(const fps of [10,30,60]){
 const make=()=>{const nav=createExplorationNavigation({stops,resolvePosition,regionAt}),rows=[];let now=0,sequence=0;nav.enter();return{nav,rows,push(phase,advance=true){if(advance){now+=1000/fps;nav.tick(1/fps);}const r=nav.getState();rows.push([now,sequence++,phase,{free:0,tour:1,completed:2}[r.mode],+r.paused,r.elapsed,...r.position,r.yaw,r.pitch,r.speed,(r.heldKeys.includes('KeyW')?1:0)|(r.heldKeys.includes('ShiftLeft')?64:0),r.position[2]>-120?0:r.position[2]>-245?1:2,0]);}};};
 const free=make();free.push(2,false);free.nav.key('KeyW',true);for(let i=0;i<3;i++)free.push(2);free.nav.key('ShiftLeft',true);while(free.nav.getState().position[2]>=-60)free.push(2);free.nav.key('ShiftLeft',false);free.nav.key('KeyW',false);free.push(2);
 const tour=make();tour.nav.startTour();tour.push(5,false);let index=0;while(tour.nav.getState().mode!=='completed'){if(++index===fps*15){tour.nav.pause(true);for(let i=0;i<fps;i++)tour.push(5);tour.nav.pause(false);}tour.push(5);}
 const freeResult=validateTimeline(free.rows,{segment:'free-compat',stops,resolvePosition}),tourResult=validateTimeline(tour.rows,{segment:'tour',stops,resolvePosition});assert(freeResult.continuousFreeCrossing&&!freeResult.completeTour&&freeResult.normalMovedSteps>0&&freeResult.boostedMovedSteps>0);assert(tourResult.completeTour&&!tourResult.continuousFreeCrossing);assert(tourResult.activeTourSeconds>71.99);assert(freeResult.maxFreeStep<=.6300001);assert(tourResult.maxAnalyticError<1e-8);fixtures.push({fps,freeRows:free.rows,tourRows:tour.rows,freeResult,tourResult});
}
const mutate=(segment,change)=>{const copy=structuredClone(segment==='tour'?fixtures[2].tourRows:fixtures[2].freeRows);change(copy);assert.throws(()=>validateTimeline(copy,{segment,stops,resolvePosition}));};
mutate('free-compat',r=>{r[5][6]+=2;});
mutate('free-compat',r=>{r[10][0]=r[9][0];});
mutate('tour',r=>{const n=r.findIndex(x=>x[5]>30);r[n][8]+=3;});
mutate('tour',r=>{const n=r.findIndex(x=>x[4]===1);r[n+1][5]+=.1;});
mutate('tour',r=>{r.splice(r.findIndex(x=>x[3]===2));});
mutate('tour',r=>{for(const x of r)if(x[13]===1)x[13]=0;});
mutate('free-compat',r=>{r[2][11]=8;});
mutate('free-compat',r=>{r[6][11]=13;});
mutate('free-compat',r=>{for(const x of r)if(x[12]===65)x[12]=1;});
mutate('tour',r=>{r[0][2]=2;});
const common={schemaVersion:2,syntheticFixture:false,status:'PASS',totalBudgetMs:450000,errors:[],failures:[],sourceIdentity:{sourceHashAggregate:'frozen149',baseMainCommit:'main',checkoutCommit:'qa'},runIdentity:{runId:'123',runAttempt:'1',qaCommit:'qa'}};
const a={...common,segment:'tour',startedAtMs:1000,completedAtMs:2100,expiresAtMs:451000},b={...common,segment:'free-compat',startedAtMs:2200,completedAtMs:3100,expiresAtMs:452200};assert(validateSegmentPair(a,b));assert.throws(()=>validateSegmentPair(null,b));assert.throws(()=>validateSegmentPair(a,null));assert.throws(()=>validateSegmentPair(a,{...b,sourceIdentity:{...b.sourceIdentity,sourceHashAggregate:'another'}}));assert.throws(()=>validateSegmentPair({...a,completedAtMs:a.expiresAtMs},b));assert.throws(()=>validateSegmentPair(a,{...b,completedAtMs:b.expiresAtMs}));assert.throws(()=>validateSegmentPair(a,{...b,runIdentity:{...b.runIdentity,runAttempt:'2'}}));
assert.throws(()=>assertDirectional([0,0,0],[1,0,0],[0,0,-1]));assertDirectional([0,0,0],[0,0,-.2],[0,0,-1]);
assert.equal(FRAME_COLUMNS.length,15);assertTourCaptureCoverage('tour-initial',[]);for(const name of['tour-grass-bay','tour-completed']){assert.throws(()=>assertTourCaptureCoverage(name,[]));assertTourCaptureCoverage(name,[{materialType:'MeshStandardMaterial',standardPBR:true,waterVertex:true,waterFragment:true}]);}

const standard={meshNames:['Open_Bay_Seagrass_Meadow_0'],materialType:'MeshStandardMaterial',draws:1,linked:true,compiled:true,glError:0,standardPBR:true,waterVertex:true,waterFragment:true};validateExplorationBinding(standard);
const basic={meshNames:['Extended_Overhead_Water'],materialType:'MeshBasicMaterial',draws:1,linked:true,compiled:true,glError:0,standardPBR:false,waterVertex:false,waterFragment:false,materialProperties:{transparent:true,opacity:.12,side:2,depthWrite:false},basicShader:{diffuseActive:true,opacityActive:true,diffuse:[.02732089163382382,.1844749944900301,.20863687013464577],opacity:.12,basicFragment:true,blendEnabled:true,depthWriteMask:false}};validateExplorationBinding(basic);assert.throws(()=>validateExplorationBinding({...basic,meshNames:['Broken_Scan_Derived_Reef_2']}));assert.throws(()=>validateExplorationBinding({...basic,meshNames:['Extended_Overhead_Water','other']}));assert.throws(()=>validateExplorationBinding({...basic,waterFragment:true}));assert.throws(()=>validateExplorationBinding({...basic,basicShader:{...basic.basicShader,opacity:.3}}));assert.throws(()=>validateExplorationBinding({...standard,standardPBR:false}));for(const name of['tour-grass-bay','tour-completed']){assert.throws(()=>assertTourCaptureCoverage(name,[basic]));assertTourCaptureCoverage(name,[basic,standard]);}

const calls=[],element={id:'scanCanvas',tagName:'CANVAS',disabled:false,hidden:false,parentElement:null,style:{display:'block',visibility:'visible',opacity:'1'},getBoundingClientRect:()=>({x:0,y:68,width:1120,height:712}),contains:()=>false,scrollIntoView:()=>calls.push(['scroll'])};
globalThis.document={getElementById:()=>element,elementFromPoint:()=>element};globalThis.innerWidth=1120;globalThis.innerHeight=780;globalThis.getComputedStyle=e=>e.style;
const page={evaluate:async(fn,arg)=>fn(arg),mouse:{click:async(...a)=>calls.push(['click',...a]),move:async(...a)=>calls.push(['move',...a]),down:async()=>calls.push(['down']),up:async()=>calls.push(['up'])}};
const box=await nativeClick(page,'scanCanvas');assert.equal(box.px,560);assert.equal(box.py,424);assert(calls.some(c=>c[0]==='click'));
await nativeHeadingDrag(page,.65);assert.equal(calls.filter(c=>c[0]==='down').length,1);assert.equal(calls.filter(c=>c[0]==='up').length,1);const moves=calls.filter(c=>c[0]==='move');assert.equal(moves[1][1]-moves[0][1],162.5);
element.disabled=true;await assert.rejects(nativeRect(page,'scanCanvas'),/Disabled/);element.disabled=false;element.style.visibility='hidden';await assert.rejects(nativeRect(page,'scanCanvas'),/Hidden/);element.style.visibility='visible';document.elementFromPoint=()=>({id:'overlay'});await assert.rejects(nativeRect(page,'scanCanvas'),/obscured/);
for(const k of['document','innerWidth','innerHeight','getComputedStyle'])delete globalThis[k];

const largeNames=[...Array.from({length:3},(_,i)=>'Ridge_'+i),...Array.from({length:6},(_,i)=>'RearConnected_'+i),'Local_Grounded_Scan_Derived_Shoulder'],baseNames=Array.from({length:44},(_,i)=>'Original_'+i);
const collisionSample=(names,scanCount,layered)=>({reported:{source:'live-world-obstacles-plus-scan-anchors',worldCount:names.length,scanCount,total:names.length+scanCount,worldNames:names},actual:{worldCount:names.length,scanCount,worldNames:names,boxes:names.map(name=>({name,min:[0,0,0],max:[1,1,1]}))},loading:{layeredRidges:layered}});
const early=collisionSample(baseNames,1,'idle'),ready=collisionSample([...baseNames,...largeNames],2,'ready'),collision={samples:[early,ready],current:ready};assert(validateCollisionObservation(collision,{requireLateLoad:true}).lateLoadObserved);
const stale=structuredClone(collision);stale.current.reported.worldNames=baseNames;assert.throws(()=>validateCollisionObservation(stale));const missing=structuredClone(collision);missing.samples=[ready];assert.throws(()=>validateCollisionObservation(missing,{requireLateLoad:true}));assert.equal(validateCollisionObservation(missing).matchingLiveWorld,true);assert.equal(validateCollisionObservation(missing).lateLoadObserved,false);const nativeOff=collisionSample(baseNames,2,'ready'),nativeToggle={before:ready,off:nativeOff,on:ready};assert.equal(validateCollisionToggle(nativeToggle).lateRegistrationVerified,true);assert.throws(()=>validateCollisionToggle({...nativeToggle,off:ready}));assert.throws(()=>validateCollisionToggle({...nativeToggle,on:nativeOff}));const invalidBox=structuredClone(collision);invalidBox.current.actual.boxes[0].min[0]=Infinity;assert.throws(()=>validateCollisionObservation(invalidBox));

const runner=readFileSync(new URL('./browser-check-exploration.mjs',import.meta.url),'utf8'),observer=readFileSync(new URL('./browser-observe-exploration.mjs',import.meta.url),'utf8');
assert(!runner.includes('.boundingBox(')&&!observer.includes('.boundingBox('));assert(!runner.includes("page.locator('#'+id).click"));assert(!runner.includes('dispatchEvent(')||runner.includes('No request(), tick(), injected clock, dispatchEvent()'));
for(const p of['scan-exhibit.js','exploration-navigation.js']){const expected=p==='scan-exhibit.js'?'b663e3dbb1561ef2e837ef2b2a14bc0ec0c00c016d7c82985933f69806ebb87b':'13cab5910ade6b1ff8c98cf320bf6607ce576bc8e7dcbf4add4c4446681423da',actual=createHash('sha256').update(readFileSync(new URL('../../reef-exploration-demo-candidate/page/'+p,import.meta.url))).digest('hex');assert.equal(actual,expected);}
console.log(JSON.stringify({status:'LOCAL_CPU_MOCK_PASS',browserLaunched:false,gpuEvidence:false,controllerRates:fixtures.map(f=>({fps:f.fps,free:f.freeResult,tour:f.tourResult})),rejectedMutations:30,independentTimelines:true,missingCrossSourceAndExpiredSegmentsRejected:true,basicWaterExactException:true,basicOnlyRegionalEvidenceRejected:true,regionalMaterialSubmissionRequired:true,collisionLiveContract:true,readyFirstSampleAccepted:true,nativeReregistrationRequired:true,nativeDOMChecks:['geometry','trusted-input-tool-path','disabled','hidden','obscured','drag-sign'],sourceHashesUnchanged:true},null,2));
