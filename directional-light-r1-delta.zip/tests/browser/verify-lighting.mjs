import {chromium} from 'playwright';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const target=process.env.REEF_TARGET||'http://127.0.0.1:4173/';
assert.equal(target,'http://127.0.0.1:4173/','Isolated branch preview only');
const out='render-evidence';await fs.mkdir(out,{recursive:true});
const report={scope:'Actual browser same-camera lighting comparison; human visual verdict required',candidate:{hemisphere:1.35,sun:4,shadow:.8},baseline:{hemisphere:2.7,sun:3,shadow:.45},errors:[],captures:[],passed:false};
const save=()=>fs.writeFile(`${out}/lighting.json`,JSON.stringify(report,null,2));
const watchdog=setTimeout(async()=>{report.errors.push('Six-minute bounded test budget exceeded');await save();process.exit(1)},350000);
const hash=b=>createHash('sha256').update(b).digest('hex');let browser;
try{
 browser=await chromium.launch({channel:'chromium',headless:true,chromiumSandbox:true,timeout:45000,args:['--enable-automation'],ignoreDefaultArgs:['--enable-unsafe-swiftshader','--disable-gpu-sandbox','--ignore-gpu-blocklist']});
 const cdp=await browser.newBrowserCDPSession();const {arguments:args}=await cdp.send('Browser.getBrowserCommandLine');for(const f of ['--no-sandbox','--disable-gpu-sandbox','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])assert(!args.includes(f));
 const context=await browser.newContext({viewport:{width:1120,height:700},deviceScaleFactor:1,reducedMotion:'reduce'});const page=await context.newPage();
 // Hold the app's animation at one timestamp. Each explicit step executes the
 // actual app loop, including renderer.render, without advancing fish or water.
 await page.addInitScript(()=>{window.__reefFrame=null;window.requestAnimationFrame=callback=>{window.__reefFrame=callback;return 1};window.__reefStep=()=>{if(!window.__reefFrame)throw Error('No app frame');window.__reefFrame(1000)};});
 page.on('pageerror',e=>report.errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')report.errors.push(m.text())});page.on('response',r=>{if(r.status()>=400)report.errors.push(`${r.status()} ${r.url()}`)});
 const served=await context.request.get(new URL('app.js',target).href);assert(served.ok());report.appHash=hash(await served.body());assert.equal(report.appHash,hash(await fs.readFile('dist/app.js')));
 await page.goto(target,{waitUntil:'domcontentloaded',timeout:60000});await page.waitForFunction(()=>window.reef3d?.getState().ready,null,{timeout:150000,polling:500});
 report.initialLights=await page.evaluate(()=>{const r=window.reef3d;const h=r.scene.children.find(o=>o.isHemisphereLight),s=r.scene.getObjectByName('Reef_sun');return {hemisphere:h.intensity,sun:s.intensity,shadow:s.shadow.intensity}});assert.deepEqual(report.initialLights,report.candidate);
 const views=[{name:'departure',p:[1.5,2.1,4.8],t:[-.5,.8,-6]},{name:'midway',p:[0,2.7,-18],t:[-1.5,1,-31]},{name:'look-back',p:[-3.8,3.6,-36],t:[0,.9,-8]}];
 for(const [i,v] of views.entries()){
  let invariant;
  for(const mode of ['baseline','candidate']){
   const state=await page.evaluate(({v,light})=>{const r=window.reef3d;r.leaveGuide();r.setTour(false);r.camera.position.set(...v.p);r.controls.target.set(...v.t);r.controls.update();const h=r.scene.children.find(o=>o.isHemisphereLight),s=r.scene.getObjectByName('Reef_sun');h.intensity=light.hemisphere;s.intensity=light.sun;s.shadow.intensity=light.shadow;window.__reefStep();window.__reefStep();r.root.updateMatrixWorld(true);const fish=[];r.root.traverse(o=>{if(/^fish_\d+$/.test(o.name))fish.push({name:o.name,matrix:o.matrixWorld.toArray()})});return {camera:r.camera.position.toArray(),target:r.controls.target.toArray(),fish,time:r.getState().simulationTime,fov:r.camera.fov};},{v,light:report[mode]});
   state.camera.forEach((x,j)=>assert(Math.abs(x-v.p[j])<1e-8));state.target.forEach((x,j)=>assert(Math.abs(x-v.t[j])<1e-8));assert.equal(state.fish.length,6);assert.equal(state.time,0);if(invariant)assert.deepEqual(state,invariant);else invariant=state;
   const file=`${i+1}-${v.name}-${mode}.png`;report.pendingCapture={file,state};await save();await page.screenshot({path:`${out}/${file}`,timeout:25000});report.captures.push({file,hash:hash(await fs.readFile(`${out}/${file}`)),state});delete report.pendingCapture;await save();console.log('LIGHTING_CAPTURE',file,JSON.stringify(state));
  }
 }
 report.passed=report.errors.length===0;assert(report.passed);await save();
}catch(e){report.errors.push(String(e.stack||e));process.exitCode=1;}finally{await save();console.log('LIGHTING_SUMMARY',JSON.stringify({passed:report.passed,errors:report.errors,appHash:report.appHash,initialLights:report.initialLights,captures:report.captures.map(({file,hash})=>({file,hash}))}));await browser?.close();clearTimeout(watchdog);}
