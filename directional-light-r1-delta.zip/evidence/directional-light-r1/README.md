# One bounded directional-light candidate

Status: local source/logic checks passed; actual browser pixels NOT YET rendered or accepted. No publication or deployment performed.

## Visual diagnosis

The actual baseline screenshots at departure, midway, and look-back show repeated domed hardbottom and sparse tube-like colonies. Lighting cannot fix their morphology. Repository records already reject several terrain/ledge rebuild families, so they remain rejected. This candidate addresses a narrower scene-wide cue: strong unoccluded hemisphere fill suppresses differences between sun-facing forms, undersides, and contact shadows.

## Exactly one profile

- Hemisphere intensity: 2.7 → 1.35
- Sun intensity: 3.0 → 4.0
- Sun shadow intensity: 0.45 → 0.8
- All light colors/directions, exposure 1.02, shadow resolution/filter/bias, water shader, materials, cameras, geometry, fish, guides, and independent scan exhibit are unchanged.

Analytic upward diffuse luminance is 3.452647 before and 3.450443 after, ratio 0.999361. This uses Three.js linear color conversion and the actual overhead sun angle. It is only a sanity check before water, caustics, BRDF, and tone mapping; it does not establish pixel brightness or visual improvement.

All runtime files other than app.js match the independent-exhibit baseline byte for byte. That single file differs only at the three values above. See preservation.json. Revert by restoring baseline app.js; do not touch the independent viewer.

## Fixed evaluation and stopping condition

One actual WebGL run, three existing passage cameras, same exposure, resolution, fish pose, water phase, renderer and UI. Compare baseline and candidate pairs, not unrelated prior screenshots. Use tests/browser/verify-lighting.mjs after the existing supported WebGL capability probe. This harness runs only against the isolated 127.0.0.1:4173 branch preview; it does not publish or change the production site.

The harness freezes requestAnimationFrame and calls the real app loop at one timestamp under reduced motion. Each shot is genuinely renderer.render output. It checks exact per-pair camera, target, all six fish world matrices, simulation time, source hash and declared lighting. These fixed-phase screenshots do not validate animation, native controls, performance or the user's GPU.

Review all three pairs:
1. Departure: clearer separation between exposed rock, branch bases, and surrounding sand, without merely hiding the regular mound outlines.
2. Midway: more readable underside/overlap of the left limestone composition and near-right branch contact. Fish outlines and body markings remain readable.
3. Look-back: the foreground limestone and branches gain orientation/overlap cues; shaded fish and far structures remain visible. No unacceptable black crush, glaring lit tops, or distracting new shadow artifacts.

Accept only if the benefit is visibly meaningful in the full views, with no material readability regression in another view. If the gain is unclear, simply darker, or trades one flaw for another, reject this candidate. Do not iterate a parameter grid, resurrect rejected geometry, alter exposure to rescue it, or start more environment troubleshooting. An accepted lighting stage would still NOT accept the main artificial scene's realism.

## Local checks performed on final values

- npm test: passed (guide state/integration, explicit no-WebGL fallback, actual model parsing, byte-exact static asset fidelity, guide surface anchors, water shader source checks)
- npm run test:exhibit: passed (independent exhibit source/logic and return-state checks)
- npm run test:tour-clock: passed (timing and route controls)
- node --check tests/browser/verify-lighting.mjs: passed
- Runtime file/hash preservation and exact three-value change: passed

These are source, geometry and simulated-renderer checks. Browser harness is prepared but not executed here. Local cloud browser/Chromium access is already blocked; no retry or bypass was attempted. No Blender image is presented as evidence because its illumination/tonemapping would not faithfully evaluate this Three.js change.
