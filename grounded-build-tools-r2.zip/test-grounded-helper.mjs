// CPU/mock invocation of the exact browser helper; never starts a browser.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {T,scene,ocean,world} from './build-grounded-fixture.mjs';
import {inspectGroundedPage} from './browser-inspect-grounded.mjs';
import {createRenderDemand} from '../../reef-grounded-integration-candidate/page/scan-render-demand.js';
const fixture=JSON.parse(fs.readFileSync(new URL('./grounded-fixture.json',import.meta.url)));
const camera=new T.PerspectiveCamera();camera.position.set(1,3,-4);ocean.update(7,camera);scene.updateMatrixWorld(true);
let field=null;
const e={scene,world,ocean,camera,renderer:{getContext:()=>({})},continuousField:{getState:()=>field?{enabled:true,installed:true,...field.inspect()}:{enabled:false,installed:false}}};globalThis.window={reefExhibit:e};
const page={evaluate:(fn,arg)=>fn(arg)};
const checkpoints=[];
const check=async(name,options={})=>{const report=await inspectGroundedPage(page,fixture,options);assert.deepEqual(report.issues,[],name);checkpoints.push(name);return report;};
await check('initial-source-and-fixture',{initialize:true,checkOriginals:true});
world.groundedShoulder.setEnabled(false);await check('off-source-exact-restore',{checkOriginals:true});
// Exercise the exact draw:true observer/readPixels branch with the real demand
// controller and a tiny mock GL context. This is API-contract evidence, not GPU QA.
const component=world.groundedShoulder,originalState=component.getState;
let inObserver=false,componentStateAvailable=true,stateReadsInObserver=0,pixelReads=0;
component.getState=()=>{if(inObserver){stateReadsInObserver++;if(!componentStateAvailable)throw Error('Mock component state unavailable in frame observer');}return originalState();};
const gl={drawingBufferWidth:40,drawingBufferHeight:32,RGBA:0x1908,UNSIGNED_BYTE:0x1401,isContextLost:()=>false,getError:()=>0,readPixels:(x,y,width,height,format,type,pixels)=>{assert.deepEqual([x,y,width,height,format,type],[0,0,40,32,0x1908,0x1401]);assert.equal(pixels.byteLength,40*32*4);pixelReads++;for(let i=0;i<pixels.length;i+=4){pixels[i]=(i/4)%40;pixels[i+3]=255;}}};
const demand=createRenderDemand({observerTimeoutMs:1000});
e.renderer={getContext:()=>gl,info:{render:{calls:1,triangles:1},memory:{geometries:0,textures:0}}};
e.controls={target:new T.Vector3(1,2,-10)};
e.getState=()=>({ambient:{time:7,paused:true},route:{active:true,progress:.2,goal:.2,yaw:0,pitch:0},waterMode:true});
e.getRenderDemandState=demand.getState;
e.observeNextRender=observe=>{const pending=demand.observeNextRender(receipt=>{inObserver=true;try{return observe(receipt);}finally{inObserver=false;}});demand.drawIfNeeded(()=>{});return pending;};
const callbacks=component.placed.map(m=>m.onAfterRender);
const drawn=await check('mock-draw-observer-component-and-pixels',{draw:true});
assert.equal(pixelReads,1);assert.equal(stateReadsInObserver,1);assert.deepEqual(drawn.frame.grounded,originalState());assert.equal(drawn.frame.grounded.enabled,false);assert.equal(drawn.frame.graphics.width,40);assert.equal(drawn.frame.graphics.height,32);assert.equal(drawn.frame.ambient.time,7);assert.equal(drawn.frame.ambient.paused,true);assert(drawn.frame.receipt.sequence>drawn.frame.previousSequence);assert(drawn.frame.graphics.sampleColors>=2);assert.equal(drawn.notDrawn.length,14);assert.deepEqual(component.placed.map(m=>m.onAfterRender),callbacks);
componentStateAvailable=false;
await assert.rejects(()=>inspectGroundedPage(page,fixture,{draw:true}),/Mock component state unavailable in frame observer/);
assert.equal(pixelReads,2);assert.equal(stateReadsInObserver,2);assert.equal(demand.getState().pending,0);assert.deepEqual(component.placed.map(m=>m.onAfterRender),callbacks);checkpoints.push('negative-mock-frame-component-rejection-restores-callbacks');
component.getState=originalState;componentStateAvailable=true;
const s=world.groundedShoulder.swaps[0];s.original.visible=false;let bad=await inspectGroundedPage(page,fixture);assert(bad.issues.includes('Exact OFF/ON inherited/source visibility'));s.original.visible=s.visible;checkpoints.push('negative-broken-off-detected');
world.groundedShoulder.setEnabled(true);camera.position.set(5,3,-25);ocean.update(7,camera);scene.updateMatrixWorld(true);await check('on-route-camera-follow',{checkOriginals:true});
const old=s.original.instanceMatrix.array[0];s.original.instanceMatrix.array[0]+=.25;bad=await inspectGroundedPage(page,fixture,{checkOriginals:true});assert(bad.issues.some(x=>x.startsWith('Fixture original')));assert(bad.issues.includes('Original buffer bytes'));s.original.instanceMatrix.array[0]=old;checkpoints.push('negative-source-matrix-detected');
// The minimal fixture scene does not install the pre-existing coral-midground
// replacement; use the complete field integration test already frozen in CPU QA.
// Here test the helper's documented ridge geometry exception explicitly.
const ridge=world.group.getObjectByName('Layered_Ridges_Weathered_Shoulders'),original=ridge.geometry;ridge.geometry=original.clone();field={inspect:()=>({points:1000000,displayTriangles:4000000})};await check('field-ridge-swap-preserves-original',{checkOriginals:true,field:true});ridge.geometry.dispose();ridge.geometry=original;field=null;await check('restored-source-exact',{checkOriginals:true});
const h=world.groundedShoulder,before={...world.budget};h.dispose();h.dispose();const result=await check('disposed-source-exact',{checkOriginals:true,disposed:true});assert.equal(result.protection.borrowedDisposals,0);assert.equal(world.budget.triangles,before.triangles-57158);assert.equal(world.budget.drawCalls,before.drawCalls-4);
const resultReport={status:'PASS_LOCAL_CPU_HELPER_ONLY',checkpoints,limits:'No actual browser, GPU, field draw or screenshot. The draw:true observer/readPixels/component contract uses mock GL and the actual render-demand controller. Actual field lifecycle remains the existing frozen CPU QA and future bounded browser run.'};fs.writeFileSync(new URL('../helper-local-checks.json',import.meta.url),JSON.stringify(resultReport,null,2)+'\n');console.log(JSON.stringify(resultReport,null,2));
