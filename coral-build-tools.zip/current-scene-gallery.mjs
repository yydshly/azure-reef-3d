import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
export const FRAME_PLAN=Object.freeze([
 {id:'artificial-opening',label:'人工礁区 · 珊瑚台地',world:'artificial',routeProgress:0},
 {id:'scan-terrace',label:'扩展水下区域 · 日光珊瑚台地',world:'scan',routeProgress:0},
 {id:'scan-valley',label:'扩展水下区域 · 开放礁盆',world:'scan',routeProgress:.5},
 {id:'scan-corridor',label:'扩展水下区域 · 远端暗礁',world:'scan',routeProgress:1},
 {id:'scan-turtle-encounter',label:'新增受控视角 · 前段20%海龟相遇',world:'scan',routeProgress:.2}
]);
export function computeContentVersion(m){return createHash('sha256').update(JSON.stringify({sourceFiles:m.sourceFiles,captureScriptSha256:m.captureScriptSha256,galleryScriptSha256:m.galleryScriptSha256,viewport:m.viewport,frames:FRAME_PLAN})).digest('hex');}
export const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function validateManifest(m){
 assert.equal(m.schema,1);assert.match(m.contentVersion,/^[a-f0-9]{64}$/);assert.match(m.captureScriptSha256,/^[a-f0-9]{64}$/);assert.match(m.galleryScriptSha256,/^[a-f0-9]{64}$/);
 assert.match(m.checkoutCommit,/^[a-f0-9]{40}$/);assert.match(m.candidateArchiveSha256,/^[a-f0-9]{64}$/);assert.match(m.candidateSourceCommit,/^[a-f0-9]{40}$/);
 assert.equal(m.contentVersion,computeContentVersion(m),'Version must bind exact source inventory and capture recipe');
 assert.equal(m.frames.length,5);assert(m.sourceFiles.length>20);assert(m.sourceFiles.every(x=>/^[a-f0-9]{64}$/.test(x.sha256)&&x.bytes>0&&!x.path.includes('..')));
 assert.equal(m.browser.sandbox,true);assert.equal(m.browser.unsafeGraphicsFlags,false);assert.equal(m.viewport.width,1120);assert.equal(m.viewport.height,780);
 for(const [i,f] of m.frames.entries()){
  const plan=FRAME_PLAN[i];assert.equal(f.id,plan.id);assert.equal(f.world,plan.world);assert.equal(f.routeProgress,plan.routeProgress);assert.equal(f.file,`${f.id}-${f.sha256.slice(0,16)}.png`);assert.match(f.sha256,/^[a-f0-9]{64}$/);assert(f.bytes>10000);assert.equal(f.width,1120);assert(f.height>=650&&f.height<=780);
  assert(f.state.ready);assert(f.camera.length===3&&f.target.length===3&&[...f.camera,...f.target].every(Number.isFinite));assert(f.graphics.available&&!f.graphics.contextLost&&f.graphics.sampleColors>=2&&f.graphics.drawCalls>0);
  assert.equal(f.materialMode,'default-unsoftened');assert.equal(f.motion,'reduced-motion-still');assert.equal(f.interactionAcceptance,false);
  if(f.world==='scan'){assert(f.state.waterMode&&!f.state.softened&&f.state.route.active);assert.equal(f.state.route.progress,f.routeProgress);assert.equal(f.state.route.yaw,0);assert.equal(f.state.route.pitch,0);}
  else assert(!f.state.low&&!f.state.tour&&!f.state.specimenInspection);
 }
 return true;
}
export function renderGallery(m){
 validateManifest(m);const dir=`assets/current-scene/${m.contentVersion}`;
 return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#102b34"><title>馆藏骨骼中景实验候选静态画面 · 浅蓝</title><link rel="stylesheet" href="current-scene.css"></head><body><header><p>浅蓝 / 静态画面</p><nav aria-label="返回三维场景"><a href="./index.html">打开人工礁区 3D</a><a href="./scan-exhibit.html">打开扩展水下区域 3D</a></nav></header><main><h1>馆藏骨骼中景实验候选静态画面</h1><p class="notice">本页为独立馆藏骨骼中景候选；右侧单株采用 Smithsonian Heliopora coerulea USNM 1145291（CC0）馆藏骨骼数字化参考，非活珊瑚、非原位水下扫描。仅替换五个合成低团块和一处合成海扇，整体外观仍待评估。单块 Poly Haven CC0 陆生岩石用于合成海底，非水下调查扫描。以下是同版本网页在托管 Chromium 中实际渲染的五张静态画面（前四张为既有固定视角，第五张为新增20%受控相遇视角），不能拖动、缩放或游动。它们不代表本机图形性能，也不表示动态效果、移动端操作或整体自然度已验收。</p><p class="version">候选内容版本 ${esc(m.contentVersion.slice(0,12))} · 捕获于 ${esc(m.capturedAt)}<br>采集视口 1120 × 780 · 减少动态效果 · 默认材质与色彩</p><nav class="jump" aria-label="静态画面位置">${FRAME_PLAN.map(f=>`<a href="#${f.id}">${f.label}</a>`).join('')}</nav><p>人工礁区与扩展水下区域分开。扩展区域内两块真实 Reefs4D 扫描仅为局部锚点；水、灯光、砂底、地形延伸、珊瑚群落、低草甸与鱼群为人工示意，不是采集地实景复原。另有四处复用同一 C4 来源的局部裁片重组，保留原 UV 与照片图集；它们是人工排列，不是新增实测地点。鳐形与海龟形生物均为代码合成示意，非扫描、非已鉴定物种。某些镜头不含完整扫描锚点。</p>${m.frames.map(f=>`<figure id="${f.id}"><h2>${esc(f.label)}</h2><img loading="lazy" decoding="async" src="${dir}/${f.file}" width="${f.width}" height="${f.height}" alt="${esc(f.label)}的当前候选版本网页静态画面，不可操作"><figcaption>${f.world==='artificial'?'参考资料指导的程序化人工礁区；馆藏干制骨架如出现在镜头中，为教学摆放，不是活体扫描。':'人工延伸的示意海底世界，两块真实扫描仅为局部锚点，不代表采集地环境。'} 静态截图中出现的按钮与提示不可操作。</figcaption></figure>`).join('')}<section aria-labelledby="sources"><h2 id="sources">来源与展示边界</h2><p>Reefs4D C1 2019 与 C4 2019：Matan Yuval、Tali Treibitz；Princess Beach，Eilat，北红海。<a href="https://zenodo.org/records/14616671">原始扫描来源</a> · <a href="https://creativecommons.org/licenses/by-nc/2.0/legalcode">CC BY-NC 2.0（署名、非商业）</a>。网页使用简化衍生网格，保留原照片纹理；C4 展示衍生网格为 149,547 三角面，测量杆、色卡与截断边界仍保留，不是额外的生物。展示位置、大小、灯光与合成环境为演示设定，未作实地尺度或真实颜色标定。</p><p>人工礁区中的 Smithsonian 干制鹿角珊瑚骨架：USNM 74016，CC0，教学摆放。<a href="https://3d.si.edu/object/3d/acropora-cervicornis:dd875177-c986-48e2-9468-8e58f01099d3">馆藏来源</a>。</p><p><a href="./references.html">完整场景依据与制作边界</a> · <a href="${dir}/manifest.json">本次捕获版本、镜头与文件校验记录</a></p></section></main><footer><a href="./index.html">重试人工礁区 3D</a><a href="./scan-exhibit.html">重试扩展水下区域 3D</a></footer></body></html>\n`;
}
