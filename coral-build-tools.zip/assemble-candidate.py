"""Local/CI staging only. No network, publication, or runtime transformation."""
import argparse,hashlib,json,pathlib,shutil,zipfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def inventory(root):
 assert root.is_dir() and not root.is_symlink()
 assert not any(p.is_symlink() for p in root.rglob('*'))
 return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
def stage(dist, gallery_zip, receipt):
 original=dist/'preview/independent-scan'; candidate=dist/'preview/natural-rock-candidate'
 assert not candidate.exists(),'Candidate must be freshly assembled'
 root_before={k:v for k,v in inventory(dist).items() if not k.startswith('preview/')}
 runtime_before=inventory(original)
 r=json.loads(receipt.read_text());assert sha(gallery_zip.read_bytes())==r['archive']['sha256']
 assert r['checkoutCommit']=='757859b4d3ce6abb802a25c7a0d71b16ee0fec64'
 with zipfile.ZipFile(gallery_zip) as z:
  assert len(z.namelist())==len(set(z.namelist()))==len(r['files'])==7
  assert set(z.namelist())==set(r['files'])
  for info in z.infolist():
   n=info.filename;rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
   assert not info.is_dir() and (info.external_attr>>16)&0o170000!=0o120000
   b=z.read(n);assert len(b)==r['files'][n]['bytes'] and sha(b)==r['files'][n]['sha256']
   p=original/n
   if p.exists():assert p.read_bytes()==b,'Existing original gallery differs: '+n
   else:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 manifest_name=next(n for n in r['files'] if n.endswith('/manifest.json'))
 current=json.loads((original/manifest_name).read_text())
 assert current['checkoutCommit']==r['checkoutCommit'] and len(current['sourceFiles'])==123
 for f in current['sourceFiles']:
  b=(original/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'], 'Original runtime mismatch: '+f['path']
 protected=inventory(original)
 assert set(protected)=={f['path'] for f in current['sourceFiles']}|set(r['files']), 'Unexpected original preview files'
 assert all(protected[k]==v for k,v in runtime_before.items())
 shutil.copytree(original,candidate)
 (candidate/'current-scene.html').unlink()
 shutil.rmtree(candidate/'assets/current-scene')
 assert inventory(original)==protected
 assert {k:v for k,v in inventory(dist).items() if not k.startswith('preview/')}==root_before
 return {'root':root_before,'originalPreview':protected,'candidateBase':inventory(candidate),'scope':'Original preview bytes preserved; candidate has no inherited generated gallery. Runtime delta not yet applied.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--dist',type=pathlib.Path,required=True);p.add_argument('--gallery',type=pathlib.Path,required=True);p.add_argument('--receipt',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();a.output.write_text(json.dumps(stage(a.dist,a.gallery,a.receipt),indent=2))
