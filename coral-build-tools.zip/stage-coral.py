import hashlib,json,pathlib,shutil,zipfile
here=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
def inv(p):
 assert p.is_dir() and not p.is_symlink();assert not any(f.is_symlink() for f in p.rglob('*'))
 return {f.relative_to(p).as_posix():sha(f.read_bytes()) for f in p.rglob('*') if f.is_file()}
dist=pathlib.Path('dist');old=dist/'preview/layered-reef-candidate';new=dist/'preview/coral-midground-candidate'
r=json.loads((here/'layered-preservation.json').read_text());archive=pathlib.Path('.coral-inputs/layered-gallery-beddb9e6.zip')
assert sha(archive.read_bytes())==r['archive']['sha256']
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==7 and set(z.namelist())==set(r['files'])
 for n,f in r['files'].items():
  rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];p=old/n;p.parent.mkdir(parents=True,exist_ok=True)
  if p.exists():assert p.read_bytes()==b
  else:p.write_bytes(b)
expected={f['path']:f['sha256'] for f in r['sourceFiles']}|{n:f['sha256'] for n,f in r['files'].items()};assert len(expected)==135 and inv(old)==expected
snapshot=pathlib.Path('.protected-preview-hashes.json');s=json.loads(snapshot.read_text());s['layeredPreview']=expected;snapshot.write_text(json.dumps(s,indent=2))
assert not new.exists();shutil.copytree(old,new);(new/'current-scene.html').unlink();shutil.rmtree(new/'assets/current-scene')
m=json.loads((here/'coral-delta-manifest.json').read_text());delta=pathlib.Path('.coral-inputs/coral-midground-runtime-delta.zip');assert len(delta.read_bytes())==m['bytes'] and sha(delta.read_bytes())==m['sha256']=='62c68e6c1fbe07d2845b86f234fc2e27c5747cc6394b85010d534feb13873d50'
with zipfile.ZipFile(delta) as z:
 assert len(z.namelist())==len(set(z.namelist()))==4 and set(z.namelist())=={f['path'] for f in m['files']}
 for f in m['files']:
  n=f['path'];rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];p=new/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
assert inv(old)==expected
fixture=pathlib.Path('.comparison-baseline')
for p in fixture.iterdir():assert p.is_file() and not p.is_symlink();p.unlink()
manifest_name=next(n for n in r['files'] if n.endswith('/manifest.json'));raw=(old/manifest_name).read_bytes();baseline=json.loads(raw)
pins={'baseMain':baseline['checkoutCommit'],'contentVersion':baseline['contentVersion'],'manifestSha256':sha(raw),'frames':[{k:f[k] for k in ['id','file','sha256','bytes','width','height']} for f in baseline['frames']]}
(fixture/'manifest.original.json').write_bytes(raw)
for f in baseline['frames']:(fixture/f['file']).write_bytes((old/pathlib.PurePosixPath(manifest_name).parent/f['file']).read_bytes())
assert json.loads((here/'comparison-baseline.json').read_text())==pins
(fixture/'comparison-baseline.json').write_bytes((here/'comparison-baseline.json').read_bytes())
print('CORAL_CANDIDATE_ASSEMBLED',len(inv(new)),'PROTECTED_LAYERED',len(expected))
