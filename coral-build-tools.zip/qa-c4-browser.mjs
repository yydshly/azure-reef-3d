import assert from 'node:assert/strict';
import {nativeHudClick,openHudControl} from './qa-hud.mjs';
export async function checkC4(page){
 assert(await page.evaluate(()=>!!window.reefExhibit?.getState().ready&&!!document.querySelector('#observeC4')&&!!document.querySelector('#hudMore')),'C4 smoke requires ready scan page');
 assert(await page.evaluate(()=>reefExhibit.ensureC4()),'C4 load failed');
 assert(await page.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches&&scrollX===0&&scrollY===0&&!document.querySelector('#hudMore').open),'C4 smoke requires reduced motion, no scroll, closed disclosure');
 const before=await page.evaluate(()=>reefExhibit.getState());assert.equal(before.c4.status,'ready');assert.equal(before.waterMode,true);assert.equal(before.selectedPatch,'C1');assert.equal(before.route.active,true);assert.equal(before.route.progress,0);
 const click=async selector=>{await openHudControl(page,selector);await nativeHudClick(page,selector);};
 await click('#observeC4');
 const focused=await page.evaluate(()=>reefExhibit.getState());assert.equal(focused.selectedPatch,'C4');assert.equal(focused.view,'c4');assert.equal(focused.route.active,false);
 await click('#toggleOcean');
 const raw=await page.evaluate(()=>({state:reefExhibit.getState(),c1:reefExhibit.scan.visible,c4:reefExhibit.c4.visible,world:reefExhibit.world.group.visible,label:document.querySelector('#scanPatchLabel').textContent,note:document.querySelector('#scanDerivativeNote').textContent}));assert.equal(raw.state.waterMode,false);assert.equal(raw.c1,false);assert.equal(raw.c4,true);assert.equal(raw.world,false);assert(raw.label.includes('C4 2019'));assert(raw.note.includes('149,547')&&raw.note.includes('3,572,296'));
 await click('#toggleOcean');
 const back=await page.evaluate(()=>reefExhibit.getState());for(const key of ['camera','target'])assert(back[key].every((v,i)=>Math.abs(v-focused[key][i])<1e-7),'C4 exact return '+key);
 await click('#nearView');await click('#toggleOcean');
 assert(await page.evaluate(()=>reefExhibit.getState().selectedPatch==='C1'&&reefExhibit.scan.visible&&!reefExhibit.c4.visible),'C1 raw selection');
 await click('#toggleOcean');await click('#closeHudMore');
 await page.evaluate(()=>{reefExhibit.enterRoute();reefExhibit.goRoute(.5,true)});
 const route=await page.evaluate(()=>reefExhibit.getState());await click('#toggleOcean');await click('#toggleOcean');await click('#closeHudMore');const returned=await page.evaluate(()=>reefExhibit.getState());assert.deepEqual(returned.route,route.route);for(const key of ['camera','target'])assert(returned[key].every((v,i)=>Math.abs(v-route[key][i])<1e-7),'Route exact return '+key);
 await page.evaluate(()=>reefExhibit.enterRoute());const after=await page.evaluate(()=>reefExhibit.getState());assert.deepEqual(after.route,before.route);for(const key of ['selectedPatch','view','waterMode','softened','ambient','c4'])assert.deepEqual(after[key],before[key],'Capture restore '+key);assert(await page.evaluate(()=>scrollX===0&&scrollY===0&&!document.querySelector('#hudMore').open),'C4 smoke changed scroll/disclosure');for(const key of ['camera','target'])assert(after[key].every((v,i)=>Math.abs(v-before[key][i])<1e-7),'Capture restore '+key);
 return {c4Ready:true,nativeObserveAndRawButtons:true,selectedSourceProvenance:true,exactC4AndRouteReturn:true,initialCaptureStateRestored:true};
}
