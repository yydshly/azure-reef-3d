import json,hashlib,pathlib,zipfile
sha=lambda b:hashlib.sha256(b).hexdigest();here=pathlib.Path(__file__).parent
m=json.loads((here/'rock-delta-manifest.json').read_text());archive=pathlib.Path('.natural-rock-inputs/natural-rock-runtime-delta.zip');assert sha(archive.read_bytes())=='fbb797b59fe4e74ad4bb50db1547d9171e1eeba0cdd6abfa1ccd34fc099753a2'
root=pathlib.Path('dist/preview/natural-rock-candidate');assert root.is_dir()
with zipfile.ZipFile(archive) as z:
 expected={f['path']:f for f in m['deltaFiles']};assert len(z.namelist())==len(set(z.namelist()))==5;assert set(z.namelist())==set(expected)
 for n,f in expected.items():
  rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
# The freshly frozen original gallery is also the candidate comparison fixture, outside dist.
snap=pathlib.Path('.comparison-baseline')
for p in snap.iterdir():
 assert p.is_file() and not p.is_symlink();p.unlink()
pins=json.loads((here/'comparison-baseline.json').read_text());original=pathlib.Path('dist/preview/independent-scan/assets/current-scene')/pins['contentVersion']
for f in pins['frames']:(snap/f['file']).write_bytes((original/f['file']).read_bytes())
(snap/'manifest.original.json').write_bytes((original/'manifest.json').read_bytes());(snap/'comparison-baseline.json').write_bytes((here/'comparison-baseline.json').read_bytes())
print('NATURAL_ROCK_DELTA_VERIFIED',len(expected))
