import assert from 'node:assert/strict';
// Build/capture-side diagnostic only. Do not import into runtime app.js.
// Call after window.reef3d reports ready and before taking the opening screenshot.
export async function checkSeagrassHosted(page){
 const actual=await page.evaluate(()=>{
  const app=window.reef3d,root=app?.root,result=root?.userData?.seagrass,group=root?.getObjectByName('Synthetic_Artificial_Seagrass');
  if(!app?.getState().ready||!result||!group)return {ready:false,status:result?.status??'absent',reason:result?.stats?.reason??'No seagrass result/group'};
  const meshes=group.children.filter(o=>o.isInstancedMesh);let tufts=0,triangles=0,bytes=0;const attributes=[];
  for(const mesh of meshes){const g=mesh.geometry;tufts+=mesh.count;triangles+=g.index.count/3*mesh.count;bytes+=Object.values(g.attributes).reduce((s,a)=>s+a.array.byteLength,0)+g.index.array.byteLength+mesh.instanceMatrix.array.byteLength;attributes.push({name:mesh.name,vertexColors:mesh.material.vertexColors,colorCount:g.attributes.color?.count,positionCount:g.attributes.position.count,normalCount:g.attributes.normal?.count,instanceColor:!!mesh.instanceColor,shadowCasting:mesh.castShadow,visible:mesh.visible});}
  return {ready:true,status:result.status,stats:result.stats,tufts,triangles,bytes,drawBatches:meshes.length,groupCopies:root.children.filter(o=>o.name==='Synthetic_Artificial_Seagrass').length,attributes,contacts:result.contacts.length,minimumProvedGap:Math.min(...result.contacts.map(c=>c.clearance.minGap)),lowFishOverlapCount:result.contacts.filter(c=>c.clearance.overlappingLowFishSweeps.length).length};
 });
 assert.equal(actual.ready,true,JSON.stringify(actual));assert.equal(actual.status,'ready');assert.equal(actual.tufts,224);assert.equal(actual.triangles,25004);assert.equal(actual.bytes,56918);assert.equal(actual.drawBatches,8);assert.equal(actual.groupCopies,1);assert.equal(actual.contacts,224);assert.ok(actual.minimumProvedGap>=1.5);assert.equal(actual.lowFishOverlapCount,0);
 for(const a of actual.attributes){assert.equal(a.vertexColors,true);assert.equal(a.colorCount,a.positionCount);assert.equal(a.normalCount,a.positionCount);assert.equal(a.instanceColor,false);assert.equal(a.shadowCasting,false);assert.equal(a.visible,true);}
 return actual;
}
