import json,pathlib,runpy,argparse
p=argparse.ArgumentParser();p.add_argument('--dist',type=pathlib.Path,required=True);p.add_argument('--snapshot',type=pathlib.Path,required=True);a=p.parse_args()
inv=runpy.run_path(str(pathlib.Path(__file__).with_name('assemble-candidate.py')))['inventory'];s=json.loads(a.snapshot.read_text())
assert inv(a.dist/'preview/independent-scan')==s['originalPreview'],'Original preview runtime/gallery changed'
actual={k:v for k,v in inv(a.dist).items() if not k.startswith('preview/')}
assert actual==s['root'] and len(actual)==79,'Formal root79 changed'
print('PROTECTED_ROOT_AND_ORIGINAL_PREVIEW_VERIFIED',len(actual),len(s['originalPreview']))

assert inv(a.dist/'preview/natural-rock-candidate')==s['naturalRockPreview'],'Natural rock preview changed'
assert len(s['naturalRockPreview'])==133
print('PROTECTED_NATURAL_ROCK_VERIFIED',133)

assert inv(a.dist/'preview/layered-reef-candidate')==s['layeredPreview'],'Layered preview changed'
assert len(s['layeredPreview'])==135
print('PROTECTED_LAYERED_VERIFIED',135)
