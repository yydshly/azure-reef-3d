import fs from 'node:fs';import {createHash} from 'node:crypto';import path from 'node:path';import assert from 'node:assert/strict';import * as T from 'three';
import {GLTFLoader} from './dist/vendor/GLTFLoader.js';
import {createScanLife} from './dist/scan-life.js';import {createScanOcean} from './dist/scan-ocean.js';
import {createScanWorld,channelX} from './dist/scan-world.js';import {routePose} from './dist/scan-route.js';
globalThis.ProgressEvent=class{};
const asset=path.resolve(process.env.REEF_ASSET_DIR||'./dist/assets')+'/';
async function load(name){const d=JSON.parse(fs.readFileSync(asset+name+'.gltf'));for(const b of d.buffers)b.uri='data:application/octet-stream;base64,'+fs.readFileSync(path.resolve(asset,b.uri)).toString('base64');return(await new Promise((r,j)=>new GLTFLoader().parse(JSON.stringify(d),'',r,j))).scene;}
const surface={limestone:m=>m,coral:m=>m,budget:{stub:'CPU geometry only'}};
const scene=new T.Scene(),world=createScanWorld(scene,await load('scan-world-corals'),()=>{},surface);world.addFish((await load('scan-fish')).getObjectByName('fish_01'));scene.updateMatrixWorld(true);

const terrainNames=['Sunlit_Broken_Coral_Shelves','Valley_And_Passage_Buttresses','Overlapping_Distant_Ridges','Shadowed_Passage_Overhangs'];
const digest=a=>createHash('sha256').update(Buffer.from(a.buffer,a.byteOffset,a.byteLength)).digest('hex');
const terrainSnapshot=root=>Object.fromEntries(terrainNames.map(name=>{const m=root.getObjectByName(name);return[name,{matrices:digest(m.instanceMatrix.array),positions:digest(m.geometry.attributes.position.array),normals:digest(m.geometry.attributes.normal.array)}];}));
assert.deepEqual(terrainSnapshot(world.group),JSON.parse(fs.readFileSync(new URL('./terrain-baseline.json',import.meta.url))));
for(const mesh of world.batches){assert.ok([...mesh.geometry.attributes.position.array,...mesh.geometry.attributes.normal.array].every(Number.isFinite));assert.ok([...mesh.geometry.index?.array||[]].every(i=>i<mesh.geometry.attributes.position.count));}
assert.ok(world.budget.habitatTriangles<=125000);
let clearance=Infinity;for(let i=0;i<=10000;i++){const p=new T.Vector3(...routePose(i/10000).position);clearance=Math.min(clearance,...world.obstacles.map(o=>o.box.distanceToPoint(p)));}assert.ok(clearance>1.2,`route clearance ${clearance}`);assert.ok(world.budget.triangles<=180000);assert.ok(world.budget.drawCalls<=16);assert.ok(world.budget.additionalOwnedGeometryBytes<500000);
const meshes=world.batches.filter(m=>/Buttresses/.test(m.name)),roof=world.group.getObjectByName('Shadowed_Passage_Overhangs'),contacts=[];
// Check actual triangle-ray overlap inside both roof-side banks, beyond AABB overlap.
const ray=new T.Raycaster(),matrix=new T.Matrix4(),v=new T.Vector3();
for(let i=0;i<roof.count;i++){roof.getMatrixAt(i,matrix);const center=new T.Vector3().setFromMatrixPosition(matrix),side=i===0?-1:1;const probes=[];
 for(const dx of [3.7,4.1,4.5])for(const dz of [-.8,0,.8]){
  const x=center.x+side*dx,z=center.z+dz;ray.set(new T.Vector3(x,20,z),new T.Vector3(0,-1,0));const bank=ray.intersectObjects(meshes,false)[0];
  // DoubleSide roof gives both top and underside intersections.
  const old=roof.material.side;roof.material.side=T.DoubleSide;const hits=ray.intersectObject(roof,false).filter(h=>h.instanceId===i);roof.material.side=old;
  if(bank&&hits.length>=2){const bottom=Math.min(...hits.map(h=>h.point.y));probes.push({x,z,bankTop:bank.point.y,roofBottom:bottom,overlap:bank.point.y-bottom});}
 }
 assert.ok(probes.filter(p=>p.overlap>.3).length>=4,'roof must have broad actual bank intersection '+JSON.stringify(probes));contacts.push({roof:i,probes});
}
const habitatMeshes=world.batches.filter(m=>!/Shelves|Buttresses|Ridges|Overhangs|World_School/.test(m.name));let nearRoute=Infinity;for(const mesh of habitatMeshes){mesh.geometry.computeBoundingBox();for(let i=0;i<mesh.count;i++){mesh.getMatrixAt(i,matrix);const box=mesh.geometry.boundingBox.clone().applyMatrix4(matrix);for(let k=0;k<=1000;k++)nearRoute=Math.min(nearRoute,box.distanceToPoint(new T.Vector3(...routePose(k/1000).position)));}}
assert.ok(nearRoute>1.2,'habitat clear '+nearRoute);
const batches=world.batches.map(m=>({name:m.name,count:m.count,triangles:(m.geometry.index?.count||m.geometry.attributes.position.count)/3*m.count}));
const attachmentProof=[];
for(const c of world.group.userData.habitat.contacts){
 const mesh=world.group.getObjectByName(c.definition),normal=new T.Vector3(...c.normal),point=new T.Vector3(...c.point);mesh.getMatrixAt(c.item,matrix);
 const position=new T.Vector3().setFromMatrixPosition(matrix);assert.ok(position.distanceTo(point.clone().addScaledVector(normal,-c.embed))<8e-6,'Exact anchor offset');
 ray.set(point.clone().addScaledVector(normal,.5),normal.clone().negate());const hit=ray.intersectObjects(world.batches.slice(0,2),false)[0];assert.ok(hit&&hit.point.distanceTo(point)<8e-6,'Actual face normal contact');assert.equal(hit.instanceId,c.instance);assert.equal(hit.object.name,c.bank);
 const attr=mesh.geometry.attributes.position;let samples=0,maxGap=-Infinity;
 for(let i=0;i<attr.count;i++){
  if(attr.getY(i)>.06||Math.hypot(attr.getX(i),attr.getZ(i))>.26)continue;
  v.fromBufferAttribute(attr,i).applyMatrix4(matrix);ray.set(v.clone().addScaledVector(normal,1),normal.clone().negate());const hit=ray.intersectObjects(world.batches.slice(0,2),false)[0];assert.ok(hit,'Root sample bank '+c.definition+' '+c.item+' '+i);maxGap=Math.max(maxGap,hit.distance-1);samples++;
 }
 assert.ok(samples>0,'Root samples '+c.definition);assert.ok(maxGap<.17,'Root floats '+c.definition+' '+maxGap);attachmentProof.push({definition:c.definition,item:c.item,rootSamples:samples,maxGap,exactFaceContact:true});
}
const projectedViews=[0,.5,1].map(progress=>{
 const pose=routePose(progress),camera=new T.PerspectiveCamera(65,1120/712,.05,240);camera.position.set(...pose.position);camera.lookAt(new T.Vector3(...pose.target));camera.updateMatrixWorld(true);const colonies=[];
 for(const mesh of habitatMeshes){if(!/Crown|Foliose|Encrusting|Fans/.test(mesh.name))continue;for(let i=0;i<mesh.count;i++){
  mesh.getMatrixAt(i,matrix);const center=new T.Vector3().setFromMatrixPosition(matrix);if(center.distanceTo(camera.position)>30)continue;
  const points=[],attr=mesh.geometry.attributes.position;for(let k=0;k<attr.count;k++){const p=new T.Vector3().fromBufferAttribute(attr,k).applyMatrix4(matrix).project(camera);if(p.z>-1&&p.z<1)points.push([(p.x+1)*560,(1-p.y)*356]);}
  if(!points.length)continue;const min=[Math.min(...points.map(p=>p[0])),Math.min(...points.map(p=>p[1]))],max=[Math.max(...points.map(p=>p[0])),Math.max(...points.map(p=>p[1]))];if(max[0]<0||min[0]>1120||max[1]<0||min[1]>712)continue;
  colonies.push({name:mesh.name,instance:i,bounds:[min,max].map(p=>p.map(v=>Math.round(v))),clippedWidth:Math.round(Math.min(1120,max[0])-Math.max(0,min[0])),clippedHeight:Math.round(Math.min(712,max[1])-Math.max(0,min[1]))});
 }}return{progress,colonies,note:'Projected mesh bounds only; overlaps and rock occlusion are not visual acceptance.'};
});
const ocean=createScanOcean(scene,new T.Texture()),life=createScanLife((await load('scan-fish')).getObjectByName('fish_01'),()=>{});scene.add(life.group);
function counts(root){let triangles=0,meshDraws=0,pointDraws=0;root.traverse(o=>{if(o.isMesh){meshDraws++;triangles+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3*(o.count||1);}if(o.isPoints)pointDraws++;});return {triangles,meshDraws,pointDraws};}
const fullSynthetic=counts(scene),rigFish=counts(life.group),oceanBudget=counts(ocean.group);assert.ok(fullSynthetic.triangles<220000);
const result={passed:true,visualAcceptance:false,terrainRoofGeometryNormalsAndPosesUnchanged:true,budget:world.budget,attachmentProof,projectedViews,fullSynthetic,rigFish,oceanBudget,sourceScanTriangles:149822,fullSceneTrianglesIncludingScan:fullSynthetic.triangles+149822,minSolidRouteClearance:clearance,minHabitatRouteClearance:nearRoute,actualRoofBankContacts:contacts,habitatContacts:world.group.userData.habitat.contacts.length,batches};fs.writeFileSync('evidence/cpu.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
