import * as THREE from 'three';
// LOCAL CANDIDATE ONLY. Terrestrial CC0 scan in a fictional underwater composition.
// Call only after createScanWorld and after all original dependent planting is built.
// boulderScene must be the unmodified bundled boulder_01_LOD1_1k.glb scene.
export function installNaturalRockCandidate({world,boulderScene,configure}) {
 const shelves=world.group.getObjectByName('Sunlit_Broken_Coral_Shelves');
 if(!shelves||shelves.count!==11)throw Error('Candidate requires the unmodified 11-instance baseline');
 const matrix=new THREE.Matrix4(),originalColor=new THREE.Color();shelves.getMatrixAt(9,matrix);shelves.getColorAt(9,originalColor);
 const p=new THREE.Vector3().setFromMatrixPosition(matrix);
 if(p.distanceTo(new THREE.Vector3(22,-.49501141905784607,-23))>1e-5)throw Error('Original source instance identity mismatch');
 if(world.group.userData.habitat.contacts.some(c=>c.bank===shelves.name&&c.instance===9))throw Error('Target has dependent habitat');
 const root=boulderScene;root.name='Synthetic_Terrestrial_Boulder_Reference';
 root.position.set(22.440520314854698,-.9166797262430184,-23.050435520142795);
 root.scale.setScalar(3.8);root.rotation.set(0,.4,0);
 let triangles=0,draws=0;root.traverse(o=>{if(!o.isMesh)return;triangles+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3;draws++;o.castShadow=false;o.receiveShadow=true;configure(o.material);});
 if(triangles!==33060||draws!==1)throw Error('Unexpected Boulder asset');
 shelves.geometry.computeBoundingBox();const oldBox=shelves.geometry.boundingBox.clone().applyMatrix4(matrix);
 const obstacleIndex=world.obstacles.findIndex(o=>o.name===shelves.name&&o.box.min.distanceTo(oldBox.min)<1e-5&&o.box.max.distanceTo(oldBox.max)<1e-5);
 if(obstacleIndex<0)throw Error('Original collision obstacle identity mismatch');
 // Validate everything before mutating the existing instance buffer.
 const next=new THREE.Matrix4(),color=new THREE.Color();shelves.getMatrixAt(10,next);shelves.getColorAt(10,color);shelves.setMatrixAt(9,next);shelves.setColorAt(9,color);shelves.count=10;shelves.instanceMatrix.needsUpdate=true;shelves.instanceColor.needsUpdate=true;shelves.computeBoundingSphere();
 const originalObstacle=world.obstacles[obstacleIndex];
 world.group.add(root);root.updateMatrixWorld(true);const box=new THREE.Box3().setFromObject(root);world.obstacles.splice(obstacleIndex,1,{name:root.name,box});
 world.budget.triangles+=32980;world.budget.drawCalls+=1;
 root.userData={syntheticPresentation:true,terrestrialScan:true,metricCalibration:false,source:'https://polyhaven.com/a/boulder_01',license:'https://polyhaven.com/license',bytes:3663288,triangles:33060,originalTexturesPreserved:true};
 let restored=false;function restore(){if(restored)return;restored=true;root.removeFromParent();shelves.count=11;shelves.setMatrixAt(9,matrix);shelves.setColorAt(9,originalColor);shelves.instanceMatrix.needsUpdate=true;shelves.instanceColor.needsUpdate=true;shelves.computeBoundingSphere();world.obstacles.splice(obstacleIndex,1,originalObstacle);world.budget.triangles-=32980;world.budget.drawCalls-=1;}
 return {root,box,restore,addedTriangles:32980,addedDraws:1,addedGlbBytes:3663288,conservativeTextureBytes:16777216};
}
