import {installNaturalRockCandidate} from './install-natural-rock.js';
export const NATURAL_ROCK_INFO=Object.freeze({bytes:3663288,triangles:33060,sha256:'65cda7cfaecbc8b1a2a81dfa1f48a93b9dc01d560fbb574a44ea148ef239461c',source:'https://polyhaven.com/a/boulder_01',license:'https://polyhaven.com/license'});
export async function loadNaturalRockAsset({signal,Loader,url='./assets/boulder_01_LOD1_1k.glb',fetchImpl=fetch}){
 const response=await fetchImpl(url,{signal});if(!response.ok)throw Error('Boulder HTTP '+response.status);
 const bytes=await response.arrayBuffer();if(bytes.byteLength!==NATURAL_ROCK_INFO.bytes)throw Error('Boulder byte budget mismatch');
 const digest=await crypto.subtle.digest('SHA-256',bytes),sha=Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('');
 if(sha!==NATURAL_ROCK_INFO.sha256)throw Error('Boulder SHA-256 mismatch');
 if(signal.aborted)throw new DOMException('Aborted','AbortError');
 return new Loader().parseAsync(bytes,'');
}
export function disposeNaturalRockAsset(root){
 const geometries=new Set(),materials=new Set(),textures=new Set();root?.traverse(o=>{if(!o.isMesh)return;geometries.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:[o.material]){materials.add(m);for(const v of Object.values(m))if(v?.isTexture)textures.add(v);}});
 root?.removeFromParent();for(const g of geometries)g.dispose();for(const m of materials)m.dispose();for(const t of textures){t.dispose();t.source?.data?.close?.();}
}
function validate(root){
 const meshes=[];root?.traverse(o=>{if(o.isMesh)meshes.push(o);});
 if(meshes.length!==1)throw Error('Boulder must have exactly one mesh');
 const {geometry:g,material:m}=meshes[0];
 if(Array.isArray(m)||!m.isMeshStandardMaterial||!g.attributes.uv||!g.attributes.normal||(g.index?.count||g.attributes.position.count)/3!==33060||g.attributes.position.count!==19773||!m.map||!m.normalMap||!m.roughnessMap||!m.metalnessMap)throw Error('Boulder geometry/material contract mismatch');
 if(g.morphAttributes.position?.length)throw Error('Unexpected Boulder morph targets');
}
export function createNaturalRockRuntime({world,load,configure,invalidate,onState=()=>{}}){
 let status='idle',error=null,disposed=false,pending=null,controller=null,epoch=0,asset=null,installed=null;
 const configured=new WeakSet();
 const getState=()=>({status,error,disposed,installed:!!installed,bytes:NATURAL_ROCK_INFO.bytes,syntheticPresentation:true,terrestrialScan:true});
 const notify=()=>{try{onState(getState());}catch(e){console.error('Natural rock status callback',e);}};
 function install(root){const handle=installNaturalRockCandidate({world,boulderScene:root,configure:m=>{if(!configured.has(m)){configure(m);configured.add(m);}}});installed=handle;invalidate();}
 function ensure(){
  if(disposed)return Promise.resolve(false);if(installed)return Promise.resolve(true);if(pending)return pending;
  if(asset){try{install(asset);status='ready';error=null;notify();return Promise.resolve(true);}catch(e){disposeNaturalRockAsset(asset);asset=null;status='error';error=String(e.message||e);notify();return Promise.resolve(false);}}
  const token=++epoch;controller=new AbortController();const signal=controller.signal;status='loading';error=null;notify();
  const task=Promise.resolve().then(()=>load(signal)).then(value=>{
   const root=value.scene||value;
   if(disposed||token!==epoch||signal.aborted){disposeNaturalRockAsset(root);return false;}
   try{validate(root);install(root);asset=root;status='ready';error=null;notify();return true;}
   catch(e){if(installed){installed.restore();installed=null;invalidate();}disposeNaturalRockAsset(root);throw e;}
  }).catch(e=>{if(!disposed&&token===epoch){status='error';error=String(e.message||e);notify();}return false;}).finally(()=>{if(token===epoch){pending=null;controller=null;}});
  pending=task;return task;
 }
 function restore(){
  if(disposed)return;epoch++;controller?.abort();controller=null;pending=null;
  if(installed){installed.restore();installed=null;invalidate();}
  status='restored';error=null;notify();
 }
 function dispose(){
  if(disposed)return;restore();disposed=true;epoch++;if(asset)disposeNaturalRockAsset(asset);asset=null;status='disposed';notify();
 }
 return {ensure,restore,dispose,getState};
}
