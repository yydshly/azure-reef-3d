import * as T from 'three';
import {mergeGeometries} from './utils/BufferGeometryUtils.js';
import {HABITAT} from './habitat-placement.js';
// Fictional, uncalibrated ecological illustration. No scan-derived organism copies.
// Positions were baked on unchanged sand, outside both states of the optional field.
export function installHabitatEnrichment({parent,meadow,configure=()=>{}}){
 if(parent.getObjectByName('Synthetic_Seabed_Transition'))throw Error('Habitat already installed');
 const group=new T.Group();group.name='Synthetic_Seabed_Transition';const batches=[],geometries=[],materials=[],swaps=[];
 let disposed=false,enabled=true;
 const targets=new Set(HABITAT.meta.replacedGrass),matrix=new T.Matrix4(),zero=new T.Matrix4().makeScale(0,0,0);
 for(const mesh of meadow.batches)for(let i=0;i<mesh.count;i++)if(targets.has(mesh.name+'_'+i)){mesh.getMatrixAt(i,matrix);swaps.push({mesh,i,matrix:matrix.clone()});}
 const grassMat=new T.MeshStandardMaterial({roughness:.95,side:T.DoubleSide,vertexColors:true});configure(grassMat);materials.push(grassMat);
 const mineralMat=new T.MeshStandardMaterial({roughness:1});configure(mineralMat);materials.push(mineralMat);
 const livingMat=new T.MeshStandardMaterial({roughness:1});configure(livingMat);materials.push(livingMat);
 function grass(variant){
  const positions=[],colors=[],indices=[];
  for(let b=0;b<4+variant;b++){
   const angle=b*2.399+variant*.73,h=.25+.065*((b*7+variant)%4),bend=.07+.026*((b*3+variant)%5),width=.012+.004*((b+variant)%3),base=positions.length/3;
   for(let j=0;j<4;j++){
    const t=j/3,cx=Math.cos(angle)*(.018+bend*t*t),cz=Math.sin(angle)*(.018+bend*t*t),y=h*(t-.16*t*t),w=width*(1-t)*(.9+.18*Math.sin(t*Math.PI));
    for(const side of [-1,1]){positions.push(cx-Math.sin(angle)*w*side,y,cz+Math.cos(angle)*w*side);const c=new T.Color().setRGB(.48+.22*t,.60+.20*t,.38+.16*t);colors.push(...c.toArray());}
    if(j<3){let a=base+j*2;indices.push(a,a+1,a+2,a+1,a+3,a+2);}
   }
  }
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));g.setIndex(indices);g.computeVertexNormals();return g;
 }
 function rubble(){const g=new T.IcosahedronGeometry(1,0),p=g.attributes.position;for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i),n=1+.13*Math.sin(x*9+z*5);p.setXYZ(i,x*.19*n,(y+1)*.105-.022,z*.15*n);}g.computeVertexNormals();return g;}
 function nodules(){const gs=[];for(let i=0;i<3;i++){const g=new T.IcosahedronGeometry(1,1);g.scale(.20+i*.022,.115+(i%2)*.04,.17+i*.022);g.translate(Math.cos(i*2.7)*.115,.075,Math.sin(i*2.7)*.12);gs.push(g);}const g=mergeGeometries(gs);gs.forEach(g=>g.dispose());return g;}
 const palettes={grass0:['#82936a','#627a51'],grass1:['#8c9572','#6b815d'],grass2:['#929a73','#748260'],rubble:['#8c8a70','#656f62'],nodules:['#697b66','#8d9271']};
 function batch(kind,geo,mat){geometries.push(geo);const items=HABITAT.items[kind],mesh=new T.InstancedMesh(geo,mat,items.length),dummy=new T.Object3D(),up=new T.Vector3(0,1,0);mesh.name='Synthetic_Transition_'+kind;mesh.castShadow=false;mesh.receiveShadow=true;
  for(const [i,o] of items.entries()){dummy.position.fromArray(o.p);dummy.quaternion.setFromUnitVectors(up,new T.Vector3(...o.n)).multiply(new T.Quaternion().setFromAxisAngle(up,o.yaw));dummy.scale.fromArray(o.s);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);mesh.setColorAt(i,new T.Color(palettes[kind][0]).lerp(new T.Color(palettes[kind][1]),o.tone));}mesh.computeBoundingSphere();group.add(mesh);batches.push(mesh);
 }
 for(let i=0;i<3;i++)batch('grass'+i,grass(i),grassMat);batch('rubble',rubble(),mineralMat);batch('nodules',nodules(),livingMat);
 const triangles=batches.reduce((n,m)=>n+(m.geometry.index?.count||m.geometry.attributes.position.count)/3*m.count,0);
 if(triangles>80000)throw Error('Habitat budget exceeded');
 group.userData={...HABITAT.meta,triangles,drawCalls:batches.length,animated:false,newTextureBytes:0};
 function apply(value){enabled=!!value;group.visible=enabled;for(const s of swaps){s.mesh.setMatrixAt(s.i,enabled?zero:s.matrix);s.mesh.instanceMatrix.needsUpdate=true;}for(const mesh of new Set(swaps.map(s=>s.mesh)))mesh.computeBoundingSphere();}
 parent.add(group);apply(true);
 return {group,batches,triangles,setEnabled(value){if(!disposed)apply(value);},getState:()=>({enabled,disposed,triangles,drawCalls:batches.length,replacedTufts:swaps.length}),dispose(){if(disposed)return;apply(false);disposed=true;group.removeFromParent();batches.forEach(m=>m.dispose());geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());}};
}
