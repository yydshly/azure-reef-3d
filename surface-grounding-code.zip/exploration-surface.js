import * as T from 'three';
// Borrowed surface maps belong to loadWorldSurface. This module never loads,
// clones, modifies, or disposes a texture and allocates no runtime render pass.
export const EXPLORATION_SURFACE_CONTRACT=Object.freeze({revision:'surface-grounding-v1',borrowedTextures:2,newDownloads:0,newTextureBytes:0,newTextureCopies:0,rockTextureLookups:6,sandTextureLookups:0,grassTextureLookups:0,additionalPasses:0,additionalShadowDraws:0,contactBake:'initialization only, existing vertex colors',textureOwner:'loadWorldSurface'});
export function bindBorrowedRockDetail(material,maps){
 if(!maps?.normal||!maps?.roughness)return false;
 const prior=material.onBeforeCompile;
 material.onBeforeCompile=shader=>{
  prior.call(material,shader);
  shader.uniforms.explorationStoneNormal={value:maps.normal};
  shader.uniforms.explorationStoneRoughness={value:maps.roughness};
  shader.fragmentShader=`uniform sampler2D explorationStoneNormal;
uniform sampler2D explorationStoneRoughness;
vec3 explorationStoneCoordinates(vec3 p){
 p*=.65;
 // A weak continuous warp breaks the obvious tile cadence; it is shared by
 // normal and roughness maps, including across separate rock meshes.
 return p+.13*vec3(sin(p.z*.37+p.y*.21),sin(p.x*.29+p.z*.17),sin(p.y*.31+p.x*.23));
}
vec3 explorationProjectionWeights(vec3 n){
 vec3 w=pow(abs(n),vec3(4.));return w/max(dot(w,vec3(1.)),.0001);
}
`+shader.fragmentShader;
  shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>',`#include <roughnessmap_fragment>
vec3 surfaceP=explorationStoneCoordinates(vExhibitWorld);
vec3 surfaceBase=inverseTransformDirection(normalize(vNormal),viewMatrix);
vec3 surfaceWeights=explorationProjectionWeights(surfaceBase);
float surfaceR=texture2D(explorationStoneRoughness,surfaceP.yz).g*surfaceWeights.x
 +texture2D(explorationStoneRoughness,surfaceP.zx).g*surfaceWeights.y
 +texture2D(explorationStoneRoughness,surfaceP.xy).g*surfaceWeights.z;
roughnessFactor=.83+.16*surfaceR;`);
  shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>',`#include <normal_fragment_maps>
vec3 stoneBase=inverseTransformDirection(normal,viewMatrix);
vec3 stoneWeights=explorationProjectionWeights(stoneBase);
vec3 stoneX=texture2D(explorationStoneNormal,surfaceP.yz).xyz*2.-1.;
vec3 stoneY=texture2D(explorationStoneNormal,surfaceP.zx).xyz*2.-1.;
vec3 stoneZ=texture2D(explorationStoneNormal,surfaceP.xy).xyz*2.-1.;
vec3 stoneDetail=vec3(0.,stoneX.x,stoneX.y)*stoneWeights.x*sign(stoneBase.x)
 +vec3(stoneY.y,0.,stoneY.x)*stoneWeights.y*sign(stoneBase.y)
 +vec3(stoneZ.x,stoneZ.y,0.)*stoneWeights.z*sign(stoneBase.z);
stoneDetail-=stoneBase*dot(stoneBase,stoneDetail);
normal=normalize(normal+(viewMatrix*vec4(stoneDetail*.27,0.)).xyz);`);
 };
 material.userData.borrowedSurfaceMaps=['normal','roughness'];
 return true;
}
// Average coincident corners only within one leaf. This preserves six separate
// leaf surfaces, silhouette, positions, triangle order, and all buffer sizes.
export function smoothLeafNormals(geometry,verticesPerLeaf=30){
 const p=geometry.attributes.position,n=geometry.attributes.normal,temp=new T.Vector3();
 for(let start=0;start<p.count;start+=verticesPerLeaf){
  const sums=new Map(),key=i=>[p.getX(i),p.getY(i),p.getZ(i)].map(v=>Math.round(v*1e6)).join(',');
  for(let i=start;i<Math.min(start+verticesPerLeaf,p.count);i++){const k=key(i),sum=sums.get(k)||new T.Vector3();sum.add(temp.fromBufferAttribute(n,i));sums.set(k,sum);}
  for(let i=start;i<Math.min(start+verticesPerLeaf,p.count);i++){temp.copy(sums.get(key(i))).normalize();n.setXYZ(i,temp.x,temp.y,temp.z);}
 }
 n.needsUpdate=true;
 return geometry;
}
// Small, finite-range visibility estimate baked once into existing sand color.
// It uses the actual rock triangles, not an ellipse, painted ring, shadow mesh,
// or an approximation that darkens every object outline equally.
export function bakeRockSedimentContact(sediments,rocks,floorHeight){
 const reach=2.2,origin=new T.Vector3(),ray=new T.Ray(),normal=new T.Vector3(),hit=new T.Vector3();
 // Temporary world-space triangle bins avoid O(vertices × all rock triangles)
 // startup work. The expanded triangle bounds conservatively include every
 // finite ray; the exact same triangle intersection determines visibility.
 const cell=4,bins=new Map();
 for(const mesh of rocks){const p=mesh.geometry.attributes.position,index=mesh.geometry.index;
  for(let i=0;i<index.count;i+=3){const triangle=[0,1,2].map(k=>new T.Vector3().fromBufferAttribute(p,index.getX(i+k)));
   const x0=Math.floor((Math.min(...triangle.map(p=>p.x))-reach)/cell),x1=Math.floor((Math.max(...triangle.map(p=>p.x))+reach)/cell);
   const z0=Math.floor((Math.min(...triangle.map(p=>p.z))-reach)/cell),z1=Math.floor((Math.max(...triangle.map(p=>p.z))+reach)/cell);
   triangle.minY=Math.min(...triangle.map(p=>p.y));triangle.maxY=Math.max(...triangle.map(p=>p.y));
   for(let x=x0;x<=x1;x++)for(let z=z0;z<=z1;z++){const key=x+','+z,items=bins.get(key)||[];items.push(triangle);bins.set(key,items);}
  }
 }
 const directions=Array.from({length:8},(_,i)=>new T.Vector3(Math.cos((i+.37)*Math.PI/4),.65,Math.sin((i+.37)*Math.PI/4)).normalize());
 const cache=new Map(),stats={sandVertices:0,sandChanged:0,uniqueSandSamples:0,rayQueries:0,triangleTests:0,rockVertices:0,rockChanged:0,minSandFactor:1,minRockFactor:1,reach,maxSandDarkening:.13,maxRockDarkening:.15};

 for(const mesh of sediments){const p=mesh.geometry.attributes.position,c=mesh.geometry.attributes.color;
  for(let i=0;i<p.count;i++){
   const x=p.getX(i),y=p.getY(i),z=p.getZ(i),key=x+','+z;stats.sandVertices++;
   let shade=cache.get(key);
   if(shade===undefined){
    origin.set(x,y+.035,z);const candidates=bins.get(Math.floor(x/cell)+','+Math.floor(z/cell))||[];
    const near=candidates.filter(t=>t.maxY>origin.y&&t.minY<origin.y+reach*.55);shade=1;
    if(near.length){let blocked=0;for(const direction of directions){ray.set(origin,direction);stats.rayQueries++;let distance=reach;
      for(const t of near){stats.triangleTests++;if(ray.intersectTriangle(t[0],t[1],t[2],true,hit)){const d=hit.distanceTo(origin);if(d>=.025)distance=Math.min(distance,d);}}
      blocked+=1-T.MathUtils.smoothstep(distance,.12,reach);
     }shade=1-.13*blocked/directions.length;stats.uniqueSandSamples++;}
    cache.set(key,shade);
   }
   if(shade<.999999){c.setXYZ(i,c.getX(i)*shade,c.getY(i)*shade,c.getZ(i)*shade);stats.sandChanged++;stats.minSandFactor=Math.min(stats.minSandFactor,shade);}
  }c.needsUpdate=true;
 }
 for(const rock of rocks){const p=rock.geometry.attributes.position,c=rock.geometry.attributes.color,n=rock.geometry.attributes.normal;
  for(let i=0;i<p.count;i++){
   stats.rockVertices++;normal.fromBufferAttribute(n,i);
   const gap=p.getY(i)-floorHeight(p.getX(i),p.getZ(i));
   const proximity=1-T.MathUtils.smoothstep(gap,.025,.85);
   const occlusion=proximity*(.35+.65*(1-Math.max(0,normal.y)));
   const shade=1-.15*occlusion;
   if(shade<.999999){c.setXYZ(i,c.getX(i)*shade,c.getY(i)*shade,c.getZ(i)*shade);stats.rockChanged++;stats.minRockFactor=Math.min(stats.minRockFactor,shade);}
  }c.needsUpdate=true;
 }
 return stats;
}
