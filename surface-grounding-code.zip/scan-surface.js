import * as THREE from 'three';
// Synthetic material treatment only. Reuses the original artificial reef's owned
// limestone/coral PBR maps; no scanned C12019 geometry or photographs are changed.
export const SURFACE_BUDGET=Object.freeze({reusedTextureFiles:4,reusedTextureDownloadBytes:3609276,newTextureBytes:0,estimatedAdditionalGpuBytes:22369624,stoneTextureLookups:6,coralTextureLookups:2});
export async function loadWorldSurface(){
 const loader=new THREE.TextureLoader();
 const maps=await Promise.all([2,3,4,5].map(i=>loader.loadAsync('./assets/reef-texture-'+i+'.png')));
 for(const map of maps){map.wrapS=map.wrapT=THREE.RepeatWrapping;map.colorSpace=THREE.NoColorSpace;map.flipY=false;map.anisotropy=2;}
 const [stoneNormal,stoneRough,coralNormal,coralRough]=maps;
 function limestone(material){
  material.roughness=1;material.metalness=0;
  material.onBeforeCompile=shader=>{
   shader.uniforms.reefStoneNormal={value:stoneNormal};shader.uniforms.reefStoneRough={value:stoneRough};
   shader.fragmentShader=`uniform sampler2D reefStoneNormal;
uniform sampler2D reefStoneRough;
float reefHash(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
float reefNoise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(mix(reefHash(i),reefHash(i+vec3(1,0,0)),f.x),mix(reefHash(i+vec3(0,1,0)),reefHash(i+vec3(1,1,0)),f.x),f.y),mix(mix(reefHash(i+vec3(0,0,1)),reefHash(i+vec3(1,0,1)),f.x),mix(reefHash(i+vec3(0,1,1)),reefHash(i+vec3(1,1,1)),f.x),f.y),f.z);}
`+shader.fragmentShader;
   shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
// World-space mineral variation does not stretch with differently scaled rocks.
float reefMineral=reefNoise(vExhibitWorld*1.15);
float reefCrust=reefNoise(vExhibitWorld*3.4+vec3(17.2,6.1,8.7));
float reefPores=reefNoise(vExhibitWorld*23.);
diffuseColor.rgb*=vec3(1.09,1.01,.91)*(.54+.58*reefMineral+.17*reefPores);
diffuseColor.rgb=mix(diffuseColor.rgb,diffuseColor.rgb*vec3(1.24,.83,.78),smoothstep(.52,.78,reefCrust)*.48);`);
   shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>',`#include <normal_fragment_maps>
vec3 reefBase=inverseTransformDirection(normal,viewMatrix);
vec3 reefWeights=pow(abs(reefBase),vec3(4.));reefWeights/=max(dot(reefWeights,vec3(1.)),.0001);
// One texture tile spans two scene units, independently of instance scale.
vec3 reefP=vExhibitWorld*.5;
vec3 reefNX=texture2D(reefStoneNormal,reefP.yz).xyz*2.-1.;
vec3 reefNY=texture2D(reefStoneNormal,reefP.zx).xyz*2.-1.;
vec3 reefNZ=texture2D(reefStoneNormal,reefP.xy).xyz*2.-1.;
vec3 reefDetail=vec3(0.,reefNX.x,reefNX.y)*reefWeights.x*sign(reefBase.x)+vec3(reefNY.y,0.,reefNY.x)*reefWeights.y*sign(reefBase.y)+vec3(reefNZ.x,reefNZ.y,0.)*reefWeights.z*sign(reefBase.z);
reefDetail-=reefBase*dot(reefBase,reefDetail);
normal=normalize(normal+(viewMatrix*vec4(reefDetail*.42,0.)).xyz);`);
   // Roughness is evaluated before normals in MeshStandardMaterial: use the
   // unperturbed view normal here rather than variables declared later above.
   shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>',`#include <roughnessmap_fragment>
vec3 reefRoughN=abs(inverseTransformDirection(normalize(vNormal),viewMatrix));
reefRoughN=pow(reefRoughN,vec3(4.));reefRoughN/=max(dot(reefRoughN,vec3(1.)),.0001);
vec3 reefRP=vExhibitWorld*.5;
float reefR=texture2D(reefStoneRough,reefRP.yz).g*reefRoughN.x+texture2D(reefStoneRough,reefRP.zx).g*reefRoughN.y+texture2D(reefStoneRough,reefRP.xy).g*reefRoughN.z;
roughnessFactor=.86+.14*reefR;`);
  };
  material.customProgramCacheKey=()=> 'syntheticPorousLimestone1';
  return material;
 }
 function coral(material){material.normalMap=coralNormal;material.normalScale=new THREE.Vector2(.38,.38);material.roughnessMap=coralRough;material.roughness=.98;material.metalness=0;return material;}
 // Read-only borrowed references: consumers must not clone, mutate, or dispose.
 return {limestone,coral,budget:SURFACE_BUDGET,stoneMaps:Object.freeze({normal:stoneNormal,roughness:stoneRough})};
}
// Keep every position/index and the existing faceted silhouette unchanged.
// Blend coincident corner normals, leaving 25% of each face normal for broad
// fractures. This is not subdivision, displacement, or a new rounded shell.
export function softenSharedNormals(geometry){
 const position=geometry.attributes.position,normal=geometry.attributes.normal,sums=new Map();
 const key=i=>[position.getX(i),position.getY(i),position.getZ(i)].map(v=>Math.round(v*1e5)).join(',');
 for(let i=0;i<position.count;i++){const k=key(i),sum=sums.get(k)||new THREE.Vector3();sum.add(new THREE.Vector3().fromBufferAttribute(normal,i));sums.set(k,sum);}
 const n=new THREE.Vector3();for(let i=0;i<position.count;i++){n.fromBufferAttribute(normal,i).multiplyScalar(.25).addScaledVector(sums.get(key(i)).clone().normalize(),.75).normalize();normal.setXYZ(i,n.x,n.y,n.z);}
 normal.needsUpdate=true;return geometry;
}
