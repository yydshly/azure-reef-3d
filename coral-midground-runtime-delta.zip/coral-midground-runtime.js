import * as T from 'three';
export const CORAL_SOURCE=Object.freeze({name:'Smithsonian Heliopora coerulea USNM 1145291',url:'https://3d.si.edu/object/3d/heliopora-coerulea:ebea5b5f-5613-4d38-97a2-32e1b8e03ac4',license:'CC0',kind:'Museum skeletal specimen, synthetic placement; not live coral or in-situ underwater scan',scale:'Illustrative scene units; not calibrated metres',bytes:3733192,sha256:'87a0e4e1be945171bb4d0732a586457ed0c7210b854601bd7f17ba2a47580793'});
export const REPLACEMENT_SET=Object.freeze({low:[91,120,129,163,175],fan:[8]});
const PLAN=[{x:17.5,z:-44.89,yaw:-.46,scale:1.65,embed:.48}];
function release(asset){const gs=new Set(),ms=new Set(),ts=new Set();asset?.traverse(o=>{if(o.geometry)gs.add(o.geometry);for(const m of (Array.isArray(o.material)?o.material:[o.material]).filter(Boolean)){ms.add(m);Object.values(m).forEach(v=>{if(v?.isTexture)ts.add(v);});}});gs.forEach(g=>g.dispose());ms.forEach(m=>m.dispose());ts.forEach(t=>t.dispose());}
function install(world,asset,configure){
const parent=world.group.getObjectByName('Candidate_Layered_Reef_Shoulders'),ridge=parent?.getObjectByName('Layered_Ridges_Weathered_Shoulders'),low=parent?.getObjectByName('Ridge_Ecology_Low_Colonies'),fan=parent?.getObjectByName('Ridge_Ecology_Sea_Fans');if(!ridge||!low||!fan)throw Error('Layered ridges must be ready');
if(parent.getObjectByName('Museum_Heliopora_Reference_Synthesis'))throw Error('Already installed');
const root=new T.Group();root.name='Museum_Heliopora_Reference_Synthesis';root.userData={...CORAL_SOURCE,synthetic:true};world.group.updateMatrixWorld(true);const ray=new T.Raycaster(),down=new T.Vector3(0,-1,0),removed=new Set(),placements=[];
const materials=new Set();asset.traverse(o=>{if(o.isMesh){for(const m of Array.isArray(o.material)?o.material:[o.material])materials.add(m);o.castShadow=false;o.receiveShadow=true;}});materials.forEach(configure);
for(const [n,p]of PLAN.entries()){
const group=asset.clone(true);group.name=`Museum_USNM1145291_${n}`;group.scale.setScalar(p.scale);group.rotation.y=p.yaw;group.updateMatrixWorld(true);let min=new T.Vector3(),minY=Infinity;
group.traverse(o=>{if(o.isMesh){const a=o.geometry.attributes.position;for(let i=0;i<a.count;i++){const v=new T.Vector3().fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld);if(v.y<minY){min.copy(v);minY=v.y;}}}});
ray.set(new T.Vector3(p.x+min.x,30,p.z+min.z),down);const hit=ray.intersectObject(ridge,false)[0];if(!hit)throw Error('Missing support');group.position.set(p.x,hit.point.y-minY-p.embed,p.z);root.add(group);placements.push({...p,position:group.position.toArray(),support:hit.point.toArray()});
REPLACEMENT_SET.low.forEach(i=>removed.add(i));
}
const replacements=[],compacts=[];let removedTriangles=0;
for(const [original,indices,label] of [[low,REPLACEMENT_SET.low,'Low_Colonies'],[fan,REPLACEMENT_SET.fan,'Sea_Fans']]){
 const excluded=new Set(indices);if(indices.some(i=>i<0||i>=original.count))throw Error('Replacement index mismatch');
 const compact=new T.InstancedMesh(original.geometry,original.material,original.count-excluded.size);compact.name='Remaining_Original_'+label;compact.castShadow=original.castShadow;compact.receiveShadow=original.receiveShadow;compact.matrix.copy(original.matrix);compact.matrixAutoUpdate=false;let dst=0;
 for(let i=0;i<original.count;i++){if(excluded.has(i))continue;const m=new T.Matrix4();original.getMatrixAt(i,m);compact.setMatrixAt(dst,m);if(original.instanceColor){const c=new T.Color();original.getColorAt(i,c);compact.setColorAt(dst,c);}dst++;}compact.computeBoundingSphere();root.add(compact);compacts.push(compact);const triangles=indices.length*(original.geometry.index?.count||original.geometry.attributes.position.count)/3;removedTriangles+=triangles;replacements.push({original,visible:original.visible,indices,triangles});
}
const budget={addedTriangles:29986,removedTriangles,netTriangles:29986-removedTriangles,newAssetBytes:CORAL_SOURCE.bytes,extraDrawCalls:1,replacementSet:REPLACEMENT_SET,removedByBatch:replacements.map(r=>({name:r.original.name,indices:r.indices,triangles:r.triangles})),placements};
parent.add(root);replacements.forEach(r=>r.original.visible=false);world.budget.triangles+=budget.netTriangles;world.budget.drawCalls+=1;let done=false;
return{root,budget,setEnabled(value){root.visible=!!value;replacements.forEach(r=>r.original.visible=value?false:r.visible);},dispose(){if(done)return;done=true;root.removeFromParent();replacements.forEach(r=>r.original.visible=r.visible);compacts.forEach(c=>c.dispose());world.budget.triangles-=budget.netTriangles;world.budget.drawCalls-=1;}};

}
export function createCoralMidgroundRuntime({world,load,configure=()=>{},invalidate=()=>{},onState=()=>{}}){
let installation=null,asset=null,pending=null,controller=null,generation=0,disposed=false,enabled=true,status='idle',error=null;
const getState=()=>({status,error,disposed,enabled,installed:!!installation,budget:installation?.budget||null,source:CORAL_SOURCE});
const notify=()=>{invalidate();onState(getState());};
function ensure(){if(disposed)return Promise.resolve(false);if(installation)return Promise.resolve(true);if(pending)return pending;const token=++generation;controller=new AbortController();status='loading';error=null;notify();const signal=controller.signal;
pending=Promise.resolve().then(()=>load(signal)).then(gltf=>{const candidate=gltf.scene||gltf;if(disposed||token!==generation){release(candidate);return false;}asset=candidate;try{installation=install(world,asset,configure);installation.setEnabled(enabled);status='ready';notify();return true;}catch(e){release(asset);asset=null;throw e;}}).catch(e=>{if(token===generation&&!disposed){status='error';error=String(e.message||e);notify();}return false;}).finally(()=>{if(token===generation){pending=null;controller=null;}});return pending;}
function clear(){generation++;controller?.abort();controller=null;pending=null;installation?.dispose();installation=null;release(asset);asset=null;}
function restore(){if(disposed)return;clear();status='idle';error=null;notify();}
function dispose(){if(disposed)return;clear();disposed=true;status='disposed';notify();}
function setEnabled(value){if(disposed)return;enabled=!!value;installation?.setEnabled(enabled);notify();}
return{ensure,restore,dispose,setEnabled,getState,getRoot:()=>installation?.root||null};
}
