import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const root=new URL('../',import.meta.url),base=new URL('reef-current-fallback/dist/',root),candidate=new URL('dist/',import.meta.url);
const threeURL=new URL('reef-current-fallback/dist/vendor/three.module.js',root).href;
const THREE=await import(threeURL);
async function moduleAt(url,extra={}){let text=await fs.readFile(url,'utf8');text=text.replaceAll('?v=surface-20261008-r1','');text=text.replaceAll("'three'",JSON.stringify(threeURL));for(const [from,to]of Object.entries(extra))text=text.replaceAll(from,to);return 'data:text/javascript;base64,'+Buffer.from(text).toString('base64');}
const surfaceURL=await moduleAt(new URL('scan-surface.js',candidate));const {loadWorldSurface,softenSharedNormals}=await import(surfaceURL);
const load=THREE.TextureLoader.prototype.loadAsync;THREE.TextureLoader.prototype.loadAsync=async()=>new THREE.Texture();const surface=await loadWorldSurface();THREE.TextureLoader.prototype.loadAsync=load;
const baseline=await import(await moduleAt(new URL('scan-world.js',base)));
const changed=await import(await moduleAt(new URL('scan-world.js',candidate),{"'./scan-surface.js'":JSON.stringify(surfaceURL)}));
const corals=new THREE.Group();for(let i=0;i<2;i++)corals.add(new THREE.Mesh(new THREE.SphereGeometry(1,12,6),new THREE.MeshStandardMaterial({vertexColors:true})));
const a=baseline.createScanWorld(new THREE.Scene(),corals,()=>{}),b=changed.createScanWorld(new THREE.Scene(),corals,()=>{},surface);
const hash=x=>createHash('sha256').update(Buffer.from(x.buffer,x.byteOffset,x.byteLength)).digest('hex');
assert.equal(a.batches.length,b.batches.length);
for(let i=0;i<a.batches.length;i++){const x=a.batches[i],y=b.batches[i];assert.equal(x.name,y.name);assert.equal(x.count,y.count);assert.equal(hash(x.instanceMatrix.array),hash(y.instanceMatrix.array));if(x.instanceColor)assert.equal(hash(x.instanceColor.array),hash(y.instanceColor.array));for(const attr of ['position','uv','color'])if(x.geometry.attributes[attr])assert.equal(hash(x.geometry.attributes[attr].array),hash(y.geometry.attributes[attr].array));assert.equal(x.geometry.index?.count,y.geometry.index?.count);if(x.geometry.index)assert.equal(hash(x.geometry.index.array),hash(y.geometry.index.array));}
assert.deepEqual(a.obstacles.map(o=>o.box.toArray?.()||[o.box.min.toArray(),o.box.max.toArray()]),b.obstacles.map(o=>[o.box.min.toArray(),o.box.max.toArray()]));
assert.equal(a.budget.triangles,b.budget.triangles);assert.equal(a.budget.drawCalls,b.budget.drawCalls);assert.equal(a.budget.instancedObjects,b.budget.instancedObjects);
console.log('PASS: every world position, index, UV, vertex/instance colour, instance matrix, obstacle bounds, draw count and triangle count preserved.');
assert.notEqual(hash(a.batches[0].geometry.attributes.normal.array),hash(b.batches[0].geometry.attributes.normal.array));
for(const batch of b.batches)for(const v of batch.geometry.attributes.normal.array)assert(Number.isFinite(v));
console.log('PASS: stone normals changed only, finite, no geometry displacement or subdivision.');
const {createScanOcean}=await import(await moduleAt(new URL('scan-ocean.js',candidate)));
const ocean=createScanOcean(new THREE.Scene(),new THREE.Texture());const mat=surface.limestone(new THREE.MeshStandardMaterial());ocean.configure(mat);
const shader={vertexShader:THREE.ShaderLib.standard.vertexShader,fragmentShader:THREE.ShaderLib.standard.fragmentShader,uniforms:{}};mat.onBeforeCompile(shader);
for(const name of ['reefStoneNormal','reefStoneRough','exhibitOceanMode','exhibitCaustics'])assert(shader.uniforms[name]);
assert(shader.fragmentShader.includes('reefDetail'));assert(shader.fragmentShader.includes('vExhibitWorld'));assert(shader.fragmentShader.includes('roughnessFactor=.86+.14*reefR;'));
console.log('PASS: composed surface/ocean shader hooks and uniforms preserved. GPU compilation remains for fresh capture pipeline.');
for(const i of [2,3,4,5]){const path=new URL('assets/reef-texture-'+i+'.png',base);assert((await fs.stat(path)).size>0);}
const baselineExhibit=await fs.readFile(new URL('scan-exhibit.js',base),'utf8'),candidateExhibit=await fs.readFile(new URL('scan-exhibit.js',candidate),'utf8');
assert.equal(candidateExhibit.replaceAll('?v=surface-20261008-r1','').replace("'./scan-route.js'","'./scan-route.js?v=arrival-20261008-r1'").replace("import {loadWorldSurface} from './scan-surface.js';\n",'').replace('const worldSurface=await loadWorldSurface();world=createScanWorld(scene,coralAsset.scene,m=>ocean.configure(m),worldSurface);','world=createScanWorld(scene,coralAsset.scene,m=>ocean.configure(m));'),baselineExhibit);
console.log('PASS: exhibit change limited to awaited surface asset load; source scan and all controls untouched.');
console.log(JSON.stringify(surface.budget,null,2));

assert.equal((await fs.readFile(new URL('scan-route.js',candidate),'utf8')).replace('?v=surface-20261008-r1',''),await fs.readFile(new URL('scan-route.js',base),'utf8'));console.log('PASS: route importer cache tag only; route logic unchanged.');
