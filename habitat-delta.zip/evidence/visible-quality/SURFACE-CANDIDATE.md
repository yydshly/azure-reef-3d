# Scan-world porous material candidate

Baseline: published main 7d302284036b1500b48a1474b6d0972e9c120c5a, Pages run 37807138800; local source reef-current-fallback. All four actual baseline gallery frames were inspected before implementation.

## Evidence and bounded response

The three scan-world views contain near/mid-field monochrome polygon faces dominating the rendered image. The synthetic terrain is a non-indexed detail-1 icosahedron without any colour or surface texture. In contrast, the retained original artificial reef includes generated porous limestone/coral normal and roughness maps. The extracted branch assets retain original vertex colours and UVs but did not retain those PBR maps.

This candidate changes only scan-world synthetic material response and shared-corner normals, plus reduces repetitive surface ripple contrast. World positions, scales, rotations, indices, UVs, vertex/instance colours, route/collision geometry, and every triangle/draw count remain unchanged. A 75% shared-corner normal blend retains 25% face normal to preserve broad fractures. There is no subdivision, displacement, generated shell, additional boulder, or replicated scan. Original artificial opening is the unchanged control.

Four existing original artificial-world textures are reused: reef-texture-2/3.png (limestone normal/roughness) and reef-texture-4/5.png (coral normal/roughness). No texture bytes were changed or added, no outside assets downloaded. Colour maps use existing vertex colours; synthetic mineral/encrusting variation is a world-space shader treatment, not recorded ecology. Stone normal/roughness sampling is triplanar with a two-demo-unit tile, independent of instance scale. Coral maps use their retained original UVs, linear texture colour space, and glTF-compatible flipY=false. Materials remain nonmetallic and rough.

C12019 mesh and photographic texture, CC BY-NC provenance, source attribution, raw observation, routes, motion, controls, learning, return and recovery logic are untouched. The only scan-exhibit.js change awaits loading the four existing maps before constructing the world, so first capture cannot race surface readiness.

## Budget

- New geometry: 0 triangles, 0 draws, 0 instances
- Existing maps newly requested by scan scene: 4 files, 3,609,276 compressed bytes
- Estimated additional GPU texture storage: 22,369,624 bytes (four 1024² RGBA8 textures with full mipmaps; browser/driver overhead not included)
- Stone shader: 6 additional texture lookup expressions (3 normal + 3 roughness); procedural colour noise adds ALU work
- Coral material: 2 additional texture lookup expressions (normal + roughness)
- Existing caustics lookup remains unchanged
- Original artificial view and its asset loading are unchanged
- No FPS claim; runtime render triangles and calls must be compared in fresh capture manifest

## Verification

node reef-surface-candidate/qa-surface.mjs passes: exact generated world position/index/UV/vertex/instance-colour/matrix/obstacle equality, finite changed normals, budget equality, surface/ocean shader hook composition, and scan-exhibit change scope. Syntax checks pass. This is CPU/source verification, not GPU shader compilation or visual acceptance.

Required before acceptance: one combined build with supporting compact HUD, same four view captures via existing fail-closed/version-bound pipeline, inspect actual pixels. The three scan views must show readable porous/mineral detail rather than dominant flat monochrome facets; water must remain legible without bright repeating ceiling marks; no oily highlights, obvious oversized tiling, source scan change, or route change. Existing low-poly silhouettes and sparse ecology remain acknowledged limits; this bounded candidate does not claim full-world aesthetic completion.

Cache coherence: changed module imports use surface-20261008-r1 throughout scan-exhibit → scan-world/scan-ocean/scan-surface/scan-route and scan-route → scan-world. scan-route.js has only this import-tag change; pure route logic is byte-identical after stripping the tag. Publisher owns combined HTML entry cache tag.
