// Imported by the hosted publisher's existing Playwright capture harness.
// Does not replace or alter the fixed-view capture pipeline. Native UI checks restore state.
import assert from 'node:assert/strict';
export async function nativeHudTarget(page,selector){
 return page.evaluate(selector=>{
  const e=document.querySelector(selector);if(!e)throw Error('Missing '+selector);
  e.scrollIntoView({block:'nearest',inline:'nearest',behavior:'instant'});
  const r=e.getBoundingClientRect(),style=getComputedStyle(e);
  const x=r.x+r.width/2,y=r.y+r.height/2,h=document.elementFromPoint(x,y);
  let visible=true;for(let n=e;n;n=n.parentElement){const c=getComputedStyle(n);if(n.hidden||c.display==='none'||c.visibility==='hidden'||c.visibility==='collapse'||Number(c.opacity)===0)visible=false;}
  if(!visible||e.disabled||r.width<=0||r.height<=0||x<0||y<0||x>=innerWidth||y>=innerHeight||!(h===e||e.contains(h)))throw Error('Blocked/disabled/outside '+selector);
  return {x,y,width:r.width,height:r.height};
 },selector);
}
export async function nativeHudClick(page,selector){
 const p=await nativeHudTarget(page,selector);
 assert(await page.evaluate(({selector,x,y})=>{const e=document.querySelector(selector),h=document.elementFromPoint(x,y);return !!e&&!e.disabled&&(h===e||e.contains(h))},{selector,...p}),'Target changed before trusted click: '+selector);
 await page.mouse.click(p.x,p.y);
}
export async function openHudControl(page,selector){
 const nested=await page.evaluate(selector=>{const e=document.querySelector(selector);if(!e)throw Error('Missing '+selector);return !!e.closest('#hudMorePanel')},selector);
 if(nested&&!await page.evaluate(()=>document.querySelector('#hudMore').open))await nativeHudClick(page,'#hudMoreSummary');
 return nativeHudTarget(page,selector);
}
export async function checkHud(page){
 const results=[];
 const state=()=>page.evaluate(()=>{const s=window.reefExhibit.getState();return {camera:s.camera,target:s.target,route:s.route,waterMode:s.waterMode,ambient:s.ambient}});
 const initial=await state();
 const oldViewport=page.viewportSize();
 assert(initial.route.active&&initial.route.progress===0&&initial.waterMode,'Run HUD smoke at paused route start');
 assert(await page.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches),'Use existing reduced-motion capture context');
 for(const viewport of [{width:1120,height:780},{width:390,height:844},{width:320,height:568}]){
  await page.setViewportSize(viewport);
  const m=await page.evaluate(()=>{
   const rect=e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom}};
   const stage=rect(document.querySelector('#scanStage')),hud=rect(document.querySelector('.stage-controls')),label=rect(document.querySelector('.stage-label'));
   const central=document.elementFromPoint(innerWidth/2,stage.y+stage.height*.58);
   return {viewport:{width:innerWidth,height:innerHeight},stage,hud,label,hudUnoccludedFraction:1-hud.width*hud.height/(stage.width*stage.height),sceneUnoccludedFraction:1-(hud.width*hud.height+label.width*label.height)/(stage.width*stage.height),centerClear:central?.id==='scanCanvas',overflow:document.documentElement.scrollWidth>innerWidth,
    targets:['#swimBack','#swimForward','#exploreRoute','#pauseAmbient','#hudMoreSummary','#routeProgress'].map(id=>({id,...rect(document.querySelector(id))})),creditVisible:document.querySelector('.hud-credit').getBoundingClientRect().bottom<innerHeight};
  });
  assert(m.centerClear,'Central travel corridor blocked');assert(!m.overflow,'Horizontal overflow');assert(m.hud.height<=150,'Collapsed HUD exceeds 150px');assert(m.hud.bottom<=viewport.height+1,'HUD below viewport');assert(m.creditVisible,'Credit absent');
  for(const r of m.targets){assert(r.height>=44,`${r.id} small hit target`);assert(r.x>=0&&r.right<=viewport.width,`${r.id} overflow`)}
  await nativeHudClick(page,'#hudMoreSummary');assert(await page.evaluate(()=>document.querySelector('#hudMore').open));
  for(const selector of ['#nearView','#wideView','#toggleOcean','#routeStart','#routeFront','#routeSide','#resetExhibit','#softenExhibit','#scanProvenance .source-link']){
   await openHudControl(page,selector);
  }
  // Native pointer gives focus; Escape closes without leaking to scene controls.
  await nativeHudClick(page,'#closeHudMore');
  assert(!await page.evaluate(()=>document.querySelector('#hudMore').open));
  assert(await page.evaluate(()=>document.activeElement.id==='hudMoreSummary'));
  await page.keyboard.press('Enter');
  assert(await page.evaluate(()=>document.querySelector('#hudMore').open));
  await page.keyboard.press('Tab');await page.keyboard.press('Escape');
  assert(!await page.evaluate(()=>document.querySelector('#hudMore').open));
  assert(await page.evaluate(()=>document.activeElement.id==='hudMoreSummary'));

  await nativeHudClick(page,'#swimForward');assert(Math.abs((await state()).route.progress-.05)<1e-8,'Native forward failed');
  await nativeHudClick(page,'#swimBack');assert.equal((await state()).route.progress,0,'Native backward did not restore start');
  results.push(m);
 }
 await page.setViewportSize(oldViewport);
 const final=await state();for(const key of ['camera','target'])assert(final[key].every((v,i)=>Math.abs(v-initial[key][i])<1e-6),'Viewport changed '+key);for(const key of ['route','waterMode','ambient'])assert.deepEqual(final[key],initial[key],'Disclosure changed '+key);
 // Small native regression: pauses and raw mode restore without replacing route state.
 await nativeHudClick(page,'#pauseAmbient');await nativeHudClick(page,'#pauseAmbient');
 await openHudControl(page,'#toggleOcean');await nativeHudClick(page,'#toggleOcean');assert(!(await state()).waterMode);
 await nativeHudClick(page,'#toggleOcean');assert((await state()).waterMode);
 await nativeHudClick(page,'#closeHudMore');
 const restored=await state();assert.deepEqual(restored.route,initial.route);assert.deepEqual(restored.ambient,initial.ambient);for(const key of ['camera','target'])assert(restored[key].every((v,i)=>Math.abs(v-initial[key][i])<1e-6),'Raw return changed '+key);
 assert(await page.evaluate(()=>scrollX===0&&scrollY===0&&!document.querySelector('#hudMore').open),'HUD smoke left scroll/disclosure changed');
 return results;
}
