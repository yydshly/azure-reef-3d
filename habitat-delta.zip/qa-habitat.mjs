import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import * as T from 'three';
import {GLTFLoader} from './dist/vendor/GLTFLoader.js';
import {createScanLife} from './dist/scan-life.js';import {createScanOcean} from './dist/scan-ocean.js';
import {createScanWorld,channelX} from './dist/scan-world.js';import {routePose} from './dist/scan-route.js';
globalThis.ProgressEvent=class{};
const asset=path.resolve(process.env.REEF_ASSET_DIR||'./dist/assets')+'/';
async function load(name){const d=JSON.parse(fs.readFileSync(asset+name+'.gltf'));for(const b of d.buffers)b.uri='data:application/octet-stream;base64,'+fs.readFileSync(path.resolve(asset,b.uri)).toString('base64');return(await new Promise((r,j)=>new GLTFLoader().parse(JSON.stringify(d),'',r,j))).scene;}
const surface={limestone:m=>m,coral:m=>m,budget:{stub:'CPU geometry only'}};
const scene=new T.Scene(),world=createScanWorld(scene,await load('scan-world-corals'),()=>{},surface);world.addFish((await load('scan-fish')).getObjectByName('fish_01'));scene.updateMatrixWorld(true);
let clearance=Infinity;for(let i=0;i<=10000;i++){const p=new T.Vector3(...routePose(i/10000).position);clearance=Math.min(clearance,...world.obstacles.map(o=>o.box.distanceToPoint(p)));}assert.ok(clearance>1.2,`route clearance ${clearance}`);assert.ok(world.budget.triangles<=180000);assert.ok(world.budget.drawCalls<=16);assert.ok(world.budget.additionalOwnedGeometryBytes<500000);
const meshes=world.batches.filter(m=>/Buttresses/.test(m.name)),roof=world.group.getObjectByName('Shadowed_Passage_Overhangs'),contacts=[];
// Check actual triangle-ray overlap inside both roof-side banks, beyond AABB overlap.
const ray=new T.Raycaster(),matrix=new T.Matrix4(),v=new T.Vector3();
for(let i=0;i<roof.count;i++){roof.getMatrixAt(i,matrix);const center=new T.Vector3().setFromMatrixPosition(matrix),side=i===0?-1:1;const probes=[];
 for(const dx of [3.7,4.1,4.5])for(const dz of [-.8,0,.8]){
  const x=center.x+side*dx,z=center.z+dz;ray.set(new T.Vector3(x,20,z),new T.Vector3(0,-1,0));const bank=ray.intersectObjects(meshes,false)[0];
  // DoubleSide roof gives both top and underside intersections.
  const old=roof.material.side;roof.material.side=T.DoubleSide;const hits=ray.intersectObject(roof,false).filter(h=>h.instanceId===i);roof.material.side=old;
  if(bank&&hits.length>=2){const bottom=Math.min(...hits.map(h=>h.point.y));probes.push({x,z,bankTop:bank.point.y,roofBottom:bottom,overlap:bank.point.y-bottom});}
 }
 assert.ok(probes.filter(p=>p.overlap>.3).length>=4,'roof must have broad actual bank intersection '+JSON.stringify(probes));contacts.push({roof:i,probes});
}
const habitatMeshes=world.batches.filter(m=>!/Shelves|Buttresses|Ridges|Overhangs|World_School/.test(m.name));let nearRoute=Infinity;for(const mesh of habitatMeshes){mesh.geometry.computeBoundingBox();for(let i=0;i<mesh.count;i++){mesh.getMatrixAt(i,matrix);const box=mesh.geometry.boundingBox.clone().applyMatrix4(matrix);for(let k=0;k<=1000;k++)nearRoute=Math.min(nearRoute,box.distanceToPoint(new T.Vector3(...routePose(k/1000).position)));}}
assert.ok(nearRoute>1.2,'habitat clear '+nearRoute);
const batches=world.batches.map(m=>({name:m.name,count:m.count,triangles:(m.geometry.index?.count||m.geometry.attributes.position.count)/3*m.count}));
const branchFooting=[];
for(const mesh of world.batches.filter(m=>/^(Existing_(Branching|Low_Mound)|Layered_Plate|Branching_Sea_Fan)/.test(m.name))){const attr=mesh.geometry.attributes.position;for(let instance=0;instance<mesh.count;instance++){mesh.getMatrixAt(instance,matrix);let maxGap=-Infinity,supported=0,points=0,rootSamples=0;for(let i=0;i<attr.count;i++){if(attr.getY(i)>.06)continue;rootSamples++;v.fromBufferAttribute(attr,i).applyMatrix4(matrix);ray.set(new T.Vector3(v.x,30,v.z),new T.Vector3(0,-1,0));const hit=ray.intersectObjects(world.batches.slice(0,2),false)[0];if(hit){points++;maxGap=Math.max(maxGap,v.y-hit.point.y);if(v.y-hit.point.y<.2)supported++;}}branchFooting.push({mesh:mesh.name,instance,maxGap,supported,points,rootSamples});}}
for(const footing of branchFooting){assert.equal(footing.points,footing.rootSamples,'All sampled base vertices need bank under them: '+footing.mesh);assert.ok(footing.maxGap<.23,'No raised colony base: '+JSON.stringify(footing));}
const ocean=createScanOcean(scene,new T.Texture()),life=createScanLife((await load('scan-fish')).getObjectByName('fish_01'),()=>{});scene.add(life.group);
function counts(root){let triangles=0,meshDraws=0,pointDraws=0;root.traverse(o=>{if(o.isMesh){meshDraws++;triangles+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3*(o.count||1);}if(o.isPoints)pointDraws++;});return {triangles,meshDraws,pointDraws};}
const fullSynthetic=counts(scene),rigFish=counts(life.group),oceanBudget=counts(ocean.group);assert.ok(fullSynthetic.triangles<220000);
const result={passed:true,visualAcceptance:false,budget:world.budget,branchFooting,fullSynthetic,rigFish,oceanBudget,sourceScanTriangles:149822,fullSceneTrianglesIncludingScan:fullSynthetic.triangles+149822,minSolidRouteClearance:clearance,minHabitatRouteClearance:nearRoute,actualRoofBankContacts:contacts,habitatContacts:world.group.userData.habitat.contacts.length,gardens:world.group.userData.habitat.gardens,batches};fs.writeFileSync('evidence/cpu.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
