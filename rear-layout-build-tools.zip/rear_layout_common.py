"""Exact local publication guards. Receipts and QA tools stay outside dist."""
import hashlib
import json
import math
import os
import pathlib
import re
import stat
import struct
import time
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
DIST = pathlib.Path('dist')
INPUTS = pathlib.Path('.rear-layout-inputs')
ENTRY_NAMES = ('index.html', 'world.css', 'current-world.json')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(pathlib.Path(path).read_text())


def save_json(path, value):
    pathlib.Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n')


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()


def safe_name(name):
    require(isinstance(name, str) and bool(name), 'Missing relative path')
    p = pathlib.PurePosixPath(name)
    require(not p.is_absolute() and '..' not in p.parts and '\\' not in name and p.as_posix() == name and name != '.', 'Unsafe path: ' + name)
    return p


def inventory(root):
    root = pathlib.Path(root)
    require(root.is_dir() and not root.is_symlink(), 'Missing/linked directory: ' + str(root))
    result = {}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink() and (p.is_file() or p.is_dir()), 'Linked/special path: ' + str(p))
        if p.is_file():
            result[p.relative_to(root).as_posix()] = sha(p.read_bytes())
    return result


def file_record(path, relative=None):
    p = pathlib.Path(path)
    b = p.read_bytes()
    return {'path': relative or p.name, 'bytes': len(b), 'sha256': sha(b)}


def validate_bytes(data, record, label):
    require(len(data) == record['bytes'] and sha(data) == record['sha256'], 'Size/SHA mismatch: ' + label)


def checked_archive(path, archive, expected):
    p = pathlib.Path(path)
    require(p.is_file() and not p.is_symlink(), 'Missing/linked archive: ' + str(p))
    validate_bytes(p.read_bytes(), archive, str(p))
    with zipfile.ZipFile(p) as z:
        require(len(z.namelist()) == len(set(z.namelist())) == len(expected) and set(z.namelist()) == set(expected), 'Unexpected archive file set: ' + str(p))
        files = {}
        for info in z.infolist():
            safe_name(info.filename)
            mode = info.external_attr >> 16
            require(not info.is_dir() and not stat.S_ISLNK(mode) and stat.S_IFMT(mode) in (0, stat.S_IFREG), 'Nonregular archive member')
            data = z.read(info)
            validate_bytes(data, expected[info.filename], info.filename)
            files[info.filename] = data
    return files


def contract():
    c = read_json(HERE / 'rear-layout-contract.json')
    require(c['candidatePath'] == 'preview/rear-layout-candidate' and c['basePath'] == 'preview/grounded-integration-candidate' and c['entryPath'] == 'preview/world', 'Unexpected destination')
    require(c['oldSiteFiles'] == 1665 and c['protectedFiles'] == 1662 and c['rootFiles'] == 79 and c['finalSiteFiles'] == 1817, 'Publication counts changed')
    require(c['totalBudgetMs'] == 450000 and c['captureTimeoutMs'] == 25000 and c['fieldLoadBudgetMs'] == 120000, '450/25-second budgets changed')
    require(c['mutableEntryPaths'] == [c['entryPath'] + '/' + n for n in ENTRY_NAMES], 'Entry allowlist changed')
    require(len(c['sourceFiles']) == len(c['sourceHashes']) == c['newSourceFiles'] == 146, 'Expected 146 candidate sources')
    require({f['path']: f['sha256'] for f in c['sourceFiles']} == c['sourceHashes'], 'Candidate source contract mismatch')
    for n in c['sourceHashes']:
        safe_name(n)
    aggregate = sha(''.join(n + '\0' + c['sourceHashes'][n] + '\n' for n in sorted(c['sourceHashes'])).encode())
    require(aggregate == c['sourceHashAggregate'], 'Candidate source aggregate mismatch')
    require(len(c['baseSourceHashes']) == len(c['baseSourceFiles']) == 144, 'Expected 144 baseline sources')
    require({f['path']: f['sha256'] for f in c['baseSourceFiles']} == c['baseSourceHashes'], 'Baseline source contract mismatch')
    changes = {f['path']: f for f in c['changes']}
    require(set(changes) == {'rear-habitat.js', 'rear-connected.js', 'rear-connected-data.js'}, 'Unexpected candidate changes')
    predicted = dict(c['baseSourceHashes'])
    for n, f in changes.items():
        require(c['baseSourceHashes'].get(n) == f['baseSha256'], 'Delta base SHA mismatch: ' + n)
        predicted[n] = f['sha256']
    require(predicted == c['sourceHashes'] and sum(c['sourceHashes'].get(n) == h for n, h in c['baseSourceHashes'].items()) == 143, 'Expected 143 unchanged sources and exact 3-file overlay')
    return c


def snapshot(c):
    records = {f['path']: f for f in c['snapshotFiles']}
    require(len(records) == 11, 'Expected old 6-gallery + 5-world snapshot')
    files = checked_archive(INPUTS / c['snapshotArchive']['path'], c['snapshotArchive'], records)
    public = {f['path']: f for f in c['oldPublicFiles']}
    require(len(public) == 155 and all(public.get(n) == records[n] for n in records), 'Old published receipt mismatch')
    expected = {c['basePath'] + '/' + n for n in c['baseSourceHashes']} | set(files)
    require(set(public) == expected, 'Old public receipt file set mismatch')
    for f in c['baseSourceFiles']:
        require(public[c['basePath'] + '/' + f['path']] == dict(f, path=c['basePath'] + '/' + f['path']), 'Old published source SHA mismatch')
    require({n for n in files if n.startswith(c['entryPath'] + '/')} == set(c['mutableEntryPaths']) | {
        c['entryPath'] + '/evidence/entry-desktop-bbb983341a60709f.png',
        c['entryPath'] + '/evidence/entry-narrow-9bb3292ddabfbf21.png'}, 'Old entry snapshot changed')
    pointer = json.loads(files[c['entryPath'] + '/current-world.json'])
    require(pointer['mainCommit'] == c['baseMainCommit'] == '7d729996eab637a046f62e75e7cb17c53fe7bc9a' and pointer['candidateSourceCommit'] == c['baseSourceCommit'] and pointer['sourceHashAggregate'] == c['baseSourceHashAggregate'], 'Published baseline identity mismatch')
    return files


def check_sources(c):
    root = DIST / c['candidatePath']
    for f in c['sourceFiles']:
        p = root / f['path']
        require(p.is_file() and not p.is_symlink(), 'Missing/linked candidate source: ' + f['path'])
        validate_bytes(p.read_bytes(), f, f['path'])


def check_old(c):
    protected = read_json('.rear-layout-protected.json')
    previous = read_json('.grounded-protected.json')
    require(len(previous) == 1510, 'Original assembly protection count mismatch')
    expected = dict(previous)
    expected.update({f['path']: f['sha256'] for f in c['oldPublicFiles'] if f['path'] not in c['mutableEntryPaths']})
    require(len(expected) == 1662 and protected == expected, 'Protected inventory must be exact 1662 old files')
    current = inventory(DIST)
    for n, digest in protected.items():
        safe_name(n)
        require(current.get(n) == digest, 'Original file changed/missing: ' + n)
    root = read_json('.root-site-hashes.json')
    require(len(root) == 79 and all(protected.get(n) == h for n, h in root.items()), 'Original 79 root files missing from protection')
    require({n: h for n, h in current.items() if not n.startswith('preview/')} == root, 'Root site files changed')
    return protected, current


def check_deadline():
    d = read_json('.rear-layout-deadline.json')
    require(d['totalBudgetMs'] == 450000 and isinstance(d['startedAtMs'], (int, float)) and isinstance(d['expiresAtMs'], (int, float)), 'Invalid shared 450-second deadline')
    require(d['expiresAtMs'] - d['startedAtMs'] == 450000, 'Shared deadline extended')
    now = time.time() * 1000
    require(d['startedAtMs'] <= now < d['expiresAtMs'], 'Shared 450-second deadline expired/invalid')
    return d


def source_identity(c):
    identity = {'candidateSourceCommit': os.environ.get('REAR_LAYOUT_SOURCE_COMMIT', ''), 'checkoutCommit': os.environ.get('GITHUB_SHA', ''),
                'candidatePath': c['candidatePath'], 'sourceHashAggregate': c['sourceHashAggregate'], 'sourceFiles': 146}
    for key in ('candidateSourceCommit', 'checkoutCommit'):
        require(re.fullmatch('[0-9a-f]{40}', identity[key]), 'Missing exact commit: ' + key)
    return identity


def png_bytes(path, record):
    p = pathlib.Path(path)
    require(p.is_file() and not p.is_symlink(), 'Missing/linked PNG: ' + str(p))
    b = p.read_bytes()
    validate_bytes(b, record, str(p))
    require(len(b) > 32 and b[:8] == b'\x89PNG\r\n\x1a\n' and b[12:16] == b'IHDR', 'Invalid PNG')
    w, h = struct.unpack('>II', b[16:24])
    require(w > 800 and h > 500, 'Unexpected PNG dimensions')
    return b, w, h


def candidate_sources(c):
    return {c['candidatePath'] + '/' + n for n in c['sourceHashes']}


def expected_entry(c, identity, old_snapshot):
    old_base, new_base = '../grounded-integration-candidate/', '../rear-layout-candidate/'
    original = old_snapshot[c['entryPath'] + '/index.html'].decode()
    require(original.count(old_base) == 4, 'Unexpected old entry link count')
    old_status = '当前入口指向局部接地实验，整体真实感未通过。<br>候选源码：<code>' + c['baseSourceCommit'] + '</code><br>发布构建：<code>' + c['baseMainCommit'] + '</code>'
    require(original.count(old_status) == 1, 'Unexpected old entry version text')
    new_status = '当前入口指向局部后方布局候选，未通过整体美术验收。<br>候选源码：<code>' + identity['candidateSourceCommit'] + '</code><br>发布构建：<code>' + identity['checkoutCommit'] + '</code>'
    index = original.replace(old_base, new_base).replace(old_status, new_status)
    pointer = {'schemaVersion': 2, 'entryPublishPath': c['entryPath'] + '/', 'version': 'rear-layout-' + c['sourceHashAggregate'],
               'selection': 'manually-selected-pinned-rear-layout-candidate-after-technical-qa',
               'candidateSourceCommit': identity['candidateSourceCommit'], 'mainCommit': identity['checkoutCommit'],
               'sourceHashAggregate': c['sourceHashAggregate'], 'candidatePath': c['candidatePath'],
               'world': new_base + 'scan-exhibit.html', 'procedural': new_base + 'index.html',
               'stills': new_base + 'current-scene.html', 'sources': new_base + 'scan-exhibit.html#scanProvenance',
               'technicalStatus': 'PASS_SUPPORTED_BROWSER', 'appearanceAccepted': False, 'acceptance': c['acceptance'],
               'acceptanceChinese': c['acceptanceChinese'], 'unverified': c['unverified'],
               'entryEvidence': 'Existing entry PNGs are preserved historical evidence; this update does not claim new entry screenshots.',
               'updatePolicy': 'Manually selected candidate source and explicit QA commit; never select newest Git commit. Provenance is not an immutable URL lock.'}
    return {'index.html': index.encode(), 'world.css': old_snapshot[c['entryPath'] + '/world.css'], 'current-world.json': json_bytes(pointer)}, pointer


def gallery_records(c):
    receipt = read_json('.rear-layout-finalized.json')
    records = receipt['galleryFiles']
    require(len(records) == len({f['path'] for f in records}) == 6, 'Expected exact six new gallery files')
    base = c['candidatePath'] + '/'
    prefix = base + 'assets/current-scene/' + c['sourceHashAggregate'] + '/'
    static = {base + 'current-scene.html', prefix + 'manifest.json'}
    require(static <= {r['path'] for r in records}, 'Gallery HTML/manifest paths changed')
    actual = set()
    for f in records:
        safe_name(f['path'])
        if f['path'] in static:
            continue
        require(f['path'].startswith(prefix), 'Gallery escaped candidate directory')
        name = f['path'][len(prefix):]
        suffix = '-' + f['sha256'][:16] + '.png'
        require(name.endswith(suffix), 'Gallery filename/SHA mismatch')
        actual.add(name[:-len(suffix)])
    require(actual == set(c['frames']), 'Gallery frame set changed')
    return receipt, records
