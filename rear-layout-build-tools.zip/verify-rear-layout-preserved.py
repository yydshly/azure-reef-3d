"""Check all 1662 protected bytes and exact candidate/entry output allowlists."""
import sys
from rear_layout_common import *


def main():
    require(sys.argv[1:] in ([], ['--source-only']), 'Unexpected arguments')
    c = contract()
    protected, current = check_old(c)
    check_sources(c)
    expected = candidate_sources(c) | set(c['mutableEntryPaths'])
    old_snapshot = snapshot(c)
    if '--source-only' in sys.argv:
        require(not pathlib.Path('.rear-layout-finalized.json').exists(), 'Already finalized')
        for n in c['mutableEntryPaths']:
            require((DIST / n).read_bytes() == old_snapshot[n], 'Published old entry changed before GPU pass: ' + n)
        require(len(current) == 1811, 'Expected 1811 staged files')
    else:
        check_deadline()
        receipt, gallery = gallery_records(c)
        identity = source_identity(c)
        require(receipt['sourceIdentity'] == identity, 'Final source identity mismatch')
        require(receipt['state'] == 'GPU_PASS_EXACT_ENTRY_UPDATE' and receipt['appearanceAccepted'] is False, 'Technical pass cannot imply appearance acceptance')
        for f in gallery:
            validate_bytes((DIST / f['path']).read_bytes(), f, f['path'])
            expected.add(f['path'])
        entry, pointer = expected_entry(c, identity, old_snapshot)
        require(receipt['pointer'] == pointer, 'Receipt pointer mismatch')
        require({f['path'] for f in receipt['entryFiles']} == set(ENTRY_NAMES) and len(receipt['entryFiles']) == 3, 'Exact three entry product files required')
        for n, b in entry.items():
            require((DIST / c['entryPath'] / n).read_bytes() == b, 'Entry differs from exact permitted update: ' + n)
        for f in receipt['entryFiles']:
            validate_bytes(entry[f['path']], f, f['path'])
        require(len(current) == 1817 and len(expected) == 155, 'Expected 1817 total, 152 new candidate files, and 3 entry products')
        check_deadline()
    require(set(current) - set(protected) == expected, 'Unexpected/missing additions: ' + repr(sorted((set(current) - set(protected)) ^ expected)))
    print('OLD_1662_BYTE_IDENTICAL_EXACT_REAR_LAYOUT_OUTPUT', len(expected))
    if not sys.argv[1:]:
        print('REAR_LAYOUT_PUBLIC_RECEIPT', json.dumps({'status': 'PASS_EXACT_152_ADDITIONS_3_ENTRY_PRODUCTS',
              'oldSiteFiles': 1665, 'protectedFiles': 1662, 'protectedFilesByteIdentical': True, 'rootFilesByteIdentical': 79,
              'oldEntryPNGsByteIdentical': 2, 'newEntryScreenshots': 0, 'newFiles': 152, 'totalFiles': 1817,
              'sourceIdentity': identity, 'appearanceAccepted': False,
              'files': [file_record(DIST / n, n) for n in sorted(expected)]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
