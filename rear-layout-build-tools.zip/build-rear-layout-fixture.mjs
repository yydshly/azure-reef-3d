// Local CPU-only fixture generation. Does not start a browser, fetch a network,
// modify product files, or overwrite the candidate's frozen verification inputs.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const toolsRoot=path.dirname(fileURLToPath(import.meta.url));
export const candidate=path.resolve(process.argv[2]||'reef-rear-layout-candidate');
const baseline=path.resolve(process.argv[3]||'reef-grounded-integration-candidate');
const sha=a=>createHash('sha256').update(Buffer.isBuffer(a)?a:Buffer.from(a.buffer,a.byteOffset,a.byteLength)).digest('hex');
const hashes=JSON.parse(fs.readFileSync(path.join(candidate,'verification/baseline-before.json')));
const oldFiles=Object.keys(hashes).filter(p=>p.startsWith('page/'));
assert.equal(oldFiles.length,144);
for(const file of oldFiles){assert.equal(sha(fs.readFileSync(path.join(baseline,file))),hashes[file],'Published baseline source '+file);if(file!=='page/rear-habitat.js')assert.equal(sha(fs.readFileSync(path.join(candidate,file))),hashes[file],'Protected candidate source '+file);}
const adapter=fs.readFileSync(path.join(candidate,'page/rear-habitat.js'),'utf8').replace("import {refineRearHabitat} from './rear-connected.js';\n",'').replace('return refineRearHabitat({world,original:api,parent});','return api;');
assert.equal(sha(Buffer.from(adapter)),hashes['page/rear-habitat.js'],'Only original importer/return wrapping permitted');
const frozen=JSON.parse(fs.readFileSync(path.join(candidate,'verification/rear-state-cpu.json')));
assert.equal(sha(fs.readFileSync(path.join(candidate,'page/rear-connected-data.js'))),frozen.dataSHA256);
const nativeFetch=globalThis.fetch;globalThis.self=globalThis;globalThis.ProgressEvent=class{};
globalThis.fetch=async u=>{const s=typeof u==='string'?u:u.url;if(s.startsWith('data:')||s.startsWith('blob:'))return nativeFetch(u);assert(s.startsWith('file://'),'Fixture must never fetch network');return new Response(fs.readFileSync(fileURLToPath(s)));};
export async function buildScene(dir,{full=true}={}){
 const root=path.join(dir,'page'),imp=n=>import(pathToFileURL(path.join(root,n)));
 const T=await imp('vendor/three.module.js'),{GLTFLoader}=await imp('vendor/GLTFLoader.js');
 async function load(name){const p=path.join(root,name),loader=new GLTFLoader();loader.register(parser=>{parser.loadTextureImage=async()=>{const t=new T.Texture();t.flipY=false;t.colorSpace=T.SRGBColorSpace;return t;};return{name:'LOCAL_TEXTURE_PLACEHOLDERS'};});const b=fs.readFileSync(p);return loader.parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),pathToFileURL(path.dirname(p)+'/').href);}
 const {createScanWorld}=await imp('scan-world.js'),{createScanOcean}=await imp('scan-ocean.js'),{placeC4}=await imp('scan-landmark.js'),{installAssemblage}=await imp('scan-assemblage.js'),{installNaturalRockCandidate}=await imp('install-natural-rock.js'),{installLayeredRidges}=await imp('install-layered-ridges.js');
 const scene=new T.Scene(),ocean=createScanOcean(scene,new T.Texture());
 const c4=placeC4((await load('assets/reefs4d/C42019-web-150k.glb')).scene,ocean.ground);scene.add(c4);
 const world=createScanWorld(scene,(await load('assets/scan-world-corals.gltf')).scene,()=>{},{limestone:m=>m,coral:m=>m,budget:{}},ocean.ground);
 let scan,life;const animals=[];
 if(full){scan=(await load('assets/reefs4d/C12019-web.glb')).scene;scan.name='Reefs4D_C1_original';scene.add(scan);for(const r of[scan,c4])r.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});const fish=(await load('assets/scan-fish.gltf')).scene.getObjectByName('fish_01');world.addFish(fish);const {createScanLife}=await imp('scan-life.js');life=createScanLife(fish,()=>{});scene.add(life.group);life.update(0);world.update(0);
  for(const name of['ray','turtle']){const mod=await imp('scan-'+name+'.js'),create=mod[name==='ray'?'createRayRuntime':'createTurtleRuntime'],animal=create({parent:scene,load:()=>load('assets/synthetic-reef-'+name+'.glb'),configure:()=>{}});assert(await animal.ensure());animal.update(0);animals.push(animal);}}
 installAssemblage(world,(await load('assets/reefs4d/C4-A-rounded-knobby.glb')).scene,c4);
 installNaturalRockCandidate({world,boulderScene:(await load('assets/boulder_01_LOD1_1k.glb')).scene,configure:()=>{}});
 const ridges=installLayeredRidges({world,ground:ocean.ground});
 if(full){const {createCoralMidgroundRuntime}=await imp('coral-midground-runtime.js');const coral=createCoralMidgroundRuntime({world,load:()=>load('assets/heliopora-lod-30000.glb')});assert(await coral.ensure());}
 scene.updateMatrixWorld(true);return{T,scene,world,ocean,scan,c4,life,animals,ridges,load,imp,root};
}
export const environment=await buildScene(candidate);
export const {T,scene,world,ocean,scan,c4,life,animals,ridges,load,imp,root}=environment;
const published=await buildScene(baseline,{full:false});
const rear=world.rearHabitat,h=rear.refinement;
export const inheritedVisible=o=>{for(let p=o;p;p=p.parent)if(!p.visible)return false;return true;};
export function budget(sceneRoot=scene){let mountedTriangles=0,visibleTriangles=0,mountedDraws=0,visibleDraws=0;sceneRoot.traverse(o=>{if(!o.isMesh)return;const t=(o.geometry.index?.count||o.geometry.attributes.position.count)/3*(o.isInstancedMesh?o.count:o.geometry.isInstancedBufferGeometry?o.geometry.instanceCount:1);mountedTriangles+=t;mountedDraws++;if(inheritedVisible(o)){visibleTriangles+=t;visibleDraws++;}});return{mountedTriangles,visibleTriangles,mountedDraws,visibleDraws};}
const attribute=a=>a?{count:a.count,itemSize:a.itemSize,normalized:a.normalized,arrayType:a.array.constructor.name,bytes:a.array.byteLength,sha256:sha(a.array)}:null;
const geometry=g=>({attributes:Object.fromEntries(Object.entries(g.attributes).map(([k,a])=>[k,attribute(a)])),index:attribute(g.index)});
const material=m=>({type:m.type,side:m.side,color:m.color?.toArray(),roughness:m.roughness,metalness:m.metalness,vertexColors:m.vertexColors,transparent:m.transparent,depthWrite:m.depthWrite,opacity:m.opacity});
const mesh=m=>({name:m.name,material:material(m.material),isInstancedMesh:!!m.isInstancedMesh,count:m.isInstancedMesh?m.count:1,castShadow:m.castShadow,receiveShadow:m.receiveShadow,frustumCulled:m.frustumCulled,matrix:m.matrix.toArray(),geometry:geometry(m.geometry),instanceMatrix:attribute(m.instanceMatrix),instanceColor:attribute(m.instanceColor)});
const shader=m=>({limestone:m.name.includes('Limestone')||m.name==='Rear_Broken_Reef_Islands',colonyRelief:/Attached_Lobes|Branch_Thicket|Crown_Branches/.test(m.name)});
for(const s of h.swaps){const original=published.world.rearHabitat.meshes.find(m=>m.name===s.original.name);assert(original);assert.deepEqual(mesh(s.original),mesh(original),'Exactly published original rear '+original.name);assert.equal(s.visible,original.visible);}
assert.deepEqual(budget(),frozen.budgetOff);
rear.setEnabled(false);const disabledBudget=budget();assert(h.swaps.every(s=>s.original.visible===s.visible&&inheritedVisible(s.original)));assert(!inheritedVisible(h.root));assert.deepEqual(disabledBudget,{...frozen.budgetOff,visibleTriangles:1280296});assert(rear.obstacles.every(o=>world.obstacles.includes(o)));assert(h.obstacles.every(o=>!world.obstacles.includes(o)));rear.setEnabled(true);assert.deepEqual(budget(),frozen.budgetOff);
const {REAR_CONNECTED_DATA:DATA}=await imp('rear-connected-data.js');
const remove=DATA.banks.flatMap(b=>b.remove.map(i=>b.name+'_'+i)),move=DATA.banks.flatMap(b=>b.move.map(m=>({name:b.name+'_'+m.index,...m})));
assert.equal(remove.length,51);assert.equal(move.length,651);assert.equal(h.meshes[0].geometry.index.count/3,16864);assert.equal(h.instances.reduce((n,m)=>n+m.count,0),1155);
const samePageProof={publishedBaselinePath:'reef-grounded-integration-candidate/page',publishedRearSourceSHA256:hashes['page/rear-habitat.js'],originalSourceFiles:144,unchangedSourceFiles:143,exactImportReturnAdapter:true,baselineOriginalMeshes:6,restoredTriangles:131804,candidateCombinedTriangles:117600,offRestoresOriginalResourcesAndObstacles:true,intermediateRejectedLayoutNotUsed:true};
export const fixture={format:'rear-layout-browser-fixture-v1',source:{kind:'CC0 terrestrial scan geometry used as art, not measured reef',url:'https://polyhaven.com/a/boulder_01',terrainTriangles:16864,dataSHA256:frozen.dataSHA256},samePageProof,expected:{budgetOff:frozen.budgetOff,budgetDisabled:disabledBudget,budgetFieldOn:frozen.budgetFieldOn,budgetDisposed:{mountedTriangles:1471660,visibleTriangles:1148492,mountedDraws:98,visibleDraws:86},netTriangles:-14204,combinedRearTriangles:117600,disposal:{geometries:1,instances:5,originalGeometries:1,originalInstances:5,borrowed:0},budgetDisposal:{triangles:117600,drawCalls:6}},sources:h.swaps.map(s=>({...mesh(s.original),originalVisible:s.visible,liveShaderRequirements:shader(s.original)})),placed:h.meshes.map(m=>({...mesh(m),parentName:m.parent.name,originalIndices:m.userData.originalIndices||null,liveShaderRequirements:shader(m)})),banks:DATA.banks.map(b=>({name:b.name,originalCount:b.originalCount,remove:b.remove,move:b.move.map(m=>({index:m.index,matrix:m.matrix,originalMatrix:m.originalMatrix}))})),actions:{remove:[...remove].sort(),move}};
fs.writeFileSync(path.join(toolsRoot,'rear-layout-fixture.json'),JSON.stringify(fixture,null,2)+'\n');
console.log(JSON.stringify({fixture:'rear-layout-fixture.json',sources:6,placed:6,remove:remove.length,move:move.length,budget:budget(),samePageProof}));
