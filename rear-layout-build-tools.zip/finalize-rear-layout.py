"""Create four-frame gallery and exact fixed-entry update after genuine bounded GPU QA."""
import html
from datetime import datetime
from rear_layout_common import *


def validate_gpu(c, report):
    require(report.get('syntheticFixture') is not True and report.get('status') == 'PASS_SUPPORTED_BROWSER', 'A genuine successful browser report is required')
    identity = source_identity(c)
    require(report['sourceIdentity'] == identity, 'GPU result source identity mismatch')
    require(report['errors'] == [] and not report.get('error'), 'GPU result contains errors')
    require(report['browser'] == {'sandbox': True, 'forbiddenFlagsAbsent': True}, 'Supported sandboxed browser proof required')
    deadline = check_deadline()
    for k in ('startedAt', 'startedAtMs', 'expiresAtMs', 'totalBudgetMs'):
        require(report[k] == deadline[k], 'GPU report belongs to another deadline: ' + k)
    completed = datetime.fromisoformat(report['completedAt'].replace('Z', '+00:00')).timestamp() * 1000
    require(deadline['startedAtMs'] <= completed <= time.time() * 1000 and completed < deadline['expiresAtMs'], 'Stale/invalid GPU completion time')
    require(isinstance(report['clock']['time'], (int, float)) and math.isfinite(report['clock']['time']) and report['clock']['time'] >= 0 and report['clock']['paused'] is True, 'Natural paused clock required')
    fixture = read_json(HERE / 'rear-layout-fixture.json')
    require(fixture['source']['dataSHA256'] == c['sourceHashes']['rear-connected-data.js'], 'GPU fixture belongs to different source bytes')
    require(report['samePageProof'] == fixture['samePageProof'] and fixture['samePageProof']['publishedRearSourceSHA256'] == c['baseSourceHashes']['rear-habitat.js'], 'OFF baseline must restore the published original')
    require(report['installation']['roots'] == 1 and report['installation']['metadata']['terrainTriangles'] == 16864, 'Candidate installed more than once or terrain changed')
    for k, v in {'netTriangles': -14204, 'combinedRearTriangles': 117600, 'triangles': 131804}.items():
        require(report['installation']['state'][k] == v, 'Installed rear budget changed: ' + k)

    def frame(f):
        require(f['ambient']['paused'] is True and f['ambient']['time'] == report['clock']['time'], 'Actual paused time mismatch')
        require(f['receipt']['sequence'] > f['previousSequence'], 'Frame was not freshly rendered')
        g = f['graphics']
        require(g['width'] == 1120 and g['height'] == 712 and g['contextLost'] is False and g['pixelError'] == 0 and g['sampleColors'] >= 2 and g['render']['calls'] > 0, 'Missing live nonblank 1120x712 GL frame')

    def budget(inspection, expected):
        require(inspection['issues'] == [], 'Scene inspection contains errors')
        require({k: inspection['budget'][k] for k in expected} == expected, 'Scene geometry budget mismatch')

    frames = report['frames']
    require([f['name'] for f in frames] == c['frames'], 'Expected exact ordered four rear frames')
    require([i['name'] for i in report['inspections']] == c['frames'], 'Four detailed scene inspections required')
    for f, inspection in zip(frames, report['inspections']):
        enabled = f['name'].endswith('-on')
        progress = .2 if '-20-' in f['name'] else .5
        require(f['view'] == 'backward' and f['field']['enabled'] is False and f['rear']['enabled'] is enabled, 'Wrong capture view/field/OFF-ON state')
        route = f['route']
        require(route['active'] is True and route['progress'] == route['goal'] == progress and abs(abs(route['yaw']) - math.pi) < .015 and route['pitch'] == 0, 'Expected native backward route pose')
        frame(f)
        require(inspection['frame'] == {k: v for k, v in f.items() if k not in ('name', 'file', 'bytes', 'sha256', 'view')}, 'Frame differs from detailed live inspection')
        require(inspection['rear']['enabled'] is enabled, 'Inspection OFF/ON mismatch')
        budget(inspection, fixture['expected']['budgetOff' if enabled else 'budgetDisabled'])
    for off, on in ((frames[0], frames[1]), (frames[2], frames[3])):
        for k in ('camera', 'target', 'ambient', 'route', 'field'):
            require(off[k] == on[k], 'OFF/ON pair changed ' + k)
    turns = report['nativeTurn']
    require(len(turns) == 3, 'Expected two native backward turns and one field recenter')
    for t, p in zip(turns[:2], (.2, .5)):
        require(t['progress'] == p and t['mouse180'] is True and t['positionUnchanged'] is True and abs(abs(t['headingDelta']) - math.pi) < .015, 'Native backward drag proof missing')
    require(turns[2] == {'progress': .5, 'recenterR': True, 'positionUnchanged': True}, 'Field recenter proof missing')
    require([m['key'] for m in report['movement']] == ['w', 's'], 'Native W/S proof missing')
    for m, direction in zip(report['movement'], (1, -1)):
        require(m['direction'] == direction and (m['progressAfter'] - m['progressBefore']) * direction > 0 and m['releaseStops'] is True and m['backwardHeadingPreserved'] is True and m['visualMotionInspected'] is False, 'Native W/S state proof invalid')
    coverage = set(report['gpuCoverage'])
    require({'Rear_Connected_Scan_Derived_Limestone', 'Rear_Broken_Reef_Islands'} <= coverage, 'Both candidate and original rocks need actual GPU submissions')
    initial = report['initial']['protection']
    for name in ('initial', 'afterFour', 'restored'):
        inspection = report[name]
        budget(inspection, fixture['expected']['budgetOff'])
        p = inspection['protection']
        require(p['issues'] == [] and p['borrowedDisposals'] == 0, 'Protected original resource changed: ' + name)
        for k in ('objects', 'sourceMeshes', 'logicalInstances', 'buffers', 'resourceIdentities'):
            require(p[k] == initial[k] and p[k] > 0, 'Original resource protection coverage changed: ' + k)
    field = report['field']
    budget(field, fixture['expected']['budgetFieldOn'])
    frame(field['frame'])
    require(field['rear']['enabled'] is True and field['field']['enabled'] is True and report['fieldRootCount'] == 1, 'One complete field activation required')
    for k, v in {'points': 1000000, 'displayTriangles': 4000000, 'removedObjects': 192, 'removedRidgeTriangles': 1620}.items():
        require(field['field'][k] == v, 'Field incomplete: ' + k)
    binding = field['bindings']['Measured_Darwin_1000000_Surfels']
    require(all(binding[k] is True for k in ('linked', 'compiled', 'standardPBR', 'waterVertex', 'waterFragment', 'fieldSurfel')) and binding['waterMode'] == 1 and binding['glError'] == 0, 'Field live shader proof missing')
    require(field['frame']['route']['yaw'] == field['frame']['route']['pitch'] == 0 and field['frame']['route']['progress'] == .5, 'Field must use forward route50 pose')
    require(report['pausedIdle']['unchanged'] is True and report['pauseResume']['advanced'] is True and report['pauseResume']['frozen'] is True, 'Clock pause/resume proof missing')
    for name, patch in (('rawC1', 'C1'), ('rawC4', 'C4')):
        require(report[name] == {'selected': patch, 'c1': patch == 'C1', 'c4': patch == 'C4', 'world': False, 'water': False, 'rearParentHidden': True, 'fieldInstalled': False}, 'Raw mode lifecycle proof missing')
    require(report['restored']['field']['installed'] is False, 'Field teardown failed')
    dispose = report['dispose']
    require(dispose['counts'] == fixture['expected']['disposal'] and dispose['budgetDelta'] == fixture['expected']['budgetDisposal'], 'Dispose counts/budget mismatch')
    require(dispose['issues'] == [] and dispose['rootPresent'] is False and dispose['apiPresent'] is False and dispose['placedRemaining'] == [] and dispose['obstaclesRemaining'] == 0 and dispose['originalVisibilityRestored'] is True, 'Dispose resource restoration failed')
    budget(report['disposedInspection'], fixture['expected']['budgetDisposed'])
    return identity


def main():
    c = contract()
    deadline = check_deadline()
    protected, current = check_old(c)
    check_sources(c)
    require(set(current) - set(protected) == candidate_sources(c) | set(c['mutableEntryPaths']), 'Unexpected pre-finalization additions')
    require(not pathlib.Path('.rear-layout-finalized.json').exists(), 'Finalization already attempted')
    original = snapshot(c)
    for n in c['mutableEntryPaths']:
        require((DIST / n).read_bytes() == original[n], 'Old published entry changed before GPU pass: ' + n)
    evidence = pathlib.Path(os.environ.get('REAR_LAYOUT_OUTPUT', 'rear-layout-qa'))
    report = read_json(evidence / 'browser-result.json')
    identity = validate_gpu(c, report)
    files, frames = {}, []
    prefix = 'assets/current-scene/' + c['sourceHashAggregate'] + '/'
    for f in report['frames']:
        safe_name(f['file'])
        require(pathlib.PurePosixPath(f['file']).name == f['file'], 'Frame must be directly in QA directory')
        b, w, h = png_bytes(evidence / f['file'], f)
        require((w, h) == (1120, 712), 'Exact original canvas dimensions required')
        name = f['name'] + '-' + f['sha256'][:16] + '.png'
        files[prefix + name] = b
        frames.append(dict(f, file=name, publicPath=prefix + name, width=w, height=h))
    manifest = dict(report, schemaVersion=1, frames=frames, sourceFiles=c['sourceFiles'], sourceHashAggregate=c['sourceHashAggregate'],
                    candidatePath=c['candidatePath'], candidateSourceCommit=identity['candidateSourceCommit'], checkoutCommit=identity['checkoutCommit'],
                    acceptance=c['acceptance'], acceptanceChinese=c['acceptanceChinese'], appearanceAccepted=False, unverified=c['unverified'],
                    comparisonLimits='Actual native backward OFF/ON pairs restore the published original rear habitat and candidate at the same naturally paused time and pose. This is technical evidence for a local layout candidate, not overall artistic acceptance.',
                    entryEvidencePolicy=c['oldEntryEvidencePolicy'], totalBudgetMs=deadline['totalBudgetMs'], captureTimeoutMs=c['captureTimeoutMs'])
    manifest_path = prefix + 'manifest.json'
    files[manifest_path] = json_bytes(manifest)
    cards = ''.join('<figure><img loading="lazy" src="' + html.escape(f['publicPath'], quote=True) + '" alt="' + html.escape(f['name'], quote=True) + ' actual WebGL frame"><figcaption>' + html.escape(f['name']) + ' · SHA256 ' + f['sha256'] + '</figcaption></figure>' for f in frames)
    gallery = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>后方布局局部候选 · 实际画面</title><style>body{margin:24px auto;max-width:1440px;padding:0 16px;background:#10282e;color:#eee;font:16px system-ui}a{color:#9edbea}img{max-width:100%;height:auto}figure{margin:28px 0}figcaption{overflow-wrap:anywhere;font-size:13px}</style><h1>局部后方布局候选，未通过整体美术验收</h1><p><a href="scan-exhibit.html">打开交互候选</a> · <a href="../world/">固定入口</a></p><p>路线20%与50%原生后向视角，各比较已发布原圆堆（OFF）和本次后方布局候选（ON）。每对图使用同一实际暂停时间、同一机位、1120×712画布及原65°视场。OFF恢复原已发后方资源，不使用被拒绝的中间低矮版本。连续性、水光着色体量、底脚接触、遮挡与前景保护仍须逐图目视判断，技术通过不等于局部或整体外观通过。</p><p>固定入口仅在本次技术检查通过后，手动选定这个精确候选源码与QA发布构建；不会自动追随最新提交。旧入口两张PNG完整保留，属于上次入口证据，本轮未重拍入口截图。</p><p>16块、6组、16,864三角继续使用Rico Cilliers / Poly Haven boulder_01的CC0陆地扫描衍生艺术形体，不是海底实测重建，不用陆地贴图。原测量层和原素材出处、许可与边界仍在交互页面保留。整体真实感尚未达标。</p><p>四图后仅一次完整百万点field加载和一帧前向实际GPU检查；400万显示三角属于surfel显示几何，不是原始源面。field后向、完整动物周期碰撞、触屏、bfcache及用户设备FPS未验收。W/S状态与有限fresh帧不证明移动全程无闪烁、漂浮或穿模。未在实际机位提交的对象明确保留GPU未验证状态。</p>'''
    gallery += cards + '<p><a href="' + manifest_path + '">精确源码、机位及技术证据清单</a></p><p>候选源码 ' + identity['candidateSourceCommit'] + ' · 发布构建 ' + identity['checkoutCommit'] + '</p></html>\n'
    files['current-scene.html'] = gallery.encode()
    require(len(files) == 6, 'Only four PNGs, one manifest and one HTML may be added')
    entry, pointer = expected_entry(c, identity, original)
    root, world = DIST / c['candidatePath'], DIST / c['entryPath']
    for n in files:
        require(not (root / n).exists(), 'Gallery destination collision: ' + n)
    check_deadline()
    for n, b in files.items():
        p = root / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
    for n, b in entry.items():
        (world / n).write_bytes(b)
    receipt = {'schemaVersion': 1, 'state': 'GPU_PASS_EXACT_ENTRY_UPDATE', 'sourceIdentity': identity, 'appearanceAccepted': False,
               'galleryFiles': [file_record(root / n, c['candidatePath'] + '/' + n) for n in sorted(files)],
               'entryFiles': [file_record(world / n, n) for n in ENTRY_NAMES], 'pointer': pointer,
               'protectedFiles': 1662, 'newEntryScreenshots': 0, 'oldEntryPNGsPreserved': 2}
    save_json('.rear-layout-finalized.json', receipt)
    check_old(c)
    check_sources(c)
    check_deadline()
    print('REAR_LAYOUT_GALLERY_AND_EXACT_ENTRY_READY', json.dumps({'galleryFiles': 6, 'frames': c['frames'], 'sourceIdentity': identity, 'appearanceAccepted': False, 'newEntryScreenshots': 0}))


if __name__ == '__main__':
    main()
