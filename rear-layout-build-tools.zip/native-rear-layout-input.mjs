// Native mouse input only. Read actual canvas dimensions; no camera mutation.
import assert from 'node:assert/strict';
export async function dragAngle(page,angle){
 const b=await page.locator('#scanCanvas').evaluate(e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height};});assert(b.width>100&&b.height>100);
 const chunk=Math.min(220,b.width*.25);let remaining=angle/.004,gestures=0;
 while(Math.abs(remaining)>.001){assert(++gestures<=8,'Bounded native turn gestures');const dx=Math.sign(remaining)*Math.min(chunk,Math.abs(remaining)),x=b.x+b.width*.5,y=b.y+b.height*.45;await page.mouse.move(x,y);await page.mouse.down();try{await page.mouse.move(x-dx,y,{steps:5});}finally{await page.mouse.up();}remaining-=dx;}
 return{gestures,angle,canvas:b};
}
