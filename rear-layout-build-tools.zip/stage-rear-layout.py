"""Restore the published grounded snapshot, protect 1662 files, add one candidate."""
from rear_layout_common import *


def main():
    c = contract()
    require(not (DIST / c['candidatePath']).exists(), 'Candidate destination already exists')
    require(not pathlib.Path('.rear-layout-protected.json').exists() and not pathlib.Path('.rear-layout-build.json').exists(), 'Stage already attempted')
    before = inventory(DIST)
    old = read_json('.grounded-protected.json')
    require(len(old) == 1510 and all(before.get(n) == h for n, h in old.items()), 'Original assembly protection mismatch')
    root = read_json('.root-site-hashes.json')
    require(len(root) == 79 and all(old.get(n) == h for n, h in root.items()), 'Root 79 protection mismatch')
    require({n: h for n, h in before.items() if not n.startswith('preview/')} == root, 'Unexpected root-site changes')
    staged = {c['basePath'] + '/' + f['path']: f['sha256'] for f in c['baseSourceFiles']}
    staged.update({c['entryPath'] + '/' + f['path']: f['sha256'] for f in c['stagedEntryFiles']})
    require(len(staged) == 147 and not set(staged) & set(old), 'Staged grounded file set overlaps old site')
    require(before == dict(old, **staged) and len(before) == 1657, 'Expected exact stage-grounded output: 1510 + 144 + 3')
    restore = snapshot(c)
    delta = checked_archive(INPUTS / c['codeArchive']['path'], c['codeArchive'], {f['path']: f for f in c['changes']})
    # Validate every source and destination before restoring any bytes.
    require(all(n in c['mutableEntryPaths'] or n not in before for n in restore), 'Published snapshot collision outside entry allowlist')
    predicted_baseline = dict(before)
    predicted_baseline.update({n: sha(b) for n, b in restore.items()})
    require(len(predicted_baseline) == 1665, 'Expected restored 1665-file published site')
    expected_public = {f['path']: f['sha256'] for f in c['oldPublicFiles']}
    require(predicted_baseline == dict(old, **expected_public), 'Restored site must match old assembly plus published receipt')
    candidate = {n: (DIST / c['basePath'] / n).read_bytes() for n in c['baseSourceHashes']}
    candidate.update(delta)
    require({n: sha(b) for n, b in candidate.items()} == c['sourceHashes'], 'Candidate bytes mismatch')
    for n, b in restore.items():
        p = DIST / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
    require(inventory(DIST) == predicted_baseline, 'Published snapshot restoration failed')
    protected = {n: h for n, h in predicted_baseline.items() if n not in c['mutableEntryPaths']}
    require(len(protected) == 1662, 'Expected exact 1662 protected files')
    save_json('.rear-layout-protected.json', protected)
    for n, b in candidate.items():
        p = DIST / c['candidatePath'] / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
    save_json('.rear-layout-build.json', {'schemaVersion': 1, 'candidatePath': c['candidatePath'], 'sourceHashAggregate': c['sourceHashAggregate'],
              'sourceFiles': c['sourceFiles'], 'protectedFiles': 1662, 'oldSiteFiles': 1665,
              'state': 'STAGED_PUBLISHED_GROUNDED_POINTER_UNCHANGED'})
    check_sources(c)
    protected, current = check_old(c)
    require(set(current) - set(protected) == candidate_sources(c) | set(c['mutableEntryPaths']), 'Unexpected staged additions')
    require(len(current) == 1811, 'Expected 1665 + 146 staged files')
    print('REAR_LAYOUT_STAGED', json.dumps({'oldSiteFiles': 1665, 'protectedFiles': 1662, 'preservedRootFiles': 79,
          'preservedEntryPNGs': 2, 'candidateSourceFiles': 146, 'unchangedSources': 143, 'sourceHashAggregate': c['sourceHashAggregate']}))


if __name__ == '__main__':
    main()
