// Offline fixture generation only. No browser/network; writes the fixture, never runtime.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const toolsRoot=path.dirname(fileURLToPath(import.meta.url));
const candidate=path.resolve(process.argv[2]||'reef-grounded-integration-candidate');
const root=path.join(candidate,'page');
const imp=n=>import(pathToFileURL(path.join(root,n)));
const T=await imp('vendor/three.module.js');
const {GLTFLoader}=await imp('vendor/GLTFLoader.js');
const {createScanWorld}=await imp('scan-world.js'),{createScanOcean}=await imp('scan-ocean.js');
const {installAssemblage}=await imp('scan-assemblage.js'),{placeC4}=await imp('scan-landmark.js');
const {installNaturalRockCandidate}=await imp('install-natural-rock.js');
const {installLayeredRidges}=await imp('install-layered-ridges.js');
const {GROUNDED_LOCAL_DATA:DATA}=await imp('grounded-shoulder-data.js');
// The GLTF loader's external buffers are read from this local asset directory only.
globalThis.self=globalThis;globalThis.ProgressEvent=class{};
const nativeFetch=globalThis.fetch;
globalThis.fetch=async u=>{const s=typeof u==='string'?u:u.url;if(s.startsWith('data:')||s.startsWith('blob:'))return nativeFetch(u);assert(s.startsWith('file://'),'Fixture must not fetch network');return new Response(fs.readFileSync(fileURLToPath(s)));};
async function load(name){const p=path.join(root,name),loader=new GLTFLoader();loader.register(parser=>{parser.loadTextureImage=async()=>{const t=new T.Texture();t.flipY=false;t.colorSpace=T.SRGBColorSpace;return t;};return{name:'READ_ONLY_LOCAL_TEXTURES'};});const b=fs.readFileSync(p);return loader.parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),pathToFileURL(path.dirname(p)+'/').href);}
const scene=new T.Scene(),ocean=createScanOcean(scene,new T.Texture());
const c4=placeC4((await load('assets/reefs4d/C42019-web-150k.glb')).scene,ocean.ground);scene.add(c4);
const world=createScanWorld(scene,(await load('assets/scan-world-corals.gltf')).scene,()=>{},{limestone:m=>m,coral:m=>m,budget:{}},ocean.ground);
installAssemblage(world,(await load('assets/reefs4d/C4-A-rounded-knobby.glb')).scene,c4);
installNaturalRockCandidate({world,boulderScene:(await load('assets/boulder_01_LOD1_1k.glb')).scene,configure:()=>{}});
installLayeredRidges({world,ground:ocean.ground});scene.updateMatrixWorld(true);
const h=world.groundedShoulder;
const sha=a=>createHash('sha256').update(Buffer.from(a.buffer,a.byteOffset,a.byteLength)).digest('hex');
const attribute=a=>a?{count:a.count,itemSize:a.itemSize,normalized:a.normalized,arrayType:a.array.constructor.name,bytes:a.array.byteLength,sha256:sha(a.array)}:null;
const geometry=g=>({attributes:Object.fromEntries(Object.entries(g.attributes).map(([k,a])=>[k,attribute(a)])),index:attribute(g.index)});
const material=m=>({type:m.type,side:m.side,color:m.color?.toArray(),roughness:m.roughness,metalness:m.metalness,vertexColors:m.vertexColors,transparent:m.transparent,depthWrite:m.depthWrite,opacity:m.opacity});
const mesh=m=>({name:m.name,material:material(m.material),isInstancedMesh:!!m.isInstancedMesh,count:m.isInstancedMesh?m.count:1,castShadow:m.castShadow,receiveShadow:m.receiveShadow,frustumCulled:m.frustumCulled,matrix:m.matrix.toArray(),geometry:geometry(m.geometry),instanceMatrix:attribute(m.instanceMatrix),instanceColor:attribute(m.instanceColor)});
const applied=JSON.parse(fs.readFileSync(path.join(candidate,'verification/applied-actions.json')));
const remove=DATA.banks.flatMap(b=>b.remove.map(i=>b.name+'_'+i)).filter(n=>n!=='Sunlit_Broken_Coral_Shelves_3');
const move=DATA.banks.flatMap(b=>b.move.map(m=>({name:b.name+'_'+m.index,index:m.index,matrix:m.matrix,dy:m.dy})));
assert.deepEqual([...remove].sort(),[...applied.remove].sort());assert.equal(remove.length,153);assert.equal(move.length,6);
for(const m of move){const old=applied.move.find(v=>v.name===m.name);assert(old);assert.deepEqual(m.matrix,old.matrix);}
const fixture={format:'grounded-browser-fixture-v1',source:{kind:'CC0 terrestrial scan geometry used as art, not measured reef',url:'https://polyhaven.com/a/boulder_01',sampleTriangles:63402},expected:{budgetDisabled:{mountedTriangles:1603464,visibleTriangles:1223138,mountedDraws:104,visibleDraws:88},budgetDisposed:{mountedTriangles:1286738,visibleTriangles:1223138,mountedDraws:90,visibleDraws:88},budgetOff:{mountedTriangles:1603464,visibleTriangles:1280296,mountedDraws:104,visibleDraws:92},budgetFieldOn:{mountedTriangles:5759262,visibleTriangles:5185202,mountedDraws:119,visibleDraws:90},netTriangles:57158,netDraws:4,disposal:{geometries:5,materials:3,instances:9,borrowed:0}},sources:h.swaps.map(s=>({...mesh(s.original),originalVisible:s.visible})),placed:h.placed.map(m=>({...mesh(m),parentName:m.parent.name,originalIndices:m.userData.originalIndices||null,liveShaderRequirements:{limestone:m.name.startsWith('Grounded_Shoulder_')||m.name.startsWith('Grounded_Clipped_')||m.name.includes('Sunlit_Broken_Coral_Shelves'),colonyRelief:m.name.includes('Visible_Habitat_')}})),banks:DATA.banks.map(b=>({name:b.name,originalCount:b.originalCount,remove:b.remove,move:b.move.map(m=>({index:m.index,matrix:m.matrix,dy:m.dy})),identities:b.identities})),actions:{remove:[...remove].sort(),move,substrates:DATA.substrates.map(s=>({name:s.name,bank:s.bank,instance:!!s.instance,index:s.index??null,triangles:s.triangles.length}))}};
assert.equal(fixture.sources.length,10);assert.equal(fixture.placed.length,14);assert.equal(fixture.actions.substrates.reduce((n,s)=>n+s.triangles,0),1314);
fs.writeFileSync(path.join(toolsRoot,'grounded-fixture.json'),JSON.stringify(fixture,null,2)+'\n');
console.log(JSON.stringify({fixture:'grounded-fixture.json',sources:fixture.sources.length,placed:fixture.placed.length,remove:remove.length,move:move.length}));

export {T,scene,ocean,world,load};
