"""Local build guards. This module and all receipts stay outside public dist."""
import hashlib
import json
import os
import pathlib
import re
import stat
import struct
import time
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
DIST = pathlib.Path('dist')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(pathlib.Path(path).read_text())


def save_json(path, value):
    pathlib.Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n')


def contracts():
    return tuple(read_json(HERE / n) for n in ('grounded-contract.json', 'rear-preservation.json', 'entry-contract.json'))


def safe_name(name):
    p = pathlib.PurePosixPath(name)
    require(isinstance(name, str) and name and not p.is_absolute() and '..' not in p.parts
            and '\\' not in name and p.as_posix() == name and name != '.', 'Unsafe path: ' + str(name))
    return p


def inventory(root):
    root = pathlib.Path(root)
    require(root.is_dir() and not root.is_symlink(), 'Missing/linked directory: ' + str(root))
    files = {}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink(), 'Symlink rejected: ' + str(p))
        require(p.is_file() or p.is_dir(), 'Special file rejected: ' + str(p))
        if p.is_file():
            files[p.relative_to(root).as_posix()] = sha(p.read_bytes())
    return files


def file_record(path, relative=None):
    p = pathlib.Path(path)
    b = p.read_bytes()
    return {'path': relative or p.name, 'bytes': len(b), 'sha256': sha(b)}


def validate_bytes(data, record, label):
    require(len(data) == record['bytes'] and sha(data) == record['sha256'], 'Size/SHA mismatch: ' + label)


def checked_archive(path, archive, expected):
    """Validate every entry before any public write; duplicates and symlinks fail."""
    path = pathlib.Path(path)
    require(path.is_file() and not path.is_symlink(), 'Missing/linked archive: ' + str(path))
    validate_bytes(path.read_bytes(), archive, str(path))
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        require(len(names) == len(set(names)) == len(expected) and set(names) == set(expected),
                'Unexpected archive file set: ' + str(path))
        result = {}
        for info in z.infolist():
            safe_name(info.filename)
            require(not info.is_dir() and not stat.S_ISLNK(info.external_attr >> 16), 'Linked/directory archive member')
            b = z.read(info)
            validate_bytes(b, expected[info.filename], info.filename)
            result[info.filename] = b
    return result


def source_map(c):
    return {f['path']: f['sha256'] for f in c['sourceFiles']}


def check_sources(c):
    root = DIST / c['candidatePath']
    for f in c['sourceFiles']:
        safe_name(f['path'])
        p = root / f['path']
        require(p.is_file() and not p.is_symlink(), 'Missing/linked candidate source: ' + f['path'])
        validate_bytes(p.read_bytes(), f, f['path'])


def check_old(c):
    protected = read_json('.grounded-protected.json')
    require(len(protected) == c['oldSiteFiles'], 'Protected inventory count mismatch')
    current = inventory(DIST)
    for name, digest in protected.items():
        safe_name(name)
        require(current.get(name) == digest, 'Original file changed/missing: ' + name)
    return protected, current


def check_deadline():
    d = read_json('.grounded-deadline.json')
    require(d['totalBudgetMs'] == 450000, 'Deadline budget must remain 450 seconds')
    require(isinstance(d['startedAtMs'], (int, float)) and isinstance(d['expiresAtMs'], (int, float)), 'Invalid deadline')
    require(d['expiresAtMs'] - d['startedAtMs'] == 450000, 'Deadline was extended')
    now = time.time() * 1000
    require(d['startedAtMs'] <= now < d['expiresAtMs'], 'Shared 450-second deadline expired/invalid')
    return d


def commit_identity():
    commits = {key: os.environ.get(env, '') for key, env in
               [('candidateSourceCommit', 'GROUNDED_SOURCE_COMMIT'), ('checkoutCommit', 'GITHUB_SHA')]}
    for key, value in commits.items():
        require(re.fullmatch('[0-9a-f]{40}', value), 'Missing exact commit: ' + key)
    return commits


def source_identity(c):
    return dict(commit_identity(), candidatePath=c['candidatePath'],
                sourceHashAggregate=c['sourceHashAggregate'], sourceFiles=144)


def png_bytes(path, record, width=None):
    p = pathlib.Path(path)
    require(p.is_file() and not p.is_symlink(), 'Missing/linked PNG')
    b = p.read_bytes()
    validate_bytes(b, record, str(p))
    require(len(b) > 32 and b[:8] == b'\x89PNG\r\n\x1a\n' and b[12:16] == b'IHDR', 'Invalid PNG')
    w, h = struct.unpack('>II', b[16:24])
    require((w == width and h >= 900) if width else (w > 800 and h > 500), 'Unexpected PNG dimensions')
    return b, w, h


def added_sources(c):
    return {c['candidatePath'] + '/' + f['path'] for f in c['sourceFiles']} | {
        c['entryPath'] + '/' + n for n in ('index.html', 'world.css', 'current-world.json')}


def gallery_records(c):
    receipt = read_json('.grounded-finalized.json')
    records = receipt['galleryFiles']
    require(len(records) == 6 and len({r['path'] for r in records}) == 6, 'Expected exact six gallery files')
    base = c['candidatePath'] + '/'
    prefix = base + 'assets/current-scene/' + c['sourceHashAggregate'] + '/'
    static = {base + 'current-scene.html', prefix + 'manifest.json'}
    require(static <= {r['path'] for r in records}, 'Gallery HTML/manifest paths changed')
    frames = [r for r in records if r['path'] not in static]
    expected = set(c['frames'])
    actual = set()
    for r in frames:
        require(r['path'].startswith(prefix), 'Gallery escaped candidate evidence directory')
        name = r['path'][len(prefix):]
        suffix = '-' + r['sha256'][:16] + '.png'
        require(name.endswith(suffix), 'Gallery filename/SHA mismatch')
        actual.add(name[:-len(suffix)])
    require(actual == expected and len(frames) == 4, 'Gallery frame set changed')
    return receipt, records
