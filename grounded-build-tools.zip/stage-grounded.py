"""Stage only the approved new directory and original static-entry package."""
from grounded_common import *


def main():
    c, rear, entry = contracts()
    require(len(c['sourceFiles']) == len(c['sourceHashes']) == 144, 'Candidate source count')
    require(source_map(c) == c['sourceHashes'], 'Source contract mismatch')
    aggregate = sha(''.join(n + '\0' + c['sourceHashes'][n] + '\n' for n in sorted(c['sourceHashes'])).encode())
    require(aggregate == c['sourceHashAggregate'], 'Source aggregate mismatch')
    old = DIST / c['basePath']
    base = {f['path']: f['sha256'] for f in rear['sourceFiles']}
    require(len(base) == 142 and inventory(old) == base, 'Rear source baseline must be exact142')
    candidate, world = DIST / c['candidatePath'], DIST / c['entryPath']
    require(not candidate.exists() and not world.exists(), 'New destinations already exist')
    require(not pathlib.Path('.grounded-protected.json').exists() and not pathlib.Path('.grounded-build.json').exists(), 'Stage already attempted')
    before = inventory(DIST)
    require(len(before) == 1504, 'Pre-gallery old site must have1504 files')
    gallery = checked_archive('.entry-inputs/rear-gallery-0badf15.zip', rear['archive'], rear['files'])
    entry_bytes = checked_archive('.entry-inputs/world-entry-code.zip', entry['archive'], {f['path']: f for f in entry['files']})
    changes = {f['path']: f for f in c['changes']}
    require(set(changes) == {'install-layered-ridges.js', 'grounded-shoulder.js', 'grounded-shoulder-data.js'}, 'Unexpected code changes')
    overlay = checked_archive('.grounded-inputs/grounded-code.zip', c['codeArchive'], changes)
    for n, f in changes.items():
        require(base.get(n) == f['baseSha256'], 'Base SHA mismatch: ' + n)
    predicted = dict(base)
    predicted.update({n: f['sha256'] for n, f in changes.items()})
    require(predicted == c['sourceHashes'] and sum(predicted.get(n) == h for n, h in base.items()) == 141,
            'Expected141 unchanged sources and exact3-file overlay')
    for n, b in gallery.items():
        p = old / n
        require(not p.exists(), 'Rear gallery collision: ' + n)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
    protected = inventory(DIST)
    require(len(protected) == 1510, 'Restored protected site must contain1510 files')
    save_json('.grounded-protected.json', protected)
    # Copy the exact142 source records, never the old six-file gallery.
    for n in sorted(base):
        p = candidate / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes((old / n).read_bytes())
    for n, b in overlay.items():
        (candidate / n).write_bytes(b)
    require(inventory(candidate) == c['sourceHashes'], 'Staged candidate source mismatch')
    world.mkdir()
    for n, b in entry_bytes.items():
        (world / n).write_bytes(b)
    # Original entry still selects the older rear version until GPU QA passes.
    save_json('.grounded-build.json', {'root': str(candidate), 'contentVersion': aggregate,
              'sourceFiles': c['sourceFiles'], 'sourceHashAggregate': aggregate, 'candidatePath': c['candidatePath'],
              'state': 'STAGED_NO_CANDIDATE_SUCCESS_POINTER'})
    check_old(c)
    print('GROUNDED_STAGED', json.dumps({'oldFiles': 1510, 'candidateSourceFiles': 144, 'unchangedSources': 141,
          'staticEntryFiles': 3, 'sourceHashAggregate': aggregate}))


if __name__ == '__main__':
    main()
