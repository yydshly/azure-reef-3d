"""Fail closed on old-file mutation or any addition outside the exact allowlist."""
import sys
from grounded_common import *


def main():
    require(sys.argv[1:] in ([], ['--source-only'], ['--before-entry-evidence']), 'Unexpected arguments')
    c, _, entry = contracts()
    protected, current = check_old(c)
    check_sources(c)
    expected = added_sources(c)
    require(len(expected) == 147, 'Expected144 candidate sources and3 entry files')
    if '--source-only' in sys.argv:
        require(not pathlib.Path('.grounded-finalized.json').exists(), 'Already finalized')
        for f in entry['files']:
            validate_bytes((DIST / c['entryPath'] / f['path']).read_bytes(), f, f['path'])
    else:
        check_deadline()
        receipt, gallery = gallery_records(c)
        require(receipt['sourceIdentity'] == source_identity(c), 'Source identity mismatch')
        require(receipt['appearanceAccepted'] is False, 'Aesthetic acceptance cannot be inferred')
        for f in gallery:
            safe_name(f['path'])
            validate_bytes((DIST / f['path']).read_bytes(), f, f['path'])
            expected.add(f['path'])
        for f in receipt['entryFiles']:
            validate_bytes((DIST / c['entryPath'] / f['path']).read_bytes(), f, f['path'])
        require(read_json(DIST / c['entryPath'] / 'current-world.json') == receipt['pointer'], 'Pointer mismatch')
        if '--before-entry-evidence' in sys.argv:
            require(receipt['state'] == 'GPU_PASS_ENTRY_QA_PENDING', 'Unexpected intermediate state')
            require(len(expected) == 153, 'Expected153 additions before entry evidence')
        else:
            require(receipt['state'] == 'GPU_AND_STATIC_ENTRY_PASS', 'Both QA passes required')
            shots = receipt['entryScreenshots']
            require([f['name'] for f in shots] == ['entry-desktop', 'entry-narrow'], 'Expected exact two entry PNGs')
            for f in shots:
                require(f['path'] == c['entryPath'] + '/evidence/' + f['name'] + '-' + f['sha256'][:16] + '.png', 'Unexpected entry evidence path')
                png_bytes(DIST / f['path'], f, width=1366 if f['name'] == 'entry-desktop' else 320)
                expected.add(f['path'])
            require(len(expected) == 155, 'Expected exact155 total additions')
    require(set(current) - set(protected) == expected,
            'Unexpected/missing additions: ' + repr(sorted((set(current) - set(protected)) ^ expected)))
    if '--source-only' not in sys.argv:
        check_deadline()
    print('OLD_1510_BYTE_IDENTICAL_EXACT_GROUNDED_ADDITIONS', len(expected))
    if not sys.argv[1:]:
        public_files = [file_record(DIST / n, n) for n in sorted(expected)]
        print('GROUNDED_PUBLIC_RECEIPT', json.dumps({'status': 'PASS_EXACT_155_ADDITIONS',
              'oldSiteFiles': 1510, 'oldFilesByteIdentical': True, 'sourceIdentity': receipt['sourceIdentity'],
              'appearanceAccepted': False, 'files': public_files}, ensure_ascii=False))


if __name__ == '__main__':
    main()
