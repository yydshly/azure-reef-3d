// Static entry only. All work consumes the GPU runner's existing450-second deadline.
import assert from 'node:assert/strict';
import {readFileSync, writeFileSync, mkdirSync, existsSync} from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';

const sha = b => createHash('sha256').update(b).digest('hex');
const deadline = JSON.parse(readFileSync('.grounded-deadline.json', 'utf8'));
assert.equal(deadline.totalBudgetMs, 450000);
assert.equal(deadline.expiresAtMs - deadline.startedAtMs, 450000);
assert(Date.now() >= deadline.startedAtMs && Date.now() < deadline.expiresAtMs, 'Shared450-second budget exhausted');
const receipt = JSON.parse(readFileSync('.grounded-finalized.json', 'utf8'));
assert.equal(receipt.state, 'GPU_PASS_ENTRY_QA_PENDING');
const contract = JSON.parse(readFileSync(new URL('./grounded-contract.json', import.meta.url), 'utf8'));
const identity = {candidateSourceCommit: process.env.GROUNDED_SOURCE_COMMIT, checkoutCommit: process.env.GITHUB_SHA,
  sourceHashAggregate: contract.sourceHashAggregate, candidatePath: contract.candidatePath, sourceFiles: 144};
assert.match(identity.candidateSourceCommit ?? '', /^[0-9a-f]{40}$/);
assert.match(identity.checkoutCommit ?? '', /^[0-9a-f]{40}$/);
assert.deepEqual(receipt.sourceIdentity, identity);
const base = process.env.ENTRY_URL;
assert(base && new URL(base).pathname.endsWith('/preview/world/'), 'Expected exact static entry URL');
const output = '.entry-evidence';
assert(!existsSync(output), 'Static entry QA already attempted; no automatic rerun');
mkdirSync(output);
const started = Date.now();
const report = {status: 'RUNNING', screenshots: [], layouts: [], keyboard: [], targetHttp: [], requests: [],
  checkpoints: [], sourceIdentity: identity, deadline};
let browser;
function persist() { writeFileSync(path.join(output, 'result.json'), JSON.stringify(report, null, 2) + '\n'); }
function remaining() { const n = deadline.expiresAtMs - Date.now(); assert(n > 0, 'Shared450-second deadline exceeded'); return n; }
const hardTimer = setTimeout(() => {
  report.status = 'FAIL_STATIC_ENTRY'; report.error = 'Shared450-second deadline exceeded'; persist();
  console.error('ENTRY_DEADLINE ' + JSON.stringify({phase: report.phase, elapsedMs: Date.now() - deadline.startedAtMs}));
  process.exit(1);
}, remaining());
async function step(name, cap, action) {
  const timeout = Math.max(1, Math.min(cap, remaining()));
  report.phase = name;
  console.log('ENTRY_PHASE ' + JSON.stringify({name, state: 'before', remainingMs: remaining(), timeoutMs: timeout}));
  let timer;
  try {
    const value = await Promise.race([action(timeout), new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Entry step timed out: ' + name)), timeout);
    })]);
    remaining();
    report.checkpoints.push({name, atMs: Date.now() - deadline.startedAtMs});
    console.log('ENTRY_PHASE ' + JSON.stringify({name, state: 'after', remainingMs: remaining()}));
    return value;
  } finally { clearTimeout(timer); }
}

try {
  const {chromium} = await step('import-playwright', 10000, () => import(pathToFileURL(path.resolve('tests/browser/node_modules/playwright/index.mjs')).href));
  browser = await step('launch', 30000, timeout => chromium.launch({channel: 'chromium', headless: true, chromiumSandbox: true,
    timeout, args: ['--enable-automation'], ignoreDefaultArgs: ['--enable-unsafe-swiftshader', '--disable-gpu-sandbox', '--ignore-gpu-blocklist']}));
  const cdp = await step('browser-session', 10000, () => browser.newBrowserCDPSession());
  const command = await step('sandbox-command-line', 10000, () => cdp.send('Browser.getBrowserCommandLine'));
  assert(!command.arguments.some(x => ['--no-sandbox', '--disable-gpu-sandbox', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'].some(f => x === f || x.startsWith(f + '='))));
  const page = await step('new-page', 10000, () => browser.newPage({viewport: {width: 1366, height: 900}, deviceScaleFactor: 1}));
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('request', r => report.requests.push(r.url()));
  const allowed = new Set([base, new URL('./world.css', base).href, new URL('/favicon.ico', base).href]);
  await step('deny-scene-assets', 10000, () => page.route('**/*', route => {
    if (allowed.has(route.request().url())) return route.continue();
    errors.push('Unexpected static-entry request: ' + route.request().url());
    return route.abort('blockedbyclient');
  }));
  const expected = ['../grounded-integration-candidate/scan-exhibit.html', '../grounded-integration-candidate/index.html',
    '../grounded-integration-candidate/current-scene.html', '../grounded-integration-candidate/scan-exhibit.html#scanProvenance'];
  const inspect = () => page.evaluate(() => ({title: document.title, lang: document.documentElement.lang,
    h1: document.querySelector('h1').textContent, links: [...document.querySelectorAll('a')].map(a => ({href: a.getAttribute('href'), text: a.textContent.trim()})),
    scripts: document.scripts.length, forms: document.forms.length, overflow: document.documentElement.scrollWidth > innerWidth,
    viewport: {width: innerWidth, height: innerHeight, dpr: devicePixelRatio},
    controls: [...document.querySelectorAll('nav a,summary')].map(e => {const r = e.getBoundingClientRect(), s = getComputedStyle(e);
      return {text: e.textContent.trim(), x: r.x, y: r.y, width: r.width, height: r.height, display: s.display, visibility: s.visibility};})}));
  async function layout(label) {
    const r = await step('layout-' + label, 10000, inspect);
    assert.equal(r.lang, 'zh-CN'); assert.equal(r.h1, '海底世界'); assert.equal(r.scripts, 0); assert.equal(r.forms, 0); assert.equal(r.overflow, false);
    assert.deepEqual(r.links.map(x => x.href), expected);
    for (const c of r.controls) {assert(c.width > 0 && c.height >= 44); assert(c.x >= 0 && c.x + c.width <= r.viewport.width + .1); assert(c.display !== 'none' && c.visibility === 'visible');}
    report.layouts.push(r);
  }
  async function shot(name) {
    await step('screenshot-' + name, 25000, timeout => page.screenshot({path: path.join(output, name + '.png'), fullPage: true, timeout}));
    const b = readFileSync(path.join(output, name + '.png'));
    report.screenshots.push({name, file: name + '.png', bytes: b.length, sha256: sha(b)});
  }
  await step('load-desktop', 30000, timeout => page.goto(base, {waitUntil: 'load', timeout}));
  await layout('desktop'); await shot('entry-desktop');
  for (let i = 0; i < 4; i++) {
    await step('tab-' + i, 5000, () => page.keyboard.press('Tab'));
    report.keyboard.push(await step('focus-' + i, 5000, () => page.evaluate(() => ({tag: document.activeElement.tagName,
      text: document.activeElement.textContent.trim(), href: document.activeElement.getAttribute('href'), outline: getComputedStyle(document.activeElement).outlineStyle}))));
  }
  assert.deepEqual(report.keyboard.map(x => x.href), [...expected.slice(0, 3), null]);
  assert.equal(report.keyboard[3].tag, 'SUMMARY'); assert(report.keyboard.every(x => x.outline !== 'none'));
  await step('details-open-key', 5000, () => page.keyboard.press('Enter'));
  assert(await step('details-open', 5000, () => page.locator('details').evaluate(e => e.open)));
  await step('details-link-tab', 5000, () => page.keyboard.press('Tab'));
  assert.equal(await step('details-link-focus', 5000, () => page.evaluate(() => document.activeElement.getAttribute('href'))), expected[3]);
  await step('details-back-tab', 5000, () => page.keyboard.press('Shift+Tab'));
  await step('details-close-key', 5000, () => page.keyboard.press('Space'));
  assert.equal(await step('details-closed', 5000, () => page.locator('details').evaluate(e => e.open)), false);
  await step('details-hidden-tab', 5000, () => page.keyboard.press('Tab'));
  assert.notEqual(await step('details-hidden-focus', 5000, () => page.evaluate(() => document.activeElement.getAttribute('href'))), expected[3]);
  report.detailsKeyboard = true;
  await step('viewport-320', 5000, () => page.setViewportSize({width: 320, height: 900}));
  await step('load-narrow', 30000, timeout => page.goto(base, {waitUntil: 'load', timeout}));
  await layout('320'); await shot('entry-narrow');
  // HTTP GET retrieves only target HTML bytes. No navigation or model request is made.
  for (const rel of expected.slice(0, 3)) {
    const url = new URL(rel, base).href;
    const res = await step('target-html-' + path.basename(rel), 20000, timeout => page.request.get(url, {timeout, maxRedirects: 0}));
    assert.equal(res.status(), 200);
    const b = await step('target-body-' + path.basename(rel), 10000, () => res.body());
    const n = path.basename(new URL(url).pathname), f = receipt.targetSourceFiles.find(f => f.path === n) || receipt.targetGallery[n];
    assert(f && sha(b) === f.sha256 && b.length === f.bytes);
    if (n === 'scan-exhibit.html') assert(b.toString().includes('id="scanProvenance"'));
    report.targetHttp.push({url, status: res.status(), bytes: b.length, sha256: sha(b)});
  }
  assert(report.requests.every(u => allowed.has(u)), 'Unexpected scene or asset request'); assert.deepEqual(errors, []);
  for (const f of receipt.entryFiles) {const b = readFileSync(path.join('dist', contract.entryPath, f.path)); assert.equal(b.length, f.bytes); assert.equal(sha(b), f.sha256);}
  await step('close-browser', 10000, () => browser.close()); browser = null;
  Object.assign(report, {status: 'PASS_STATIC_ENTRY', elapsedMs: Date.now() - started, totalElapsedMs: Date.now() - deadline.startedAtMs,
    limits: 'Static1366/320 viewport layout and keyboard/details only. Target HTML fetched without executing scenes/models. Native touch, bfcache, user-device FPS, and overall appearance are not accepted.'});
  remaining(); persist(); console.log('ENTRY_COMPLETE ' + JSON.stringify({status: report.status, elapsedMs: report.elapsedMs, totalElapsedMs: report.totalElapsedMs}));
} catch (e) {
  report.status = 'FAIL_STATIC_ENTRY'; report.error = String(e.stack || e); persist();
  console.error('ENTRY_FAILED ' + JSON.stringify({phase: report.phase, error: report.error}));
  process.exitCode = 1;
} finally {
  if (browser && Date.now() < deadline.expiresAtMs) {
    try { await step('cleanup-browser', 5000, () => browser.close()); }
    catch (e) { report.status = 'FAIL_STATIC_ENTRY'; report.cleanupError = String(e); persist(); process.exitCode = 1; }
  }
  clearTimeout(hardTimer);
}
