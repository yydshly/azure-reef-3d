"""Publish build-local evidence only after a bounded technical PASS.

Run once after GPU QA, then with --entry-evidence after static-entry QA.
Neither operation deploys or writes to a remote service.
"""
import html
import sys
from datetime import datetime
from grounded_common import *


def validate_gpu(c, report):
    require(report['status'] == 'PASS_SUPPORTED_BROWSER', 'GPU QA did not pass')
    expected_identity = source_identity(c)
    require(report['sourceIdentity'] == expected_identity, 'GPU result source identity mismatch')
    require(report['errors'] == [] and not report.get('error'), 'GPU result contains errors')
    deadline = check_deadline()
    for key in ('startedAt', 'startedAtMs', 'expiresAtMs', 'totalBudgetMs'):
        require(report[key] == deadline[key], 'GPU result does not belong to this deadline: ' + key)
    completed = datetime.fromisoformat(report['completedAt'].replace('Z', '+00:00')).timestamp() * 1000
    require(deadline['startedAtMs'] <= completed <= time.time() * 1000 and completed < deadline['expiresAtMs'], 'Invalid/stale GPU completion time')
    frames = report['frames']
    require([f['name'] for f in frames] == c['frames'], 'Expected exact ordered four frames')
    for f in frames:
        require(f['field']['enabled'] is False, 'Four captures must precede field activation')
        require(f['grounded']['enabled'] is f['name'].endswith('-on'), 'OFF/ON component state mismatch')
        require(f['ambient']['paused'] is True and f['ambient']['time'] == report['clock']['time'], 'Actual paused time mismatch')
        require(f['route']['progress'] == (0.2 if '-20-' in f['name'] else 0.5), 'Capture route progress mismatch')
        require(f['receipt']['sequence'] > f['previousSequence'], 'Capture is not a fresh render')
        graphics = f['graphics']
        require(graphics['contextLost'] is False and graphics['pixelError'] == 0 and graphics['sampleColors'] >= 2
                and graphics['render']['calls'] > 0, 'Missing live nonblank GL frame')
    for off, on in ((frames[0], frames[1]), (frames[2], frames[3])):
        for key in ('camera', 'target', 'ambient', 'route'):
            require(off[key] == on[key], 'OFF/ON pair changed ' + key)
        require(off['field'] == on['field'], 'OFF/ON pair changed field state')
    return expected_identity


def finalize_gpu():
    c, _, entry = contracts()
    deadline = check_deadline()
    protected, current = check_old(c)
    check_sources(c)
    require(set(current) - set(protected) == added_sources(c), 'Unexpected pre-finalization additions')
    require(not pathlib.Path('.grounded-finalized.json').exists(), 'GPU finalization already attempted')
    root, world = DIST / c['candidatePath'], DIST / c['entryPath']
    for f in entry['files']:
        validate_bytes((world / f['path']).read_bytes(), f, f['path'])
    evidence = pathlib.Path(os.environ.get('GROUNDED_OUTPUT', 'grounded-qa'))
    report = read_json(evidence / 'browser-result.json')
    identity = validate_gpu(c, report)
    frames = []
    files = {}
    prefix = 'assets/current-scene/' + c['sourceHashAggregate'] + '/'
    for original in report['frames']:
        safe_name(original['file'])
        require(pathlib.PurePosixPath(original['file']).name == original['file'], 'Frame must be directly inside evidence directory')
        b, w, h = png_bytes(evidence / original['file'], original)
        frame = dict(original, width=w, height=h)
        frame['file'] = original['name'] + '-' + original['sha256'][:16] + '.png'
        frame['publicPath'] = prefix + frame['file']
        files[frame['publicPath']] = b
        frames.append(frame)
    manifest = dict(report, frames=frames, schemaVersion=1, sourceFiles=c['sourceFiles'],
                    sourceHashAggregate=c['sourceHashAggregate'], candidatePath=c['candidatePath'],
                    candidateSourceCommit=identity['candidateSourceCommit'], checkoutCommit=identity['checkoutCommit'],
                    acceptance=c['acceptance'], acceptanceChinese=c['acceptanceChinese'], appearanceAccepted=False,
                    unverified=c['unverified'], totalBudgetMs=deadline['totalBudgetMs'],
                    comparisonLimits='OFF/ON pairs share the actual paused clock and camera; no claim of full-world appearance acceptance. The new63,402 triangles use terrestrial CC0 geometry, not measured reef geometry.')
    manifest_path = prefix + 'manifest.json'
    files[manifest_path] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    cards = ''.join('<figure><img loading="lazy" src="' + html.escape(f['publicPath'], quote=True)
                    + '" alt="' + html.escape(f['name'], quote=True) + ' actual WebGL frame"><figcaption>'
                    + html.escape(f['name']) + ' · SHA256 ' + f['sha256'] + '</figcaption></figure>' for f in frames)
    gallery = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>局部接地实验 · 实际画面</title><style>body{margin:24px auto;max-width:1440px;padding:0 16px;background:#10282e;color:#eee;font:16px system-ui}a{color:#9edbea}img{max-width:100%;height:auto}figure{margin:28px 0}figcaption{overflow-wrap:anywhere;font-size:13px}</style><h1>局部接地实验，整体真实感未通过</h1><p><a href="scan-exhibit.html">打开交互候选</a> · <a href="../world/">固定入口</a></p><p>同一实际暂停时间和机位，分别比较路线20%前向、50%后向的接地组件 OFF / ON。技术检查通过不等于局部外观或整体海底目标验收。20%薄脚、Lobe_45局部离面约0.149、50%背面裁切接口及生态清除断带仍待目视复核；如果本轮四图不可辨，Lobe_45保持未核实。新增63,402三角来自人工使用的陆地CC0几何，不是测量礁体；没有新增陆地贴图。原实测层和原素材的出处、许可与边界仍在交互页面保留。</p><p>百万点field仅执行一次完整加载和实际fresh帧；400万显示三角是点的surfel显示几何，不是原始源面。field后向、动物全周期碰撞、触屏、bfcache及设备FPS未验收。</p>'''
    gallery += cards + '<p><a href="' + manifest_path + '">精确源码、机位及技术证据清单</a></p><p>候选源码 ' + identity['candidateSourceCommit'] + ' · 发布构建 ' + identity['checkoutCommit'] + '</p></html>\n'
    files['current-scene.html'] = gallery.encode()
    require(len(files) == 6, 'Gallery must add only four PNGs, one manifest and one HTML')
    # This explicit candidate is fixed in the contract, never discovered from latest commit.
    pointer = {'schemaVersion': 2, 'entryPublishPath': c['entryPath'] + '/',
               'version': 'grounded-' + c['sourceHashAggregate'], 'selection': 'explicitly-pinned-grounded-experiment-after-technical-qa',
               'candidateSourceCommit': identity['candidateSourceCommit'], 'mainCommit': identity['checkoutCommit'],
               'sourceHashAggregate': c['sourceHashAggregate'], 'candidatePath': c['candidatePath'],
               'world': '../grounded-integration-candidate/scan-exhibit.html',
               'procedural': '../grounded-integration-candidate/index.html',
               'stills': '../grounded-integration-candidate/current-scene.html',
               'sources': '../grounded-integration-candidate/scan-exhibit.html#scanProvenance',
               'technicalStatus': report['status'], 'appearanceAccepted': False,
               'acceptance': c['acceptance'], 'acceptanceChinese': c['acceptanceChinese'], 'unverified': c['unverified'],
               'updatePolicy': 'Manually selected candidate source and explicit QA commit; never select newest Git commit. Provenance is not an immutable URL lock.'}
    index = (world / 'index.html').read_text()
    require(index.count('../rear-habitat-candidate/') == 4, 'Unexpected entry links')
    index = index.replace('../rear-habitat-candidate/', '../grounded-integration-candidate/')
    original = '当前入口指向已验收的后方礁群阶段。<br>版本：<code>main0badf15ab2005fc3ed4bea91978054e036ef4667</code>'
    require(index.count(original) == 1, 'Unexpected entry version text')
    index = index.replace(original, '当前入口指向局部接地实验，整体真实感未通过。<br>候选源码：<code>'
                          + identity['candidateSourceCommit'] + '</code><br>发布构建：<code>' + identity['checkoutCommit'] + '</code>')
    check_deadline()
    for n, b in files.items():
        p = root / n
        require(not p.exists(), 'New gallery collision: ' + n)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
    (world / 'index.html').write_text(index)
    save_json(world / 'current-world.json', pointer)
    gallery_files = [file_record(root / n, c['candidatePath'] + '/' + n) for n in sorted(files)]
    entry_files = [file_record(world / n, n) for n in ('index.html', 'world.css', 'current-world.json')]
    receipt = {'schemaVersion': 1, 'sourceIdentity': identity, 'galleryFiles': gallery_files, 'entryFiles': entry_files,
               'targetSourceFiles': c['sourceFiles'], 'targetGallery': {'current-scene.html': file_record(root / 'current-scene.html')},
               'pointer': pointer, 'state': 'GPU_PASS_ENTRY_QA_PENDING', 'appearanceAccepted': False}
    save_json('.grounded-finalized.json', receipt)
    check_old(c)
    check_deadline()
    print('GROUNDED_PUBLIC_GALLERY_READY', json.dumps({'galleryFiles': 6, 'frames': c['frames'], 'sourceIdentity': identity, 'appearanceAccepted': False}))


def finalize_entry():
    c, _, _ = contracts()
    deadline = check_deadline()
    check_old(c)
    check_sources(c)
    receipt, gallery = gallery_records(c)
    require(receipt['state'] == 'GPU_PASS_ENTRY_QA_PENDING', 'Entry already finalized/invalid state')
    require(receipt['sourceIdentity'] == source_identity(c), 'Source identity changed')
    for f in gallery:
        validate_bytes((DIST / f['path']).read_bytes(), f, f['path'])
    world = DIST / c['entryPath']
    for f in receipt['entryFiles']:
        validate_bytes((world / f['path']).read_bytes(), f, f['path'])
    result = read_json('.entry-evidence/result.json')
    require(result['status'] == 'PASS_STATIC_ENTRY', 'Static entry QA did not pass')
    require(result['sourceIdentity'] == receipt['sourceIdentity'], 'Static result source identity changed')
    require(result['deadline'] == deadline, 'Static runner changed shared deadline')
    require([f['name'] for f in result['screenshots']] == ['entry-desktop', 'entry-narrow'], 'Expected exact two entry screenshots')
    out = world / 'evidence'
    require(not out.exists(), 'Entry evidence already exists')
    outputs = []
    for shot in result['screenshots']:
        safe_name(shot['file'])
        require(shot['file'] == shot['name'] + '.png', 'Unexpected entry screenshot path')
        b, w, h = png_bytes(pathlib.Path('.entry-evidence') / shot['file'], shot,
                            width=1366 if shot['name'] == 'entry-desktop' else 320)
        n = 'evidence/' + shot['name'] + '-' + shot['sha256'][:16] + '.png'
        outputs.append((n, b, dict(shot, path=c['entryPath'] + '/' + n, width=w, height=h)))
    check_deadline()
    out.mkdir()
    for n, b, _ in outputs:
        (world / n).write_bytes(b)
    receipt.update(entryScreenshots=[record for _, _, record in outputs], state='GPU_AND_STATIC_ENTRY_PASS',
                   entryResultSha256=sha(pathlib.Path('.entry-evidence/result.json').read_bytes()))
    save_json('.grounded-finalized.json', receipt)
    check_old(c)
    check_deadline()
    print('GROUNDED_ENTRY_EVIDENCE_READY', json.dumps({'screenshots': receipt['entryScreenshots'], 'appearanceAccepted': False}))


if __name__ == '__main__':
    require(sys.argv[1:] in ([], ['--entry-evidence']), 'Unexpected arguments')
    (finalize_entry if '--entry-evidence' in sys.argv else finalize_gpu)()
