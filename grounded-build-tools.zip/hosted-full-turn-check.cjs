// Optional runner helper. Native Playwright input only; public read APIs for assertions.
// Caller waits for assets/ready, captures its own four images, and owns run budget.
const assert=require('node:assert/strict');
async function dragAngle(page,angle){
  const b=await page.locator('#scanCanvas').evaluate(e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}});assert(b&&b.width>100);
  const chunk=Math.min(220,b.width*.25);let remaining=angle/.004;
  while(Math.abs(remaining)>.001){const dx=Math.sign(remaining)*Math.min(chunk,Math.abs(remaining)),x=b.x+b.width*.5,y=b.y+b.height*.45;
   await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x-dx,y,{steps:5});await page.mouse.up();remaining-=dx;
  }
 }

module.exports=async function verifyFullTurn(page){
 const report={kind:'hosted browser native mouse and keyboard'};
 try{
 const state=()=>page.evaluate(()=>window.reefExhibit.getState());
 const wrap=x=>((x+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI;
 const near=(a,b,e=.015)=>assert(Math.abs(wrap(a-b))<e,`${a} != ${b}`);
 const sameCamera=(a,b)=>assert.deepEqual(a.camera,b.camera);
 const heading=s=>Math.atan2(s.target[0]-s.camera[0],s.target[2]-s.camera[2]);
 const canvas=page.locator('#scanCanvas');
 async function focus(){await canvas.focus();}
 async function click(selector){const b=await page.locator(selector).evaluate(e=>{const r=e.getBoundingClientRect();const x=r.x+r.width/2,y=r.y+r.height/2,hit=document.elementFromPoint(x,y);return {x,y,width:r.width,height:r.height,disabled:!!e.disabled,hit:!!hit&&(hit===e||e.contains(hit)),inViewport:x>=0&&y>=0&&x<innerWidth&&y<innerHeight}});assert(b.width>0&&b.height>0&&!b.disabled&&b.hit&&b.inViewport);await page.mouse.click(b.x,b.y);}
 // Public goRoute is used only for reproducible setup; every tested input is native.
 await page.evaluate(()=>{window.reefExhibit.enterRoute();window.reefExhibit.goRoute(.2,true);window.reefExhibit.setAmbientPaused(true)});
 let initial=await state();await dragAngle(page,Math.PI);let back=await state();sameCamera(initial,back);near(back.route.yaw,Math.PI);near(heading(back),heading(initial)+Math.PI);report.mouse180=true;
 await dragAngle(page,Math.PI);let full=await state();sameCamera(initial,full);near(full.route.yaw,0,.025);near(heading(full),heading(initial),.025);report.mouse360=true;
 await click('#recenterLook');let centered=await state();sameCamera(initial,centered);near(centered.route.yaw,0,1e-8);near(centered.route.pitch,0,1e-8);
 await focus();let edgeBefore,edgeAfter;for(let i=0;i<200;i++){await page.keyboard.press('ArrowRight');if(i===38)edgeBefore=await state();if(i===39)edgeAfter=await state();}near(heading(edgeAfter)-heading(edgeBefore),.08,1e-8);sameCamera(edgeBefore,edgeAfter);report.normalizationBoundary={yawBefore:edgeBefore.route.yaw,yawAfter:edgeAfter.route.yaw,horizontalHeadingStep:.08};let multi=await state();sameCamera(initial,multi);near(multi.route.yaw,wrap(16),1e-8);near(heading(multi),heading(initial)+16,1e-8);report.keyboardMultiTurn=true;
 await page.keyboard.press('r');let r=await state();sameCamera(initial,r);near(r.route.yaw,0,1e-8);assert.equal(r.route.progress,.2);report.recenterButtonAndR=true;
 await dragAngle(page,Math.PI);await focus();const p=(await state()).route.progress;await page.keyboard.down('w');await page.waitForFunction(p=>window.reefExhibit.getState().route.progress>p,p,{timeout:12000});await page.keyboard.up('w');let stopped=await state();assert(stopped.route.progress>p);assert.equal(stopped.route.goal,stopped.route.progress);await page.waitForTimeout(180);assert.equal((await state()).route.progress,stopped.route.progress);
 await page.keyboard.down('s');await page.waitForFunction(p=>window.reefExhibit.getState().route.progress<p,stopped.route.progress,{timeout:12000});await page.keyboard.up('s');stopped=await state();assert.equal(stopped.route.goal,stopped.route.progress);report.wsAlongRouteWhenBackwardAndRelease=true;
 await page.keyboard.down('w');await page.waitForFunction(p=>window.reefExhibit.getState().route.progress>p,stopped.route.progress,{timeout:12000});await page.locator('#recenterLook').focus();await page.keyboard.up('w');let blurred=await state();assert.equal(blurred.route.goal,blurred.route.progress);await page.waitForTimeout(180);assert.equal((await state()).route.progress,blurred.route.progress);report.focusBlurStops=true;
 let beforeRaw=await state();if(!await page.locator('#hudMore').evaluate(e=>e.open))await click('#hudMoreSummary');await click('#toggleOcean');assert.equal((await state()).waterMode,false);await click('#toggleOcean');let afterRaw=await state();assert.equal(afterRaw.waterMode,true);assert.deepEqual(afterRaw.route,beforeRaw.route);assert(beforeRaw.camera.every((v,i)=>Math.abs(v-afterRaw.camera[i])<1e-6));await click('#closeHudMore');report.rawRoundTrip=true;
 await click('#exploreRoute');assert.equal((await state()).route.active,false);await click('#exploreRoute');let reenter=await state();assert.equal(reenter.route.active,true);assert.equal(reenter.route.progress,0);near(reenter.route.yaw,0,1e-8);report.exitReentry=true;
 await page.evaluate(()=>window.reefExhibit.goRoute(.5,true));await page.emulateMedia({reducedMotion:'reduce'});await focus();await page.keyboard.press('w');assert(Math.abs((await state()).route.progress-.55)<1e-10);await page.keyboard.press('s');assert(Math.abs((await state()).route.progress-.5)<1e-10);await page.keyboard.press('ArrowLeft');near((await state()).route.yaw,-.08,1e-8);report.reducedMotion=true;
 await page.keyboard.press('Home');let home=await state();assert.equal(home.route.progress,0);near(home.route.yaw,0,1e-8);report.home=true;await page.emulateMedia({reducedMotion:'no-preference'});
 report.unverified=['Native touch and actual pointercancel/lost capture','Actual tab hiding and browser bfcache navigation','User-device performance'];
 return report;
 }finally{console.log('FULL_TURN_NATIVE_CHECKPOINTS '+JSON.stringify(report));}
};

module.exports.dragAngle=dragAngle;
