# Grounded candidate build contract

These are build tools, not public product files. Only `dist` is deployable. No tool here performs a remote write.

The unchanged earlier assembly must end with the142-source rear candidate and1504 site files. `stage-grounded.py` validates the old rear source inventory, checks the pinned six-file gallery ZIP, restores that gallery, snapshots all1510 old file hashes, and stages exactly144 candidate source files plus the original three-file world-entry package. The only code overlay is `install-layered-ridges.js`, `grounded-shoulder.js`, and `grounded-shoulder-data.js`. It neither modifies runtime code nor creates a candidate-success pointer.

Inputs:

- `.entry-inputs/rear-gallery-0badf15.zip`,4,421,060 bytes, SHA256 `6e0be988b8f812b98e36c9cb9f99577635db14c45cd22d950428fc21d0c021d6`, existing QA commit `cf5fb36d21f9a55ae7ec1732f2a128d3c64749dd`.
- `.entry-inputs/world-entry-code.zip`,3,124 bytes, SHA256 `806cf567bd152ab16be854bb0f8080b21d69d3d31f9ea94c40876a3d4bae6295`, same existing QA commit.
- `.grounded-inputs/grounded-code.zip`,1,294,389 bytes, SHA256 `07778417c1ab1de28e97161f6eb008b9b47b8df7cdf33f1659b2147c415d6c41`.

Source identity is the exact five-field object `{candidatePath, sourceHashAggregate, candidateSourceCommit, checkoutCommit, sourceFiles}`. `candidateSourceCommit` comes from explicitly pinned `GROUNDED_SOURCE_COMMIT`; `checkoutCommit` is the actual build `GITHUB_SHA`. Both must be40 lowercase hexadecimal characters. No tool chooses the newest commit. The aggregate hashes sorted UTF-8 records `path + NUL + sha256 + LF`; this candidate aggregate is `ed947eda671eefcd297112720ee3a03a5dd01a88a54fa19c3622f1f574d96310`.

Run order:

1. `python3 tools/stage-grounded.py`
2. `python3 tools/verify-grounded-preserved.py --source-only`
3. The one permitted GPU runner, with `GROUNDED_OUTPUT=grounded-qa`. It alone creates `.grounded-deadline.json` using exclusive creation. Its start+450,000ms is the shared hard deadline.
4. `python3 tools/finalize-grounded.py`. Requires `grounded-qa/browser-result.json` status `PASS_SUPPORTED_BROWSER`, exact source identity and run timestamps, zero errors, four named PNGs with SHA256/dimensions, live nonblank GL evidence and exact paused OFF/ON pairs. It creates four PNGs, one manifest, one gallery HTML, then explicitly selects this candidate in the static entry. Appearance acceptance stays false.
5. Optionally `python3 tools/verify-grounded-preserved.py --before-entry-evidence`.
6. `ENTRY_URL=http://127.0.0.1:PORT/preview/world/ node tools/browser-check-entry.mjs`. Uses only the existing deadline remainder. It checks1366px and320px layouts, keyboard focus/details, and the three target HTML documents by GET. It does not execute target scene/model code. Every page request outside entry/CSS/favicon is blocked. Screenshots have25-second individual caps, bounded by the same remaining time. No automatic retry is permitted.
7. `python3 tools/finalize-grounded.py --entry-evidence`. Requires a matching `PASS_STATIC_ENTRY` receipt and adds only two PNGs.
8. `python3 tools/verify-grounded-preserved.py`. Rehashes all old files and exact additions; checks the shared deadline before and after; emits `GROUNDED_PUBLIC_RECEIPT` containing all155 new paths/bytes/SHA256 and both commits.

The exact final allowlist is144 candidate sources +6 gallery files +3 static entry files +2 entry screenshots =155 additions,1665 total site files. A missing/modified old file, candidate source mismatch, symlink, unexpected file, mismatched evidence identity, stale result, failed QA, or expired deadline rejects the build. Failed verification must prevent Pages upload/deploy. Private build receipts and raw browser output are outside `dist`.

The gallery labels the result “局部接地实验，整体真实感未通过”. Four images are evidence for parent visual review, not aesthetic acceptance. Lobe_45 remains unverified when not discernible. Field-enabled rear view, full animal-cycle collisions, touch, bfcache, and device FPS remain unverified.

`../test-stage.py` runs offline guards against real pinned baseline bytes and explicit synthetic QA/PNG fixtures. Synthetic fixtures are removed after the test and never represent real GPU/browser QA.
