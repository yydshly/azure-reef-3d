// CPU/mock invocation of the exact browser helper; never starts a browser.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {T,scene,ocean,world} from './build-grounded-fixture.mjs';
import {inspectGroundedPage} from './browser-inspect-grounded.mjs';
const fixture=JSON.parse(fs.readFileSync(new URL('./grounded-fixture.json',import.meta.url)));
const camera=new T.PerspectiveCamera();camera.position.set(1,3,-4);ocean.update(7,camera);scene.updateMatrixWorld(true);
let field=null;
const e={scene,world,ocean,camera,renderer:{getContext:()=>({})},continuousField:{getState:()=>field?{enabled:true,installed:true,...field.inspect()}:{enabled:false,installed:false}}};globalThis.window={reefExhibit:e};
const page={evaluate:(fn,arg)=>fn(arg)};
const checkpoints=[];
const check=async(name,options={})=>{const report=await inspectGroundedPage(page,fixture,options);assert.deepEqual(report.issues,[],name);checkpoints.push(name);return report;};
await check('initial-source-and-fixture',{initialize:true,checkOriginals:true});
world.groundedShoulder.setEnabled(false);await check('off-source-exact-restore',{checkOriginals:true});
const s=world.groundedShoulder.swaps[0];s.original.visible=false;let bad=await inspectGroundedPage(page,fixture);assert(bad.issues.includes('Exact OFF/ON inherited/source visibility'));s.original.visible=s.visible;checkpoints.push('negative-broken-off-detected');
world.groundedShoulder.setEnabled(true);camera.position.set(5,3,-25);ocean.update(7,camera);scene.updateMatrixWorld(true);await check('on-route-camera-follow',{checkOriginals:true});
const old=s.original.instanceMatrix.array[0];s.original.instanceMatrix.array[0]+=.25;bad=await inspectGroundedPage(page,fixture,{checkOriginals:true});assert(bad.issues.some(x=>x.startsWith('Fixture original')));assert(bad.issues.includes('Original buffer bytes'));s.original.instanceMatrix.array[0]=old;checkpoints.push('negative-source-matrix-detected');
// The minimal fixture scene does not install the pre-existing coral-midground
// replacement; use the complete field integration test already frozen in CPU QA.
// Here test the helper's documented ridge geometry exception explicitly.
const ridge=world.group.getObjectByName('Layered_Ridges_Weathered_Shoulders'),original=ridge.geometry;ridge.geometry=original.clone();field={inspect:()=>({points:1000000,displayTriangles:4000000})};await check('field-ridge-swap-preserves-original',{checkOriginals:true,field:true});ridge.geometry.dispose();ridge.geometry=original;field=null;await check('restored-source-exact',{checkOriginals:true});
const h=world.groundedShoulder,before={...world.budget};h.dispose();h.dispose();const result=await check('disposed-source-exact',{checkOriginals:true,disposed:true});assert.equal(result.protection.borrowedDisposals,0);assert.equal(world.budget.triangles,before.triangles-57158);assert.equal(world.budget.drawCalls,before.drawCalls-4);
const resultReport={status:'PASS_LOCAL_CPU_HELPER_ONLY',checkpoints,limits:'No actual browser, GPU, field draw or screenshot. Actual field lifecycle remains the existing frozen CPU QA and future bounded browser run.'};fs.writeFileSync(new URL('../helper-local-checks.json',import.meta.url),JSON.stringify(resultReport,null,2)+'\n');console.log(JSON.stringify(resultReport,null,2));
