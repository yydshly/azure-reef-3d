// Run ONLY in the already-authorized supported browser runner, not the restricted local executor.
// Existing Playwright installation required. No software install or deployment is performed here.
import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
const base=process.env.SURFEL_URL;if(!base)throw new Error('Set SURFEL_URL to the isolated candidate URL');
const output=process.env.SURFEL_OUTPUT||'surfel-browser-evidence';await mkdir(output,{recursive:true});
const browser=await chromium.launch({channel:'chromium',headless:true,chromiumSandbox:true,timeout:30000,args:['--enable-automation'],ignoreDefaultArgs:['--enable-unsafe-swiftshader','--disable-gpu-sandbox','--ignore-gpu-blocklist']});
const cdp=await browser.newBrowserCDPSession();const command=await cdp.send('Browser.getBrowserCommandLine');assert(!command.arguments.some(x=>['--no-sandbox','--disable-gpu-sandbox','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'].includes(x)),'Security-weakening browser flag');
const page=await browser.newPage({viewport:{width:1440,height:1300},deviceScaleFactor:1});
const deadline=setTimeout(()=>{console.error('450s overall QA deadline');process.exit(1);},450000);
const errors=[];page.on('pageerror',e=>errors.push(e.message));
try {
 await page.goto(base);assert.equal(await page.locator('canvas').count(),0);
 let payloadRequests=0;page.on('request',r=>{if(r.url().endsWith('darwin-1000k.bin'))payloadRequests++;});
 await page.waitForTimeout(200);assert.equal(payloadRequests,0,'not loaded before explicit action');
 await page.route('**/darwin-1000k.bin',route=>route.fulfill({status:503,body:'test failure'}),{times:1});
 await page.locator('#load').click();await page.waitForFunction(()=>document.body.dataset.state==='error');
 assert.match(await page.locator('#status').textContent(),/503/);
 await page.locator('#load').click();await page.waitForFunction(()=>document.body.dataset.state==='ready',null,{timeout:120000});
 const initial=await page.evaluate(()=>window.reefSurfel.inspect());
 assert.equal(initial.points,1000000);assert.equal(initial.sceneChildren,1);assert.equal(initial.render.calls,1);assert.equal(initial.render.triangles,4000000);assert.equal(initial.textureCount,0);assert.equal(initial.lastError,null);assert.equal(initial.uniqueCPUPointBuffers,1);assert.equal(Object.values(initial.attributes).reduce((n,a)=>n+a.byteLength,0),24000000);assert(initial.programs.length>0&&initial.programs.every(p=>p.linked));
 const normalProbe=await page.evaluate(()=>window.reefSurfel.probePixels());assert.equal(normalProbe.glError,0);assert(normalProbe.nonBackground>10000);
 assert.equal(await page.evaluate(()=>document.querySelector('canvas').getContext('webgl2').getError()),0);
 await page.screenshot({path:`${output}/normal-browser.png`,clip:await page.locator('#viewport').boundingBox(),timeout:25000});
 await page.locator('#side').click();await page.waitForTimeout(150);
 const sideProbe=await page.evaluate(()=>window.reefSurfel.probePixels());assert.equal(sideProbe.glError,0);assert(sideProbe.nonBackground>10000);
 const side=await page.evaluate(()=>window.reefSurfel.inspect());assert.equal(side.elevation,12);
 await page.screenshot({path:`${output}/side-browser.png`,clip:await page.locator('#viewport').boundingBox(),timeout:25000});
 const stable=await page.evaluate(()=>window.reefSurfel.inspect().frames);await page.waitForTimeout(500);assert.equal(await page.evaluate(()=>window.reefSurfel.inspect().frames),stable,'idle produces no frames');
 await page.locator('#pause').click();await page.locator('#normal').click();await page.waitForTimeout(250);
 assert.equal(await page.evaluate(()=>window.reefSurfel.inspect().frames),stable,'paused view changes produce no frames');
 await page.locator('#pause').click();await page.waitForTimeout(150);assert((await page.evaluate(()=>window.reefSurfel.inspect().frames))>stable);
 const box=await page.locator('canvas').boundingBox();await page.mouse.move(box.x+100,box.y+100);await page.mouse.down();await page.mouse.move(box.x+1200,box.y+900);await page.mouse.up();
 const orbit=await page.evaluate(()=>window.reefSurfel.inspect());assert(orbit.yaw<=15&&orbit.yaw>=-15&&orbit.elevation>=12&&orbit.elevation<=55);
 await page.locator('#normal').click();await page.waitForTimeout(100);
 const gl=await page.evaluate(()=>{const g=document.querySelector('canvas').getContext('webgl2');return{version:g.getParameter(g.VERSION),renderer:g.getParameter(g.RENDERER),vendor:g.getParameter(g.VENDOR),maxTextureSize:g.getParameter(g.MAX_TEXTURE_SIZE),error:g.getError()};});assert.equal(gl.error,0);
 await page.locator('#destroy').click();assert.equal(await page.locator('canvas').count(),0);
 const destroyed=await page.evaluate(()=>window.reefSurfel.inspect());assert.equal(destroyed.disposed,true);assert.equal(destroyed.points,0);assert.equal(destroyed.scheduledFrames,0);
 await page.locator('#load').click();await page.waitForFunction(()=>document.body.dataset.state==='ready',null,{timeout:120000});assert.equal(await page.locator('canvas').count(),1);
 await page.locator('#destroy').click();
 assert.deepEqual(errors,[]);
 const frames=await Promise.all(['normal','side'].map(async name=>{const data=await readFile(`${output}/${name}-browser.png`);return{name,file:`${name}-browser.png`,bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')};}));
 await writeFile(`${output}/browser-result.json`,JSON.stringify({status:'PASS_SUPPORTED_BROWSER',frames,browser:{version:browser.version(),sandbox:true,unsafeGraphicsFlags:false},initial,side,normalProbe,sideProbe,orbit,destroyed,gl,payloadRequests,errors,limits:'WebGL desktop runner only; not physical GPU memory/FPS/mobile validation'},null,2));
} finally {clearTimeout(deadline);await browser.close();}
