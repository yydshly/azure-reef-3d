import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {decode,readPacked,cameraPosition} from '../data.js';
import {buildGeometry,vertexShader} from '../viewer.js';
const m=JSON.parse(await readFile(new URL('../data/manifest.json',import.meta.url)));
const file=await readFile(new URL('../data/darwin-1000k.bin',import.meta.url));
const buffer=file.buffer.slice(file.byteOffset,file.byteOffset+file.byteLength);
assert.equal(createHash('sha256').update(file).digest('hex'),m.sha256);
const a=decode(buffer,m);const geometry=buildGeometry(a,m.points);
assert.equal(a.positions.buffer,a.normals.buffer);assert.equal(a.colors.buffer,a.positions.buffer);
assert.equal(a.positions.byteLength+a.normals.byteLength+a.colors.byteLength,24000000);
assert.equal(geometry.instanceCount,1000000);assert.equal(geometry.index.count,12);assert.equal(geometry.attributes.position.count,6);
assert.equal(geometry.attributes.center.array,a.positions);assert.equal(geometry.attributes.sourceNormal.normalized,true);assert.equal(geometry.attributes.sourceColor.normalized,true);
assert.equal(geometry.attributes.position.array.byteLength+geometry.index.array.byteLength,96);
for(let i=0;i<m.points;i++){
 for(let j=0;j<3;j++)assert(Number.isFinite(a.positions[3*i+j]));
 const n=Math.hypot(...a.normals.subarray(4*i,4*i+3))/32767;assert(n>.9999&&n<1.0001);
 assert.equal(a.normals[4*i+3],0);assert.equal(a.colors[4*i+3],255);
}
assert.deepEqual(cameraPosition(m,50),m.views.normal);assert.deepEqual(cameraPosition(m,12),m.views.side);
assert.equal(m.orthoWidth,12.99991512298584);assert(vertexShader.includes('cross(n,ref)'));assert(!vertexShader.includes('cameraPosition'));
assert.throws(()=>decode(new ArrayBuffer(8),m));
const originalFetch=globalThis.fetch;
try{
 let progress=0;
 globalThis.fetch=async()=>new Response(file,{headers:{'content-length':String(m.bytes)}});
 const downloaded=await readPacked('memory',m,new AbortController().signal,n=>progress=n);assert.equal(progress,24000000);assert.equal(downloaded.colors[0],a.colors[0]);
 globalThis.fetch=async()=>new Response(file.subarray(0,100));
 await assert.rejects(readPacked('memory',m,new AbortController().signal,()=>{}),/Truncated/);
 globalThis.fetch=async()=>new Response(file);
 await assert.rejects(readPacked('memory',{...m,sha256:'bad'},new AbortController().signal,()=>{}),/SHA-256/);
 globalThis.fetch=async()=>new Response('bad',{status:503});
 await assert.rejects(readPacked('memory',m,new AbortController().signal,()=>{}),/503/);
}finally{globalThis.fetch=originalFetch;geometry.dispose();}
console.log(JSON.stringify({status:'PASS_CPU_ONLY',points:m.points,uniqueCPUPointBufferBytes:buffer.byteLength,gpuAttributeBytes:24000000,primitiveBytes:96,normalQuantizationMaxDegrees:m.maxNormalErrorDegrees,payloadSHA256:m.sha256,checks:['Three module import','geometry instancing and shared CPU buffer','finite positions/unit normals','exact reference cameras','stream progress','truncated payload','bad hash','HTTP failure']},null,2));
