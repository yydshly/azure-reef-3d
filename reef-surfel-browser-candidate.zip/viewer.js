import * as THREE from './vendor/three.module.js';
import {readPacked, cameraPosition} from './data.js';
export const vertexShader = `
attribute vec3 center;
attribute vec4 sourceNormal;
attribute vec4 sourceColor;
uniform float radius;
varying vec3 rgb;
void main() {
  vec3 n = normalize(sourceNormal.xyz);
  vec3 ref = abs(n.z) > 0.9 ? vec3(1.,0.,0.) : vec3(0.,0.,1.);
  vec3 u = normalize(cross(n,ref));
  vec3 v = cross(n,u);
  vec3 p = center + radius * (position.x*u + position.y*v);
  rgb = sourceColor.rgb;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p,1.);
}`;
export const fragmentShader = `
varying vec3 rgb;
void main() {
  // Source byte values assumed sRGB, as in the offline reference.
  vec3 linearRGB = mix(pow((rgb + vec3(.055))/1.055, vec3(2.4)), rgb/12.92, lessThanEqual(rgb,vec3(.04045)));
  gl_FragColor = vec4(linearRGB,1.);
  #include <colorspace_fragment>
}`;
export function buildGeometry(a, count) {
  const g = new THREE.InstancedBufferGeometry();
  const corners = new Float32Array(18);
  for(let i=0;i<6;i++){corners[3*i]=Math.cos(i*Math.PI/3);corners[3*i+1]=Math.sin(i*Math.PI/3);}
  g.setAttribute('position',new THREE.BufferAttribute(corners,3));
  g.setIndex(new THREE.BufferAttribute(new Uint16Array([0,1,2,0,2,3,0,3,4,0,4,5]),1));
  g.setAttribute('center',new THREE.InstancedBufferAttribute(a.positions,3));
  g.setAttribute('sourceNormal',new THREE.InstancedBufferAttribute(a.normals,4,true));
  g.setAttribute('sourceColor',new THREE.InstancedBufferAttribute(a.colors,4,true));
  g.instanceCount=count; return g;
}
export function createViewer(host, report) {
  const lifecycle=new AbortController(), signal=lifecycle.signal;
  let renderer=null, scene=null, camera=null, mesh=null, manifest=null, pending=null;
  let disposed=false, paused=false, raf=0, dirty=false, contextLost=false, ready=false;
  let elevation=50, yaw=0, frames=0, drag=null, lastError=null;
  function status(state, text){ if(!disposed) report({state,text}); }
  function resize(){
    if(!renderer || !camera || disposed) return;
    const w=Math.max(1,Math.floor(host.clientWidth)), h=Math.max(1,Math.floor(host.clientHeight));
    renderer.setSize(w,h,false);
    const width=manifest.orthoWidth;
    camera.left=-width/2;camera.right=width/2;camera.top=width*h/w/2;camera.bottom=-camera.top;
    camera.updateProjectionMatrix();invalidate();
  }
  function invalidate(){
    dirty=true;
    if(disposed || paused || contextLost || document.hidden || raf || !ready) return;
    raf=requestAnimationFrame(()=>{
      raf=0;if(disposed||paused||contextLost||document.hidden||!dirty)return;
      dirty=false;
      try {renderer.render(scene,camera);frames++;if(lastError)throw new Error(lastError);status('ready',`${manifest.points.toLocaleString()} measured points · 1 instanced mesh · ${renderer.info.render.calls} draw · ${renderer.info.render.triangles.toLocaleString()} display triangles`);}
      catch(e){ready=false;status('error',`Render failed: ${e.message}`);}
    });
  }
  function updateCamera(){camera.position.fromArray(cameraPosition(manifest,elevation,yaw));camera.lookAt(0,0,0);camera.updateMatrixWorld();invalidate();}
  function view(name){if(!ready)return;elevation=name==='side'?12:50;yaw=0;updateCamera();}
  async function load(){
    if(disposed||pending||ready)return;
    pending=new AbortController();const own=pending;
    signal.addEventListener('abort',()=>own.abort(),{once:true});
    status('loading','Loading manifest…');
    try {
      const r=await fetch('./data/manifest.json',{signal:own.signal,cache:'no-store'});if(!r.ok)throw new Error(`Manifest HTTP ${r.status}`);manifest=await r.json();
      const a=await readPacked('./data/darwin-1000k.bin',manifest,own.signal,(n,total)=>status('loading',`Loading points ${(100*n/total).toFixed(1)}% · ${(n/1e6).toFixed(1)}/${total/1e6} MB`));
      if(disposed||own.signal.aborted)return;
      status('loading','SHA-256 verified. Creating WebGL buffers…');
      renderer=new THREE.WebGLRenderer({antialias:false,alpha:false,depth:true,stencil:false,preserveDrawingBuffer:false,powerPreference:'default'});
      renderer.setPixelRatio(1);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.NoToneMapping;
      renderer.setClearColor(0x404040); // Exact empty-background pixel of the frozen offline PNG.
      renderer.debug.onShaderError=(_gl,_program,vs,fs)=>{lastError=`Shader compile/link failure: ${_gl.getShaderInfoLog(vs)} ${_gl.getShaderInfoLog(fs)}`;};
      host.append(renderer.domElement);
      scene=new THREE.Scene();camera=new THREE.OrthographicCamera(-1,1,1,-1,manifest.near,manifest.far);camera.up.set(0,0,1);
      const material=new THREE.ShaderMaterial({vertexShader,fragmentShader,uniforms:{radius:{value:manifest.radius}},side:THREE.DoubleSide,transparent:false,depthWrite:true,depthTest:true,blending:THREE.NoBlending,toneMapped:false});
      mesh=new THREE.Mesh(buildGeometry(a,manifest.points),material);mesh.frustumCulled=false;scene.add(mesh);
      const canvas=renderer.domElement;
      canvas.addEventListener('webglcontextlost',e=>{if(disposed||canvas!==renderer?.domElement)return;e.preventDefault();contextLost=true;if(raf)cancelAnimationFrame(raf);raf=0;status('error','WebGL context lost. Wait for restoration or destroy and retry.');},{signal});
      canvas.addEventListener('webglcontextrestored',()=>{if(disposed||canvas!==renderer?.domElement)return;contextLost=false;lastError=null;ready=true;invalidate();},{signal});
      canvas.addEventListener('pointerdown',e=>{if(paused)return;drag={x:e.clientX,y:e.clientY};canvas.setPointerCapture(e.pointerId);},{signal});
      canvas.addEventListener('pointermove',e=>{if(!drag||paused)return;yaw=THREE.MathUtils.clamp(yaw+(e.clientX-drag.x)*.08,-15,15);elevation=THREE.MathUtils.clamp(elevation+(e.clientY-drag.y)*.08,12,55);drag={x:e.clientX,y:e.clientY};updateCamera();},{signal});
      for(const event of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(event,()=>{drag=null;},{signal});
      ready=true;resize();updateCamera();
    } catch(e){ if(!disposed&&e.name!=='AbortError'){releaseRenderer();status('error',e.message);} }
    finally {if(pending===own)pending=null;}
  }
  function releaseRenderer(){
    ready=false;if(raf)cancelAnimationFrame(raf);raf=0;
    if(mesh){scene.remove(mesh);mesh.geometry.dispose();mesh.material.dispose();mesh=null;}
    if(renderer){const canvas=renderer.domElement;renderer.dispose();renderer.forceContextLoss();canvas.remove();renderer=null;}
    scene=null;camera=null;
  }
  const observer=new ResizeObserver(resize);observer.observe(host);
  document.addEventListener('visibilitychange',()=>{if(document.hidden){if(raf)cancelAnimationFrame(raf);raf=0;}else invalidate();},{signal});
  function pause(value){paused=value;if(paused){if(raf)cancelAnimationFrame(raf);raf=0;drag=null;status('paused','Paused · no render loop');}else invalidate();}
  function dispose(){if(disposed)return;disposed=true;pending?.abort();pending=null;lifecycle.abort();observer.disconnect();releaseRenderer();manifest=null;drag=null;}
  function inspect(){
    const size=renderer?.getDrawingBufferSize(new THREE.Vector2());
    const attributes=mesh?Object.fromEntries(['center','sourceNormal','sourceColor'].map(name=>{const a=mesh.geometry.getAttribute(name);return [name,{byteLength:a.array.byteLength,count:a.count,itemSize:a.itemSize,type:a.array.constructor.name,normalized:a.normalized}];})):{};
    const pointBytes=Object.values(attributes).reduce((n,a)=>n+a.byteLength,0);
    const primitiveBytes=mesh?mesh.geometry.getAttribute('position').array.byteLength+mesh.geometry.index.array.byteLength:0;
    const gl=renderer?.getContext();
    const programs=renderer?.info.programs.map(p=>({linked:gl.getProgramParameter(p.program,gl.LINK_STATUS),log:gl.getProgramInfoLog(p.program)}))??[];
    return {attributes,programs,uniqueCPUPointBuffers:mesh?new Set(['center','sourceNormal','sourceColor'].map(n=>mesh.geometry.getAttribute(n).array.buffer)).size:0,ready,disposed,paused,frames,scheduledFrames:raf?1:0,elevation,yaw,points:mesh?.geometry.instanceCount??0,sceneChildren:scene?.children.length??0,geometryCount:renderer?.info.memory.geometries??0,textureCount:renderer?.info.memory.textures??0,pointGPUAttributeBytes:pointBytes,sharedPrimitiveBytes:primitiveBytes,retainedCPUPointBytes:mesh?mesh.geometry.getAttribute('center').array.buffer.byteLength:0,sourceCacheBytes:0,applicationTextureBytes:0,framebuffer:{width:size?.x??0,height:size?.y??0,samples:renderer?.getContext().getParameter(renderer.getContext().SAMPLES)??0,estimateColorDepthBytes:size?size.x*size.y*8:0,note:'Estimate only; browser swapchain/driver overhead not measurable here'},camera:camera?{position:camera.position.toArray(),up:camera.up.toArray(),left:camera.left,right:camera.right,top:camera.top,bottom:camera.bottom,near:camera.near,far:camera.far}:null,sourceSHA256:manifest?.sourceSHA256,payloadSHA256:manifest?.sha256,render:renderer?{...renderer.info.render}:null,lastError};
  }
  function probePixels(){
    if(!ready||paused||disposed||contextLost)throw new Error('Viewer must be ready and unpaused');
    // Synchronous render+readback: never read a discarded default buffer in a later task.
    renderer.render(scene,camera);frames++;
    const gl=renderer.getContext(),size=renderer.getDrawingBufferSize(new THREE.Vector2());
    const pixels=new Uint8Array(size.x*size.y*4);gl.readPixels(0,0,size.x,size.y,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
    let nonBackground=0,checksum=0;
    for(let i=0;i<pixels.length;i+=4){if(pixels[i]!==64||pixels[i+1]!==64||pixels[i+2]!==64)nonBackground++;checksum=(checksum+pixels[i]+pixels[i+1]+pixels[i+2])>>>0;}
    return {width:size.x,height:size.y,nonBackground,checksum,glError:gl.getError(),temporaryReadbackBytes:pixels.byteLength};
  }
  return {load,view,pause,dispose,inspect,probePixels};
}
