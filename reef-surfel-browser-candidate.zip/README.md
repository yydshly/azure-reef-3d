# Isolated Darwin normal-surfel candidate

This directory is an independent, opt-in page. It does not edit, import from, or preload data into the older reef scene. No deployment, browser launch, model download, installation or main-scene integration was performed.

## Scope and evidence

- Real, continuous measured plot; 1,000,000 sampled points from 2,500,859 original vertices. Original source has **no faces and no UV**.
- Shared six-corner instanced disks oriented by measured surface normals, not view-facing billboards. Radius stays frozen at 0.016215423575204186 source units. Same hexagonal footprint and tangent basis as offline reference. Exactly 4 display triangles per point: 4,000,000 submitted display triangles in one instanced draw. These are rendering primitives, not source/reconstructed reef faces.
- Original RGB is byte-identical. Source RGB assumed sRGB, decoded to linear and returned through sRGB display transfer; unlit, no tone mapping, invented fill, fog, grading or lighting. Background #404040 matches the frozen PNG's empty pixel. Browser rasterization differs from offline Cycles antialiasing; pixel equivalence is not claimed.
- Opaque, double-sided, depth testing and depth writes ON; blending OFF. No transparent-splat sorting, multipass accumulation, soft alpha edges, MSAA or EWA. This intentionally exposes holes and grazing-angle gaps instead of blending them away.
- Camera orbit only: yaw ±15° around original bearing, elevation parameter 12–55°. Fixed target and distance formula; no zoom, pan, free flight, lower-surface entry or point picking. 50°/12° buttons reset exact reference coordinates. This is a limited-midground candidate, not a complete navigable reef.
- Metres are a high-confidence interpretation supported by author methods, not a unit field in the PLY. Source plot is ~10 × 10 × 1.94164 coordinate units.

## Files and loading

Open index.html through an existing approved HTTPS/localhost static server, then explicitly click Load. Do not use file://. No server was launched in this task. Three.js is vendored from the existing feasibility source; its MIT notice is in vendor/THREE-LICENSE.txt.

- data/darwin-1000k.bin: exactly 24,000,000 bytes; SHA-256 checked before GPU creation.
- vendor/three.core.js + three.module.js: 2,120,885 bytes total.
- data/manifest.json: source/sample/payload hashes, full attribution, radius, centering and exact cameras.
- pack.py: reproducible pack from the frozen sample-1000k.npz (no new samples).
- data.js: streamed fetch into one preallocated buffer, progress, length/hash validation.
- viewer.js: normal-surfel shader, geometry, lifecycle and restricted controls.
- tests/check.mjs: CPU/module/data and failure-path checks, passed; output tests/cpu-result.json.
- tests/browser-check.mjs: prepared for the existing supported runner only. **Not run here**. Imports the runner's existing Playwright; does not install it. Set SURFEL_URL and optionally SURFEL_OUTPUT. 450s overall deadline and 25s per screenshot; only the two candidate views. Test failed-load/retry, first render, GL error, 1m instances/one draw, reference screenshots, idle/pause, restricted orbit, destruction and reload.

Loading reports bytes, HTTP/truncation/hash/render errors and supports retry. Abort on destruction; SHA processing cannot be cancelled in-flight but its result is discarded if aborted. No requestAnimationFrame loop: only a dirty-frame request on load, controls, resize or restoration. Pause cancels pending frames; background tabs suspend pending renders. Dispose aborts requests, cancels frames, disconnects ResizeObserver/listeners, disposes geometry/material/renderer, removes canvas and releases retained references. Source point arrays remain until disposal so context restoration can reupload them. Actual driver reclamation timing is browser-controlled.

## Memory accounting (calculated, not measured device allocations)

Packed file uses structure-of-arrays: float32 XYZ at byte 0 (12 MB), int16 XYZW at byte 12,000,000 (8 MB, W=0), uint8 RGBA at byte 20,000,000 (4 MB, A=255). Normals and colors normalized in shader/attribute pipeline. Normals quantize then renormalize; maximum measured angular error 0.00146996°. RGB and centered XYZ unchanged.

- Retained CPU point storage: ONE 24 MB ArrayBuffer shared by three typed-array views. No deinterleaved point copies, original PLY, NPZ, indices, explicit million-mesh scene nodes or application source cache in browser.
- GPU attributes: THREE buffers 12 + 8 + 4 = **24 MB**, not three uploads of a 24 MB mixed-type buffer. Shared hex corner/index buffers total 96 bytes. One Mesh, one geometry, one material, six shared vertices, 1m instances.
- Application textures: 0 bytes; render-target textures: none. Renderer programs, internal objects and driver copies excluded from point total.
- Framebuffer: pixel ratio 1, antialias false, no stencil. At 1400×1000 nominal RGBA8 + depth24/32 estimate **11.2 MB**; browser swapchain, depth format alignment and driver overhead may add to this. inspect() reports actual dimensions/samples plus the estimate, not a measured allocation.
- Network chunks and SHA-256 processing create temporary browser-managed storage; conservatively allow another 24 MB digest copy plus received chunks/driver upload staging. Fetch uses no-store; no application cache duplicates source. Browser-internal caching/GC/driver behavior cannot be guaranteed from JS.
- Runtime counts and drawing-buffer diagnostics exposed as window.reefSurfel.inspect(). Attribute lengths are read from the actual Three geometry, alongside GL linked-program status. probePixels() synchronously renders then reads the fresh default framebuffer (one temporary width×height×4 array), returning non-background pixel counts/checksum/GL error; it is explicit diagnostics, not a permanent render loop. CPU attribute byte totals must not be represented as measured GPU RAM. No FPS/mobile/GPU-memory pass has been established.

## Exact offline alignment

Coordinate frame retained Z-up; positions = original XYZ minus [0.12477527558803558, 0.06939307600259781, -0.3903692364692688]. No further rotation/scale. Target [0,0,0], camera up [0,0,1]. L = 9.999935150146484 from original 250k sample's maximum XY extent. Offline script's numpy/Blender float32 coordinates are preserved:

- normal: [0.9999935030937195, -12.855669021606445, 15.320789337158203]
- side: [0.9999935030937195, -19.56282615661621, 4.158206939697266]
- Orthographic horizontal width 12.99991512298584; at 1400×1000 vertical height = width/1.4. Near .001, far 199.9987030029297. Browser viewport is 1.4 aspect and capped at 1400 CSS pixels, DPR1; runner canvas screenshots match 1400×1000. Fixed elevation labels refer to original script parameters; the small X offset makes true angle marginally different.

## Provenance and license

Galápagos_3D, Yuval, Matan; Keith, Inti; Terán, Franklin; Bensted-Smith, William; Iñiguez, Wilson. https://doi.org/10.5281/zenodo.14914807 · official record https://zenodo.org/records/14914807 · CC BY 4.0 https://creativecommons.org/licenses/by/4.0/

Member DarwinMay24_FinalExperimentChunk.ply from FinalPointClouds.zip. Source SHA-256 b100240b870f6b2de270c53cb2cd3395c4da9c53ef916420c02513bf9be7f8d1. Source evidence remains in sibling reef-pointcloud-feasibility/evidence/; full frozen statistics in revision-1000k/statistics.json. Sampling without replacement, seed 20261010, sorted source indices retained in original NPZ. Changes: 1m sampling, centering, int16 normal quantization, RGB alpha padding and normal-oriented display primitives. No reconstructed faces/UV or synthetic points.

The supplied upstream interleaved binary is intentionally not copied into browser: this SoA packing avoids Three mixed-type interleaving pitfalls and duplicate backing-store GPU uploads. Both derive from the same frozen NPZ. Payload SHA-256 87564b81a9b4343b758e3649944e74edf06c8a7daf1e9ccf64aafc17fc9343c0.
