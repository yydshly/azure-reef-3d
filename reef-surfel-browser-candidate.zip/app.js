import {createViewer} from './viewer.js';
const $=id=>document.getElementById(id);let viewer=null,paused=false;
function report({state,text}){$('status').textContent=text;document.body.dataset.state=state;$('load').disabled=state==='loading'||state==='ready'||state==='paused';for(const id of ['normal','side','pause'])$(id).disabled=!['ready','paused'].includes(state);if(state==='error')$('load').textContent='Retry load';}
function make(){viewer=createViewer($('viewport'),report);window.reefSurfel=viewer;}
$('load').onclick=()=>{if(viewer){viewer.dispose();}paused=false;$('pause').textContent='Pause';make();viewer.load();};
$('normal').onclick=()=>viewer?.view('normal');$('side').onclick=()=>viewer?.view('side');
$('pause').onclick=()=>{paused=!paused;viewer?.pause(paused);$('pause').textContent=paused?'Resume':'Pause';};
$('destroy').onclick=()=>{viewer?.dispose();paused=false;$('pause').textContent='Pause';$('load').textContent='Reload 24 MB candidate';report({state:'destroyed',text:'Destroyed · buffers disposed, requests aborted, listeners removed'});};
window.addEventListener('pagehide',()=>viewer?.dispose());
