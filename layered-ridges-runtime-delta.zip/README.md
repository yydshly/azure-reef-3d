# Layered reef shoulders: local structure candidate

Status: retained as a spatial-structure candidate only. Not deployed or committed. Blender comparisons are offline, not screenshots or browser acceptance. Visual realism remains unapproved: the new forms and small colony geometry are simplified.

## Frozen base and delta

Base = `reef-recovered-public/source/` overlaid with the existing `reef-natural-rock-candidate/delta/`. This is the **natural-rock candidate baseline**, not the default-only site. The original terrestrial boulder replacement remains installed. Do not apply its asset or replacement twice.

`page/` is a complete local copy for future independent webpage observation. `runtime-delta/` has exactly four incremental files: `install-layered-ridges.js`, `layered-ridges-runtime.js`, `scan-exhibit.js`, `scan-exhibit.html`. Existing assets, route, fish, turtle, ray, grass, C1/C4 scans, and C4/A assembly modules are unchanged. `output/freeze-manifest.json` records before/after file SHA256 and base provenance. `layered-ridges-runtime-delta.zip` contains the four-file delta and manifest.

## Composition and cost

Three independent, staggered shoulders, centered around (-17,-24), (22,-50), and (-9,-86), each built from nine unequal interlocking rock volumes. New ecology is ray-seated exclusively on new rock triangles. No global sand modification or original planting adjustment. The right side remains open at the far endpoint.

- Increment: 106,356 triangles, 6 mesh batches, zero new textures.
- Entire constructed page scene, measured by actual `scene.traverse`: 763,840 triangles, 70 meshes, one points object. This is the constructed ceiling, not a GPU frame-counter or device performance measurement.
- Natural-rock baseline: 657,484 triangles, 64 meshes, one points object.
- Offline export omits shader meshes: 762,622 triangles / 68 mesh batches.
- Colonies: 72 branch groups, 267 low groups, 21 fans, 63 plates, 21 rubble instances; 444 rooted instances total.
- Installer CPU timing: approximately 2.7 seconds in this workspace on the final lifecycle test. This is not a browser or frame-time test; synchronous generation may need precomputation before performance acceptance.

## Readiness and controls

`window.reefExhibit.ensureLayeredRidges()` waits for the original C4/A assembly and ensures the candidate. Automatic initial loading waits for C4/A and the natural-rock load attempt.

`window.reefExhibit.layeredRidges` provides:
- `getState()` => status, installed, enabled, error, disposed, budget.
- `setEnabled(boolean)` => independently hide/show and remove/re-add only its collision entries.
- `restore()` => remove only this candidate, restore its budget and obstacle entries, retain natural rock and baseline ecology.
- `ensure()` => synchronous reinstall after prerequisites; use page-level `ensureLayeredRidges()` if C4/A readiness is uncertain.
- `dispose()` => idempotent permanent release, without disposing baseline geometry, materials, or shared textures.
- `getRoot()` => candidate diagnostic root.

The root belongs to `world.group`, so raw C1/C4 mode hides it. UI buttons allow toggling, restoring the current baseline, and reloading. These transitions invalidate render-on-demand. A persisted pagehide preserves resources; non-persisted pagehide disposes the candidate before baseline disposal.

## One localized grass repair

The initial and one aesthetic revision are retained under `v1/` and `v2-before-foot-repair/`. After the authorized shape revision, a separately authorized foot correction moved exactly five new-terrain vertices along +X to x=10.58. Their original values are saved in root metadata. Maximum displacement: 1.401684 units. Y/Z coordinates, triangles, all other geometry positions, all instance matrices, all colony placements, and all materials were unchanged. Fourteen adjacent vertex normals were recomputed. The installer exposes `setFootRepair(false/true)` for a diagnostic reversible return to the pre-repair geometry; false deliberately reintroduces the documented grass intersections.

Final exact triangle intersections with baseline scan/plant/grass surfaces: zero. Original habitat contacts covered by new rock: zero. New root-to-surface contact mismatches: zero. Full original exported geometry/materials/transforms preserved, with ordered comparison so duplicate mesh names are not collapsed.

Route nearest new-surface distance: 5.4122 units (10,001 samples; gap bound 0.004). Conservative full-period ray/turtle/fish checks are positive; details and method are in `output/geometry-validation.json`. These are synthetic scene units, not measured metres.

## Verification

- `node reef-layered-ridges-candidate/test-installer.mjs`: real Three scene/loader; duplicate install guard, toggle, raw inheritance, exact original preservation, local repair rollback, budget and obstacle restoration, own-only/idempotent disposal. Water shader hooks inspected, not WebGL-compiled.
- `node reef-layered-ridges-candidate/test-page.mjs`: actual copied page module and real scene/loader with mocked DOM/renderer; initial readiness, raw C1/C4, paused-demand render behavior, repeated toggle, restore/reinstall, bfcache and unload tested. Includes actual constructed scene traversal budget. **Not browser QA.**
- `blender --background --python reef-layered-ridges-candidate/validate_geometry.py`: BVH contact, grass/scan intersection, route and motion checks.
- `python reef-layered-ridges-candidate/check_repair_diff.py`: exact pre/post repair geometry/matrix/material comparison and fixed-camera image-change statistics.
- Final fixed camera/time-zero offline frames: `output/scene-{before,after}-{00,20,50,100}.png`. `output/offline-comparison-final.jpg` is the four-view side-by-side review sheet.

Rendering approximations: Blender Cycles, 1120x712, vertical FOV65, 32 samples, source cameras/objects/morphs; water/material/tone mapping differ from Three.js, and particle points/custom surface envelope are omitted or approximated. Small path-tracing pixel differences can extend beyond the edited toe. No real web screenshot, WebGL compile, touch/drag, browser lifecycle, or device performance pass is claimed.

## Rollback

At runtime use `layeredRidges.restore()` (natural rock stays). To remove the page experiment, restore scan-exhibit.js/html from the natural-rock delta and remove the two new layered modules. The original source and existing deployed files were never changed. Nothing in this package deploys or publishes.
