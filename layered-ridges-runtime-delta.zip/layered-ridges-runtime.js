import {installLayeredRidges} from './install-layered-ridges.js';
// Lifecycle wrapper for a LOCAL structure-review candidate, not approved visuals.
export function createLayeredRidgesRuntime({world,ground,configure,surface,invalidate=()=>{},onState=()=>{}}){
 let installation=null,status='idle',error=null,disposed=false,enabled=true;
 const getState=()=>({status,error,installed:!!installation,enabled,disposed,budget:installation?.budget||null,synthetic:true,localStructureCandidate:true});
 const notify=()=>{invalidate();onState(getState());};
 function ensure(){if(disposed)return false;if(installation)return true;status='loading';notify();try{installation=installLayeredRidges({world,ground,configure,surface,enabled});status='ready';error=null;notify();return true;}catch(e){status='error';error=String(e.message||e);notify();return false;}}
 function setEnabled(value){if(disposed)return;enabled=!!value;installation?.setEnabled(enabled);notify();}
 function restore(){if(disposed)return;installation?.dispose();installation=null;status='idle';error=null;notify();}
 function dispose(){if(disposed)return;installation?.dispose();installation=null;disposed=true;status='disposed';notify();}
 return {getState,ensure,setEnabled,restore,dispose,getRoot:()=>installation?.root||null};
}
