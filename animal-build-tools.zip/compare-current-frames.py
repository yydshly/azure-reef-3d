"""Compare freshly captured PNGs with SHA-pinned, locally preserved public product gallery PNGs.
Only aggregate numeric diagnostics are printed; never pixel data or images.
"""
import hashlib, io, json, math, pathlib, signal, sys
from PIL import Image, ImageChops, ImageDraw

def deadline(*_):
    raise TimeoutError('Bounded 60-second numeric comparison deadline')
signal.signal(signal.SIGALRM, deadline)
signal.alarm(60)
HERE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path('dist/preview/coral-midground-candidate')
sha = lambda b: hashlib.sha256(b).hexdigest()

BASELINE = pathlib.Path('.comparison-baseline')

def baseline_bytes(name):
    rel = pathlib.PurePosixPath(name)
    assert len(rel.parts) == 1 and not rel.is_absolute() and name not in ('', '.', '..')
    p = BASELINE / name
    assert BASELINE.is_dir() and not BASELINE.is_symlink() and p.is_file() and not p.is_symlink()
    data = p.read_bytes()
    assert len(data) <= 8 * 1024 * 1024
    return data

def region_stats(diff, region):
    maximum = diff.getchannel('R')
    for channel in diff.split()[1:]:
        maximum = ImageChops.lighter(maximum, channel)
    histogram = maximum.histogram(mask=region)
    total = sum(histogram)
    masked = ImageChops.multiply(maximum, region)
    return {'pixels': total, 'equalPixels': histogram[0],
            'differentPixels': total - histogram[0], 'differenceBBox': masked.getbbox(),
            'maximumChannelDifferenceRGBA': [ImageChops.multiply(c, region).getextrema()[1] for c in diff.split()]}

ANIMAL_BOUNDS = json.loads((HERE / 'animal-projection-bounds.json').read_text())

def compare_images(baseline, candidate, rectangles, frame_id):
    assert baseline.size == candidate.size
    baseline, candidate = baseline.convert('RGBA'), candidate.convert('RGBA')
    diff = ImageChops.difference(baseline, candidate)
    full = Image.new('L', candidate.size, 255)
    hud = Image.new('L', candidate.size, 0)
    painter = ImageDraw.Draw(hud)
    w, h = candidate.size
    for r in rectangles:
        left, top = max(0, math.floor(r['x'])), max(0, math.floor(r['y']))
        right, bottom = min(w, math.ceil(r['x'] + r['width'])), min(h, math.ceil(r['y'] + r['height']))
        if right > left and bottom > top:
            painter.rectangle((left, top, right - 1, bottom - 1), fill=255)
    rock = Image.new('L', candidate.size, 0)
    bounds = ANIMAL_BOUNDS.get(frame_id, [])
    if bounds:
        assert candidate.size == (1120,712)
        for l,t,r,b in bounds:
            ImageDraw.Draw(rock).rectangle((l,t,r-1,b-1),fill=255)
    unaffected = ImageChops.invert(ImageChops.lighter(hud,rock))
    return {'approvedAnimalBounds':bounds, 'animalRegion':region_stats(diff,rock), 'unaffectedSceneRegion':region_stats(diff,unaffected), 'dimensions': list(candidate.size), 'whole': region_stats(diff, full),
            'hudRectangles': rectangles, 'hudBoundsRegion': region_stats(diff, hud),
            'outsideHudBoundsSceneRegion': region_stats(diff, ImageChops.invert(hud)),
            'maskMeaning': 'Union of current visible DOM overlay bounds, including transparent parts; not a pure UI-pixel segmentation. BBoxes are PNG-local, right/bottom exclusive.'}

def assert_pixel_scope(result):
    assert result['unaffectedSceneRegion']['differentPixels']==0, 'Pixels outside approved animal/HUD changed'
    hud=result['hudBoundsRegion']
    assert hud['differentPixels']<=64 and max(hud['maximumChannelDifferenceRGBA'][:3])<=12 and hud['maximumChannelDifferenceRGBA'][3]==0, 'HUD difference exceeds approved scope'

def main():
    baseline = json.loads((HERE / 'comparison-baseline.json').read_text())
    assert baseline_bytes('comparison-baseline.json') == (HERE / 'comparison-baseline.json').read_bytes(), 'Baseline fixture list differs from candidate pin'
    data = baseline_bytes('manifest.original.json')
    assert sha(data) == baseline['manifestSha256'], 'Pinned original baseline manifest changed'
    old = json.loads(data)
    assert old['contentVersion'] == baseline['contentVersion']
    manifests = list((ROOT / 'assets/current-scene').glob('*/manifest.json'))
    assert len(manifests) == 1, 'Expected one fresh current-candidate manifest'
    new_path = manifests[0]
    new = json.loads(new_path.read_text())
    assert len(new['frames']) == len(baseline['frames']) == 5
    reports = []
    for expected, previous, current in zip(baseline['frames'], old['frames'], new['frames']):
        assert expected['id'] == previous['id'] == current['id']
        assert expected['sha256'] == previous['sha256']
        old_bytes = baseline_bytes(expected['file'])
        assert len(old_bytes) == expected['bytes'] and sha(old_bytes) == expected['sha256']
        new_bytes = (new_path.parent / current['file']).read_bytes()
        assert len(new_bytes) == current['bytes'] and sha(new_bytes) == current['sha256']
        numeric = current['numericCapture']
        clip = current['captureClip']
        rects = [{**r, 'x': r['x'] - clip['x'], 'y': r['y'] - clip['y']} for r in numeric['before']['hudRects']]
        with Image.open(io.BytesIO(old_bytes)) as a, Image.open(io.BytesIO(new_bytes)) as b:
            assert list(a.size) == [expected['width'], expected['height']]
            assert list(b.size) == [current['width'], current['height']]
            result = compare_images(a, b, rects, current['id'])
        result.update({'id': current['id'], 'baselineSha256': expected['sha256'], 'candidateSha256': current['sha256'],
                       'encodedBytesEqual': old_bytes == new_bytes, 'baselineCamera': previous['camera'],
                       'baselineTarget': previous['target'], 'baselineState': previous['state'],
                       'candidateCamera': current['camera'], 'candidateTarget': current['target'],
                       'candidateState': current['state'], 'numericCapture': numeric,
                       'baselineProjection': previous.get('numericCapture', {}).get('before', {}).get('projection'), 'baselineProjectionLimitation': 'Recorded projection included when present in pinned baseline; no reconstructed measurements.'})
        assert previous['camera']==current['camera'] and previous['target']==current['target'], 'Camera changed'
        for key in ['route','ambient','waterMode','selectedPatch']:
            if key in previous['state']:assert previous['state'][key]==current['state'][key], 'State changed '+key
        assert previous['numericCapture']['before']['projection']==numeric['before']['projection'], 'Projection changed'
        assert_pixel_scope(result)
        result['visualGate']='Exact scene outside frozen individual animal bounds; inside requires actual visual review'
        reports.append(result)
        print('PNG_NUMERIC_COMPARISON ' + json.dumps(result, separators=(',', ':')), flush=True)
    output = {'completed': True, 'baselineContentVersion': old['contentVersion'], 'candidateContentVersion': new['contentVersion'],
              'allDecodedPixelsEqual': all(r['whole']['differentPixels'] == 0 for r in reports), 'frames': reports,
              'acceptance': 'Numeric comparison only; nonzero differences require review. No automatic visual acceptance.'}
    pathlib.Path('render-evidence').mkdir(exist_ok=True)
    pathlib.Path('render-evidence/png-comparison.json').write_text(json.dumps(output, indent=2) + '\n')
    print('PNG_COMPARISON_COMPLETE ' + json.dumps({'frames': len(reports), 'allDecodedPixelsEqual': output['allDecodedPixelsEqual']}), flush=True)

if __name__ == '__main__':
    main()
