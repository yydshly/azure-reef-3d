import hashlib,json,pathlib,zipfile
here=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
root=pathlib.Path('dist/preview/coral-midground-candidate')
def inv(p):return {f.relative_to(p).as_posix():sha(f.read_bytes()) for f in p.rglob('*') if f.is_file()}
r=json.loads((here/'coral-preservation.json').read_text());expected={f['path']:f['sha256'] for f in r['sourceFiles']}
assert len(expected)==130 and inv(root)==expected,'Current accepted coral source identity mismatch'
zpath=pathlib.Path('.animal-inputs/coral-gallery-20262d13.zip');assert sha(zpath.read_bytes())==r['archive']['sha256']
fixture=pathlib.Path('.comparison-baseline')
for p in fixture.iterdir():assert p.is_file() and not p.is_symlink();p.unlink()
with zipfile.ZipFile(zpath) as z:
 assert len(z.namelist())==len(set(z.namelist()))==7 and set(z.namelist())==set(r['files'])
 for n,f in r['files'].items():
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256']
 raw=z.read(next(n for n in r['files'] if n.endswith('/manifest.json')));m=json.loads(raw)
 assert m['checkoutCommit']=='20262d135dc41406ec16db00a4907a9d3cbca59f'
 (fixture/'manifest.original.json').write_bytes(raw)
 for f in m['frames']:(fixture/f['file']).write_bytes(z.read('assets/current-scene/'+m['contentVersion']+'/'+f['file']))
 pins={'baseMain':m['checkoutCommit'],'contentVersion':m['contentVersion'],'manifestSha256':sha(raw),'frames':[{k:f[k] for k in ['id','file','sha256','bytes','width','height']} for f in m['frames']]}
 assert pins==json.loads((here/'comparison-baseline.json').read_text());(fixture/'comparison-baseline.json').write_bytes((here/'comparison-baseline.json').read_bytes())
d=json.loads((here/'animal-delta-manifest.json').read_text());archive=pathlib.Path('.animal-inputs/animal-scale-cache-delta.zip');assert len(archive.read_bytes())==d['bytes'] and sha(archive.read_bytes())==d['sha256']
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==6 and set(z.namelist())=={f['path'] for f in d['files']}
 for f in d['files']:
  n=f['path'];assert pathlib.PurePosixPath(n).name==n and n not in ('.','..')
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];(root/n).write_bytes(b)
after=inv(root);assert len(after)==130 and all(after[n]==h for n,h in expected.items() if n not in {f['path'] for f in d['files']})
print('ANIMAL_SCALE_STAGED',json.dumps({'sourceFiles':130,'changed':6,'otherSourcesExact':124,'rollbackMain':m['checkoutCommit'],'galleryFilesVerified':7}))
