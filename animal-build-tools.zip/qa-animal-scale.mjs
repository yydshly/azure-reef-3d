// Read-only browser-side helper. Paste/call within existing natural-clock sampling.
// Does not mutate matrices, move the camera, advance/pause time or add interactions.
export function verifyAnimalScaleSnapshot(reef=window.reefExhibit){
 const time=reef.getState().ambient.time,results=[];
 const distance=(a,b)=>Math.hypot(...a.map((v,i)=>v-b[i]));
 const matrixValues=(m,i)=>Array.from(m.instanceMatrix.array.slice(i*16,i*16+16));
 function check(name,a,position,scale,rotation,castShadow){
  const scales=[0,4,8].map(k=>Math.hypot(a[k],a[k+1],a[k+2]));
  const normalized=[0,4,8].flatMap((k,i)=>a.slice(k,k+3).map(v=>v/scales[i]));
  const positionError=distance(a.slice(12,15),position),scaleError=Math.max(...scales.map(s=>Math.abs(s-scale))),orientationError=Math.max(...normalized.map((v,i)=>Math.abs(v-rotation[i])));
  results.push({name,positionError,scaleError,orientationError,castShadow,passed:positionError<1e-5&&scaleError<1e-6&&orientationError<1e-6&&castShadow===false});
 }
 for(const part of ['body','tail']){
  const m=reef.world.group.getObjectByName('World_School_'+part);if(!m||m.count!==12)throw Error('Main fish count/mesh changed');
  for(let i=0;i<12;i++){
   const base=i<6?-34:-65,a=time*.12+i*.27,center=4+4*Math.sin((-base+8)*.055);
   let yaw=-Math.atan2(6*Math.cos(a),-3.5*Math.sin(a));if(part==='tail')yaw+=Math.sin(time*4+i)*.14;
   const c=Math.cos(yaw),s=Math.sin(yaw);
   check(m.name+'_'+i,matrixValues(m,i),[center+3.5*Math.cos(a),4.4+Math.sin(i*2)*.35,base+6*Math.sin(a)],.15+(i%3)*.014,[c,0,-s,0,1,0,s,0,c],m.castShadow);
  }
 }
 const t=reef.turtle.group,q=.35-Math.PI*2*time/180,dx=-1.05*Math.cos(q),dz=4.5*Math.sin(q),l=Math.hypot(dx,dz),fx=dx/l,fz=dz/l;
 let turtleCasts=false;t.traverse(o=>{if(o.isMesh&&o.castShadow)turtleCasts=true;});
 check('Synthetic_Code_Turtle',Array.from(t.matrix.elements),[4.8+1.05*Math.sin(q),2.15,-15.2+4.5*Math.cos(q)],.56,[-fz,0,fx,0,1,0,-fx,0,-fz],turtleCasts);
 return {time,passed:results.every(r=>r.passed),maxPositionError:Math.max(...results.map(r=>r.positionError)),maxScaleError:Math.max(...results.map(r=>r.scaleError)),maxOrientationError:Math.max(...results.map(r=>r.orientationError)),objects:results};
}
