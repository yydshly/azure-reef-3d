import * as T from 'three';
import {mergeGeometries} from './utils/BufferGeometryUtils.js';
import {VISIBLE_HABITAT} from './visible-habitat-placement.js';
// Original synthetic growth-form studies, not measured habitat or species models.
// NOAA Coral Species Framework pp. 3–4 informs curved cylindrical branching and
// joined uneven colony relief. Placement transforms and source scans are unchanged.
export function installVisibleHabitat({world,parent,configure=()=>{}}){
 const root=new T.Group();root.name='Synthetic_Visible_Slope_Habitat';parent.add(root);
 const meshes=[],geos=[],mats=[];
 function geometry(type){const parts=[];
  function tube(a,b,r0,r1,seed){
   const av=new T.Vector3(...a),bv=new T.Vector3(...b),d=bv.clone().sub(av),len=d.length(),axis=d.clone().normalize();
   const side=new T.Vector3(Math.sin(seed),.15,Math.cos(seed)).cross(axis).normalize(),other=axis.clone().cross(side).normalize();
   const pos=[],idx=[],rings=[0,.34,.69,.94,1],sides=6;
   rings.forEach((t,j)=>{const center=av.clone().addScaledVector(d,t).addScaledVector(side,Math.sin(Math.PI*t)*len*.075).addScaledVector(other,Math.sin(Math.PI*t)*len*.025);let radius=(r0*(1-t)+r1*t)*(j===4?.62:1);for(let k=0;k<sides;k++){const angle=k*2*Math.PI/sides,ir=radius*(1+.045*Math.sin(k*2.4+j*1.7+seed));const v=center.clone().addScaledVector(side,Math.cos(angle)*ir).addScaledVector(other,Math.sin(angle)*ir);pos.push(...v.toArray());}});
   for(let j=0;j<rings.length-1;j++)for(let k=0;k<sides;k++){const a=j*sides+k,b=j*sides+(k+1)%sides,c=a+sides,d=b+sides;idx.push(a,b,c,b,d,c);}
   const end=pos.length/3;pos.push(...bv.clone().addScaledVector(axis,r1*.42).toArray());for(let k=0;k<sides;k++)idx.push(24+k,24+(k+1)%sides,end);
   const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setIndex(idx);g.computeVertexNormals();parts.push(g);
  }
  if(type===0){
   // A single attached skin, rather than seven intersecting equal-size pebbles.
   const pos=[0,.285,0],idx=[],n=24,rings=8;
   for(let j=1;j<=rings;j++)for(let k=0;k<n;k++){
    const a=k*2*Math.PI/n,r=j/rings,edge=.62+.035*Math.sin(3*a+.7)+.025*Math.sin(5*a-1.1),x=Math.cos(a)*r*edge,z=Math.sin(a)*r*edge;
    const lobes=.047*Math.sin(13*x+2*Math.sin(4*z))+.034*Math.cos(15*z-3*x)+.018*Math.sin(24*x+15*z);
    const y=.065+.22*Math.pow(Math.max(0,1-r*r),.65)+lobes*Math.sin(Math.PI*r)+.012*Math.sin(a*5)*r;
    pos.push(x,y,z);
   }
   for(let k=0;k<n;k++)idx.push(0,1+(k+1)%n,1+k);
   for(let j=0;j<rings-1;j++)for(let k=0;k<n;k++){const a=1+j*n+k,b=1+j*n+(k+1)%n,c=a+n,d=b+n;idx.push(a,b,c,b,d,c);}
   const base=pos.length/3;pos.push(0,-.065,0);for(let k=0;k<n;k++)idx.push(base,1+(rings-1)*n+k,1+(rings-1)*n+(k+1)%n);
   // Bounded shared-prototype contact correction; all placement transforms retained.
   pos.splice(0,pos.length,...[0.0,0.284999996,0.0,0.077533431,0.3172324,0.0,0.079696052,0.319415897,0.021354493,0.072717406,0.317441523,0.041983414,0.055748411,0.314117283,0.055748411,0.036030728,0.311726987,0.06240705,0.018328967,0.309974581,0.068404637,0.0,0.306096524,0.075571306,-0.020753104,0.297810495,0.077451639,-0.040241692,0.287620723,0.069700651,-0.055781838,0.280353874,0.055781838,-0.068539873,0.276809156,0.039571512,-0.077238493,0.275090188,0.02069599,-0.07746657,0.273614019,0.0,-0.070022449,0.272228241,-0.018762458,-0.061516531,0.27211538,-0.035516586,-0.053853143,0.27201429,-0.053853143,-0.041469272,0.269479573,-0.07182689,-0.021787984,0.266512364,-0.081313863,-0.0,0.269158781,-0.079428695,0.019363848,0.278151363,-0.072266862,0.037258308,0.2892147,-0.064533286,0.053819712,0.299235672,-0.053819712,0.065694064,0.306639403,-0.037928484,0.072480015,0.312249392,-0.019420961,0.127930164,0.297637463,0.0,0.139468089,0.29709214,0.037370361,0.141798943,0.296886474,0.081867658,0.111496821,0.292005688,0.111496821,0.072061457,0.297175229,0.124814101,0.034825034,0.298156738,0.129968807,0.0,0.303459197,0.151142612,-0.041506208,0.289963573,0.154903278,-0.080483384,0.259192079,0.139401302,-0.111563675,0.234508604,0.111563675,-0.137079746,0.235368401,0.079143025,-0.154476985,0.256358474,0.04139198,-0.15493314,0.274372935,0.0,-0.140044898,0.277481258,-0.037524916,-0.123033062,0.275059938,-0.071033172,-0.107706286,0.269625127,-0.107706286,-0.082938544,0.253853858,-0.14365378,-0.043575969,0.230774879,-0.162627727,-0.0,0.215941012,-0.15885739,0.038727697,0.228945345,-0.144533724,0.074516617,0.262720585,-0.129066572,0.107639425,0.297734797,-0.107639425,0.131388128,0.316658586,-0.075856969,0.126840025,0.30551827,-0.03398668,0.232600287,0.282810897,0.0,0.239088163,0.286110848,0.064063482,0.218152225,0.262751251,0.125950247,0.167245224,0.24014625,0.167245224,0.108092181,0.238672316,0.187221155,0.054986902,0.254768848,0.205213904,0.0,0.277659237,0.226713911,-0.062259313,0.284556448,0.232354909,-0.120725073,0.231289119,0.20910196,-0.167345509,0.178510755,0.167345509,-0.205619618,0.201050386,0.118714541,-0.231715471,0.258271784,0.062087972,-0.232399717,0.294012219,0.0,-0.210067347,0.298697114,-0.056287374,-0.175322101,0.280966848,-0.101222269,-0.153481454,0.259351134,-0.153481454,-0.124407813,0.238911256,-0.215480655,-0.065363958,0.222084776,-0.243941605,-0.0,0.194972903,-0.238286093,0.058091544,0.186876535,-0.2168006,0.111774921,0.235710204,-0.19359985,0.161459133,0.287397176,-0.161459133,0.197082192,0.286343038,-0.113785461,0.217440039,0.27633357,-0.058262885,0.310133725,0.247770205,0.0,0.318784207,0.247253284,0.085417971,0.290869623,0.201852709,0.167933658,0.222993642,0.17937541,0.222993642,0.144122913,0.204219908,0.249628201,0.073315866,0.235440627,0.273618549,0.0,0.274643004,0.302285224,-0.083012417,0.297767431,0.309806556,-0.160966769,0.232577369,0.278802603,-0.22312735,0.159339055,0.22312735,-0.274159491,0.199858144,0.15828605,-0.308953971,0.246581003,0.08278396,-0.302119642,0.285338998,0.0,-0.23107408,0.279100507,-0.061916109,-0.221459508,0.266839862,-0.127859712,-0.215412572,0.250877231,-0.215412572,-0.165877089,0.244711459,-0.28730756,-0.082794338,0.225605562,-0.308992684,-0.0,0.213585526,-0.278000444,0.065837085,0.19464463,-0.245707333,0.145307407,0.243308917,-0.251679808,0.177605048,0.271108478,-0.177605048,0.243068039,0.229225188,-0.140335396,0.289920062,0.21723862,-0.077683844,0.387667149,0.197783679,0.0,0.398480266,0.23237969,0.106772467,0.363587022,0.199941635,0.209917068,0.278742045,0.138857931,0.278742045,0.180153638,0.169079304,0.312035263,0.091644838,0.244871929,0.342023194,0.0,0.287538379,0.377856523,-0.103765517,0.280748576,0.387258202,-0.201208457,0.226485208,0.348503262,-0.278909206,0.176864415,0.278909206,-0.334131867,0.216377303,0.192911133,-0.386192441,0.224853873,0.103479952,-0.329232931,0.263073206,0.0,-0.315100998,0.279445827,-0.08443106,-0.215307847,0.239782438,-0.12430805,-0.262534082,0.248630792,-0.262534082,-0.207346365,0.289397746,-0.359134436,-0.084428437,0.23702462,-0.315091223,-0.0,0.205210507,-0.26807186,0.067773469,0.210531831,-0.252934009,0.14437595,0.248632655,-0.250066459,0.242188692,0.277874917,-0.242188692,0.32847032,0.191307396,-0.189642429,0.344280034,0.174153447,-0.092249565,0.465200573,0.177433342,0.0,0.442313105,0.254015148,0.118517444,0.43630445,0.22118786,0.251900494,0.334490448,0.177957922,0.334490448,0.199970543,0.149524957,0.346359134,0.109973803,0.215659842,0.410427809,0.0,0.26071468,0.453427821,-0.124518625,0.207909495,0.464709818,-0.241450146,0.17945078,0.41820392,-0.334691018,0.1864454,0.334691018,-0.328991383,0.212297335,0.189943269,-0.463430941,0.207368508,0.124175943,-0.464799434,0.218256429,0.0,-0.346611112,0.209945366,-0.092874169,-0.36909917,0.182671607,-0.213099509,-0.298884958,0.18715246,-0.298884958,-0.205272883,0.241547301,-0.355543077,-0.081704944,0.217978567,-0.304926991,-0.0,0.161984578,-0.428914964,0.066805273,0.197783187,-0.249320686,0.139718652,0.224775016,-0.241999805,0.226042777,0.231738448,-0.226042777,0.335039735,0.173195526,-0.193435282,0.33703205,0.148337722,-0.090307467,0.515597343,0.166758433,0.0,0.557872415,0.187882721,0.14948146,0.432668597,0.158243254,0.249801308,0.312191099,0.165101051,0.312191099,0.201772079,0.148307189,0.349479496,0.112264924,0.157149911,0.418978393,0.0,0.184802055,0.52899915,-0.138008147,0.136612847,0.515053391,-0.281691849,0.123772018,0.487904578,-0.390472859,0.154147223,0.390472859,-0.479779094,0.177266672,0.277000606,-0.540669441,0.163411751,0.144871935,-0.542266011,0.134492487,0.0,-0.441141397,0.135691956,-0.118203484,-0.344492584,0.128869489,-0.198892877,-0.282729,0.152115196,-0.282729,-0.217713684,0.180240989,-0.37709114,-0.122012712,0.161123365,-0.455357641,-0.0,0.134017751,-0.389200628,0.060996119,0.17284736,-0.227640629,0.123883888,0.184302017,-0.21457319,0.207205892,0.180159509,-0.207205892,0.321900904,0.156506121,-0.185849592,0.329784065,0.139468074,-0.088365369,0.465200603,0.096249998,0.0,0.494115502,0.102108113,0.132397845,0.334500074,0.121575005,0.193123698,0.234143317,0.119920224,0.234143317,0.158535212,0.115534231,0.274591029,0.087979041,0.116863497,0.328342259,0.0,0.119374998,0.377856523,-0.112066768,0.107721433,0.418238848,-0.257546842,0.081686154,0.446084172,-0.390472859,0.073200375,0.390472859,-0.520903051,0.076950006,0.30074349,-0.525221765,0.093602434,0.140732735,-0.464799404,0.096249998,0.0,-0.406130224,0.09097144,-0.108822264,-0.442919016,0.072099999,-0.255719423,-0.366201371,0.090962484,-0.366201371,-0.199052513,0.121235386,-0.34476909,-0.104582332,0.1131365,-0.390306562,-0.0,0.114649996,-0.349486262,0.089073703,0.116339147,-0.332427561,0.186291546,0.11837019,-0.322666436,0.193750963,0.137568384,-0.193750963,0.289053887,0.117949992,-0.166885331,0.434880078,0.087556668,-0.116525769,0.0,-0.007624991,0.0]);
   const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setIndex(idx);g.computeVertexNormals();parts.push(g);
  }else{
   const tall=type===2;tube([0,-.04,0],[.025,.47,.015],.103,.076,1);
   for(let k=0;k<5;k++){
    const a=k*2.399+.3,h=.24+(k%3)*.072,spread=tall?.42:.45;
    const fork=[Math.cos(a)*spread,.65+(k%3)*.10,Math.sin(a)*spread];
    tube([.015,h,0],fork,.079,.046,k+2);
    const n=k%2===0?2:1;
    for(let j=0;j<n;j++){const b=a+(j?-.64:.45),tip=[fork[0]+Math.cos(b)*.205,fork[1]+(tall?.34:.22),fork[2]+Math.sin(b)*.205];tube(fork,tip,.047,.027,k*3+j+7);}
   }
  }
  const g=mergeGeometries(parts);parts.forEach(p=>p.dispose());g.computeBoundingBox();geos.push(g);return g;
 }
 const prototypes=[0,1,2].map(geometry),mat=new T.MeshStandardMaterial({color:'#ffffff',roughness:1});configure(mat);
 // Fine monochrome normal relief; no new textures, pigment patches, or animation.
 const priorCompile=mat.onBeforeCompile,priorKey=mat.customProgramCacheKey.bind(mat);
 mat.onBeforeCompile=function(shader,...args){priorCompile.call(this,shader,...args);
  shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vColonyLocal;').replace('#include <begin_vertex>','#include <begin_vertex>\nvColonyLocal=position;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nvarying vec3 vColonyLocal;').replace('#include <normal_fragment_begin>',`#include <normal_fragment_begin>
   float colonyRelief = .0013*(sin(vColonyLocal.x*93.0+sin(vColonyLocal.z*53.0))*sin(vColonyLocal.y*87.0+vColonyLocal.z*71.0)) + .00065*sin(dot(vColonyLocal,vec3(147.0,131.0,113.0)));
   vec3 colonyQ0=dFdx(-vViewPosition),colonyQ1=dFdy(-vViewPosition);
   vec3 colonyR0=cross(colonyQ1,normal),colonyR1=cross(normal,colonyQ0);
   float colonyDet=dot(colonyQ0,colonyR0);
   vec3 colonyGrad=sign(colonyDet)*(dFdx(colonyRelief)*colonyR0+dFdy(colonyRelief)*colonyR1);
   normal=normalize(abs(colonyDet)*normal-colonyGrad);
  `);
 };
 mat.customProgramCacheKey=()=>priorKey()+'|colony-form-relief-v1';mats.push(mat);
 const dummy=new T.Object3D();let triangles=0;
 for(let t=0;t<3;t++)for(let region=0;region<2;region++){const items=VISIBLE_HABITAT.items.filter(p=>p.type===t&&p.field===!!region);if(!items.length)continue;const m=new T.InstancedMesh(prototypes[t],mat,items.length);m.name=`Visible_Habitat_${['Attached_Lobes','Branch_Thicket','Crown_Branches'][t]}_${region?'Field':'Stable'}`;m.userData.fieldReplaced=!!region;m.receiveShadow=true;m.castShadow=true;
 items.forEach((p,i)=>{dummy.position.fromArray(p.p);dummy.quaternion.fromArray(p.q);dummy.scale.fromArray(p.s);dummy.updateMatrix();m.setMatrixAt(i,dummy.matrix);m.setColorAt(i,new T.Color(p.color));});m.computeBoundingSphere();root.add(m);meshes.push(m);triangles+=(prototypes[t].index.count/3)*items.length;}
 if(triangles>250000||meshes.length>8)throw Error('Visible habitat budget exceeded');
 root.userData={synthetic:true,measuredHabitat:false,metricCalibration:false,triangles,drawCalls:meshes.length,newTextures:0,selection:VISIBLE_HABITAT.meta};world.budget.triangles+=triangles;world.budget.drawCalls+=meshes.length;
 let disposed=false;const api={root,meshes,triangles,setFieldEnabled(v){if(disposed)return;for(const m of meshes)if(m.userData.fieldReplaced)m.visible=!v;},dispose(){if(disposed)return;disposed=true;root.removeFromParent();meshes.forEach(m=>m.dispose());geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());world.budget.triangles-=triangles;world.budget.drawCalls-=meshes.length;if(world.visibleHabitat===api)delete world.visibleHabitat;},getState:()=>({disposed,triangles,drawCalls:meshes.length})};world.visibleHabitat=api;return api;
}
