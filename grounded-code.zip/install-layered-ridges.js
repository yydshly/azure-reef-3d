import {installGroundedShoulder} from './grounded-shoulder.js';
import {installRearHabitat} from './rear-habitat.js';
import {installVisibleHabitat} from './visible-habitat.js';
import * as THREE from 'three';
import {mergeGeometries} from './utils/BufferGeometryUtils.js';
// Candidate additive fictional terrain. Install AFTER C4/A and original ecology.
// Owns all new geometry/materials; never modifies or disposes baseline resources.
export const RIDGE_PLAN=Object.freeze([
 {id:'near_left_shoulder',x:-17,z:-24,sx:12,sz:11,height:6.1,yaw:-.32,color:'#748775',seed:1},
 {id:'middle_right_saddle',x:22,z:-50,sx:12.5,sz:15,height:8.1,yaw:.55,color:'#687f75',seed:3},
 {id:'far_left_crown',x:-9,z:-86,sx:12,sz:14,height:9.1,yaw:-.5,color:'#5c7876',seed:7}
]);
const smooth=(a,b,x)=>{let t=THREE.MathUtils.clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);};
export function installLayeredRidges({world,ground,configure=()=>{},surface={limestone:m=>m},enabled=true}) {
 if(world.group.getObjectByName('Candidate_Layered_Reef_Shoulders'))throw Error('Ridges already installed');
 if(!world.group.getObjectByName('Synthetic_C4_A_Reassemblage'))throw Error('Install after C4/A original assembly');
 const root=new THREE.Group();root.name='Candidate_Layered_Reef_Shoulders';root.visible=enabled;
 const meshes=[],ownedGeometries=[],ownedMaterials=[],contacts=[],ridgeRecords=[],obstacles=[];
 const down=new THREE.Vector3(0,-1,0),ray=new THREE.Raycaster(),dummy=new THREE.Object3D();ground.updateMatrixWorld(true);
 let seed=487129;const rnd=()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296;};
 const sandCache=new Map();function sand(x,z){const key=x.toFixed(5)+","+z.toFixed(5);if(sandCache.has(key))return sandCache.get(key);ray.set(new THREE.Vector3(x,30,z),down);const hit=ray.intersectObject(ground,false)[0];if(!hit)throw Error('Ridge outside sand');sandCache.set(key,hit.point.y);return hit.point.y;}
 function terrain(spec) {
  const positions=[],colors=[],indices=[],co=new THREE.Color(spec.color),c=Math.cos(spec.yaw),s=Math.sin(spec.yaw);
  // Each shoulder is an interlocking, unequal fracture assemblage. No radial
  // mound heightfield, closed contour terraces, repeated dome, or single summit.
  const blocks=[
   [-.15,-.30,.48,.43,.96,-.23],[-.49,-.02,.39,.39,.72,.42],
   [.28,-.20,.36,.38,.77,.61],[.06,.36,.43,.34,.49,-.58],
   [-.48,.39,.35,.28,.37,.22],[.53,.16,.28,.34,.34,-.51],
   [-.56,-.49,.28,.30,.52,-.33],[.37,-.59,.31,.27,.54,.28],
   [.22,.64,.30,.21,.22,.68]
  ];
  const toWorld=(u,v)=>[spec.x+u*spec.sx*c-v*spec.sz*s,spec.z+u*spec.sx*s+v*spec.sz*c];
  for(let blockIndex=0;blockIndex<blocks.length;blockIndex++){
   const [cx,cz,rx,rz,height,yaw]=blocks[blockIndex],N=18,offset=positions.length/3;
   // Staggered fracture bands, slanting irregular roofs, undercut ledges. The
   // gaps between crossing blocks become the readable diagonal gullies.
   const levels=[[0,1.03],[.18,1.06],[.53,.97],[.78,.84],[.95,.52]];
   const thetaOffset=spec.seed*.37+blockIndex*.41;
   for(let j=0;j<levels.length;j++)for(let k=0;k<N;k++){
    const angle=2*Math.PI*k/N,polygon=1+.14*Math.sin(3*angle+thetaOffset)+.075*Math.cos(5*angle-thetaOffset);
    const cut=1-.20*Math.pow(Math.max(0,Math.cos(angle-.6-blockIndex*.7)),6);
    const width=levels[j][1]*polygon*cut;
    const u0=Math.cos(angle)*rx*width,v0=Math.sin(angle)*rz*width;
    const leanX=(j/4)*.045*Math.sin(blockIndex*2+spec.seed),leanZ=(j/4)*.06*Math.cos(blockIndex+spec.seed);
    const u=cx+u0*Math.cos(yaw)-v0*Math.sin(yaw)+leanX,v=cz+u0*Math.sin(yaw)+v0*Math.cos(yaw)+leanZ;
    const [x,z]=toWorld(u,v),bottom=sand(x,z)-.18;
    const tilt=.08*Math.sin(angle+thetaOffset)+.055*Math.sin(angle*3+blockIndex);
    const y=bottom+height*spec.height*(levels[j][0]+tilt*(j/4));
    positions.push(x,y,z);const shade=.84+.12*(j/4)+.045*Math.sin(blockIndex*2+angle);colors.push(co.r*shade,co.g*shade,co.b*shade);
   }
   for(let j=0;j<levels.length-1;j++)for(let k=0;k<N;k++){let a=offset+j*N+k,b=offset+j*N+(k+1)%N,d=offset+(j+1)*N+k,e=offset+(j+1)*N+(k+1)%N;indices.push(a,d,b,b,d,e);}
   const [mx,mz]=toWorld(cx+.03,cz-.045),roof=positions.length/3;positions.push(mx,sand(mx,mz)-.18+height*spec.height*.91,mz);colors.push(co.r*.94,co.g*.94,co.b*.94);
   for(let k=0;k<N;k++)indices.push(roof,offset+4*N+(k+1)%N,offset+4*N+k);
   const base=positions.length/3;positions.push(mx,-2.2,mz);colors.push(co.r*.7,co.g*.7,co.b*.7);for(let k=0;k<N;k++)indices.push(base,offset+k,offset+(k+1)%N);
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.setIndex(indices);g.computeVertexNormals();g.computeBoundingBox();return g;
 }
 const geos=RIDGE_PLAN.map(terrain),ridgeGeometry=mergeGeometries(geos);geos.forEach(g=>g.dispose());
 function material(color,vertexColors=false,rock=false){let m=new THREE.MeshStandardMaterial({color,vertexColors,roughness:1});if(rock)m=surface.limestone(m);configure(m);ownedMaterials.push(m);return m;}
 function mesh(name,g,m,items){ownedGeometries.push(g);let o;if(items){o=new THREE.InstancedMesh(g,m,items.length);items.forEach((p,i)=>{dummy.position.fromArray(p.p);dummy.rotation.set(0,p.yaw||0,0);dummy.scale.fromArray(p.s);dummy.updateMatrix();o.setMatrixAt(i,dummy.matrix);o.setColorAt(i,new THREE.Color(p.color||'#ffffff'));});o.computeBoundingSphere();}else o=new THREE.Mesh(g,m);o.name=name;o.receiveShadow=true;o.castShadow=false;root.add(o);meshes.push(o);return o;}
 const ridge=mesh('Layered_Ridges_Weathered_Shoulders',ridgeGeometry,material('#ffffff',true,true));root.updateMatrixWorld(true);
 for(const p of RIDGE_PLAN){const g=terrain(p),box=g.boundingBox.clone();g.dispose();obstacles.push({name:'Ridge_'+p.id,box});ridgeRecords.push({...p,bounds:{min:box.min.toArray(),max:box.max.toArray()}});}
 // Plant only on new actual triangles: no global ground-height override.
 const colonies={branch:[],mound:[],fan:[],plate:[],rubble:[]};
 const palette={branch:['#91886c','#8d9680','#a3987b'],mound:['#718c77','#829276','#8c8079'],fan:['#9d8675','#827c8c','#849387'],plate:['#8d9279','#a1947c'],rubble:['#788774','#6c8073']};
 for(const p of RIDGE_PLAN){
  // Wide, low connected living patches over visible shoulders, not a line on top.
  const patches=p.id==='middle_right_saddle'?[[-.44,.26],[-.31,-.12],[.12,.48],[-.15,-.50],[.30,.07]]:[[.39,.21],[.10,.48],[.24,-.28],[-.27,.25],[-.1,-.45]];
  let accepted=0;
  for(let i=0;i<2200&&accepted<148;i++){
   const center=patches[Math.floor(rnd()*patches.length)],u=center[0]+(rnd()+rnd()-1)*.32,v=center[1]+(rnd()+rnd()-1)*.30;
   const x=p.x+u*p.sx*Math.cos(p.yaw)-v*p.sz*Math.sin(p.yaw),z=p.z+u*p.sx*Math.sin(p.yaw)+v*p.sz*Math.cos(p.yaw);
   ray.set(new THREE.Vector3(x,25,z),down);const hit=ray.intersectObject(ridge,false)[0];if(!hit||hit.face.normal.y<.42||hit.point.y<sand(x,z)+.32)continue;
   const slot=accepted%20,type=slot<3?'branch':slot<15?'mound':slot<18?'plate':slot===18?'fan':'rubble';
   const scale=type==='mound'?.72+rnd()*.77:type==='branch'?.6+rnd()*.42:.55+rnd()*.55,sy=type==='fan'?.78+rnd()*.65:scale;
   const colors=palette[type],item={p:[x,hit.point.y-.055,z],s:[scale,sy,scale],yaw:rnd()*Math.PI*2,color:colors[Math.floor(rnd()*colors.length)]};
   colonies[type].push(item);contacts.push({ridge:p.id,type,point:hit.point.toArray(),base:item.p,normal:hit.face.normal.toArray(),embed:.055});accepted++;
  }
 }
 function branchGeometry(fan=false){const gs=[];function rod(a,b,r1,r2){const av=new THREE.Vector3(...a),bv=new THREE.Vector3(...b),dir=bv.clone().sub(av),g=new THREE.CylinderGeometry(r2,r1,dir.length(),5,1);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),dir.normalize()));g.translate(...av.add(bv).multiplyScalar(.5).toArray());gs.push(g);}
  if(fan){rod([0,0,0],[0,.72,0],.036,.023);for(let k=0;k<9;k++){const angle=-1.13+k*.2825,end=[Math.sin(angle)*.85,.72+Math.cos(angle)*.95,Math.sin(k*2)*.03];rod([0,.24,0],end,.019,.006);for(let j=1;j<=3;j++){const t=.28+j*.17,base=end.map((n,i)=>i===1?.24+(n-.24)*t:n*t);rod(base,[base[0]+.14*(k<4?-1:1),base[1]+.18,0],.012,.004);}}}
  else {rod([0,0,0],[0,.66,0],.082,.048);for(let k=0;k<7;k++){const a=k*2.399,r=.25+(k%3)*.08,base=[0,.24+(k%3)*.13,0],tip=[Math.cos(a)*r,.80+(k%3)*.15,Math.sin(a)*r];rod(base,tip,.045,.018);for(let j=0;j<2;j++){const b=a+(j?-.65:.65);rod(tip,[tip[0]+Math.cos(b)*.19,tip[1]+.25,tip[2]+Math.sin(b)*.19],.018,.008);}}}
  const g=mergeGeometries(gs);gs.forEach(g=>g.dispose());return g;
 }
 function moundGeometry(){const gs=[];for(let i=0;i<9;i++){let g=new THREE.IcosahedronGeometry(1,0);const a=i*2.399,r=i===0?0:.18+(i%3)*.13;g.scale(.26+(i%3)*.05,.25+(i%2)*.11,.28);g.translate(Math.cos(a)*r,.22+(i===0?.2:0),Math.sin(a)*r);gs.push(g);}const g=mergeGeometries(gs);gs.forEach(g=>g.dispose());return g;}
 mesh('Ridge_Ecology_Branch_Thickets',branchGeometry(),material('#ffffff'),colonies.branch);
 mesh('Ridge_Ecology_Low_Colonies',moundGeometry(),material('#ffffff'),colonies.mound);
 mesh('Ridge_Ecology_Sea_Fans',branchGeometry(true),material('#ffffff'),colonies.fan);
 const plate=new THREE.SphereGeometry(1,9,5);plate.scale(.63,.105,.51);plate.translate(0,.075,0);mesh('Ridge_Ecology_Tiered_Plates',plate,material('#ffffff'),colonies.plate);
 const rubble=new THREE.IcosahedronGeometry(1,1);rubble.scale(.36,.22,.29);rubble.translate(0,.15,0);mesh('Ridge_Ecology_Buried_Rubble',rubble,material('#ffffff',false,true),colonies.rubble);
 // One authorized localized collision repair. Keep ecology deterministic and
 // unchanged: patch AFTER its placement, and never move a baseline grass blade.
 const footIndices=[1201,1202,1219,1220,1237],footPosition=ridgeGeometry.attributes.position;
 const footOriginal=footIndices.map(i=>new THREE.Vector3().fromBufferAttribute(footPosition,i));
 const footExpected=[[9.7393398,-1.2661783,-45.0436897],[9.5125313,-1.1842031,-46.970253],[9.4117298,-.7746565,-44.8821373],[9.1783161,-.7289787,-46.8648148],[9.5603685,.2273923,-45.0823517]];
 if(footOriginal.some((v,i)=>v.distanceTo(new THREE.Vector3(...footExpected[i]))>.0001))throw Error('Foot repair vertex identity mismatch');
 let footRepairEnabled=false;
 function setFootRepair(value){footRepairEnabled=!!value;footIndices.forEach((index,i)=>{const v=footOriginal[i];footPosition.setXYZ(index,value?Math.max(v.x,10.58):v.x,v.y,v.z);});footPosition.needsUpdate=true;ridgeGeometry.computeVertexNormals();ridgeGeometry.computeBoundingBox();ridgeGeometry.computeBoundingSphere();if(root.userData.footRepair)root.userData.footRepair.enabled=footRepairEnabled;}
 setFootRepair(true);
 const triangles=meshes.reduce((n,m)=>n+(m.geometry.index?.count||m.geometry.attributes.position.count)/3*(m.isInstancedMesh?m.count:1),0),drawCalls=meshes.length;
 if(triangles>110000||drawCalls>8)throw Error('Candidate exceeds budget');
 world.group.add(root);if(enabled)world.obstacles.push(...obstacles);world.budget.triangles+=triangles;world.budget.drawCalls+=drawCalls;
 root.userData={footRepair:{enabled:true,axis:"positive X only",floorX:10.58,vertexIndices:footIndices,originalPositions:footOriginal.map(v=>v.toArray()),maximumShift:Math.max(...footOriginal.map(v=>10.58-v.x)),reason:"Clear three immutable original grass clumps",ecologyChanged:false},synthetic:true,candidate:true,metricCalibration:false,newTextureBytes:0,triangles,drawCalls,ridgeRecords,contacts,colonyCounts:Object.fromEntries(Object.entries(colonies).map(([k,v])=>[k,v.length]))};
 const visibleHabitat=installVisibleHabitat({world,parent:root,configure});
 const rearHabitat=installRearHabitat({world,ground,parent:root,stoneMaterial:ridge.material});
 const groundedShoulder=installGroundedShoulder({world,parent:root,surface,configure});groundedShoulder.setEnabled(enabled);
 let disposed=false;return {root,meshes,obstacles,setFootRepair,budget:{triangles,drawCalls,newTextureBytes:0},setEnabled(value){if(disposed)return;root.visible=!!value;groundedShoulder.setEnabled(value);rearHabitat.setEnabled(value);for(const o of obstacles){const i=world.obstacles.indexOf(o);if(value&&i<0)world.obstacles.push(o);else if(!value&&i>=0)world.obstacles.splice(i,1);}},dispose(){if(disposed)return;disposed=true;groundedShoulder.dispose();rearHabitat.dispose();visibleHabitat.dispose();root.removeFromParent();for(const o of obstacles){const i=world.obstacles.indexOf(o);if(i>=0)world.obstacles.splice(i,1);}world.budget.triangles-=triangles;world.budget.drawCalls-=drawCalls;ownedGeometries.forEach(g=>g.dispose());ownedMaterials.forEach(m=>m.dispose());}};
}
