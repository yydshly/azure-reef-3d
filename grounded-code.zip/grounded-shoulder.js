import * as T from 'three';
import {GROUNDED_LOCAL_DATA as DATA} from './grounded-shoulder-data.js';
// One localized ART composition from CC0 terrestrial scan geometry, not a reef survey.
// Original source geometry/materials/matrices remain untouched. Retained copies and
// clipped fragments are owned here; no source texture is imported with the sample.
export function installGroundedShoulder({world,parent,surface={limestone:m=>m},configure=()=>{}}){
 if(world.group.getObjectByName('Local_Grounded_Scan_Derived_Shoulder'))throw Error('Local shoulder already installed');
 const root=new T.Group();root.name='Local_Grounded_Scan_Derived_Shoulder';
 const geometries=[],materials=[],instances=[],swaps=[],placed=[],obstacles=[];
 let netTriangles=0,netDraws=0,enabled=true,disposed=false;
 const triangleCount=m=>(m.geometry.index?.count||m.geometry.attributes.position.count)/3*(m.isInstancedMesh?m.count:1);
 function geometry(d){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(d.vertices.flat(),3));g.setIndex(d.triangles.flat());if(d.normals)g.setAttribute('normal',new T.Float32BufferAttribute(d.normals.flat(),3));else g.computeVertexNormals();g.computeBoundingBox();g.computeBoundingSphere();geometries.push(g);return g;}
 function register(o,p){p.add(o);placed.push(o);netTriangles+=triangleCount(o);netDraws++;return o;}
 try{
  const material=surface.limestone(new T.MeshStandardMaterial({color:'#748775',roughness:1,metalness:0}));configure(material);materials.push(material);
  for(const [name,d]of Object.entries(DATA.sample)){const o=new T.Mesh(geometry(d),material);o.name='Grounded_Shoulder_'+name;o.castShadow=false;o.receiveShadow=true;register(o,root);}
  for(const patch of DATA.banks){
   const original=world.group.getObjectByName(patch.name);if(!original?.isInstancedMesh)throw Error('Missing original local bank '+patch.name);
   if(original.count!==patch.originalCount)throw Error('Original count mismatch '+patch.name);
   const excluded=new Set(patch.remove),moved=new Map(patch.move.map(r=>[r.index,r]));
   for(const r of patch.identities){const m=new T.Matrix4();original.getMatrixAt(r.index,m);if(m.elements.some((v,i)=>Math.abs(v-r.matrix[i])>1e-6))throw Error('Original matrix mismatch '+patch.name+'_'+r.index);}
   const copy=new T.InstancedMesh(original.geometry,original.material,original.count-excluded.size);instances.push(copy);copy.name='Grounded_Retained_'+patch.name;copy.matrix.copy(original.matrix);copy.matrixAutoUpdate=false;copy.castShadow=original.castShadow;copy.receiveShadow=original.receiveShadow;
   const matrix=new T.Matrix4(),color=new T.Color();let j=0;for(let i=0;i<original.count;i++){if(excluded.has(i))continue;original.getMatrixAt(i,matrix);if(moved.has(i)){const move=moved.get(i);if(move.matrix)matrix.fromArray(move.matrix);else matrix.elements[13]+=move.dy;}copy.setMatrixAt(j,matrix);if(original.instanceColor){original.getColorAt(i,color);copy.setColorAt(j,color);}j++;}
   copy.computeBoundingSphere();copy.userData.originalIndices=Array.from({length:original.count},(_,i)=>i).filter(i=>!excluded.has(i));
   swaps.push({original,visible:original.visible});netTriangles-=triangleCount(original);netDraws--;register(copy,original.parent);
  }
  for(const patch of DATA.substrates){
   const original=world.group.getObjectByName(patch.bank);if(!original?.isMesh)throw Error('Missing local substrate '+patch.bank);
   const o=new T.Mesh(geometry(patch),original.material);o.name='Grounded_Clipped_'+patch.name;o.castShadow=original.castShadow;o.receiveShadow=original.receiveShadow;
   if(patch.color){o.material=original.material; // The replacement material remains borrowed; instance tint is stored as vertex color only when needed below.
    const base=original.material.clone();base.color.multiply(new T.Color().fromArray(patch.color));base.onBeforeCompile=original.material.onBeforeCompile;base.customProgramCacheKey=original.material.customProgramCacheKey.bind(original.material);materials.push(base);o.material=base;
   }
   if(!patch.instance){swaps.push({original,visible:original.visible});netTriangles-=triangleCount(original);netDraws--;}
   register(o,root);
  }
  parent.add(root);root.updateMatrixWorld(true);const box=new T.Box3();for(const child of root.children)if(child.name.startsWith('Grounded_Shoulder_'))box.union(new T.Box3().setFromObject(child));obstacles.push({name:root.name,box});
  for(const s of swaps)s.original.visible=false;world.obstacles.push(...obstacles);world.budget.triangles+=netTriangles;world.budget.drawCalls+=netDraws;
 }catch(error){for(const s of swaps)s.original.visible=s.visible;placed.forEach(o=>o.removeFromParent());root.removeFromParent();instances.forEach(o=>o.dispose());geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());throw error;}
 root.userData={synthetic:true,terrestrialScan:true,measuredReef:false,source:'https://polyhaven.com/a/boulder_01',license:'CC0',sampleTriangles:63402,netTriangles,netDraws,newTextureBytes:0,localBounds:[[-3,-1.224646672,-26],[3,2.680744825,-16]],changes:DATA.summary};
 const api={root,placed,swaps,geometries,materials,instances,netTriangles,netDraws,setEnabled(value){if(disposed)return;enabled=!!value;root.visible=enabled;for(const s of swaps)s.original.visible=enabled?false:s.visible;for(const o of placed)if(o.parent!==root)o.visible=enabled;for(const obstacle of obstacles){const i=world.obstacles.indexOf(obstacle);if(enabled&&i<0)world.obstacles.push(obstacle);if(!enabled&&i>=0)world.obstacles.splice(i,1);}},dispose(){if(disposed)return;api.setEnabled(false);disposed=true;for(const s of swaps)s.original.visible=s.visible;placed.forEach(o=>o.removeFromParent());root.removeFromParent();instances.forEach(o=>o.dispose());geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());world.budget.triangles-=netTriangles;world.budget.drawCalls-=netDraws;if(world.groundedShoulder===api)delete world.groundedShoulder;},getState:()=>({enabled,disposed,netTriangles,netDraws})};world.groundedShoulder=api;return api;
}
