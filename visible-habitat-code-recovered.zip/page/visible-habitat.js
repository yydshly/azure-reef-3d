import * as T from 'three';
import {mergeGeometries} from './utils/BufferGeometryUtils.js';
import {VISIBLE_HABITAT} from './visible-habitat-placement.js';
// Fictional attachment ecology, baked against actual visible support triangles.
// No scan-derived geometry. No frame callback or textures.
export function installVisibleHabitat({world,parent,configure=()=>{}}){
 const root=new T.Group();root.name='Synthetic_Visible_Slope_Habitat';parent.add(root);
 const meshes=[],geos=[],mats=[];const up=new T.Vector3(0,1,0);
 function geometry(type){const parts=[];
  function rod(a,b,r0,r1){const av=new T.Vector3(...a),bv=new T.Vector3(...b),d=bv.clone().sub(av),g=new T.CylinderGeometry(r1,r0,d.length(),6,1,false);g.applyQuaternion(new T.Quaternion().setFromUnitVectors(up,d.normalize()));g.translate(...av.add(bv).multiplyScalar(.5).toArray());parts.push(g);}
  if(type===0){for(let i=0;i<7;i++){const a=i*2.399,r=i===0?0:.34+(i%2)*.1;const g=new T.SphereGeometry(1,8,5);g.scale(.31+(i%3)*.045,.17+(i%3)*.055,.29);g.rotateY(a);g.translate(Math.cos(a)*r,.10+(i===0?.06:0),Math.sin(a)*r);parts.push(g);}}
  else {const tall=type===2;rod([0,-.04,0],[.035,.45,0],.105,.067);for(let k=0;k<6;k++){const a=k*2.399+.3,h=.26+(k%3)*.07,spread=tall?.46:.5;const fork=[Math.cos(a)*spread,.66+(k%3)*.11,Math.sin(a)*spread];rod([.02,h,0],fork,.067,.032);for(let j=0;j<2;j++){const b=a+(j?-.57:.57),tip=[fork[0]+Math.cos(b)*.25,fork[1]+(tall?.45:.24),fork[2]+Math.sin(b)*.25];rod(fork,tip,.032,.010);}}}
  const g=mergeGeometries(parts);parts.forEach(p=>p.dispose());g.computeBoundingBox();geos.push(g);return g;}
 const prototypes=[0,1,2].map(geometry),mat=new T.MeshStandardMaterial({color:'#ffffff',roughness:1});configure(mat);mats.push(mat);
 const dummy=new T.Object3D();let triangles=0;
 for(let t=0;t<3;t++)for(let region=0;region<2;region++){const items=VISIBLE_HABITAT.items.filter(p=>p.type===t&&p.field===!!region);if(!items.length)continue;const m=new T.InstancedMesh(prototypes[t],mat,items.length);m.name=`Visible_Habitat_${['Attached_Lobes','Branch_Thicket','Crown_Branches'][t]}_${region?'Field':'Stable'}`;m.userData.fieldReplaced=!!region;m.receiveShadow=true;m.castShadow=true;
 items.forEach((p,i)=>{dummy.position.fromArray(p.p);dummy.quaternion.fromArray(p.q);dummy.scale.fromArray(p.s);dummy.updateMatrix();m.setMatrixAt(i,dummy.matrix);m.setColorAt(i,new T.Color(p.color));});m.computeBoundingSphere();root.add(m);meshes.push(m);triangles+=(prototypes[t].index.count/3)*items.length;}
 if(triangles>200000||meshes.length>8)throw Error('Visible habitat budget exceeded');
 root.userData={synthetic:true,measuredHabitat:false,metricCalibration:false,triangles,drawCalls:meshes.length,newTextures:0,selection:VISIBLE_HABITAT.meta};world.budget.triangles+=triangles;world.budget.drawCalls+=meshes.length;
 let disposed=false;const api={root,meshes,triangles,setFieldEnabled(v){if(disposed)return;for(const m of meshes)if(m.userData.fieldReplaced)m.visible=!v;},dispose(){if(disposed)return;disposed=true;root.removeFromParent();meshes.forEach(m=>m.dispose());geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());world.budget.triangles-=triangles;world.budget.drawCalls-=meshes.length;if(world.visibleHabitat===api)delete world.visibleHabitat;},getState:()=>({disposed,triangles,drawCalls:meshes.length})};world.visibleHabitat=api;return api;
}
