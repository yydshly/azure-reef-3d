import * as T from 'three';
import {readPacked} from './field-data.js';
const BASE='./assets/field/';
const abort=()=>new DOMException('Aborted','AbortError');
export async function loadField(signal,progress=()=>{}){
 const json=async name=>{const r=await fetch(BASE+name,{signal});if(!r.ok)throw Error(name+' HTTP '+r.status);return r.json();};
 const [points,support,placement]=await Promise.all(['points-manifest.json','support-manifest.json','placement.json'].map(json));
 if(support.format!=='ReefSupportMeshLE-v1'||support.file!=='support.bin'||support.vertices!==9120||support.triangles!==14818||support.bytes!==287256)throw Error('Unexpected support format/count');
 if(!Array.isArray(placement.removed)||placement.removed.filter(x=>typeof x==='string').length!==192)throw Error('Unexpected replacement contract');
 const a=await readPacked(BASE+'darwin-1000k.bin',points,signal,(n,total)=>progress(n,total));
 const r=await fetch(BASE+support.file,{signal});if(!r.ok)throw Error('Support HTTP '+r.status);const buffer=await r.arrayBuffer();
 if(buffer.byteLength!==support.bytes)throw Error('Support length mismatch');
 const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',buffer))].map(n=>n.toString(16).padStart(2,'0')).join('');
 if(hash!==support.sha256)throw Error('Support SHA-256 mismatch');if(signal.aborted)throw abort();
 return {a,points,support,placement,buffer};
}
export function buildFieldGeometry(a,count){
 const g=new T.InstancedBufferGeometry(),corners=new Float32Array(18);
 for(let i=0;i<6;i++){corners[3*i]=Math.cos(i*Math.PI/3);corners[3*i+1]=Math.sin(i*Math.PI/3);}
 g.setAttribute('position',new T.BufferAttribute(corners,3));g.setAttribute('normal',new T.BufferAttribute(new Float32Array(18).fill(0),3));
 g.setIndex([0,1,2,0,2,3,0,3,4,0,4,5]);g.setAttribute('center',new T.InstancedBufferAttribute(a.positions,3));g.setAttribute('sourceNormal',new T.InstancedBufferAttribute(a.normals,4,true));g.setAttribute('sourceColor',new T.InstancedBufferAttribute(a.colors,4,true));g.instanceCount=count;return g;
}
export function fieldMaterial(radius,configure){
 const m=new T.MeshStandardMaterial({roughness:1,side:T.DoubleSide});
 m.onBeforeCompile=shader=>{
  shader.uniforms.fieldRadius={value:radius};
  shader.vertexShader='attribute vec3 center;\nattribute vec4 sourceNormal;\nattribute vec4 sourceColor;\nuniform float fieldRadius;\nvarying vec3 fieldRGB;\n'+shader.vertexShader;
  shader.vertexShader=shader.vertexShader.replace('#include <beginnormal_vertex>','vec3 objectNormal=normalize(sourceNormal.xyz);');
  shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`vec3 n=normalize(sourceNormal.xyz);vec3 ref=abs(n.z)>.9?vec3(1.,0.,0.):vec3(0.,0.,1.);vec3 u=normalize(cross(n,ref));vec3 v=cross(n,u);vec3 transformed=center+fieldRadius*(position.x*u+position.y*v);fieldRGB=sourceColor.rgb;`);
  shader.fragmentShader='varying vec3 fieldRGB;\n'+shader.fragmentShader;
  shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>\nvec3 fieldLinear=mix(pow((fieldRGB+vec3(.055))/1.055,vec3(2.4)),fieldRGB/12.92,lessThanEqual(fieldRGB,vec3(.04045)));diffuseColor.rgb*=fieldLinear;`);
 };m.customProgramCacheKey=()=> 'darwinFieldSurfel1';try{configure(m);}catch(e){m.dispose();throw e;}return m;
}
function visible(o,root){for(let p=o;p;p=p.parent){if(!p.visible)return false;if(p===root)break;}return true;}
// Prepare all replacements before mutating a single baseline object.
export function installField({world,ground,data,configure=()=>{}}){
 if(world.group.getObjectByName('Experimental_Continuous_Reef_Field'))throw Error('Field already installed');
 const root=new T.Group();root.name='Experimental_Continuous_Reef_Field';
 const ownedG=[],ownedM=[],compacts=[],swaps=[];let removedTriangles=0,removedDraws=0,budgetApplied=false,netTriangles=0,netDraws=0;
 const wanted=new Set(data.placement.removed.filter(x=>typeof x==='string')),found=new Set();
 const release=()=>{if(budgetApplied){world.budget.triangles-=netTriangles;world.budget.drawCalls-=netDraws;budgetApplied=false;}root.removeFromParent();world.visibleHabitat?.setFieldEnabled(false);
  for(const s of swaps){if(s.kind==='geometry'){if(s.o.geometry===s.next)s.o.geometry=s.original;}else s.o.visible=s.original;}compacts.forEach(c=>{c.removeFromParent();c.dispose();});ownedG.forEach(g=>g.dispose());ownedM.forEach(m=>m.dispose());};
 try{
  world.group.updateMatrixWorld(true);
  const objects=[];world.group.traverse(o=>{if(o.isMesh&&visible(o,world.group))objects.push(o);});
  for(const o of objects){
   const indices=[];const count=o.isInstancedMesh?o.count:1;
   for(let i=0;i<count;i++){const key=o.name+'_'+i;if(wanted.has(key)){indices.push(i);found.add(key);}}
   if(!indices.length)continue;removedTriangles+=indices.length*(o.geometry.index?.count||o.geometry.attributes.position.count)/3;if(indices.length===count)removedDraws++;
   swaps.push({kind:'visibility',o,original:o.visible});
   if(o.isInstancedMesh&&indices.length<o.count){
    const excluded=new Set(indices),c=new T.InstancedMesh(o.geometry,o.material,o.count-indices.length),mat=new T.Matrix4(),color=new T.Color();
    c.name='Field_Retained_'+o.name;c.matrix.copy(o.matrix);c.matrixAutoUpdate=false;c.castShadow=o.castShadow;c.receiveShadow=o.receiveShadow;
    let j=0;for(let i=0;i<o.count;i++)if(!excluded.has(i)){o.getMatrixAt(i,mat);c.setMatrixAt(j,mat);if(o.instanceColor){o.getColorAt(i,color);c.setColorAt(j,color);}j++;}c.computeBoundingSphere();compacts.push(c);c.userData.originalParent=o.parent;
   }
  }
  const missing=[...wanted].filter(x=>!found.has(x));if(missing.length)throw Error('Baseline replacement mismatch: '+missing.slice(0,4).join(', '));
  const ridge=world.group.getObjectByName('Layered_Ridges_Weathered_Shoulders');if(!ridge?.geometry.index)throw Error('Missing original ridge');
  const rg=ridge.geometry.clone(),pos=rg.attributes.position,old=rg.index.array,keep=[];let removed=0;
  for(let i=0;i<old.length;i+=3){const ids=[old[i],old[i+1],old[i+2]],x=ids.reduce((s,j)=>s+pos.getX(j),0)/3,z=ids.reduce((s,j)=>s+pos.getZ(j),0)/3;if(x>8&&z< -31&&z> -68)removed++;else keep.push(...ids);}
  ownedG.push(rg);rg.setIndex(keep);if(removed!==1620)throw Error('Ridge triangle identity mismatch');swaps.push({kind:'geometry',o:ridge,original:ridge.geometry,next:rg});
  const sm=data.support,g=new T.BufferGeometry();ownedG.push(g);
  g.setAttribute('position',new T.BufferAttribute(new Float32Array(data.buffer,0,sm.vertices*3),3));g.setIndex(new T.BufferAttribute(new Uint32Array(data.buffer,sm.vertices*12,sm.triangles*3),1));g.computeVertexNormals();g.computeBoundingSphere();
  const support=new T.Mesh(g,ground.material);support.name='Synthetic_Field_Contact_Sand';support.receiveShadow=true;root.add(support);
  const fg=buildFieldGeometry(data.a,data.points.points);ownedG.push(fg);const fm=fieldMaterial(data.points.radius,configure);ownedM.push(fm);
  const cloud=new T.Mesh(fg,fm);cloud.name='Measured_Darwin_1000000_Surfels';cloud.frustumCulled=false;cloud.scale.setScalar(2);cloud.rotation.x=-Math.PI/2;cloud.position.set(21.5,.04,-44);root.add(cloud);
  root.userData={experimental:true,syntheticSupport:true,metricCalibration:false,points:1000000,displayTriangles:4000000,sourceSHA256:data.points.sourceSHA256,payloadSHA256:data.points.sha256};
  // No await from this point: commit is atomic relative to UI actions/rendering.
  world.visibleHabitat?.setFieldEnabled(true);
  for(const s of swaps){if(s.kind==='geometry')s.o.geometry=s.next;else s.o.visible=false;}
  for(const c of compacts){const parent=c.userData.originalParent;delete c.userData.originalParent;parent.add(c);}
  world.group.add(root);netTriangles=4000000+sm.triangles-removedTriangles-removed;netDraws=2-removedDraws;world.budget.triangles+=netTriangles;world.budget.drawCalls+=netDraws;budgetApplied=true;
  let disposed=false;return {root,cloud,support,removed:found.size,dispose(){if(disposed)return;disposed=true;release();},inspect:()=>({points:fg.instanceCount,displayTriangles:fg.instanceCount*4,pointBytes:data.a.positions.buffer.byteLength,removedObjects:found.size,removedTriangles:removedTriangles+removed,netTriangles,netDraws,removedRidgeTriangles:removed,supportTriangles:sm.triangles,sameSandMaterial:support.material===ground.material,instances:1,allocatedMeshObjects:2+compacts.length,visibleMeshObjects:[...root.children,...compacts].filter(o=>visible(o,world.group)).length,compactBatches:compacts.length,ownedGeometries:ownedG.length,ownedMaterials:ownedM.length,sharedMaterials:1,estimatedGeometryGPUBytes:ownedG.reduce((n,g)=>n+Object.values(g.attributes).reduce((s,a)=>s+a.array.byteLength,0)+(g.index?.array.byteLength||0),0),estimatedCompactGPUBytes:compacts.reduce((n,c)=>n+c.instanceMatrix.array.byteLength+(c.instanceColor?.array.byteLength||0),0),gpuBytesAreEstimates:true})};
 }catch(e){release();throw e;}
}
export function createFieldRuntime({world,ground,configure,prepare=async()=>true,load=loadField,invalidate=()=>{},onState=()=>{}}){
 let generation=0,controller=null,pending=null,installation=null,disposed=false,status='idle',enabled=false,error=null,progress=0;
 const getState=()=>({status,enabled,disposed,error,progress,installed:!!installation,...installation?.inspect()});
 const notify=()=>{invalidate();onState(getState());};
 function clear(){generation++;controller?.abort();controller=null;pending=null;installation?.dispose();installation=null;}
 function restore(){if(disposed)return;clear();enabled=false;status='idle';error=null;progress=0;notify();}
 function ensure(){if(disposed)return Promise.resolve(false);if(installation)return Promise.resolve(true);if(pending)return pending;enabled=true;status='loading';error=null;progress=0;const token=++generation;controller=new AbortController();const signal=controller.signal;notify();
  pending=Promise.resolve().then(()=>prepare()).then(ok=>{if(signal.aborted||token!==generation)throw abort();if(!ok)throw Error('Original reef dependencies unavailable');return load(signal,(n,t)=>{if(token===generation&&!disposed){progress=n/t;notify();}});}).then(data=>{if(signal.aborted||token!==generation||disposed)throw abort();installation=installField({world,ground,configure,data});status='ready';notify();return true;}).catch(e=>{if(token===generation&&!disposed){controller?.abort();installation?.dispose();installation=null;enabled=false;status='error';error=String(e.message||e);notify();}return false;}).finally(()=>{if(token===generation){pending=null;controller=null;}});return pending;
 }
 function setEnabled(value){return value?ensure():(restore(),Promise.resolve(false));}
 function reject(reason){if(disposed)return;clear();enabled=false;status='error';error=String(reason.message||reason);notify();}
 function dispose(){if(disposed)return;clear();enabled=false;disposed=true;status='disposed';notify();}
 return {ensure,setEnabled,restore,reject,dispose,getState,getRoot:()=>installation?.root||null};
}
