import pathlib,json,hashlib,zipfile
here=pathlib.Path(__file__).parent;dist=pathlib.Path('dist');sha=lambda b:hashlib.sha256(b).hexdigest()
def inv(root):
 assert root.is_dir() and not any(p.is_symlink() for p in root.rglob('*'))
 return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
old=dist/'preview/rear-habitat-candidate';r=json.loads((here/'rear-preservation.json').read_text());assert inv(old)=={f['path']:f['sha256'] for f in r['sourceFiles']}
p=pathlib.Path('.entry-inputs/rear-gallery-0badf15.zip');b=p.read_bytes();assert len(b)==r['archive']['bytes'] and sha(b)==r['archive']['sha256']
with zipfile.ZipFile(p) as z:
 assert len(z.namelist())==len(set(z.namelist()))==6 and set(z.namelist())==set(r['files'])
 for n,f in r['files'].items():
  rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];p=old/n;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
before=inv(dist);assert len(before)==1510;pathlib.Path('.entry-protected.json').write_text(json.dumps(before,sort_keys=True));new=dist/'preview/world';assert not new.exists();new.mkdir()
m=json.loads((here/'entry-contract.json').read_text());p=pathlib.Path('.entry-inputs/world-entry-code.zip');b=p.read_bytes();assert len(b)==m['archive']['bytes'] and sha(b)==m['archive']['sha256']
with zipfile.ZipFile(p) as z:
 assert len(z.namelist())==len(set(z.namelist()))==3 and set(z.namelist())=={f['path'] for f in m['files']}
 for f in m['files']:
  n=f['path'];assert pathlib.PurePosixPath(n).name==n;b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];(new/n).write_bytes(b)
assert len(inv(new))==3;print('ENTRY_STAGED',json.dumps({'oldFiles':1510,'newSourceFiles':3,'selectedCommit':m['selectedCommit']}))
