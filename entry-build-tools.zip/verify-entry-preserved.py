import pathlib,json,hashlib,re,sys
root=pathlib.Path('dist');m=json.loads(pathlib.Path('.entry-protected.json').read_text());assert len(m)==1510
for n,h in m.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
current={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()};extra=current-set(m);expected={'preview/world/index.html','preview/world/world.css','preview/world/current-world.json'}
if '--source-only' in sys.argv:assert extra==expected,extra
else:
 pngs=extra-expected;assert len(pngs)==2 and {re.fullmatch(r'preview/world/evidence/(entry-desktop|entry-narrow)-[0-9a-f]{16}\.png',n).group(1) for n in pngs}=={'entry-desktop','entry-narrow'};assert extra==expected|pngs
contract=json.loads((pathlib.Path(__file__).parent/'entry-contract.json').read_text())
for f in contract['files']:
 b=(root/'preview/world'/f['path']).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
print('OLD_1510_FILES_BYTE_IDENTICAL_AND_ONLY_ENTRY_ADDITIONS',len(extra))
