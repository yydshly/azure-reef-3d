import pathlib,json,hashlib,struct,os
sha=lambda b:hashlib.sha256(b).hexdigest();here=pathlib.Path(__file__).parent;root=pathlib.Path('dist/preview/world');r=json.loads(pathlib.Path('.entry-evidence/result.json').read_text());assert r['status']=='PASS_STATIC_ENTRY';m=json.loads((here/'entry-contract.json').read_text())
for f in m['files']:
 b=(root/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
assert [s['name'] for s in r['screenshots']]==['entry-desktop','entry-narrow'];out=root/'evidence';out.mkdir()
for s in r['screenshots']:
 p=pathlib.Path('.entry-evidence')/s['file'];b=p.read_bytes();assert sha(b)==s['sha256'] and len(b)==s['bytes'];assert b[:8]==b'\x89PNG\r\n\x1a\n';w,h=struct.unpack('>II',b[16:24]);assert w==(1366 if s['name']=='entry-desktop' else 320) and h>=900;s['width']=w;s['height']=h;s['publicPath']='evidence/'+s['name']+'-'+s['sha256'][:16]+'.png';(root/s['publicPath']).write_bytes(b)
r.update(mainCommit=os.environ['GITHUB_SHA'],sourceCommit=os.environ['ENTRY_SOURCE_COMMIT'],sourceFiles=m['files'],selectedSceneCommit=m['selectedCommit']);print('ENTRY_PUBLIC_EVIDENCE_READY',json.dumps(r,ensure_ascii=False))
