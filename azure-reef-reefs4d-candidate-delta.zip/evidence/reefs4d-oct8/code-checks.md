# Reefs4D integration code and geometry checks

Checked 2026-10-08 on the local candidate based on accepted commit 498cc09acda8b7d4609ee2dc863e01e6712c790c. These results are not browser rendering or performance acceptance.

Passed:
- `npm test`: guide state, simulated actual app integration, no-WebGL fallback, authoritative/static model, guide anchors and water shader assembly
- `npm run test:motion`, `npm run test:life`, `npm run test:fish-surface`
- `npm run test:inhabited`, `npm run test:route-rebalance`
- `npm run test:tour-clock`
- `npm run test:specimen`
- `npm run test:branch-grounding`, `npm run test:sibling-grounding`
- `node qa-reef-scan.mjs`: actual scan parsing, texture presence, uniformly scaled independent scene group, preserved baseline object identities/transforms/geometry/material references, sampled camera/fish separation, unobscured guide anchors and skeleton ray
- `REEF_REDUCED_MOTION=1 node qa-guide-integration.mjs`
- `REEF_SCAN_LOAD_FAILURE=1 node qa-guide-integration.mjs`: optional scan failure keeps baseline usable
- JavaScript syntax and `git diff --check`

The scan-specific numeric result is in `integration-check.json`. Its 0.9 scene-unit fish sphere is deliberately conservative and checked against the present rest-pose radii (all below 0.375); route samples are at 0.1-second steps for 180 seconds. This is not a proof about unsampled continuous motion.

The simulated app checks cover native-handler wiring, same camera/target/projection after comparison, repeated focus/return, Escape, guide interruption, scan/skeleton transitions, native-tour interruption, and world-control restoration. They do not execute a browser layout engine or graphics driver. Small-screen comparison controls are compact during the guide and hidden during skeleton inspection to preserve its existing screen area; real responsive layout remains for browser verification.

`tests/browser/verify-pages.mjs` has been extended for the separately authorized existing workflow: scan-ready wait, source hash matching, six fish, three same-camera baseline/scan pairs, native scan focus/return/repeat, five native guide selections (fixed screenshot poses), existing skeleton inspection/return, and a 390×844 viewport native comparison/focus/return with guide-card/footer overlap checks. Security flags and workflows are unchanged. Animated objects are not time-locked between paired screenshots. Actual workflow results must be recorded separately; writing this script is not a test pass.
