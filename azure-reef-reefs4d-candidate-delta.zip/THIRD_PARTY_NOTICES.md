# Third-party notices and reference provenance

## Three.js

The browser bundle and helper modules under `dist/vendor/` and `dist/utils/` are from Three.js 0.186.1. The MIT license is retained verbatim at `dist/vendor/THREE-LICENSE.txt`. Development checks install the same pinned Three.js version.

## Development dependencies

`@napi-rs/canvas` 0.1.100 is used only by Node-side validation. Its package/license metadata is supplied through npm; it is not copied into the browser bundle. Python texture generation uses NumPy and Pillow under their respective upstream licenses. Dependency packages and caches are not included in this export.

## Original assets

Coral, substrate, sand, fish geometry and six procedural texture maps were authored for this project. The final GLB and editable Blender scene are included, with generation provenance and deterministic seeds. The accepted procedural baseline remains original. The separately attributed Smithsonian dry specimen and Reefs4D reef scan below are external scan assets.

## Scientific and photographic references

These sources informed modeling and beginner explanations. They are references, not endorsements or scientific validation of the model. The source pages retain their own image credits and terms; reference photographs are not redistributed here.

- NOAA Fisheries, staghorn coral morphology, color, growth forms and habitat: https://www.fisheries.noaa.gov/species/staghorn-coral
- NOAA/FKNMS, Mission: Iconic Reefs and Cheeca Rocks imagery: https://sanctuaries.noaa.gov/news/press/mission-iconic-reefs/
- Florida Keys connected habitats: https://floridakeys.noaa.gov/education/habitats.html
- Coral anatomy, reef structure and substrate: https://floridakeys.noaa.gov/corals/coralreefs.html
- Reef fauna: https://floridakeys.noaa.gov/education/creature-feature.html
- Light and water requirements: https://oceanservice.noaa.gov/facts/coralwaters.html

The app intentionally does not identify its generic fish to species or claim measured co-occurrence, depth, population density or water optics.


## Reefs4D C12019 reef scan (local integration candidate, 2026-10-08)

- Title/version: Reefs4D, v3; creators Matan Yuval and Tali Treibitz.
- Record and source files: https://zenodo.org/records/14616671 (C12019.ply and C12019.jpg).
- License: Creative Commons Attribution-NonCommercial 2.0 Generic (CC BY-NC 2.0): https://creativecommons.org/licenses/by-nc/2.0/legalcode . This integration is a noncommercial technical demonstration; this notice does not license it for commercial use.
- Requested research citation: Yuval, Matan, et al. “Assessment of storm impact on coral reef structural complexity.” Science of The Total Environment (2023), 164493. https://doi.org/10.1016/j.scitotenv.2023.164493
- Site: C1, Princess Beach, Eilat, Gulf of Aqaba, northern Red Sea. This is not a Caribbean reef scan and does not establish ecological co-occurrence with the existing interpreted scene.
- Derivative browser asset: `dist/assets/reefs4d/C12019-web.glb`. Technical conversion recenters the source, changes coordinate basis, and reduces triangle count while retaining the full source footprint and its 4096-pixel color atlas. See conversion/provenance records accompanying the asset. No hole filling, scientific correction, recoloring or removal of the two visible survey targets is claimed.
- Runtime presentation: separate scene group, rigid rotation/translation and uniform scale only. Some lower geometry is occluded by the existing substrate. Source-unit-to-meter conversion was not established; the scale and placement are demonstrative. No claims of measured reef size, depth, water optics, species identity, density or biological validation are made.
- Water, animated fish and original surrounding reef components are invented demonstration additions. Source colors also contain captured underwater lighting. The dataset creators do not endorse this application.

## Smithsonian dry coral specimen

The separate dry skeleton is Smithsonian NMNH USNM 74016, Acropora cervicornis, CC0: https://3d.si.edu/object/3d/acropora-cervicornis:dd875177-c986-48e2-9468-8e58f01099d3 . See `modeling/specimen/README.md` for the preserved specimen-specific provenance and conversion record. It is a teaching placement, not a live-reef scan.
