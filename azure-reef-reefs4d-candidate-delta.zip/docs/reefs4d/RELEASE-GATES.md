# Candidate and release gates

Accepted baseline: `498cc09acda8b7d4609ee2dc863e01e6712c790c`.

This candidate is authorized for an independent public QA branch and existing free Chromium rendering workflow only. No merge to `main`, production publication, paid runner/service, account change or new credential is authorized.

1. Complete offline model/logic regressions and freeze candidate.
2. Create a separate branch from the accepted baseline using an already-authorized account with repository write access. Upload candidate code, derived 8,871,688-byte GLB, tests and necessary provenance. Keep raw 81MB PLY and external/private work files out of the branch.
3. Run existing `render-check.yml` with `target_source=branch-preview`, branch ref set to the candidate and `view_set=passage`. Do not dispatch Pages deployment.
4. Inspect real-browser report and screenshots, not just a green workflow status. Compare same-camera ordinary view with scan off/on; evaluate cyan photographed atlas vs procedural material continuity under actual water/fog/light. Check all five guide stops, six fish, skeleton focus/return, scan focus/return, low mode, reduced motion, keyboard/native controls, load failure, mobile controls and hosted-runner frame cost.
5. Ask the user to review meaningful visual changes. A verified render is not automatic realism acceptance or user-device GPU acceptance. Only explicit subsequent authority may publish to main/Pages.

At 2026-10-08 preparation time, installed local Chromium could not create a process socket and cloud browser explicitly blocked localhost. Connected GitHub metadata reported `pull:true,push:false`; local `gh` had no logged-in host. No branch/workflow was claimed created based on preparation alone.

Rollback: scan is an independently loaded group; the in-page original-scene control hides it without modifying baseline geometry. Full source rollback is checkout of the accepted baseline. The candidate source/provenance text intentionally remains honest about the hybrid scene.
