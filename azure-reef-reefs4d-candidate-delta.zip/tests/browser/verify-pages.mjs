import {chromium} from 'playwright';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';

const mode=process.argv[2]||'probe';
if(!['probe','render'].includes(mode))throw Error('Expected probe or render');
const out=path.resolve('render-evidence');await fs.mkdir(out,{recursive:true});
const target=process.env.REEF_TARGET||'https://yydshly.github.io/azure-reef-3d/';
if(!['https://yydshly.github.io/azure-reef-3d/','http://127.0.0.1:4173/'].includes(target))throw Error('Unapproved test target');
const viewSet=process.env.REEF_VIEW_SET||'passage';
const sha=b=>createHash('sha256').update(b).digest('hex');
const report={mode,target,viewSet,checkedAt:new Date().toISOString(),checkoutCommit:process.env.GITHUB_SHA||null,
  sandbox:true,unsafeGraphicsFlags:false,limitations:['Hosted runner rendering is not user-device performance or physical GPU acceptance.','Screenshots require human visual review; successful rendering alone is not realism acceptance.']};
let browser,context,page;
const save=()=>fs.writeFile(path.join(out,`${mode}.json`),JSON.stringify(report,null,2)+'\n');
async function capability(p){return p.evaluate(()=>{
  const c=document.createElement('canvas');c.width=16;c.height=16;
  const gl=c.getContext('webgl2');if(!gl)return {available:false,reason:'getContext(webgl2) returned null'};
  const debug=gl.getExtension('WEBGL_debug_renderer_info');gl.clearColor(.2,.4,.6,1);gl.clear(gl.COLOR_BUFFER_BIT);gl.finish();
  const pixel=new Uint8Array(4);gl.readPixels(0,0,1,1,gl.RGBA,gl.UNSIGNED_BYTE,pixel);
  const result={available:true,version:gl.getParameter(gl.VERSION),shadingLanguage:gl.getParameter(gl.SHADING_LANGUAGE_VERSION),vendor:gl.getParameter(gl.VENDOR),renderer:gl.getParameter(gl.RENDERER),unmaskedVendor:debug?gl.getParameter(debug.UNMASKED_VENDOR_WEBGL):null,unmaskedRenderer:debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):null,pixel:Array.from(pixel),error:gl.getError()};
  gl.getExtension('WEBGL_lose_context')?.loseContext();return result;
});}
try{
  browser=await chromium.launch({channel:'chromium',headless:true,chromiumSandbox:true,timeout:45000,args:['--enable-automation'],
    ignoreDefaultArgs:['--enable-unsafe-swiftshader','--disable-gpu-sandbox','--ignore-gpu-blocklist']});
  report.browserVersion=browser.version();
  const cdp=await browser.newBrowserCDPSession();
  const command=await cdp.send('Browser.getBrowserCommandLine');
  report.securityFlags={sandboxDisabled:command.arguments.includes('--no-sandbox'),gpuSandboxDisabled:command.arguments.includes('--disable-gpu-sandbox'),unsafeSwiftshader:command.arguments.includes('--enable-unsafe-swiftshader'),gpuBlocklistIgnored:command.arguments.includes('--ignore-gpu-blocklist')};
  if(Object.values(report.securityFlags).some(Boolean))throw Error('Unexpected security-weakening browser flag');
  context=await browser.newContext({viewport:{width:1120,height:700},deviceScaleFactor:1,reducedMotion:'no-preference',...(mode==='render'&&process.env.RECORD_VIDEO==='true'?{recordVideo:{dir:path.join(out,'video'),size:{width:1120,height:700}}}:{})});
  page=await context.newPage();page.setDefaultTimeout(30000);
  report.webgl2=await capability(page);report.webgl2.softwareRenderer=/swiftshader|llvmpipe|software/i.test(report.webgl2.unmaskedRenderer||report.webgl2.renderer||'');
  console.log('WEBGL2_PROBE',JSON.stringify(report.webgl2));await save();
  if(mode==='probe'){
    if(process.env.GITHUB_OUTPUT)await fs.appendFile(process.env.GITHUB_OUTPUT,`available=${report.webgl2.available}\n`);
  }else{
    if(!report.webgl2.available)throw Error('WebGL2 unavailable; rendering not attempted');
    report.consoleErrors=[];report.pageErrors=[];report.failedRequests=[];report.httpErrors=[];
    page.on('console',m=>{if(m.type()==='error')report.consoleErrors.push(m.text());});
    page.on('pageerror',e=>report.pageErrors.push(String(e)));
    page.on('requestfailed',r=>report.failedRequests.push({url:r.url(),error:r.failure()?.errorText}));
    page.on('response',r=>{if(r.status()>=400)report.httpErrors.push({url:r.url(),status:r.status()});});
    report.sourceMatch={};
    for(const f of ['app.js','model-version.js','reef-scan.js','index.html','style.css','guide-data.js']){
      const r=await context.request.get(new URL(f,target).href);const bytes=await r.body();
      report.sourceMatch[f]={status:r.status(),served:sha(bytes),checkout:sha(await fs.readFile(`dist/${f}`))};
      if(!r.ok()||report.sourceMatch[f].served!==report.sourceMatch[f].checkout)throw Error(`Pages source differs from checked-out ${f}`);
    }
    await page.goto(target,{waitUntil:'domcontentloaded',timeout:60000});
    await page.waitForFunction(()=>window.reef3d?.getState().ready===true||!document.querySelector('#unsupported').hidden,{},{timeout:150000});
    if(await page.locator('#unsupported').isVisible())throw Error(await page.locator('#failure').innerText());
    await page.waitForFunction(()=>['ready','error'].includes(window.reef3d?.getState().scan?.state),{},{timeout:90000});
    report.runtime=await page.evaluate(()=>window.reef3d.getState());
    if(report.runtime.scan.state!=='ready')throw Error('Independent Reefs4D scan did not load');
    if(report.runtime.fish!==6)throw Error('Expected the retained six-fish population');
    report.scanAsset=await page.evaluate(()=>{const group=window.reef3d.scene.getObjectByName('Reefs4D_C12019');let triangles=0,textured=0;group.traverse(o=>{if(!o.isMesh)return;triangles+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3;if(o.material.map)textured++;});return {triangles,textured,position:group.position.toArray(),scale:group.scale.toArray(),source:group.userData.source};});
    if(report.scanAsset.triangles<50000||report.scanAsset.textured===0)throw Error('Scan is missing meaningful textured geometry');
    report.actualCanvas=await page.evaluate(()=>{const c=document.querySelector('#reef');const gl=c.getContext('webgl2');const ext=gl.getExtension('WEBGL_debug_renderer_info');return {width:c.width,height:c.height,contextLost:gl.isContextLost(),renderer:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER)};});
    report.captures=[];report.fixedViewMethod='Explicit camera/target and guide state through the existing app API; not an assertion that native input or transition smoothness passed.';
    async function capture(name){const file=path.join(out,`${name}.png`);await page.screenshot({path:file,timeout:45000});const state=await page.evaluate(()=>window.reef3d.getState());report.captures.push({file:`${name}.png`,sha256:sha(await fs.readFile(file)),state});await save();}
    async function fixedCamera(position,target,free=true){
      await page.evaluate(({position,target,free})=>{const r=window.reef3d;if(free)r.leaveGuide();r.setTour(false);r.camera.position.set(...position);r.controls.target.set(...target);r.controls.update();r.camera.updateMatrixWorld();},{position,target,free});
      const actual=await page.evaluate(()=>window.reef3d.getState());
      if(actual.camera.some((v,i)=>Math.abs(v-position[i])>.001)||actual.target.some((v,i)=>Math.abs(v-target[i])>.001))throw Error('Application constrained the requested camera; not the claimed fixed viewpoint');
      await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(true)))));
    }
    const planned=viewSet==='passage'?[{name:'departure',p:[1.5,2.1,4.8],t:[-.5,.8,-6]},{name:'midway',p:[0,2.7,-18],t:[-1.5,1,-31]},{name:'look-back',p:[-3.8,3.6,-36],t:[0,.9,-8]}]:[{name:'opening',p:[1.5,1.6,4.8],t:[-.5,.8,-6]},{name:'reverse',p:[-8,3.7,-11],t:[0,.9,0]},{name:'close',p:[1.6,1.8,5.8],t:[-2,.9,0]}];
    await page.evaluate(()=>window.reef3d.leaveGuide());
    report.plannedViews=planned;
    const state=()=>page.evaluate(()=>window.reef3d.getState());
    const samePose=(a,b)=>['camera','target'].every(k=>a[k].every((v,i)=>Math.abs(v-b[k][i])<1e-7));
    const painted=()=>page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(true)))));
    report.scanComparisons=[];
    for(let i=0;i<planned.length;i++){
      const v=planned[i];await fixedCamera(v.p,v.t);
      await page.locator('#scanBaseline').click();await painted();const before=await state();
      if(before.scan.visible)throw Error('Native baseline button did not hide scan');await capture(`${i+1}-${v.name}-baseline`);
      await page.locator('#scanCandidate').click();await painted();const after=await state();
      if(!after.scan.visible||!samePose(before,after))throw Error('Native scan comparison changed viewpoint or failed visibility');
      await capture(`${i+1}-${v.name}-scan`);report.scanComparisons.push({view:v.name,before,after,sameCamera:true,nativeButtons:true});
    }
    // This focus is within the same world. It must restore the original pose exactly.
    await fixedCamera(planned[0].p,planned[0].t);const focusBefore=await state();
    await page.locator('#scanFocus').click();await painted();const scanFocused=await state();
    if(!scanFocused.scan.inspection||!scanFocused.scan.visible)throw Error('Native scan focus did not enter');await capture('scan-in-world-focus');
    await page.locator('#scanReturn').click();await painted();const focusReturned=await state();
    if(focusReturned.scan.inspection||!samePose(focusBefore,focusReturned))throw Error('Native scan return did not restore exact viewpoint');
    report.scanFocus={before:focusBefore,focused:scanFocused,returned:focusReturned,nativeButtons:true,restored:true};
    // Repeat to catch a stale saved pose or click-state race.
    await page.locator('#scanFocus').click();await painted();await page.locator('#scanReturn').click();await painted();
    if(!samePose(focusBefore,await state()))throw Error('Repeated scan focus changed return viewpoint');
    const v=planned[0];await fixedCamera(v.p,v.t);
    const fish=()=>page.evaluate(()=>{const a=[];window.reef3d.root.traverse(o=>{if(/^fish_\d+$/.test(o.name))a.push({name:o.name,position:o.position.toArray()});});return a;});
    const before=await fish();await page.waitForTimeout(8000);const after=await fish();report.animation={sampleSeconds:8,before,after,positionsChanged:JSON.stringify(before)!==JSON.stringify(after)};await capture('4-after-animation');
    report.guideStops=[];await page.locator('#guideEntry').click();
    for(let i=0;i<5;i++){
      await page.locator(`[data-guide="${i}"]`).click();
      const selection=await state();if(!selection.guide.active||selection.guide.index!==i)throw Error('Native guide selection failed at '+i);
      const pose=await page.evaluate(()=>{const r=window.reef3d;r.guide.pause();return {p:r.guide.current.position,t:r.guide.current.target};});
      // Slow software rendering cannot validate native interpolation by snapping.
      // Record the distinction: native step selection, then a fixed review pose.
      await fixedCamera(pose.p,pose.t,false);await capture(`guide-${i+1}`);
      report.guideStops.push({stop:i,title:await page.locator('#guideTitle').innerText(),state:await state(),method:'Native step button; fixed camera for screenshot; no transition-smoothness claim'});
      if(i===1)report.guideMarkers=await page.locator('#focusMarker, #focusMarkerSecondary').evaluateAll(es=>es.map(e=>({hidden:e.hidden,text:e.textContent,rect:e.getBoundingClientRect().toJSON()})));
      if(i===2){
        const before=await state();await page.locator('#specimenInspect').click();await painted();const focused=await state();
        if(!focused.specimenInspection)throw Error('Existing skeleton inspection broke');await capture('guide-3-skeleton');
        await page.locator('#specimenReturn').click();await painted();const returned=await state();
        if(returned.specimenInspection||!samePose(before,returned))throw Error('Skeleton return viewpoint changed');
        report.skeletonInspection={before,focused,returned,nativeButtons:true,restored:true};
      }
    }
    await page.locator('#guideExplore').click();if((await state()).guide.active)throw Error('Guide free-explore button failed');
    await page.setViewportSize({width:390,height:844});await painted();
    async function inspectMobileLayout(){
      const layout=await page.evaluate(()=>{
        const rect=id=>{const e=document.querySelector(id);if(!e||getComputedStyle(e).display==='none'||e.hidden)return null;const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom};};
        return {viewport:[innerWidth,innerHeight],panel:rect('#scanPanel'),guideCard:rect('#guideCard'),footer:rect('footer'),buttons:['#scanBaseline','#scanCandidate','#scanFocus','#scanReturn'].map(id=>({id,rect:rect(id)})).filter(x=>x.rect)};
      });
      const p=layout.panel;if(!p||p.x<0||p.y<0||p.right>390||p.bottom>844)throw Error('Mobile scan panel is outside viewport');
      const overlaps=(a,b)=>b&&Math.min(a.right,b.right)>Math.max(a.x,b.x)&&Math.min(a.bottom,b.bottom)>Math.max(a.y,b.y);
      if(overlaps(p,layout.guideCard)||overlaps(p,layout.footer))throw Error('Mobile scan panel overlaps guide card or footer');
      for(const b of layout.buttons)if(b.rect.width<40||b.rect.height<30)throw Error('Mobile scan button is too small');
      return layout;
    }
    const mobileFreeLayout=await inspectMobileLayout();
    await page.locator('#scanBaseline').click();await painted();const mobileBefore=await state();
    await page.locator('#scanCandidate').click();await painted();const mobileAfter=await state();
    if(!mobileAfter.scan.visible||!samePose(mobileBefore,mobileAfter))throw Error('Mobile native comparison failed');
    await capture('mobile-scan-world');
    await page.locator('#guideEntry').click();await page.locator('#scanBaseline').click();await page.locator('#scanCandidate').click();await painted();
    const mobileGuideLayout=await inspectMobileLayout();await capture('mobile-guide-with-scan-controls');
    const mobileFocusBefore=await state();await page.locator('#scanFocus').click();await painted();const mobileFocused=await state();
    if(!mobileFocused.scan.inspection)throw Error('Mobile focus failed');const mobileFocusLayout=await inspectMobileLayout();await capture('mobile-scan-focus');
    await page.locator('#scanReturn').click();await painted();const mobileReturned=await state();
    if(mobileReturned.scan.inspection||!mobileReturned.guide.active||!samePose(mobileFocusBefore,mobileReturned))throw Error('Mobile focus return failed');
    report.mobile={viewport:[390,844],freeLayout:mobileFreeLayout,guideLayout:mobileGuideLayout,focusLayout:mobileFocusLayout,comparison:{before:mobileBefore,after:mobileAfter,sameCamera:true},focus:{before:mobileFocusBefore,focused:mobileFocused,returned:mobileReturned},nativeButtons:true,reducedMotionBrowserContext:'Not run separately; reduced-motion app logic is covered by the local simulation suite'};
    report.scope='Actual sandboxed Chromium/WebGL rendering and native comparison/focus/guide buttons, including a 390x844 viewport. Camera review poses explicitly fixed; animated objects are not time-locked between paired screenshots. Not full-tour smoothness, physical GPU or realism acceptance.';
    report.passed=report.pageErrors.length===0&&report.consoleErrors.length===0&&report.failedRequests.length===0&&report.httpErrors.length===0&&report.animation.positionsChanged&&!report.actualCanvas.contextLost;
    if(!report.passed)throw Error('Runtime error, failed request, lost context or unchanged animation; inspect evidence');
  }
}catch(e){report.error=String(e?.stack||e);report.passed=false;console.error(report.error);if(mode==='probe'&&process.env.GITHUB_OUTPUT)await fs.appendFile(process.env.GITHUB_OUTPUT,'available=false\n');if(mode==='render')process.exitCode=1;}
finally{await save();await context?.close().catch(()=>{});await browser?.close().catch(()=>{});}
