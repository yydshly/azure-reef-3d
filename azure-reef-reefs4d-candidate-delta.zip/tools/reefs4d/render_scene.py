import bpy,pathlib,math,json,os
from mathutils import Vector,Quaternion
base=pathlib.Path(os.environ['REEFS4D_WORK_DIR']);repo=pathlib.Path(__file__).resolve().parents[2];out=base/'qa'
def coord(v):return (v[0],-v[2],v[1])
def load(path):
 before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(path));return list(set(bpy.data.objects)-before)
def group(objs,name,pos=(0,0,0),yaw=0,scale=1):
 e=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(e)
 for o in objs:
  if o.parent not in objs:o.parent=e
 e.location=coord(pos);e.rotation_euler.z=yaw;e.scale=(scale,)*3;return e
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
load(repo/'dist/assets/models/68e02c88ba14a2c2/reef.gltf')
for o in list(bpy.data.objects):
 if o.name.startswith('Coral_Staghorn_Thicket_') and int(o.name.split('_')[-1]) not in [0,1,3,12,16]:bpy.data.objects.remove(o,do_unlink=True)
for name,down in [('Corridor_Distant_Linked_03',.12711730762552115),('Depth_Staghorn_Linked_01_1',.10224513179842109)]:
 o=bpy.data.objects.get(name)
 if o:o.location.z-=down
for name,p,yaw,omit in [('NearLeft',[-4.8,.09174240518222349,-10],1.3,'Attached_small_fan_form'),('FarRight',[3.5,-.015196346640586854,-44],1.3,'Attached_reticulate_fan_form'),('Middle',[-4.8,-.06576677229367059,-26],-.2,None)]:
 objs=load(repo/'dist/assets/inhabited/bf93ec504f8f2fc3/pilot.glb')
 for o in list(objs):
  if omit and o.name.startswith(omit):objs.remove(o);bpy.data.objects.remove(o,do_unlink=True)
 group(objs,'Inhabited_'+name,p,yaw)
group(load(repo/'dist/assets/specimens/fe5fc88fe1bb4ae6/skeleton.glb'),'Skeleton',[-.4,-.03827932751178741,-6.5],math.radians(25))
scan_objs=load(repo/'dist/assets/reefs4d/C12019-web.glb')
cfg=json.loads((out/'scene-transform.json').read_text());scan=group(scan_objs,'Scan',cfg['position'],cfg['yaw'],cfg['scale'])
sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.samples=16;sc.cycles.use_denoising=False;sc.render.resolution_x=1440;sc.render.resolution_y=960;sc.render.resolution_percentage=100;sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs[0].default_value=(.045,.13,.18,1);sc.world.node_tree.nodes['Background'].inputs[1].default_value=.65;sc.view_settings.view_transform='AgX'
ld=bpy.data.lights.new('Sun','SUN');lo=bpy.data.objects.new('Sun',ld);sc.collection.objects.link(lo);lo.rotation_euler=(.25,-.5,-.3);ld.energy=2;ld.angle=.2
ld=bpy.data.lights.new('Fill','AREA');lo=bpy.data.objects.new('Fill',ld);sc.collection.objects.link(lo);lo.location=(0,0,15);ld.energy=1400;ld.size=20
camd=bpy.data.cameras.new('Same_camera');cam=bpy.data.objects.new('Same_camera',camd);sc.collection.objects.link(cam);camd.lens=27.6;camd.sensor_width=36;camd.clip_start=.12;camd.clip_end=140;sc.camera=cam
views=cfg.get('views',[{'name':'ordinary','position':[1.5,2.1,4.8],'target':[-.5,.8,-6]}])
for view in views:
 cam.location=coord(view['position']);cam.rotation_euler=(Vector(coord(view['target']))-cam.location).to_track_quat('-Z','Y').to_euler()
 for show in [False,True]:
  for o in scan_objs:o.hide_render=not show
  sc.render.filepath=str(out/(view['name']+('-after.png' if show else '-before.png')));bpy.ops.render.render(write_still=True)
print('SCENE_RENDER_COMPLETE')
