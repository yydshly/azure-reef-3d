# Reefs4D C12019 conversion

Use the already installed Blender 4.3.2, Python 3 with NumPy, and a separate work directory outside the repository. No model scripts are executed: the PLY is read as numeric data, with triangle and UV counts validated; Blender starts with `--factory-startup --disable-autoexec`.

Set `REEFS4D_WORK_DIR` to that work directory. Create `originals/` and `qa/` inside it. Download only the two named files from the official record https://zenodo.org/records/14616671 and preserve them unchanged:

- C12019.ply: 81,489,593 bytes, MD5 98800f508c13c344d930e4d888fdcefe
- C12019.jpg: 2,644,512 bytes, MD5 1103bac52cffb192b832ffc49808ac83

Run `python tools/reefs4d/inspect_scan.py`, then `blender -b --factory-startup --disable-autoexec --python tools/reefs4d/convert_scan.py` from this repository. The first writes numerical inspection and an NPZ into the work directory; the second renders original/derived meshes from the same camera, applies a collapse decimation targeting 150,000 triangles, writes the web GLB into this repository, and retains a derived Blender file in the work directory.

The current asset contains 149,822 triangles and 138,370 exported vertices including UV splits. Original per-face UVs are imported and interpolated by the decimator. The source JPEG is embedded without re-encoding (its MD5 matches the original). Geometry is recentered and converted from assumed Z-up to standard glTF Y-up. No crop, repair, axis stretch, texture repaint, or repeat tiling is applied. Raw source units are unverified; the UI's uniform 2.3 placement scale is a visual demonstration choice.

Review original and web previews, numerical inspection, topology boundaries, and the integrated same-camera comparison before release. Offline renders do not establish browser rendering, interaction, or device performance. The source scan is an open capture, not a watertight solid; visible survey targets belong to the photographic atlas.

Reefs4D v3 by Matan Yuval and Tali Treibitz is CC BY-NC 2.0. This candidate is a noncommercial technical visualization. Preserve author, title, version, source, license and modification attribution with the asset. It does not change licenses of other project assets.
