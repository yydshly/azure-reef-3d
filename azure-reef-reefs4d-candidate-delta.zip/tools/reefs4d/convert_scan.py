import bpy,numpy as np,pathlib,json,math,time,os,struct,hashlib
from mathutils import Vector
base=pathlib.Path(os.environ['REEFS4D_WORK_DIR'])
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
d=np.load(base/'qa/parsed-scan.npz');v=d['v'];tri=d['tri'];uv=d['uv'];center=(v.min(0)+v.max(0))/2;v=v-center
me=bpy.data.meshes.new('C12019_original_UV');me.vertices.add(len(v));me.vertices.foreach_set('co',v.ravel());me.loops.add(tri.size);me.loops.foreach_set('vertex_index',tri.ravel());me.polygons.add(len(tri));me.polygons.foreach_set('loop_start',np.arange(len(tri),dtype=np.int32)*3);me.polygons.foreach_set('loop_total',np.full(len(tri),3,dtype=np.int32));me.uv_layers.new(name='Original_per_face_UV').data.foreach_set('uv',uv.ravel());me.update()
o=bpy.data.objects.new('Reefs4D_C12019',me);bpy.context.collection.objects.link(o);bpy.context.view_layer.objects.active=o;o.select_set(True)
m=bpy.data.materials.new('C12019_photographic_texture');m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=.9;tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(base/'originals/C12019.jpg'));m.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color']);o.data.materials.append(m)
# No repair, crop, arbitrary axis stretch or texture paint. Source Z assumed vertical for preview only.
sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.samples=12;sc.cycles.use_denoising=False;sc.render.resolution_x=1200;sc.render.resolution_y=900;sc.render.resolution_percentage=100;sc.world.color=(.16,.16,.16);sc.view_settings.view_transform='Standard'
camd=bpy.data.cameras.new('Inspection');cam=bpy.data.objects.new('Inspection',camd);sc.collection.objects.link(cam);cam.location=(4,-5,4);cam.rotation_euler=(-cam.location).to_track_quat('-Z','Y').to_euler();camd.type='ORTHO';camd.ortho_scale=4.8;sc.camera=cam
for loc,power,size in [((1,-3,6),650,5),((-4,1,3),350,4)]:
 ld=bpy.data.lights.new('Inspection softbox','AREA');lo=bpy.data.objects.new('Inspection softbox',ld);sc.collection.objects.link(lo);lo.location=loc;lo.rotation_euler=(-lo.location).to_track_quat('-Z','Y').to_euler();ld.energy=power;ld.shape='DISK';ld.size=size
sc.render.filepath=str(base/'qa/source-textured-preview.png');bpy.ops.render.render(write_still=True)
original_faces=len(me.polygons);mod=o.modifiers.new('Web_budget_150k','DECIMATE');mod.ratio=150000/original_faces;mod.use_collapse_triangulate=True;bpy.ops.object.modifier_apply(modifier=mod.name)
sc.render.filepath=str(base/'qa/web-textured-preview.png');bpy.ops.render.render(write_still=True)
bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
out=pathlib.Path(__file__).resolve().parents[2]/'dist/assets/reefs4d';out.mkdir(parents=True,exist_ok=True)
bpy.ops.export_scene.gltf(filepath=str(out/'C12019-web.glb'),export_format='GLB',use_selection=True,export_image_format='JPEG',export_jpeg_quality=90,export_yup=True,export_extras=True)
blob=(out/'C12019-web.glb').read_bytes();json_length=struct.unpack_from('<I',blob,12)[0];gltf=json.loads(blob[20:20+json_length]);binary=blob[28+json_length:];view=gltf['bufferViews'][gltf['images'][0]['bufferView']];offset=view.get('byteOffset',0);embedded=binary[offset:offset+view['byteLength']]
assert hashlib.md5(embedded).hexdigest()=='1103bac52cffb192b832ffc49808ac83', 'Texture bytes changed; review conversion before release'
r={'source_center_removed':center.tolist(),'source_axes':'Unchanged before standard Blender Z-up to glTF Y-up export','source_faces':original_faces,'web_faces':len(o.data.polygons),'web_vertices':len(o.data.vertices),'decimation':'Blender 4.3.2 collapse, target 150000 triangles, triangulate; original per-face UV interpolation','texture':'Original 4096x4096 JPEG atlas embedded byte-for-byte, MD5 verified; no resize, recolor or repaint','crop':'none','repair':'none','scale':'No geometric scaling in asset; metric interpretation unverified','preview':'Offline Cycles 12 samples, same camera and light, not browser screenshots'}
(base/'qa/conversion.json').write_text(json.dumps(r,indent=2));print('CONVERSION',json.dumps(r));bpy.ops.wm.save_as_mainfile(filepath=str(base/'qa/C12019-web.blend'))
