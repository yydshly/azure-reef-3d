import vtk,numpy as np,json,struct,pathlib,os
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
base=pathlib.Path(os.environ['REEFS4D_WORK_DIR']);d=np.load(base/'qa/parsed-scan.npz');sv=d['v'];sf=d['tri'];center=(sv.min(0)+sv.max(0))/2;sv=sv-center
b=(pathlib.Path(__file__).resolve().parents[2]/'dist/assets/reefs4d/C12019-web.glb').read_bytes();l=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+l]);binary=b[28+l:]
def acc(i):
 a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];n={'SCALAR':1,'VEC3':3,'VEC2':2}[a['type']];return np.frombuffer(binary,dtype=dtype,count=a['count']*n,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,n)
p=j['meshes'][0]['primitives'][0];wv=acc(p['attributes']['POSITION']);wv=np.stack([wv[:,0],-wv[:,2],wv[:,1]],1);wf=acc(p['indices']).reshape(-1,3)
def locator(v,f):
 pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(v,deep=True));ca=vtk.vtkCellArray();ca.SetCells(len(f),numpy_to_vtkIdTypeArray(np.column_stack([np.full(len(f),3),f]).astype(np.int64).ravel(),deep=True));pd=vtk.vtkPolyData();pd.SetPoints(pts);pd.SetPolys(ca);loc=vtk.vtkStaticCellLocator();loc.SetDataSet(pd);loc.BuildLocator();return loc
rng=np.random.default_rng(42)
def sample(v,f,n):
 t=v[f];area=np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1);pick=rng.choice(len(f),n,p=area/area.sum());r=rng.random((n,2));s=np.sqrt(r[:,0]);return (1-s[:,None])*t[pick,0]+(s*(1-r[:,1]))[:,None]*t[pick,1]+(s*r[:,1])[:,None]*t[pick,2]
def distances(points,loc):
 ds=[]
 for pt in points:
  near=[0.,0.,0.];cell=vtk.reference(0);sub=vtk.reference(0);dist=vtk.reference(0.);loc.FindClosestPoint(pt,near,cell,sub,dist);ds.append(float(dist)**.5)
 return np.array(ds)
r={}
for name,a,v,f in [('source_to_web',sample(sv,sf,10000),wv,wf),('web_to_source',sample(wv,wf,10000),sv,sf)]:
 ds=distances(a,locator(v,f));r[name]={'samples':len(ds),'median_raw_units':float(np.median(ds)),'p95_raw_units':float(np.quantile(ds,.95)),'max_sampled_raw_units':float(ds.max()),'rms_raw_units':float(np.sqrt((ds**2).mean()))}
r['method']='Area-weighted deterministic samples, closest triangle via vtkStaticCellLocator, source centering and exact axis conversion undone; no assumed meters; sampled not Hausdorff bound.';(base/'qa/geometric-fidelity.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
