import numpy as np,json,pathlib,hashlib,os
p=pathlib.Path(os.environ['REEFS4D_WORK_DIR'])/'originals/C12019.ply'
assert p.stat().st_size == 81489593, 'Unexpected PLY size'
assert hashlib.md5(p.read_bytes()).hexdigest() == '98800f508c13c344d930e4d888fdcefe', 'PLY hash mismatch'
texture=p.with_suffix('.jpg')
assert hashlib.md5(texture.read_bytes()).hexdigest() == '1103bac52cffb192b832ffc49808ac83', 'Texture hash mismatch'
with p.open('rb') as f:
 h=b''
 while not h.endswith(b'end_header\n'):h+=f.readline()
 v=np.fromfile(f,dtype='<f4',count=926606*3).reshape(-1,3)
 d=np.dtype([('n','u1'),('v','<i4',(3,)),('nu','u1'),('uv','<f4',(6,))]);t=np.fromfile(f,dtype=d,count=1851841)
r={'header':h.decode(),'vertices':len(v),'faces':len(t),'bounds':[v.min(0).tolist(),v.max(0).tolist()],'extent':np.ptp(v,axis=0).tolist(),'finite_vertices':bool(np.isfinite(v).all()),'finite_uv':bool(np.isfinite(t['uv']).all()),'uv_range':[float(t['uv'].min()),float(t['uv'].max())],'triangle_counts':np.unique(t['n']).tolist(),'uv_counts':np.unique(t['nu']).tolist(),'invalid_indices':int(((t['v']<0)|(t['v']>=len(v))).sum()),'zero_area_faces':int((np.linalg.norm(np.cross(v[t['v'][:,1]]-v[t['v'][:,0]],v[t['v'][:,2]]-v[t['v'][:,0]]),axis=1)<1e-12).sum())}
print(json.dumps(r,indent=2));(p.parent.parent/'qa/source-inspection.json').write_text(json.dumps(r,indent=2));np.savez(p.parent.parent/'qa/parsed-scan.npz',v=v,tri=t['v'],uv=t['uv'])
