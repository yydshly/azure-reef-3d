import pathlib,json,hashlib,zipfile,shutil
here=pathlib.Path(__file__).parent;dist=pathlib.Path('dist');sha=lambda b:hashlib.sha256(b).hexdigest()
def inv(root):
 assert root.is_dir() and not any(p.is_symlink() for p in root.rglob('*'))
 return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
old=dist/'preview/reef-field-candidate';r=json.loads((here/'field-preservation.json').read_text());assert inv(old)=={f['path']:f['sha256'] for f in r['sourceFiles']}
p=pathlib.Path('.habitat-inputs/field-gallery-95db4be1.zip');b=p.read_bytes();assert len(b)==r['archive']['bytes'] and sha(b)==r['archive']['sha256']
with zipfile.ZipFile(p) as z:
 assert len(z.namelist())==len(set(z.namelist()))==7 and set(z.namelist())==set(r['files'])
 for n,f in r['files'].items():
  rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];p=old/n;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
before=inv(dist);assert len(before)==772;pathlib.Path('.habitat-protected.json').write_text(json.dumps(before,sort_keys=True));new=dist/'preview/habitat-enrichment-candidate';assert not new.exists();shutil.copytree(old,new);(new/'current-scene.html').unlink();shutil.rmtree(new/'assets/current-scene')
m=json.loads((here/'habitat-contract.json').read_text());archive=pathlib.Path('.habitat-inputs/habitat-code-delta.zip');b=archive.read_bytes();assert len(b)==238953 and sha(b)=='b95951cf803b5a40c42d8a90f5e3f2285820331e5f87ea06d2963ed41edd48b5'
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==3 and set(z.namelist())=={'page/'+f['file'] for f in m['files']}
 for f in m['files']:
  n=f['file'];p=new/n
  if f['baselineSha256']:assert sha(p.read_bytes())==f['baselineSha256']
  else:assert not p.exists()
  b=z.read('page/'+n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];p.write_bytes(b)
# Keep every world import on one exact module URL in this new candidate path.
for n in ['scan-exhibit.js','scan-route.js','scan-assemblage.js']:
 p=new/n;s=p.read_text();a='./scan-world.js?v=animal-scale-20261010-r1';assert s.count(a)==1;p.write_text(s.replace(a,'./scan-world.js?v=habitat-20261010-r1'))
p=new/'scan-exhibit.html';s=p.read_text();a='scan-exhibit.js?v=field-runtime-local-r1';assert s.count(a)==1;s=s.replace(a,'scan-exhibit.js?v=habitat-20261010-r1');s=s.replace('</h1>',' · 生态衔接实验</h1>',1).replace('<title>连续礁区实验候选 · 浅蓝</title>','<title>生态衔接实验候选 · 浅蓝</title>');p.write_text(s)
source=[{'path':n,'bytes':(new/n).stat().st_size,'sha256':h} for n,h in sorted(inv(new).items())];assert len(source)==139
version=sha(json.dumps(source,sort_keys=True).encode()+(here/'browser-check-habitat.mjs').read_bytes());pathlib.Path('.habitat-build.json').write_text(json.dumps({'root':str(new),'contentVersion':version,'sourceFiles':source,'sourceArchiveSha256':sha(archive.read_bytes())},indent=2));print('HABITAT_STAGED',json.dumps({'sourceFiles':len(source),'oldFiles':772,'contentVersion':version}))
