// Use only from the approved publisher's existing browser. Read-only diagnostics;
// temporarily hooks onAfterRender, restoring each callback in finally.
// Usage: const report=await inspectHabitatPage(page, JSON.parse(await readFile(fixture)));
export async function inspectHabitatPage(page, fixture){
 return page.evaluate(async fixture=>{
  const e=window.reefExhibit;if(!e?.world?.habitat)throw Error('Missing habitat API');
  const hash=async a=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new Uint8Array(a.buffer,a.byteOffset,a.byteLength)))].map(v=>v.toString(16).padStart(2,'0')).join('');
  const array=async a=>({type:a.constructor.name,length:a.length,bytes:a.byteLength,sha256:await hash(a)});
  const issues=[],batches=e.world.habitat.batches,actual=[];
  for(const expected of fixture.meshes){const m=batches.find(m=>m.name===expected.name);if(!m){issues.push('Missing '+expected.name);continue;}const attributes={};for(const[name,a]of Object.entries(m.geometry.attributes))attributes[name]={itemSize:a.itemSize,normalized:a.normalized,...await array(a.array)};
   const result={name:m.name,count:m.count,index:await array(m.geometry.index?.array||new Uint16Array()),attributes,instanceMatrix:await array(m.instanceMatrix.array),instanceColor:await array(m.instanceColor.array),material:{type:m.material.type,roughness:m.material.roughness,side:m.material.side,vertexColors:m.material.vertexColors},triangles:(m.geometry.index?.count||m.geometry.attributes.position.count)/3*m.count};actual.push(result);if(JSON.stringify(result)!==JSON.stringify(expected))issues.push('Typed array/material fixture mismatch '+m.name);
  }
  if(batches.length!==fixture.meshCount)issues.push('Unexpected habitat batch count');
  const visible=o=>{for(let p=o;p;p=p.parent)if(!p.visible)return false;return true;};
  function stats(onlyVisible){const geometries=new Set(),materials=new Set(),buffers=new Set();let meshes=0,instances=0,batches=0,triangles=0,points=0,geometryBytes=0,instanceBytes=0;
   e.scene.traverse(o=>{if(onlyVisible&&!visible(o))return;if(!o.isMesh&&!o.isPoints&&!o.isLine)return;const g=o.geometry;if(!g)return;geometries.add(g);for(const m of(Array.isArray(o.material)?o.material:[o.material]))if(m)materials.add(m);
    if(o.isMesh){meshes++;const n=o.isInstancedMesh?o.count:g.isInstancedBufferGeometry?g.instanceCount:1;instances+=n;if(o.isInstancedMesh||g.isInstancedBufferGeometry)batches++;triangles+=(g.index?.count||g.attributes.position.count)/3*n;}
    if(o.isPoints)points+=g.attributes.position.count;
    for(const a of [g.index,...Object.values(g.attributes),...Object.values(g.morphAttributes).flat()])if(a?.array&&!buffers.has(a.array)){buffers.add(a.array);geometryBytes+=a.array.byteLength;}
    for(const a of[o.instanceMatrix,o.instanceColor])if(a?.array&&!buffers.has(a.array)){buffers.add(a.array);instanceBytes+=a.array.byteLength;}
   });return{meshObjects:meshes,logicalMeshInstances:instances,instancedBatches:batches,geometryResources:geometries.size,materialResources:materials.size,sceneTriangleBudget:triangles,pointVertices:points,typedGeometryBytes:geometryBytes,typedInstanceBytes:instanceBytes};
  }
  const gl=e.renderer.getContext(),bindings={},old=batches.map(m=>({m,after:m.onAfterRender}));
  for(const {m,after}of old)m.onAfterRender=function(...args){after.apply(this,args);const p=gl.getParameter(gl.CURRENT_PROGRAM),sh=gl.getAttachedShaders(p),vs=sh.find(s=>gl.getShaderParameter(s,gl.SHADER_TYPE)===gl.VERTEX_SHADER),fs=sh.find(s=>gl.getShaderParameter(s,gl.SHADER_TYPE)===gl.FRAGMENT_SHADER),vertex=gl.getShaderSource(vs),fragment=gl.getShaderSource(fs);const location=gl.getUniformLocation(p,'exhibitOceanMode');bindings[m.name]={linked:gl.getProgramParameter(p,gl.LINK_STATUS),compiled:sh.every(s=>gl.getShaderParameter(s,gl.COMPILE_STATUS)),standardPBR:fragment.includes('reflectedLight.directDiffuse')&&fragment.includes('roughness'),waterVertex:vertex.includes('vExhibitWorld')&&vertex.includes('instanceMatrix'),waterFragment:fragment.includes('exhibitOceanMode')&&fragment.includes('exhibitCaustics')&&fragment.includes('transmission'),waterMode:location===null?null:gl.getUniform(p,location),vertexColorExpected:m.material.vertexColors,vertexColorShader:vertex.includes('vColor'),error:gl.getError()};};
  let receipt;try{receipt=await e.observeNextRender(r=>({receipt:r,render:{...e.renderer.info.render},memory:{...e.renderer.info.memory},programs:e.renderer.info.programs.length}));}finally{for(const {m,after}of old)m.onAfterRender=after;}
  for(const m of batches){const b=bindings[m.name];if(!b)issues.push('Batch not drawn at current camera '+m.name);else if(!b.linked||!b.compiled||!b.standardPBR||!b.waterVertex||!b.waterFragment||b.waterMode!==1||b.error!==0)issues.push('PBR/water binding failure '+m.name);}
  return {issues,fixture:actual,attachedScene:stats(false),visibleScene:stats(true),bindings,frame:receipt,habitat:e.world.habitat.getState(),field:e.continuousField.getState(),limits:['Scene statistics count attached/visible scene objects, not all retained renderer allocations or culled draw cost.','renderer.info.memory counts resources, not VRAM bytes. Typed byte totals exclude textures, driver copies, framebuffers and overhead.','Draw receipt is actual WebGL submission at the selected camera; not device FPS or mobile testing.']};
 },fixture);
}
