"""Restore the exact latest publication, protect 1969 bytesets, add 149 sources."""
from enriched_common import *


def stage(c):
    require(not (DIST / c['candidatePath']).exists(), 'Candidate destination exists')
    require(not any(pathlib.Path(n).exists() for n in ('.enriched-protected.json', '.enriched-baseline.json', '.enriched-build.json')), 'Stage already attempted')
    before = inventory(DIST)
    protected = assembly_protection(c)
    staged = {c['basePath'] + '/' + f['path']: f['sha256'] for f in c['baseSourceFiles']}
    staged.update({f['path']: f['sha256'] for f in c['stagedEntryFiles']})
    require(not set(staged) & set(protected) and before == dict(protected, **staged) and len(before) == c['oldAssemblyFiles'], 'Exact previous 1966-file staging output required')
    restore = snapshot(c)
    delta = checked_archive(INPUTS / c['codeArchive']['path'], c['codeArchive'], {f['path']: f for f in c['changes']})
    require(all(n in c['mutableEntryPaths'] or n not in before for n in restore), 'Snapshot collision outside three world products')
    baseline = dict(before, **{n: sha(b) for n, b in restore.items()})
    require(baseline == baseline_hashes(c), 'Snapshot cannot reproduce exact latest 1972-file publication')
    candidate = {n: (DIST / c['basePath'] / n).read_bytes() for n in c['baseSourceHashes']}
    candidate.update(delta)
    require({n: sha(b) for n, b in candidate.items()} == c['sourceHashes'], 'Candidate source bytes mismatch')
    # All archive, source, collision and restoration checks precede public writes.
    for n, b in restore.items():
        p = DIST / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
    require(inventory(DIST) == baseline, 'Published baseline restoration failed')
    save_json('.enriched-baseline.json', baseline)
    protected = {n: h for n, h in baseline.items() if n not in c['mutableEntryPaths']}
    require(len(protected) == c['protectedFiles'], 'Expected 1969 protected old files')
    save_json('.enriched-protected.json', protected)
    for n, b in candidate.items():
        p = DIST / c['candidatePath'] / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
    save_json('.enriched-build.json', {'schemaVersion': 1, 'state': 'STAGED_OLD_WORLD_POINTER_UNCHANGED', 'sourceHashAggregate': c['sourceHashAggregate'], 'sourceFiles': 149, 'oldSiteFiles': 1972, 'protectedFiles': 1969})
    check_sources(c)
    protected, current = check_old(c)
    require(set(current) - set(protected) == candidate_sources(c) | set(c['mutableEntryPaths']) and len(current) == c['stagedSiteFiles'], 'Unexpected stage output')
    print('EXPLORATION_STAGED', json.dumps({'oldSiteFiles': 1972, 'protectedFiles': 1969, 'candidateSourceFiles': 149, 'unchangedSources': 143, 'sourceHashAggregate': c['sourceHashAggregate']}))


if __name__ == '__main__':
    stage(contract())
