"""Package three actual tour frames and numeric evidence after bounded browser QA."""
import html
import sys
from enriched_common import *

FRAME_COLUMNS = ['rafMs', 'sequence', 'phase', 'mode', 'paused', 'elapsed', 'x', 'y', 'z', 'yaw', 'pitch', 'speed', 'heldMask', 'region', 'hidden']


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def validate_draw(binding):
    require(binding['draws'] > 0 and binding['glError'] == 0 and binding['linked'] is True and binding['compiled'] is True, 'Actually submitted material failed draw/compile/link checks')


def validate_pbr_binding(binding):
    validate_draw(binding)
    require(binding['materialType'] == 'MeshStandardMaterial' and all(binding[k] is True for k in ('standardPBR', 'waterVertex', 'waterFragment', 'continuousWater', 'deepTransmission')), 'Actually submitted enriched material failed strict water/PBR checks')
    u = binding['oceanUniforms']
    require(all(u[k] is True for k in ('modeActive', 'timeActive', 'causticsActive')) and u['mode'] == 1 and finite(u['time']) and isinstance(u['caustics'], int) and not isinstance(u['caustics'], bool) and u['caustics'] >= 0, 'Actual ocean uniform binding invalid')


def validate_material_binding(binding):
    names = binding['meshNames']
    require(isinstance(names, list) and names and all(isinstance(n, str) for n in names), 'Material binding has no actual mesh names')
    require('Extended_Overhead_Water' not in names, 'Deleted overhead water object must not be submitted')
    validate_pbr_binding(binding)


def validate_material_bindings(bindings, require_pbr=False):
    require(isinstance(bindings, list), 'Material submission list missing')
    for binding in bindings:
        validate_material_binding(binding)
    require(not require_pbr or bool(bindings), 'New-world middle/final stage must actually submit strict PBR geometry')


def validate_ocean_bindings(bindings):
    require(isinstance(bindings, list) and any(b['name'] == 'Synthetic_Water_Volume' for b in bindings), 'Actual water envelope submission missing')
    for b in bindings:
        validate_draw(b)
        if b['name'] == 'Synthetic_Water_Volume':
            require(b['materialType'] == 'ShaderMaterial' and b['materialProperties'] == {'transparent': False, 'opacity': 1, 'side': 1, 'depthWrite': False}, 'Water volume material changed')
            require(all(b[k] is True for k in ('continuousWater', 'toneMapping', 'colorSpace')), 'Continuous envelope shader absent')
        elif b['name'] == 'Synthetic_Receding_Sand':
            validate_pbr_binding(b)
            require(b['sandEdge'] is True, 'Actual original sand edge shader absent')
        elif b['name'] == 'Synthetic_Overhead_Surface':
            require(b['materialType'] == 'ShaderMaterial' and b['materialProperties'] == {'transparent': True, 'opacity': .6, 'side': 2, 'depthWrite': False}, 'Original surface material changed')
            require(all(b[k] is True for k in ('surfaceEdgeFade', 'toneMapping', 'colorSpace')), 'Actual original surface edge fade absent')
        else:
            require(False, 'Unexpected ocean binding: ' + str(b['name']))


def validate_collisions(collision):
    def snapshot(s, full=False):
        r, a = s['reported'], s['actual']
        require(r['source'] == 'live-world-obstacles-plus-scan-anchors', 'Collision source is not the live obstacle list')
        require(all(isinstance(a[k], int) and not isinstance(a[k], bool) and a[k] >= 0 for k in ('worldCount', 'scanCount')), 'Invalid collision counts')
        require(r['worldCount'] == a['worldCount'] and r['scanCount'] == a['scanCount'] and r['total'] == a['worldCount'] + a['scanCount'], 'Live collision reported/actual counts differ')
        require(r['worldNames'] == a['worldNames'] and len(a['worldNames']) == a['worldCount'] == len(a['boxes']), 'Live collision membership differs from actual scene')
        require(all(isinstance(n, str) for n in a['worldNames']) and [b['name'] for b in a['boxes']] == a['worldNames'], 'Collision boxes do not match obstacle names')
        for b in a['boxes']:
            require(len(b['min']) == len(b['max']) == 3 and all(finite(v) for v in b['min'] + b['max']) and all(v <= b['max'][i] for i, v in enumerate(b['min'])), 'Invalid live collision box')
        if full:
            require([r['worldCount'], r['scanCount'], r['total']] == [54, 2, 56], 'Ready collision coverage must include 54 live world and two scan anchors')
            names = r['worldNames']
            require(sum(n.startswith('Ridge_') for n in names) == 3 and sum(n.startswith('RearConnected_') for n in names) == 6 and names.count('Local_Grounded_Scan_Derived_Shoulder') == 1, 'Late-loaded collision groups missing')
        return r

    for name in ('ready', 'field', 'restored'):
        value = collision[name]
        require(isinstance(value['samples'], list) and value['samples'], 'Natural collision samples missing')
        for s in value['samples']:
            snapshot(s)
        snapshot(value['current'], True)
    ready = collision['ready']
    late_observed = any(s['loading']['layeredRidges'] != 'ready' and s['reported']['worldCount'] < 54 for s in ready['samples'])
    c1_observed = any(s['reported']['scanCount'] == 1 for s in ready['samples'])
    # Startup intermediates can complete between real RAF callbacks. Report
    # actual observation honestly; never force delays or fail for missed history.
    require(collision['readyValidation'] == {'matchingLiveWorld': True, 'lateLoadObserved': late_observed, 'c1BeforeC4Observed': c1_observed, 'startupHistory': 'OBSERVED' if late_observed and c1_observed else 'NOT_OBSERVED_NO_ARTIFICIAL_DELAY', 'worldCount': 54, 'scanCount': 2, 'total': 56, 'source': 'live-world-obstacles-plus-scan-anchors'}, 'Collision readiness observation claims mismatch')
    toggle = collision['toggle']
    before, off, on = snapshot(toggle['before'], True), snapshot(toggle['off']), snapshot(toggle['on'], True)
    require(toggle['removedAndRestored'] is True and sorted(off['worldNames']) != sorted(before['worldNames']) and sorted(on['worldNames']) == sorted(before['worldNames']), 'Native layer toggle did not remove and restore live collision membership')
    require(not any(n.startswith('Ridge_') or n.startswith('RearConnected_') or n == 'Local_Grounded_Scan_Derived_Shoulder' for n in off['worldNames']), 'Layer OFF retained late layer collision proxies')
    require(toggle['removedNames'] == [n for n in before['worldNames'] if n not in off['worldNames']] and toggle['addedNames'] == [n for n in off['worldNames'] if n not in before['worldNames']], 'Collision toggle delta mismatch')
    require(collision['registrationValidation'] == {'lateRegistrationVerified': True, 'evidence': 'native-layer-off-on', 'removedAndRestored': True, 'removedNames': toggle['removedNames'], 'addedNames': toggle['addedNames']}, 'Native live-registration proof missing')
    require(sorted(collision['restored']['current']['reported']['worldNames']) == sorted(ready['current']['reported']['worldNames']), 'Field restoration changed collision membership')


def validate_timeline(path, record, segment='all'):
    require(segment in ('all', 'tour', 'free-compat'), 'Unknown timeline segment')
    require(record['file'] == ('free-navigation-frames.jsonl' if segment == 'free-compat' else 'actual-navigation-frames.jsonl'), 'Unexpected timeline filename')
    p = pathlib.Path(path)
    require(p.is_file() and not p.is_symlink(), 'Missing/linked numeric timeline')
    data = p.read_bytes()
    validate_bytes(data, record, str(p))
    rows = [json.loads(line) for line in data.splitlines() if line.strip()]
    require(len(rows) == record['rows'] and len(rows) > (200 if segment == 'all' else 3), 'Incomplete numeric callback evidence')
    require(all(isinstance(r, list) and len(r) == 15 and all(finite(v) for v in r) for r in rows), 'Only finite numeric 15-column RAF rows accepted')
    require(all(b[0] > a[0] for a, b in zip(rows, rows[1:])), 'Actual RAF timestamps must strictly increase')
    if segment != 'tour':
        require(any(r[2] == 2 and r[8] < -60 for r in rows), 'Native free crossing did not finish')
    if segment != 'free-compat':
        require(any(r[2] == 5 and r[3] == 2 and r[5] == 72 for r in rows), 'Actual complete 72-second tour missing')
    tour = [r for r in rows if r[2] == 5 and r[3] in (1, 2)]
    require(segment == 'free-compat' or {int(r[13]) for r in tour} == {0, 1, 2}, 'Three natural tour regions missing')
    require(segment != 'tour' or all(r[2] in (1, 4, 5, 9, 8) for r in rows), 'Tour timeline contains another segment phase')
    require(segment != 'free-compat' or all(r[2] in (1, 2, 3, 6, 7, 8) for r in rows), 'Free/compat timeline contains tour phases')
    free_steps, active_tour, normal_moved, boosted_moved = 0, 0, 0, 0
    for a, b in zip(rows, rows[1:]):
        dt = (b[0] - a[0]) / 1000
        displacement = math.dist(a[6:9], b[6:9])
        require(b[1] >= a[1], 'Actual render receipt sequence reversed')
        if a[2] == b[2] and b[2] in (2, 3, 5) and displacement > 1e-7:
            require(b[1] > a[1], 'Camera moved without a fresh actual render receipt')
        if a[2] == b[2] and b[2] in (2, 3) and a[3] == b[3] == 0 and a[4] == b[4] == 0:
            speed = 12.6 if (int(a[12]) | int(b[12])) & 192 else 7
            require(displacement <= speed * min(.05, dt) + 1e-5 and b[11] <= speed + 1e-5, 'Free movement exceeds actual dt/speed bound')
            free_steps += 1
            if b[2] == 2:
                require(b[12] in (0, 1, 64, 65) and b[8] <= a[8] + 1e-7 and abs(b[6] - 4) < 1e-5 and abs(b[7] - 5) < 1e-5, 'Straight native crossing changed input, lane or direction')
                normal_moved += int(a[12] == b[12] == 1 and displacement > 1e-7)
                boosted_moved += int(a[12] == b[12] == 65 and displacement > 1e-7)
        if a[2] == b[2] == 5 and a[3] == 1 and b[3] in (1, 2):
            delta = b[5] - a[5]
            require(-1e-8 <= delta <= dt + .01, 'Tour elapsed invalid for actual callback delta')
            if a[4] == b[4] == 1:
                require(delta == 0 and displacement < 1e-8, 'Paused tour moved')
            active_tour += max(0, delta)
    if segment == 'free-compat':
        crossing = [r for r in rows if r[2] == 2]
        require(crossing[0][6:9] == [4, 5, 10] and normal_moved > 0 and boosted_moved > 0, 'Ordinary W then native boosted continuous crossing proof missing')
    require(segment != 'all' or free_steps >= 200, 'Incomplete native free progression')
    require(segment == 'free-compat' or active_tour > 70, 'Incomplete native tour progression')
    return data


SEGMENT_PHASES = {'tour': ['setup', 'tour-controls', 'tour-and-captures', 'replay', 'finalize'],
                  'free-compat': ['setup', 'free-crossing', 'directional-input', 'compatibility', 'responsive-reduced', 'finalize']}


def validate_segment_pair(c, reports):
    check_qa_segments(c, reports)


def validate_compatibility_payload(report):
    require(report['rawFreeReturn']['positionPreserved'] is True and [v['patch'] for v in report['rawViews']] == ['C1', 'C4'], 'Raw views and saved free return missing')
    field = report['fieldFrame']
    validate_ocean_bindings(field['oceanBindings'])
    validate_material_bindings(field['explorationBindings'])
    require(field['field']['displayTriangles'] == 4000000 and field['fieldBinding']['instances'] == 1000000 and field['fieldBinding']['linked'] is True and field['fieldBinding']['compiled'] is True and field['fieldBinding']['glError'] == 0, 'One actual complete field render missing')
    require(field['receipt']['sequence'] > field['previousSequence'] and field['graphics']['readPixelsInRenderObserver'] is True and field['graphics']['pixelError'] == 0 and field['graphics']['sampleColors'] >= 2 and field['graphics']['render']['calls'] > 0, 'Actual same-stack field render missing')
    require(report['restoredBudget']['exploration']['disposed'] is False and report['pausedIdle']['unchanged'] is True and report['pauseResume']['ambientAdvanced'] is True, 'Restoration and idle/clock proof missing')
    narrow = report['narrow']
    require([narrow['width'], narrow['height']] == [390, 740] and narrow['overflow'] is False and all(v['hit'] is True for v in narrow['rectangles'] if v['id'] != 'scanCanvas'), 'Narrow control proof missing')
    closed = ['scanCanvas', 'startTour', 'pauseNavigation', 'hudMoreSummary', 'swimForward']
    opened = ['exploreRoute', 'resetExhibit', 'pauseAmbient', 'swimBack', 'strafeLeft', 'strafeRight', 'turnLeft', 'turnRight', 'rise', 'descend', 'closeHudMore']
    require([v['id'] for v in narrow['rectangles']] == closed + opened and narrow['disclosureClosedByTouch'] is True, 'Exact compact HUD controls and native touch close proof required')
    for v in narrow['rectangles']:
        require(v['disclosurePhase'] == ('closed' if v['id'] in closed else 'open') and all(finite(v[k]) for k in ('x', 'y', 'width', 'height')) and v['width'] > 0 and v['height'] > 0 and v['x'] >= -1 and v['y'] >= -1 and v['x'] + v['width'] <= 391 and v['y'] + v['height'] <= 741, 'Compact HUD control clipped or measured in wrong disclosure phase')
    require(report['reduced']['emulated'] is True and report['reduced']['noAutomaticMovement'] is True and report['reduced']['next']['elapsed'] == 14.4, 'Actual reduced-motion next-stop proof missing')


def validate_segment(c, report, evidence, segment):
    require(report.get('schemaVersion') == 2 and report.get('segment') == segment and report.get('status') == 'PASS' and report.get('syntheticFixture') is False, 'Genuine complete browser segment PASS required')
    require(report['sourceIdentity'] == source_identity(c), 'Browser source identity mismatch')
    require(report['errors'] == [] and report['failures'] == [], 'Browser report contains errors/failures')
    require(report['browser']['sandbox'] is True and report['browser']['forbiddenFlagsAbsent'] is True, 'Supported sandbox/graphics proof missing')
    require(report['servedSourceHashes'] == c['sourceHashes'], 'All 149 served source hashes required')
    if segment == 'free-compat':
        validate_collisions(report['collision'])
    require(report['thresholds'] == {'sourceFiles': 149, 'totalBudgetMs': 450000, 'pngTimeoutMs': 25000, 'tourSeconds': 72, 'freeCrossingZ': -60, 'freeSpeed': 7, 'freeBoostSpeed': 12.6, 'freeTickCapSeconds': .05, 'narrowViewport': [390, 740], 'readyTimeoutMs': 180000, 'readyBoundMs': 181000, 'freeCrossingCapMs': 180000, 'freeTailReserveMs': 130000}, 'Frozen QA thresholds changed')
    require(report['observation']['legacyExtendedWaterAbsent'] is True, 'Deleted overhead water remains mounted')
    validate_ocean_bindings(report['initialFrame']['oceanBindings'])
    validate_material_bindings(report['initialFrame']['explorationBindings'])
    expected_budget = c['expectedExplorationBudget']
    require(report['expectedExplorationBudget'] == expected_budget and report['observation']['ownedResources'] == c['expectedOwnedResources'], 'Frozen exploration resources changed')
    for name in (('initialBudget',) if segment == 'tour' else ('initialBudget', 'fieldBudget', 'restoredBudget')):
        stats = report[name]
        require({k: stats['exploration']['budget'][k] for k in expected_budget} == expected_budget, 'Frozen exploration budget mismatch: ' + name)
        require({k: stats['explorationActual'][k] for k in ('meshes', 'triangles', 'instances', 'geometryBytes')} == {k: expected_budget[k] for k in ('meshes', 'triangles', 'instances', 'geometryBytes')}, 'Actual exploration geometry mismatch: ' + name)
    if segment == 'free-compat':
        for k in ('mountedTriangles', 'visibleTriangles', 'mountedDraws', 'visibleDraws'):
            require(report['restoredBudget'][k] == report['initialBudget'][k], 'Whole scene failed exact own-baseline restoration: ' + k)
    d = check_deadline(segment, current=segment == 'free-compat')
    for k in ('startedAtMs', 'expiresAtMs', 'totalBudgetMs'):
        require(report[k] == d[k], 'Browser report belongs to another deadline: ' + k)
    require(finite(report['completedAtMs']) and d['startedAtMs'] <= report['completedAtMs'] <= time.time() * 1000 and report['completedAtMs'] < d['expiresAtMs'], 'Completion outside original deadline')
    phases = report['phases']
    require(isinstance(phases, list) and [p['name'] for p in phases] == SEGMENT_PHASES[segment], 'Exact mandatory segment phase order missing')
    require(all(p['status'] == 'PASS' for p in phases), 'Mandatory phase incomplete')
    require(all(all(finite(p[k]) and p[k] >= 0 for k in ('startedMs', 'limitMs', 'elapsedMs')) and p['startedMs'] + p['elapsedMs'] < 450000 for p in phases), 'Phase time evidence invalid')
    default = report['defaultState']
    require(default['route']['mode'] == 'free' and default['route']['position'] == default['camera'] == [4, 5, 10] and default['route']['reduced'] is False, 'Default free spawn not tested')
    if segment == 'tour':
        require(report['tourControls']['resumed'] is True and report['tourControls']['takeover']['posePreserved'] is True, 'Tour control transition proof missing')
        require(report['completeTour']['completed'] is True and report['completeTour']['elapsed'] == 72 and report['completeTour']['wallElapsedMs'] >= 72000 and report['replay']['restarted'] is True and report['replay']['progressed'] is True, 'Actual complete tour/replay missing')
        require(report['continuity']['completeTour'] is True and report['continuity']['maxAnalyticError'] < 1e-5, 'Tour analytic continuity check missing')
    else:
        crossing = report['freeCrossing']
        require(crossing['nativeKey'] == 'KeyW' and crossing['before']['position'] == [4, 5, 10] and crossing['after']['position'][2] < -60 and crossing['release']['stopped'] is True, 'Native W crossing/release missing')
        require(crossing['inputPolicy'] == 'ordinary-W-then-native-W+ShiftLeft' and crossing['noShift'] is False and crossing['shiftHintDeclared'] is True and crossing['shiftHintDisclosure'] == 'Shift acceleration is declared in #hudMorePanel text; the details panel may be collapsed.' and crossing['ordinary']['displacement'] > 0 and report['continuity']['normalMovedSteps'] > 0 and report['continuity']['boostedMovedSteps'] > 0, 'Ordinary W and explicitly declared native Shift acceleration were not both verified')
        require([v['key'] for v in report['directions']] == ['w', 'a', 'd', 'q', 'e'] and all(v['projection'] > .08 and v['orthogonal'] < .03 for v in report['directions']), 'Native heading-relative directions missing')
        require(report['canvasBlur']['clearedKeys'] is True and report['continuity']['continuousFreeCrossing'] is True, 'Free control transition/continuity proof missing')
    require(report['trustedInput']['allTrusted'] is True and report['trustedInput']['events'] and all(e['trusted'] is True for e in report['trustedInput']['events']), 'Trusted native input proof missing')
    protection = report['sourceProtection']
    require(protection['issues'] == [] and protection['borrowedDisposals'] == 0 and all(protection[k] > 0 for k in ('objects', 'buffers', 'resources')), 'Original resource isolation missing')
    if segment == 'free-compat':
        validate_compatibility_payload(report)
    if segment == 'tour':
        frames = report['frames']
        require([f['name'] for f in frames] == c['frames'], 'Exactly three ordered tour captures required')
        last_elapsed = -1
        submitted_materials, submitted_meshes = set(), set()
        for f, region in zip(frames, c['frameRegions']):
            require(f['file'] == f['name'] + '.png', 'Unexpected raw capture filename')
            r, g = f['route'], f['graphics']
            require(r['paused'] is True and r['region'] == region and finite(r['elapsed']) and last_elapsed < r['elapsed'] <= 72, 'Natural tour capture phase/time mismatch')
            last_elapsed = r['elapsed']
            require(r['mode'] == ('completed' if f['name'] == 'tour-completed' else 'tour'), 'Wrong tour capture mode')
            require(f['name'] != 'tour-completed' or r['elapsed'] == 72, 'Final capture must be actual completed state')
            for k in ('camera', 'target'):
                require(isinstance(f[k], list) and len(f[k]) == 3 and all(finite(v) for v in f[k]), 'Finite camera/target vector required')
            require(f['receipt']['sequence'] > f['previousSequence'], 'Capture lacks a fresh actual render')
            require((g['width'], g['height']) == (1120, 712) and (f['width'], f['height']) == (1120, 712), 'Original canvas size changed')
            require(g['contextLost'] is False and g['pixelError'] == 0 and g['sampleColors'] >= 2 and g['render']['calls'] > 0 and g['readPixelsInRenderObserver'] is True, 'Missing same-stack nonblank rendered GL frame')
            validate_ocean_bindings(f['oceanBindings'])
            validate_material_bindings(f['explorationBindings'], require_pbr=f['name'] != 'tour-initial')
            for binding in f['explorationBindings']:
                submitted_materials.add(binding['materialUUID'])
                submitted_meshes.update(binding['meshNames'])
        coverage = report['explorationGPUCoverage']
        require(submitted_meshes and submitted_materials == set(coverage['materialUUIDs']) and submitted_meshes == set(coverage['meshNames']), 'Exact actual exploration GPU coverage missing')
    require(report['timeline']['columns'] == FRAME_COLUMNS and report['timeline']['segment'] == segment, 'Numeric timeline segment/column contract mismatch')
    filename = 'actual-navigation-frames.jsonl' if segment == 'tour' else 'free-navigation-frames.jsonl'
    data = validate_timeline(evidence / filename, report['timeline'], segment)
    if segment == 'free-compat':
        require(report['frames'] == [], 'Free/compat segment cannot substitute tour captures')
        require(report['timelineRows'] == [json.loads(line) for line in data.splitlines() if line.strip()], 'Embedded free/compat rows differ from its own hashed numeric evidence')
    return data


def validate_gpu(c, reports, evidence):
    validate_segment_pair(c, reports)
    tour = validate_segment(c, reports['tour'], evidence / 'tour', 'tour')
    validate_segment(c, reports['free-compat'], evidence / 'free-compat', 'free-compat')
    return tour


def finalize(c, update_world=False):
    check_deadline()
    protected, current = check_old(c)
    check_sources(c)
    require(set(current) - set(protected) == candidate_sources(c) | set(c['mutableEntryPaths']) and len(current) == c['stagedSiteFiles'], 'Unexpected pre-finalization files')
    require(not pathlib.Path('.enriched-finalized.json').exists(), 'Already finalized')
    original = snapshot(c)
    for n in c['mutableEntryPaths']:
        require((DIST / n).read_bytes() == original[n], 'Old world changed before all QA passed: ' + n)
    evidence = pathlib.Path(os.environ.get('EXPLORATION_OUTPUT', 'exploration-qa'))
    reports = {segment: read_json(evidence / segment / 'browser-result.json') for segment in ('tour', 'free-compat')}
    timeline = validate_gpu(c, reports, evidence)
    report = reports['tour']
    identity = source_identity(c)
    prefix = 'assets/current-scene/' + c['sourceHashAggregate'] + '/'
    files, frames = {}, []
    for f in report['frames']:
        b, w, h = png_bytes(evidence / 'tour' / f['file'], f)
        name = f['name'] + '-' + f['sha256'][:16] + '.png'
        files[prefix + name] = b
        frames.append(dict(f, file=name, publicPath=prefix + name, width=w, height=h))
    files[prefix + 'actual-navigation-frames.jsonl'] = timeline
    manifest = dict(report, frames=frames, segmentReports=reports, independentBrowserSessions=True, numericEvidencePolicy='Tour RAF JSONL is public; the independent free/compat numeric rows are embedded under segmentReports.free-compat.timelineRows. Never concatenate the two RAF clocks.', candidatePath=c['candidatePath'], sourceFiles=c['sourceFiles'],
        sourceHashAggregate=c['sourceHashAggregate'], candidateSourceCommit=identity['candidateSourceCommit'], checkoutCommit=identity['checkoutCommit'],
        productVersion=c['productVersion'], acceptance=c['acceptance'], acceptanceChinese=c['acceptanceChinese'], appearanceAccepted=False, unverified=c['unverified'],
        entryEvidencePolicy=c['oldEntryEvidencePolicy'], captureTimeoutMs=c['captureTimeoutMs'],
        evidenceLimits='Three natural paused tour stages plus passive numeric callback evidence. Technical checks do not establish whole-world naturalness, continuous video quality, native touch hardware, or user-device FPS.')
    files[prefix + 'manifest.json'] = json_bytes(manifest)
    cards = ''.join('<figure><img loading="lazy" src="' + html.escape(f['publicPath'], quote=True) + '" alt="' + html.escape(f['name'], quote=True) + ' actual WebGL frame"><figcaption>' + html.escape(f['name']) + ' · elapsed ' + str(f['route']['elapsed']) + ' s · SHA256 ' + f['sha256'] + '</figcaption></figure>' for f in frames)
    gallery = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>分层生态自由探索 · 实际画面</title><style>body{margin:24px auto;max-width:1440px;padding:0 16px;background:#10282e;color:#eee;font:16px system-ui}a{color:#9edbea}img{max-width:100%;height:auto}figure{margin:28px 0}figcaption{overflow-wrap:anywhere;font-size:13px}</style><h1>分层生态自由探索候选</h1><p><a href="scan-exhibit.html">打开自由探索</a> · <a href="../world/">固定入口</a></p><p>真实导览自然经过原生扫描礁区、开阔海草浅湾与大陆架深水边缘。三张画面以原生界面暂停，记录实际经过时间；末图在真实72秒导览完成后取得。逐帧数值记录与同帧WebGL读回支撑技术检查，静态图片不证明全程视觉连续性。</p><p>进入后可自由游动，也可开始导览、暂停、继续或重新播放。真实扫描只是局部素材，扩展地形和空间布局为艺术演示，不是原采集地实景复原。整体真实感仍未达标，最终美术效果尚未验收。原素材出处、许可和展示边界在交互页保留。</p><p>保留旧入口的两张历史PNG，本次没有新入口截图。窄屏与鼠标指针模拟不代表真实双指触屏硬件验收；用户设备FPS和连续视频质量尚未验证。页面生命周期支持范围以技术清单为准。</p>'''
    gallery += '<p>版本 ' + html.escape(c['productVersion']) + '</p>' + cards + '<p><a href="' + prefix + 'manifest.json">源码、实际机位与技术证据</a> · <a href="' + prefix + 'actual-navigation-frames.jsonl">逐帧数值记录</a></p><p>候选源码 ' + identity['candidateSourceCommit'] + ' · 发布构建 ' + identity['checkoutCommit'] + '</p></html>\n'
    files['current-scene.html'] = gallery.encode()
    require(len(files) == c['newGalleryFiles'], 'Only three PNGs, one numeric timeline, manifest and HTML allowed')
    entry, pointer = expected_entry(c, identity, original) if update_world else ({n: original[c['entryPath'] + '/' + n] for n in ENTRY_NAMES}, None)
    root, world = DIST / c['candidatePath'], DIST / c['entryPath']
    require(all(not (root / n).exists() for n in files), 'Evidence destination collision')
    check_deadline()
    # All report, timeline, PNG, source and pointer checks precede any public write.
    for n, b in files.items():
        p = root / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
    if update_world:
        for n, b in entry.items():
            (world / n).write_bytes(b)
    save_json('.enriched-finalized.json', {'schemaVersion': 1, 'state': 'QA_PASS_EXACT_WORLD_UPDATE' if update_world else 'QA_PASS_WORLD_UNCHANGED',
        'sourceIdentity': identity, 'runIdentity': run_identity(), 'segments': {name: {k: value[k] for k in ('segment', 'startedAtMs', 'expiresAtMs', 'completedAtMs', 'totalBudgetMs', 'status')} for name, value in reports.items()}, 'appearanceAccepted': False, 'galleryFiles': [file_record(root / n, c['candidatePath'] + '/' + n) for n in sorted(files)],
        'entryFiles': [file_record(world / n, n) for n in ENTRY_NAMES], 'pointer': pointer, 'protectedFiles': 1969, 'oldEntryPNGsPreserved': 2, 'newEntryScreenshots': 0})
    check_old(c)
    check_sources(c)
    check_deadline()
    print('EXPLORATION_EVIDENCE_READY', json.dumps({'frames': c['frames'], 'evidenceFiles': 6, 'sourceIdentity': identity, 'worldUpdated': update_world, 'appearanceAccepted': False}))


if __name__ == '__main__':
    require(sys.argv[1:] in ([], ['--update-world']), 'Unexpected arguments')
    finalize(contract(), '--update-world' in sys.argv)
