"""Build a frozen six-file overlay plus nine exact saved-public R6 products; no fetch."""
from pathlib import Path
import hashlib
import json
import zipfile

P = Path(__file__).resolve().parent.parent
W = P.parent
sha = lambda b: hashlib.sha256(b).hexdigest()

def record(n, b):
    return {'path': n, 'bytes': len(b), 'sha256': sha(b)}

def archive(n, files):
    p = P / n
    with zipfile.ZipFile(p, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(files.items()):
            i = zipfile.ZipInfo(name, (2026, 10, 11, 0, 0, 0))
            i.compress_type = zipfile.ZIP_DEFLATED
            i.external_attr = 0o100644 << 16
            z.writestr(i, data)
    return record(n, p.read_bytes())

def main():
    previous = W / 'reef-exploration-demo-publish'
    old = json.loads((previous / 'tools/exploration-contract.json').read_text())
    result_path = previous / 'evidence/run38140009875-public-receipt.json'
    result = json.loads(result_path.read_text())
    get_path = previous / 'public-get-receipt.json'
    get = json.loads(get_path.read_text())
    assert result['totalFiles'] == 1972 and result['protectedFilesByteIdentical'] is True
    assert get['mainCommit'] == result['sourceIdentity']['checkoutCommit'] == 'b8c552753dc8a8080a1b7fd541413328355e6cfa'
    assert result['sourceIdentity']['candidateSourceCommit'] == 'da6d0e2669e2dacfc95e03d03e3ef5ad9228fd23'
    assert result['sourceIdentity']['sourceHashAggregate'] == old['sourceHashAggregate']
    public = {f['path']: f for f in result['files']}
    fetched = {f['sitePath']: f for f in get['verified']}
    snapshots = set(public) - {old['candidatePath'] + '/' + n for n in old['sourceHashes']}
    assert len(public) == 158 and len(snapshots) == 9
    saved = {}
    for n in sorted(snapshots):
        b = (previous / 'published' / n).read_bytes()
        assert record(n, b) == public[n]
        assert fetched[n]['status'] == 200 and fetched[n]['sha256'] == sha(b) and fetched[n]['bytes'] == len(b)
        saved[n] = b
    source = W / 'reef-exploration-enriched-candidate/page'
    manifest_path = W / 'reef-exploration-enriched-candidate/verification/enriched-final-source-sha256.json'
    product_path = W / 'reef-exploration-enriched-candidate/verification/enriched-final-contract.json'
    product = json.loads(product_path.read_text())
    assert product['sourceManifestSha256'] == sha(manifest_path.read_bytes())
    assert product['baselinePublishedCommit'] == get['mainCommit'] and product['productFiles'] == 149
    frozen = json.loads(manifest_path.read_text())
    assert all(n.startswith('page/') for n in frozen)
    hashes = {n[5:]: h for n, h in frozen.items()}
    files = {p.relative_to(source).as_posix(): p.read_bytes() for p in sorted(source.rglob('*')) if p.is_file()}
    assert len(files) == len(hashes) == 149 and {n: sha(b) for n, b in files.items()} == hashes
    assert set(old['sourceHashes']) == set(hashes)
    delta = {n: b for n, b in files.items() if old['sourceHashes'].get(n) != sha(b)}
    assert {n: sha(b) for n, b in delta.items()} == {n[5:]: h for n, h in product['changedFiles'].items()}
    assert set(delta) == {'scan-exhibit.html', 'scan-exhibit.css', 'scan-exhibit.js', 'exploration-world.js', 'scan-ocean.js', 'exploration-world-data.js'}
    assert sum(hashes.get(n) == h for n, h in old['sourceHashes'].items()) == 143
    with zipfile.ZipFile(previous / old['snapshotArchive']['path']) as z:
        staged_entry = [record(n, z.read(n)) for n in old['mutableEntryPaths']]
    aggregate = sha(''.join(n + '\0' + hashes[n] + '\n' for n in sorted(hashes)).encode())
    c = dict(schemaVersion=1, candidatePath='preview/exploration-enriched-candidate', basePath=old['candidatePath'], entryPath='preview/world',
        baseMainCommit=get['mainCommit'], baseSourceCommit=result['sourceIdentity']['candidateSourceCommit'],
        baseSourceHashAggregate=old['sourceHashAggregate'], sourceHashAggregate=aggregate,
        sourceHashes=hashes, sourceFiles=[record(n, files[n]) for n in sorted(files)],
        baseSourceHashes=old['sourceHashes'], baseSourceFiles=old['sourceFiles'], oldPublicFiles=list(public.values()),
        snapshotFiles=[public[n] for n in sorted(saved)], snapshotArchive=archive('exploration-demo-snapshot-b8c55275.zip', saved),
        stagedEntryFiles=staged_entry, codeArchive=archive('exploration-enriched-code.zip', delta),
        changes=[dict(record(n, delta[n]), baseSha256=old['sourceHashes'].get(n)) for n in sorted(delta)],
        mutableEntryPaths=old['mutableEntryPaths'], oldAssemblyProtectedFiles=1814, oldAssemblyFiles=1966,
        oldSiteFiles=1972, protectedFiles=1969, rootFiles=79, newSourceFiles=149, unchangedSourceFiles=143,
        newGalleryFiles=6, stagedSiteFiles=2121, finalSiteFiles=2127,
        frames=old['frames'], frameRegions=old['frameRegions'], qaSegments=old['qaSegments'], requiredSegmentPhases=old['requiredSegmentPhases'],
        totalBudgetMs=450000, captureTimeoutMs=25000,
        expectedExplorationBudget=product['extensionBudget'], expectedFullLoadedScene=product['fullLoadedScene'],
        expectedOwnedResources={'geometries': 63, 'materials': 7, 'instances': 17},
        productVersion=product['candidate'], productContract=product,
        acceptance='Enriched exploration technical evidence only. The world is still synthetic and simplified; overall realism and final artistic acceptance remain unapproved.',
        acceptanceChinese='分层生态自由探索候选，整体真实感仍未达标，最终美术效果尚未验收',
        unverified=old['unverified'], oldEntryEvidencePolicy=old['oldEntryEvidencePolicy'],
        frozenManifest=record('verification/enriched-final-source-sha256.json', manifest_path.read_bytes()),
        frozenProductContract=record('verification/enriched-final-contract.json', product_path.read_bytes()),
        preparationOnly=True, candidateSourceCommit='__ENRICHED_SOURCE_COMMIT__',
        provenance={'oldPublishedResult': record(str(result_path.relative_to(W)), result_path.read_bytes()),
                    'savedPublicReceipt': record(str(get_path.relative_to(W)), get_path.read_bytes())})
    (P / 'tools/enriched-contract.json').write_text(json.dumps(c, ensure_ascii=False, indent=2, sort_keys=True) + '\n')
    summary = {'status': 'LOCAL_PREPARATION_ONLY', 'sourceFiles': 149, 'sourceHashAggregate': aggregate, 'changes': c['changes'],
               'unchangedSourceFiles': 143, 'snapshotFiles': 9, 'protectedFiles': 1969,
               'oldSiteFiles': 1972, 'stagedSiteFiles': 2121, 'finalSiteFiles': 2127,
               'packages': [c['codeArchive'], c['snapshotArchive']], 'browserRun': False, 'uploaded': False}
    (P / 'input-package-receipt.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
