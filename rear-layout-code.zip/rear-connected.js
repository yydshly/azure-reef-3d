import * as T from 'three';
import {REAR_CONNECTED_DATA as DATA} from './rear-connected-data.js';
// CC0 terrestrial boulder geometry composed as fictional low reef. Not a survey.
// Original rear resources remain owned by their original installer, retained for restoration.
export function refineRearHabitat({world,original,parent}) {
 const root=new T.Group();root.name='Rear_Connected_Low_Reef';original.root.add(root);
 const swaps=[],instances=[],geometries=[],meshes=[],obstacles=[];let disposed=false,enabled=false,netTriangles=0,netDraws=0;
 const count=o=>(o.geometry.index?.count||o.geometry.attributes.position.count)/3*(o.isInstancedMesh?o.count:1);
 const oldTerrain=original.root.getObjectByName('Rear_Broken_Reef_Islands');
 const p=[],ind=[],colors=[],c=new T.Color(),groupBounds=new Map();
 for(const d of Object.values(DATA.meshes)){const off=p.length/3;p.push(...d.vertices.flat());ind.push(...d.triangles.flat().map(i=>i+off));c.set(DATA.colors[d.group]);for(const v of d.vertices){colors.push(c.r,c.g,c.b);if(!groupBounds.has(d.group))groupBounds.set(d.group,new T.Box3());groupBounds.get(d.group).expandByPoint(new T.Vector3(...v));}}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));g.setIndex(ind);g.computeVertexNormals();g.computeBoundingBox();g.computeBoundingSphere();geometries.push(g);
 const rock=new T.Mesh(g,oldTerrain.material);rock.name='Rear_Connected_Scan_Derived_Limestone';rock.castShadow=oldTerrain.castShadow;rock.receiveShadow=oldTerrain.receiveShadow;root.add(rock);meshes.push(rock);swaps.push({original:oldTerrain,visible:oldTerrain.visible});netTriangles+=count(rock)-count(oldTerrain);
 for(const [name,box]of groupBounds)obstacles.push({name:'RearConnected_'+name,box});
 for(const patch of DATA.banks){const src=original.root.getObjectByName(patch.name);if(!src?.isInstancedMesh||src.count!==patch.originalCount)throw Error('Rear source identity mismatch '+patch.name);const removed=new Set(patch.remove),moves=new Map(patch.move.map(r=>[r.index,r]));
  const copy=new T.InstancedMesh(src.geometry,src.material,src.count-removed.size);copy.name='Rear_Connected_Retained_'+patch.name;copy.matrix.copy(src.matrix);copy.matrixAutoUpdate=false;copy.castShadow=src.castShadow;copy.receiveShadow=src.receiveShadow;const m=new T.Matrix4(),color=new T.Color();let j=0;
  for(let i=0;i<src.count;i++){src.getMatrixAt(i,m);const move=moves.get(i);if(move&&m.elements.some((n,k)=>Math.abs(n-move.originalMatrix[k])>1e-6))throw Error('Rear original matrix mismatch '+patch.name+' '+i);if(removed.has(i))continue;if(move)m.fromArray(move.matrix);copy.setMatrixAt(j,m);if(src.instanceColor){src.getColorAt(i,color);copy.setColorAt(j,color);}j++;}
  copy.userData.originalIndices=Array.from({length:src.count},(_,i)=>i).filter(i=>!removed.has(i));copy.computeBoundingSphere();root.add(copy);meshes.push(copy);instances.push(copy);swaps.push({original:src,visible:src.visible});netTriangles+=count(copy)-count(src);
 }
 world.budget.triangles+=netTriangles;
 const ownTriangles=meshes.reduce((a,m)=>a+count(m),0),combined=original.triangles+netTriangles;if(combined>200000||meshes.length>6)throw Error('Rear refinement budget exceeded');
 root.userData={synthetic:true,terrestrialScanArt:true,measuredReef:false,source:'https://polyhaven.com/a/boulder_01',license:'CC0',terrainTriangles:ind.length/3,netTriangles,combinedRearTriangles:combined,newTextures:0,changes:DATA.summary};
 function enable(value){if(disposed)return;enabled=!!value;root.visible=enabled;for(const s of swaps)s.original.visible=enabled?false:s.visible;for(const o of original.obstacles){const i=world.obstacles.indexOf(o);if(enabled&&i>=0)world.obstacles.splice(i,1);if(!enabled&&parent.visible&&i<0)world.obstacles.push(o);}for(const o of obstacles){const i=world.obstacles.indexOf(o);if(enabled&&parent.visible&&i<0)world.obstacles.push(o);if(!enabled&&i>=0)world.obstacles.splice(i,1);}}
 const api={...original,refinement:{root,swaps,instances,geometries,meshes,obstacles,netTriangles},setEnabled(value){original.setEnabled(value);enable(value);},getState:()=>({...original.getState(),refined:true,enabled,disposed,netTriangles,combinedRearTriangles:combined}),dispose(){if(disposed)return;enable(false);disposed=true;root.removeFromParent();instances.forEach(o=>o.dispose());geometries.forEach(o=>o.dispose());world.budget.triangles-=netTriangles;original.dispose();if(world.rearHabitat===api)delete world.rearHabitat;}};
 world.rearHabitat=api;enable(parent.visible);return api;
}
