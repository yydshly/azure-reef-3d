import pathlib,json,hashlib
root=pathlib.Path('dist');before=json.loads(pathlib.Path('.turn-protected.json').read_text());assert len(before)==1215
for n,h in before.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
print('OLD_1215_FILES_BYTE_IDENTICAL')
