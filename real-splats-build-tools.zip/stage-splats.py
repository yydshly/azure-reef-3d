"""Restore only six saved surface evidence files; protect all old 2283 files."""
from splats_common import *

def stage(c):
    require(not (DIST / c['candidatePath']).exists(), 'Candidate destination exists')
    require(not any(pathlib.Path(n).exists() for n in ('.splats-protected.json', '.splats-baseline.json', '.splats-build.json')), 'Stage already attempted')
    before = inventory(DIST)
    protected = assembly_protection(c)
    staged = {c['basePath'] + '/' + f['path']: f['sha256'] for f in c['baseSourceFiles']}
    require(not set(staged) & set(protected) and before == dict(protected, **staged) and len(before) == c['oldAssemblyFiles'], 'Exact previous 2277-file staging output required')
    restore = snapshot(c)
    require(not set(restore) & set(before), 'Snapshot must only add missing surface evidence')
    baseline = dict(before, **{n: sha(b) for n, b in restore.items()})
    require(baseline == baseline_hashes(c), 'Cannot reproduce exact 2283-file publication')
    original = checked_archive(INPUTS / c['sourceArchive']['path'], c['sourceArchive'], {f['path']: f for f in c['sourceArchiveFiles']})
    candidate = {n: original[origin] for n, origin in c['sourceArchiveMapping'].items()}
    require({n: sha(b) for n, b in candidate.items()} == c['sourceHashes'], 'Source extraction mismatch')
    # Validate every source/archive/collision before any public write.
    for n, b in restore.items():
        p = DIST / n; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b)
    require(inventory(DIST) == baseline, 'Published surface restoration failed')
    save_json('.splats-baseline.json', baseline); save_json('.splats-protected.json', baseline)
    for n, b in candidate.items():
        p = DIST / c['candidatePath'] / n; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b)
    save_json('.splats-build.json', dict(schemaVersion=1, state='STAGED_ALL_2283_OLD_FILES_PROTECTED', sourceHashAggregate=c['sourceHashAggregate'], sourceFiles=c['newSourceFiles'], protectedFiles=2283, worldEntryChanged=False))
    check_sources(c); protected, current = check_old(c)
    require(set(current) - set(protected) == candidate_sources(c) and len(current) == c['stagedSiteFiles'], 'Unexpected stage output')
    print('SPLATS_STAGED', json.dumps(dict(protectedFiles=2283, sourceFiles=c['newSourceFiles'], sourceHashAggregate=c['sourceHashAggregate'])))

if __name__ == '__main__': stage(contract())
