"""Synthetic report-schema arithmetic only; never browser or acceptance evidence."""
import copy
import importlib.util
from pathlib import Path
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import splats_common as common
spec = importlib.util.spec_from_file_location('finalizer', Path(__file__).with_name('finalize-splats.py'))
final = importlib.util.module_from_spec(spec); spec.loader.exec_module(final)

def main():
    c = common.contract()
    draw = dict(hookInstalled=True, nonzeroSplatDraws=2, lastInstances=1)
    source = dict(count=c['asset']['count'], sha256=c['asset']['sha256'])
    cam = lambda p, q=None: dict(position=p, quaternion=q or [0, 0, 0, 1], fov=65)
    origin, forward, drag, backward = cam([0,0,0]), cam([0,0,-1]), cam([0,0,-1],[0,.1,0,.99]), cam([0,0,1])
    release = dict(stopped=True, before=origin, after=origin)
    disposed = dict(status='unloaded', source=dict(count=0), camera=None, draw=None, stats=dict(lastDispose=dict(meshCleared=True, sortWorkerCleared=True, animationLoopCancelled=True, sceneChildren=0, after=dict(geometries=0, textures=0)), loads=3))
    cycles = [dict(cycle=i, disposed=dict(report=disposed, framesStopped=True), reloaded=dict(source=source, draw=draw)) for i in (1,2,3)]
    errors = [dict(kind='load', message='Failed to fetch')]
    report = dict(status='TECHNICAL_PASS', limits=dict(totalMs=450000,pngMs=25000,assetMs=30000,workerMs=10000,viewSettleMs=5000,performanceMs=10000), browser=dict(sandbox=True, forbiddenFlagsAbsent=True, graphics=dict(renderer='SwiftShader', softwareRenderer=True)), servedSourceHashes={n:h for n,h in c['sourceHashes'].items() if not n.endswith('.ply')}, device=dict(devicePixelRatio=1,viewport=[1120,712]), pageErrors=[],console=[],limitations=['Synthetic report schema fixture only.'], finalDisposal=dict(framesStopped=True, report=disposed), checks=dict(
        identityAndActualDraw=dict(status='PASS', **source, draw=draw), fixedViews=dict(status='PASS_NONEMPTY_DRAW_ONLY', views=c['frames'], visualAcceptance=False),
        controls=dict(status='PASS', focusedButtonBlocksWAndArrow=True, exactReset=True, original=origin, forward=forward, drag=drag, backward=backward, wRelease=release,sRelease=release,buttonRelease=release),
        pointerCancel=dict(status='UNSUPPORTED_NATIVE_EVENT'), blur=dict(status='UNSUPPORTED_NATIVE_EVENT'), visibility=dict(status='UNSUPPORTED_NATIVE_EVENT'), lostPointerCapture=dict(status='UNSUPPORTED_NATIVE_EVENT',independentlyForced=False),
        boundary=dict(status='PASS_NATIVE_CROSSING',guideButtonToggled=True,insideText='在参考范围内',outsideText='当前在参考范围外',inside=origin,outside=cam([100,0,0])),
        cycles=dict(status='PASS',cycles=cycles,rendererMemoryReturned=True,driverMemoryReleased='UNVERIFIED'),
        loadCancellation=dict(status='PASS',assetRequestWasHeld=True,report=disposed), rapidRepeatedLoad=dict(status='PASS',calls=3,allPromisesAwaited=True,report=dict(draw=draw,stats=dict(loads=4))),
        assetFailure=dict(status='PASS',blockedRequests=1,oneRetry=True,failed=dict(status='error',source=dict(count=0),draw=None,camera=None,stats=disposed['stats'],errors=errors),failureUI=dict(visible=True,text='Data load failed'),retried=dict(errors=errors,draw=draw)),
        bootstrapError=dict(status='PASS',blockedImports=1,failure=dict(fallbackVisible=True,failure='Import failed',report=None)), absentWebGL=dict(status='NOT_INDUCED')))
    def cadence(r, gap, rendered):
        times = list(range(0, 10001, gap)); elapsed=times[-1]-times[0]; intervals=[gap]*(len(times)-1); fraction=sum(v>=250 for v in intervals)/len(intervals); hz=rendered*1000/elapsed; low=hz<10 or fraction>.2
        r['status'] = final.PASS_STATUSES[int(low)]
        r['checks']['performance'] = dict(cadence=dict(elapsedMs=elapsed,callbacks=len(times),intervalsMs=intervals,renderedFrames=rendered,renderedHz=hz,gapsAtLeast250Ms=sum(v>=250 for v in intervals)),timestamps=times,longGapFraction=fraction,thresholds=dict(renderedHzBelow=10,longGapMs=250,longGapFractionAbove=.2),frameWorkIsFps=False,productionPerformanceClaim=False,unsuitable=low,softwareRenderer=True,status='LOW_CADENCE' if low else 'MEASURED_DEVICE_ONLY',technicalStatus=r['status'])
        if low:r['limitations'].append('LOW_CADENCE: software-only limitation.')
    cadence(report, 20, 500)
    final.validate_checks(c, report)
    checks = ['complete-synthetic-necessary-function-schema-accepted']
    low = copy.deepcopy(report); cadence(low,500,20); final.validate_checks(c,low); checks.append('narrow-software-low-cadence-diagnostic-schema-accepted')
    for label, source_report, mutate in [
        ('missing-core-check',report,lambda r:r['checks'].pop('loadCancellation')),
        ('wrong-source',report,lambda r:r['checks']['identityAndActualDraw'].__setitem__('count',0)),
        ('unreleased-motion',report,lambda r:r['checks']['controls']['wRelease'].__setitem__('stopped',False)),
        ('outside-not-crossed',report,lambda r:r['checks']['boundary'].__setitem__('outside',origin)),
        ('incomplete-dispose',report,lambda r:r['finalDisposal']['report']['stats']['lastDispose'].__setitem__('sortWorkerCleared',False)),
        ('invented-rendered-FPS',report,lambda r:r['checks']['performance']['cadence'].__setitem__('renderedHz',100)),
        ('false-normal-status-on-low',low,lambda r:r.__setitem__('status','TECHNICAL_PASS')),
        ('physical-device-low-exception',low,lambda r:r['browser']['graphics'].__setitem__('renderer','Physical GPU')),
        ('missing-low-limitation',low,lambda r:r.__setitem__('limitations',[])),
        ('short-actual-observation',report,lambda r:r['checks']['performance']['timestamps'].pop()),
        ('unhandled-page-error',report,lambda r:r.__setitem__('pageErrors',['error']))]:
        altered=copy.deepcopy(source_report); mutate(altered)
        try:final.validate_checks(c,altered)
        except (ValueError,KeyError):checks.append(label+'-rejected')
        else:raise AssertionError('Accepted '+label)
    result=dict(status='PASS_SYNTHETIC_SCHEMA_TESTS',browserRun=False,gpuRun=False,checks=checks)
    common.save_json(Path(__file__).resolve().parent.parent/'local-finalizer-test-result.json',result)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
