import assert from 'node:assert/strict';
import test from 'node:test';
import {readFileSync} from 'node:fs';
import {LIMITS,EXPECTED,VIEWS,remaining,assertLaunchArguments,assertProduct,assertCapture,assertDisposed,assertStableCamera,cadenceSummary,classifyCadence,referenceOutside,sha256} from './browser-check-splats.mjs';

const product=()=>({status:'ready',source:{count:30381,sha256:EXPECTED.sha256},dependencies:{three:'186',spark:'2.3.1'},gl:{version:'WebGL 2.0',isContextLost:false,error:0},draw:{hookInstalled:true,nonzeroSplatDraws:3,lastInstances:300,activeSplats:300},errors:[]});
const capture=()=>({name:'side',width:1120,height:712,guidesHidden:true,draw:{hookInstalled:true,nonzeroSplatDraws:3,lastInstances:300},activeSplats:300,glError:0,nonBackgroundPixels:10000,coverage:10000/(1120*712)});
test('one absolute deadline retains all contract caps',()=>{
  assert.deepEqual(LIMITS,{totalMs:450000,pngMs:25000,assetMs:30000,workerMs:10000,viewSettleMs:5000,performanceMs:10000});
  assert.equal(remaining(450000,440000,25000),10000);assert.equal(remaining(450000,100,25000),25000);
  for(const a of [[100,100],[100,101],[NaN,0],[100,0,0]])assert.throws(()=>remaining(...a));
});
test('unsafe browser flags cannot be admitted',()=>{
  assertLaunchArguments(['chromium','--enable-automation']);
  for(const flag of ['--no-sandbox','--disable-gpu-sandbox','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--disable-web-security']){assert.throws(()=>assertLaunchArguments([flag]));assert.throws(()=>assertLaunchArguments([flag+'=true']));}
});
test('parse-only, stale, wrong-source and WebGL error reports fail',()=>{
  assertProduct(product());
  for(const change of [r=>r.status='loading',r=>r.source.count--,r=>r.source.sha256='other',r=>r.draw.hookInstalled=false,r=>r.draw.nonzeroSplatDraws=0,r=>r.draw.lastInstances=0,r=>r.draw.activeSplats=0,r=>r.gl.error=1282,r=>r.gl.isContextLost=true,r=>r.gl.version='WebGL 1.0',r=>r.dependencies.three='185',r=>r.errors.push({kind:'shader',message:'bad'})]){const r=product();change(r);assert.throws(()=>assertProduct(r));}
  const r=product();r.errors=[{kind:'load',message:'Failed to fetch'}];assertProduct(r,r.errors);assert.throws(()=>assertProduct(r,[]));
});
test('all four requested views require genuine nonempty guide-free draw',()=>{
  assert.deepEqual(VIEWS,['overview','side','back','low']);assertCapture(capture(),'side');
  for(const change of [e=>e.name='back',e=>e.guidesHidden=false,e=>e.draw.hookInstalled=false,e=>e.draw.lastInstances=0,e=>e.activeSplats=0,e=>e.glError=1282,e=>e.coverage=0,e=>e.nonBackgroundPixels=0,e=>e.width=800]){const e=capture();change(e);assert.throws(()=>assertCapture(e,'side'));}
});
test('unload cannot pass with a stale mesh, scene, worker or render loop',()=>{
  const make=()=>({status:'unloaded',source:{count:0},camera:null,draw:null,stats:{lastDispose:{meshCleared:true,sortWorkerCleared:true,animationLoopCancelled:true,sceneChildren:0}}});assertDisposed(make());
  for(const change of [r=>r.status='unloading',r=>r.source.count=30381,r=>r.camera={},r=>r.draw={},r=>r.stats.lastDispose.meshCleared=false,r=>r.stats.lastDispose.sortWorkerCleared=false,r=>r.stats.lastDispose.animationLoopCancelled=false,r=>r.stats.lastDispose.sceneChildren=1,r=>r.stats.lastDispose.status='INCOMPLETE_RELOAD_REQUIRED']){const r=make();change(r);assert.throws(()=>assertDisposed(r));}
});
test('exact release/reset rejects any ongoing translation or rotation',()=>{
  const a={position:[0,8,8],quaternion:[0,0,0,1]};assertStableCamera(a,structuredClone(a));assert.throws(()=>assertStableCamera(a,{...a,position:[0,8,8.000001]}));assert.throws(()=>assertStableCamera(a,{...a,quaternion:[0,0,.001,1]}));
});
test('cadence requires ten real seconds and exposes a narrow software exception',()=>{
  const samples=Array.from({length:601},(_,i)=>i*1000/60),normal=cadenceSummary(samples,600);assert.equal(normal.elapsedMs,10000);assert.equal(normal.renderedHz,60);assert.equal(classifyCadence(normal,true).status,'MEASURED_DEVICE_ONLY');
  const slow=cadenceSummary(samples,30);assert.equal(classifyCadence(slow,true).technicalStatus,'TECHNICAL_PASS_SOFTWARE_LOW_CADENCE_VISUAL_PENDING');assert.equal(classifyCadence(slow,false).unsuitable,true);assert.equal(classifyCadence({...normal,renderedHz:10},true).unsuitable,false);
  assert.equal(classifyCadence({...normal,gapsAtLeast250Ms:120},true).unsuitable,false);assert.equal(classifyCadence({...normal,gapsAtLeast250Ms:121},true).unsuitable,true);
  assert.throws(()=>cadenceSummary(samples.slice(1),600));assert.throws(()=>cadenceSummary([0,0,10000],1));
});
test('short native boundary path starts from the frozen low preset',()=>{
  const manifest=JSON.parse(readFileSync(new URL('../../reef-real-splats-probe/page/assets/manifest.json',import.meta.url)));
  assert.equal(referenceOutside([-4.9,.65,5],manifest),true);assert.equal(referenceOutside([-4.45,.6,4.5],manifest),false);
});
test('runner is import-safe and preserves frozen source identity',()=>{
  const runner=readFileSync(new URL('./browser-check-splats.mjs',import.meta.url),'utf8');
  assert.match(runner,/chromiumSandbox:true/);assert.match(runner,/Input\.dispatchTouchEvent/);assert.match(runner,/stats\.frames,r\.stats\.frames/);assert(!runner.includes('dispatchEvent('));assert(!runner.includes('clock.install'));assert(!runner.includes('setSystemTime'));assert.match(runner,/flag:'wx'/);assert.match(runner,/if\(!browser\)clearTimeout\(hardTimer\)/);
  const c=JSON.parse(readFileSync(new URL('./splats-contract.json',import.meta.url)));assert.equal(c.sourceHashAggregate,sha256(Object.keys(c.sourceHashes).sort().map(f=>f+'\0'+c.sourceHashes[f]+'\n').join('')));
  for(const file of ['probe.js','probe-core.js','bootstrap.js','assets/soneva-ootsl1-20260218-lod4.ply'])assert.equal(sha256(readFileSync(new URL('../../reef-real-splats-probe/page/'+file,import.meta.url))),c.sourceHashes[file]);
});
