import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';

// Importing this module does not start a browser. Only runSplatsQA() does.
// This runner has no deploy operation and cannot give visual acceptance.
export const LIMITS = Object.freeze({totalMs:450000, pngMs:25000, assetMs:30000, workerMs:10000, viewSettleMs:5000, performanceMs:10000});
export const LOW_CADENCE = Object.freeze({renderedHzBelow:10, longGapMs:250, longGapFractionAbove:.2});
export const EXPECTED = Object.freeze({count:30381, bytes:7171392, sha256:'bdf77330d5a4df5c92aa2bb0f0dcc800ccebbc471903429703309c955fd82499', width:1120, height:712});
export const VIEWS = Object.freeze(['overview','side','back','low']);
export const FORBIDDEN_FLAGS = Object.freeze(['--no-sandbox','--disable-gpu-sandbox','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--disable-web-security']);
export const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
export function remaining(expiresAtMs, now=Date.now(), cap=Infinity) {
  assert(Number.isFinite(expiresAtMs) && Number.isFinite(now) && cap>0, 'Invalid deadline');
  const value=Math.min(expiresAtMs-now,cap); assert(value>0,'Shared deadline exhausted'); return value;
}
export function assertLaunchArguments(args) {
  assert(Array.isArray(args));
  assert(!args.some(a=>FORBIDDEN_FLAGS.some(f=>a===f || a.startsWith(f+'='))), 'Unsupported browser security/graphics flag');
}
export function assertProduct(r, expectedErrors=[]) {
  assert.equal(r?.status,'ready', 'Product did not reach ready');
  assert.equal(r.source.count,EXPECTED.count); assert.equal(r.source.sha256,EXPECTED.sha256);
  assert.equal(r.dependencies.three,'186'); assert.equal(r.dependencies.spark,'2.3.1');
  assert.match(r.gl.version,/WebGL 2/i); assert.equal(r.gl.isContextLost,false); assert.equal(r.gl.error,0);
  assert.equal(r.draw.hookInstalled,true); assert(r.draw.nonzeroSplatDraws>0 && r.draw.lastInstances>0 && r.draw.activeSplats>0,'No nonzero actual Gaussian draw');
  assert.deepEqual(r.errors,expectedErrors,'Unexpected product errors');
}
export function assertCapture(e, name) {
  assert.equal(e.name,name); assert.equal(e.width,EXPECTED.width); assert.equal(e.height,EXPECTED.height);
  assert(e.guidesHidden && e.draw.hookInstalled && e.draw.nonzeroSplatDraws>0 && e.draw.lastInstances>0 && e.activeSplats>0,'Readback must come from real Gaussian draw with guides hidden');
  assert.equal(e.glError,0); assert(e.coverage>.005 && e.coverage<=1,'Almost-empty or invalid raw splat readback');
  assert(Number.isInteger(e.nonBackgroundPixels)&&e.nonBackgroundPixels>0);assert.equal(e.coverage,e.nonBackgroundPixels/(e.width*e.height));
}
export function assertDisposed(r) {
  assert.equal(r.status,'unloaded'); assert.equal(r.source.count,0); assert.equal(r.camera,null); assert.equal(r.draw,null);
  const d=r.stats.lastDispose; assert(d && d.meshCleared && d.sortWorkerCleared && d.animationLoopCancelled,'Incomplete disposal');
  assert.equal(d.sceneChildren,0); assert.notEqual(d.status,'INCOMPLETE_RELOAD_REQUIRED'); return d;
}
export function assertStableCamera(a,b) {
  assert.deepEqual(b.position,a.position,'Released camera kept moving');
  assert.deepEqual(b.quaternion,a.quaternion,'Released camera kept rotating');
}
export function distance(a,b) { return Math.hypot(...a.map((v,i)=>v-b[i])); }
export function referenceOutside(position, manifest) {
  const [x,,z]=position,c=manifest.coordinates.rawOrigin,b=manifest.bounds.orthoXY;
  return x+c[0]<b.min_x || x+c[0]>b.max_x || c[1]-z<b.min_y || c[1]-z>b.max_y;
}
export function cadenceSummary(timestamps, frameDelta) {
  assert(timestamps.length>=2,'Missing actual RAF observations');
  const elapsedMs=timestamps.at(-1)-timestamps[0]; assert(elapsedMs>=LIMITS.performanceMs,'Less than 10 s of actual RAF cadence');
  const intervals=timestamps.slice(1).map((t,i)=>t-timestamps[i]); assert(intervals.every(v=>v>0),'Non-monotonic RAF data');
  const sorted=[...intervals].sort((a,b)=>a-b), pick=q=>sorted[Math.min(sorted.length-1,Math.floor(sorted.length*q))];
  return {elapsedMs,callbacks:timestamps.length,rafHz:intervals.length*1000/elapsedMs,renderedFrames:frameDelta,renderedHz:frameDelta*1000/elapsedMs,intervalMedianMs:pick(.5),intervalP95Ms:pick(.95),intervalMaxMs:sorted.at(-1),gapsAtLeast250Ms:intervals.filter(t=>t>=250).length,intervalsMs:intervals};
}
export function classifyCadence(cadence, softwareRenderer) {
  const longGapFraction=cadence.gapsAtLeast250Ms/(cadence.callbacks-1);
  const unsuitable=cadence.renderedHz<LOW_CADENCE.renderedHzBelow || longGapFraction>LOW_CADENCE.longGapFractionAbove;
  return {unsuitable,longGapFraction,softwareRenderer,status:unsuitable?'LOW_CADENCE':'MEASURED_DEVICE_ONLY',technicalStatus:unsuitable&&softwareRenderer?'TECHNICAL_PASS_SOFTWARE_LOW_CADENCE_VISUAL_PENDING':'TECHNICAL_PASS',thresholds:LOW_CADENCE};
}
function publicText(value) {
  return String(value).replace(/(Bearer\s+)[\w.~-]+/gi,'$1[REDACTED]').replace(/([?&](?:token|key|secret|code|signature|sig|password)=[^\s&#]*)/gi,'[REDACTED_QUERY]').replace(/((?:password|api[_-]?key|access[_-]?token)\s*[=:]\s*)[^\s,;]+/gi,'$1[REDACTED]');
}
function installPassiveObservation() {
  const q=window.__splatsQA={events:[],raf:[],collectRaf:false};
  for(const type of ['keydown','keyup','pointerdown','pointerup','pointercancel','lostpointercapture','focus','blur','visibilitychange']) {
    const target=type==='visibilitychange'?document:window;
    target.addEventListener(type,e=>q.events.push({type,at:performance.now(),trusted:e.isTrusted,code:e.code||null,target:e.target?.id||e.target?.dataset?.key||e.target?.dataset?.view||e.target?.tagName||'window',hidden:document.hidden}),true);
  }
  function observe(t) {if(q.collectRaf)q.raf.push(t);requestAnimationFrame(observe);} requestAnimationFrame(observe);
}

export async function runSplatsQA() {
  const startedAtMs=Date.now(),expiresAtMs=startedAtMs+LIMITS.totalMs,output=path.resolve(process.env.SPLATS_OUTPUT||'splats-qa');
  mkdirSync(output,{recursive:true});
  // A second invocation in this checkout cannot silently spend another run budget.
  writeFileSync(path.resolve('.splats-deadline.json'),JSON.stringify({startedAtMs,expiresAtMs,totalBudgetMs:LIMITS.totalMs})+'\n',{flag:'wx'});
  const report={schemaVersion:1,runnerRevision:'raw-splats-bounded-r1',status:'RUNNING',visualStatus:'PENDING_MANUAL_SIDE_BACK_LOW_REVIEW',publicationAllowed:false,syntheticFixture:false,startedAtMs,expiresAtMs,totalBudgetMs:LIMITS.totalMs,limits:LIMITS,frames:[],checks:{},checkpoints:[],console:[],pageErrors:[],requests:[],errors:[],failures:[],limitations:[
    'Raw Gaussian GPU draws and nonempty pixels do not establish visual quality, orientation, coverage or complete back/underside structure.',
    'Overview is context. Side, back and low each require human review at normal scale and magnification before any visual conclusion.',
    'Conditional native blur, visibility and pointer cancellation are reported only if trusted browser events occur. No synthetic DOM events are used.',
    'Renderer counters and optional JS heap do not establish zero driver memory. No GPU byte-memory API is assumed.',
    'A 30 s load timeout means only that loading did not complete within this budget. Finer download/decode/GPU stages are UNKNOWN unless observed.',
    'This isolated approximately 84.564 m² patch cannot establish a large sea-world goal. No main world is updated.'
  ]};
  let browser,context,page,cdp,aborted=false,hardTimer,currentPhase='setup',expectedErrors=[],expectedNetworkMode=null;
  const save=()=>writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');
  const log=(event,detail={})=>{const item={event,phase:currentPhase,elapsedMs:Date.now()-startedAtMs,...detail};report.checkpoints.push(item);save();console.log('SPLATS_CHECKPOINT '+JSON.stringify(item));};
  const guard=cap=>{assert(!aborted,'Browser work stopped after first failure');return remaining(expiresAtMs,Date.now(),cap);};
  const op=async(name,fn,cap=LIMITS.workerMs,{cleanup=false}={})=>{
    const allowance=cleanup?remaining(expiresAtMs,Date.now(),cap):guard(cap);let timer;
    try {const value=await Promise.race([Promise.resolve().then(fn),new Promise((_,reject)=>{timer=setTimeout(()=>{aborted=true;reject(new Error('Bounded operation timeout: '+name));},allowance);})]);if(!cleanup)guard(1);return value;}
    catch(error){report.failedOperation??=name;throw error;}finally{clearTimeout(timer);}
  };
  const phase=async(name,fn)=>{guard();currentPhase=name;log('begin');await fn();log('done');};
  const state=()=>op('read-product-report',()=>page.evaluate(()=>reefProbe.report()));
  const passive=()=>op('read-passive-input',()=>page.evaluate(()=>window.__splatsQA.events));
  const callbacks=()=>op('two-actual-raf-callbacks',()=>page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve())))));
  const pause=ms=>op('real-elapsed-'+ms+'ms',()=>page.waitForTimeout(ms),Math.max(1000,ms+1000));
  const wait=async(name,fn,arg,cap=LIMITS.workerMs)=>op(name,()=>page.waitForFunction(fn,arg,{polling:100,timeout:guard(cap)}),cap);
  const rect=async(selector,fx=.5,fy=.5)=>op('native-target-'+selector,()=>page.evaluate(({selector,fx,fy})=>{
    const e=document.querySelector(selector);if(!e||e.disabled||e.hidden)throw new Error('Missing/disabled/hidden native target '+selector);
    const s=getComputedStyle(e),r=e.getBoundingClientRect(),x=r.x+r.width*fx,y=r.y+r.height*fy,hit=document.elementFromPoint(x,y);
    if(!r.width||!r.height||s.visibility==='hidden'||s.display==='none'||!(hit===e||e.contains(hit)))throw new Error('Native target obscured '+selector);
    return{x,y,width:r.width,height:r.height};
  },{selector,fx,fy}));
  const click=async selector=>{const r=await rect(selector);await op('mouse-click-'+selector,()=>page.mouse.click(r.x,r.y));};
  const key=async(code,down)=>op('native-key-'+code+'-'+(down?'down':'up'),()=>page.keyboard[down?'down':'up'](code));
  const releaseCheck=async label=>{await callbacks();const a=(await state()).camera;await pause(180);const b=(await state()).camera;assertStableCamera(a,b);return{label,before:a,after:b,stopped:true};};
  const movedSince=async(camera,label)=>{const frames=(await state()).stats.frames;return wait(label,({position,frames})=>{const r=reefProbe.report();return r.stats.frames>frames&&Math.hypot(...r.camera.position.map((v,i)=>v-position[i]))>.01;},{position:camera.position,frames});};
  const reset=async()=>{await click('[data-view="overview"]');await callbacks();return(await state()).camera;};
  const sampleResources=()=>op('read-resource-counters',()=>page.evaluate(()=>({report:reefProbe.report(),heap:performance.memory?{usedJSHeapSize:performance.memory.usedJSHeapSize,totalJSHeapSize:performance.memory.totalJSHeapSize,jsHeapSizeLimit:performance.memory.jsHeapSizeLimit}:null,gpuHeap:null})));
  const diagnostics=async target=>op('failure-last-state',()=>target.evaluate(()=>({report:window.reefProbe?.report()||null,stage:document.querySelector('#stage')?.textContent,detail:document.querySelector('#detail')?.textContent,failure:document.querySelector('#failure')?.textContent,fallbackVisible:document.querySelector('#fallback')?!document.querySelector('#fallback').hidden:null,bootstrapError:window.__reefProbeBootstrapError||null,events:window.__splatsQA?.events||[],downloadPhase:'UI_AND_NETWORK_ONLY',decodeSubstage:'UNKNOWN_UNLESS_REPORT_HISTORY_EXPOSES_IT'})),2000,{cleanup:true});
  function listen(target,label) {
    target.on('console',message=>{const text=publicText(message.text()),location=message.location();const expected=expectedNetworkMode && /Failed to fetch|Failed to load resource: net::ERR_(FAILED|ABORTED)|Failed to fetch dynamically imported module|Importing a module script failed/i.test(text);const item={page:label,type:message.type(),text,location,expected:!!expected,mode:expectedNetworkMode,elapsedMs:Date.now()-startedAtMs};report.console.push(item);save();console.log('SPLATS_CONSOLE '+JSON.stringify(item));});
    target.on('pageerror',error=>{const item={page:label,error:publicText(error.stack||error),elapsedMs:Date.now()-startedAtMs};report.pageErrors.push(item);save();console.error('SPLATS_PAGE_ERROR '+JSON.stringify(item));});
    target.on('requestfailed',request=>{const url=request.url(),expected=expectedNetworkMode==='intentional-bootstrap-import-failure'?url===new URL('probe.js',report.url).href:['cancel-local-ply','intentional-local-ply-failure'].includes(expectedNetworkMode)&&url===new URL(report.device.manifest.asset.url,report.url).href;const item={page:label,event:'failed',url:publicText(url),failure:request.failure(),expected,mode:expectedNetworkMode,elapsedMs:Date.now()-startedAtMs};report.requests.push(item);save();console.log('SPLATS_REQUEST '+JSON.stringify(item));});
    target.on('response',response=>{const u=new URL(response.url());if(u.pathname.endsWith('.ply')||response.status()>=400){const item={page:label,event:'response',url:u.origin+u.pathname,status:response.status(),elapsedMs:Date.now()-startedAtMs};report.requests.push(item);save();console.log('SPLATS_REQUEST '+JSON.stringify(item));}});
  }
  function healthy() {assert.deepEqual(report.pageErrors,[],'Unhandled browser runtime errors');const errors=report.console.filter(e=>e.type==='error'&&!e.expected);assert.equal(errors.length,0,'Unexpected browser console errors: '+JSON.stringify(errors));assert.deepEqual(report.requests.filter(r=>r.event==='failed'&&!r.expected),[],'Unexpected failed browser requests');}
  const drawReady=async()=>{await wait('actual-gaussian-draw',()=>{const r=window.reefProbe?.report();return r?.status==='error'||r?.draw?.nonzeroSplatDraws>0;});const r=await state();assertProduct(r,expectedErrors);report.lastReadyReport=r;healthy();return r;};
  const load=async label=>{const t=Date.now();try{await op(label,()=>page.evaluate(()=>reefProbe.load()),LIMITS.assetMs);}catch(error){if(Date.now()-t>=LIMITS.assetMs-50)report.failureMeaning='LOAD_NOT_COMPLETED_WITHIN_30S; cause not established';throw error;}return drawReady();};
  const unload=async label=>{await op(label,()=>page.evaluate(()=>reefProbe.unload()));const r=await state();assertDisposed(r);await pause(200);const after=await state();assert.equal(after.stats.frames,r.stats.frames,'Render frames continued after unload');assert.equal(after.draw,null);return{report:r,framesStopped:true};};
  hardTimer=setTimeout(()=>{aborted=true;report.status='TECHNICAL_FAIL';report.failedOperation??=currentPhase;report.failures.push('Hard 450 s process deadline reached; no rerun authorized');report.completedAtMs=Date.now();save();console.error('SPLATS_HARD_DEADLINE '+JSON.stringify({phase:currentPhase,lastReadyReport:report.lastReadyReport||null}));process.exit(1);},remaining(expiresAtMs));
  try {
    await phase('source-and-supported-browser',async()=>{
      const contract=JSON.parse(readFileSync(new URL('./splats-contract.json',import.meta.url)));
      const input=process.env.SPLATS_URL;assert(input,'SPLATS_URL is required');const u=new URL(input);assert(['127.0.0.1','localhost','[::1]'].includes(u.hostname),'GPU runner only accepts the authorized isolated localhost build');assert.equal(u.pathname.replace(/\/$/,''),'/'+contract.candidatePath);assert(!u.search&&!u.hash&&!u.username&&!u.password,'Local source URL must not contain credentials or parameters');u.pathname='/'+contract.candidatePath+'/';const base=u.href;
      report.url=u.origin+u.pathname;report.dependencyPins=contract.dependencyPins;
      const sourceHashAggregate=sha256(Object.keys(contract.sourceHashes).sort().map(f=>f+'\0'+contract.sourceHashes[f]+'\n').join(''));assert.equal(sourceHashAggregate,contract.sourceHashAggregate);
      const root=path.resolve(process.env.SPLATS_PAGE_ROOT||path.join('dist',contract.candidatePath));
      for(const[file,hash]of Object.entries(contract.sourceHashes))assert.equal(sha256(readFileSync(path.join(root,file))),hash,'Frozen source '+file);
      const candidateSourceCommit=process.env.SPLATS_SOURCE_COMMIT,checkoutCommit=process.env.GITHUB_SHA;assert.match(candidateSourceCommit||'',/^[0-9a-f]{40}$/);assert.match(checkoutCommit||'',/^[0-9a-f]{40}$/);
      report.sourceIdentity={candidatePath:contract.candidatePath,sourceHashAggregate,sourceFiles:Object.keys(contract.sourceHashes).length,candidateSourceCommit,checkoutCommit,baseMainCommit:contract.baseMainCommit};report.runIdentity={runId:process.env.GITHUB_RUN_ID,runAttempt:process.env.GITHUB_RUN_ATTEMPT,qaCommit:checkoutCommit};assert.match(report.runIdentity.runId||'',/^\d+$/);assert.match(report.runIdentity.runAttempt||'',/^\d+$/);
      const {chromium}=await op('load-official-playwright',()=>import(pathToFileURL(path.resolve(process.env.SPLATS_PLAYWRIGHT||'tests/browser/node_modules/playwright/index.mjs')).href));
      // Keep the existing official sandbox launch. No security or graphics fallback.
      browser=await op('launch-supported-browser',()=>chromium.launch({channel:'chromium',headless:true,chromiumSandbox:true,timeout:30000,args:['--enable-automation'],ignoreDefaultArgs:['--enable-unsafe-swiftshader','--disable-gpu-sandbox','--ignore-gpu-blocklist']}),32000);
      const session=await op('browser-command-session',()=>browser.newBrowserCDPSession());const command=await op('verify-browser-command',()=>session.send('Browser.getBrowserCommandLine'));assertLaunchArguments(command.arguments);
      report.browser={version:browser.version(),sandbox:true,forbiddenFlagsAbsent:true,headless:true,hasTouch:true};
      context=await op('create-context',()=>browser.newContext({viewport:{width:EXPECTED.width,height:EXPECTED.height},deviceScaleFactor:1,hasTouch:true,reducedMotion:'no-preference'}));page=await op('create-main-page',()=>context.newPage());page.setDefaultTimeout(LIMITS.workerMs);listen(page,'main');
      cdp=await op('create-native-input-session',()=>context.newCDPSession(page));await op('install-passive-observer',()=>page.addInitScript(installPassiveObservation));
      report.servedSourceHashes={};
      // The PLY identity is checked by the actual page load; do not fetch another dataset/LOD.
      for(const[file,expected]of Object.entries(contract.sourceHashes)){if(file.endsWith('.ply'))continue;const response=await op('verify-served-'+file,()=>context.request.get(new URL(file,base).href,{timeout:LIMITS.assetMs}),LIMITS.assetMs);assert(response.ok(),'Served source HTTP '+file);const bytes=await op('read-served-'+file,()=>response.body(),LIMITS.assetMs);assert.equal(sha256(bytes),expected,'Served source hash '+file);report.servedSourceHashes[file]=expected;await response.dispose();}
    });
    await phase('initial-load-and-actual-draw',async()=>{
      const loadExpiresAtMs=Math.min(expiresAtMs,Date.now()+LIMITS.assetMs);
      try{await op('initial-navigation',()=>page.goto(report.url,{waitUntil:'domcontentloaded',timeout:remaining(loadExpiresAtMs)}),remaining(loadExpiresAtMs));await wait('initial-load-ready',()=>window.reefProbe?.getState()==='ready'||window.reefProbe?.getState()==='error'||window.__reefProbeBootstrapError,null,remaining(loadExpiresAtMs));}
      catch(error){report.failureMeaning='LOAD_NOT_COMPLETED_WITHIN_30S; cause not established';throw error;}
      report.initial=await drawReady();const device=await op('read-device',()=>page.evaluate(()=>({devicePixelRatio,viewport:[innerWidth,innerHeight],userAgent:navigator.userAgent,platform:navigator.platform,hardwareConcurrency:navigator.hardwareConcurrency,deviceMemory:navigator.deviceMemory??null,manifest:reefProbe.manifest})));
      assert.equal(device.devicePixelRatio,1);assert.deepEqual(device.viewport,[EXPECTED.width,EXPECTED.height]);report.device=device;assert.equal(device.manifest.asset.bytes,EXPECTED.bytes);
      const driver=report.initial.gl.unmaskedRenderer||report.initial.gl.renderer;report.browser.graphics={...report.initial.gl,softwareRenderer:/swiftshader|llvmpipe|softpipe|software|lavapipe/i.test(driver),physicalGpu:'UNVERIFIED: WebGL device string alone does not establish physical-device performance'};
      report.checks.identityAndActualDraw={status:'PASS',count:report.initial.source.count,sha256:report.initial.source.sha256,draw:report.initial.draw};
    });
    await phase('four-fixed-view-captures',async()=>{
      for(const name of VIEWS){const before=await state();assert(await op('set-view-'+name,()=>page.evaluate(v=>reefProbe.setView(v),name)));await wait('settle-view-'+name,previous=>{const r=reefProbe.report();return r.draw.nonzeroSplatDraws>previous&&r.stats.frames>0;},before.draw.nonzeroSplatDraws,LIMITS.viewSettleMs);
        const evidence=await op('capture-actual-'+name,()=>page.evaluate(v=>reefProbe.captureEvidence(v),name));assertCapture(evidence,name);const r=await state();assertProduct(r,expectedErrors);
        const file=name+'.png';await op('png-'+name,()=>page.screenshot({path:path.join(output,file),timeout:LIMITS.pngMs}),LIMITS.pngMs);const bytes=readFileSync(path.join(output,file));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(bytes.readUInt32BE(16),EXPECTED.width);assert.equal(bytes.readUInt32BE(20),EXPECTED.height);assertStableCamera(r.camera,(await state()).camera);
        report.frames.push({name,file,bytes:bytes.length,sha256:sha256(bytes),width:EXPECTED.width,height:EXPECTED.height,evidence,report:r,role:name==='overview'?'ORIENTATION_CONTEXT':'MANDATORY_VISUAL_REVIEW',visualStatus:'PENDING'});writeFileSync(path.join(output,name+'.json'),JSON.stringify({evidence,report:r},null,2)+'\n');log('frame-saved',{name});}
      report.checks.fixedViews={status:'PASS_NONEMPTY_DRAW_ONLY',views:VIEWS,visualAcceptance:false};
    });
    await phase('native-controls-and-release',async()=>{
      const original=await reset();await click('#reef');await key('w',true);await pause(500);await movedSince(original,'completed-frame-native-W');await key('w',false);const forward=(await state()).camera;assert(distance(original.position,forward.position)>.01,'Native W did not move');const wRelease=await releaseCheck('W release');
      const center=await rect('#reef');await op('drag-start-position',()=>page.mouse.move(center.x,center.y));await op('drag-down',()=>page.mouse.down());await op('drag-move',()=>page.mouse.move(center.x+90,center.y+25,{steps:8}));await op('drag-up',()=>page.mouse.up());await callbacks();const drag=(await state()).camera;assert.notDeepEqual(drag.quaternion,forward.quaternion,'Native drag did not rotate');
      await key('s',true);await pause(500);await movedSince(drag,'completed-frame-native-S');await key('s',false);const backward=(await state()).camera;assert(distance(drag.position,backward.position)>.01,'Native S did not move');const sRelease=await releaseCheck('S release');assertStableCamera(original,await reset());
      const button=await rect('[data-key="KeyW"]');await op('button-position',()=>page.mouse.move(button.x,button.y));await op('button-hold',()=>page.mouse.down());await pause(400);await movedSince(original,'completed-frame-native-button');await op('button-release',()=>page.mouse.up());const buttonMoved=(await state()).camera;assert(distance(original.position,buttonMoved.position)>.01,'On-screen forward button did not move');const buttonRelease=await releaseCheck('on-screen release');
      await reset();await click('#guides');const focused=await op('read-button-focus',()=>page.evaluate(()=>document.activeElement?.id));assert.equal(focused,'guides');const a=(await state()).camera;for(const code of ['w','ArrowUp']){await key(code,true);await pause(250);await key(code,false);}assertStableCamera(a,(await state()).camera);await click('#guides');
      const events=await passive();assert(events.some(e=>e.type==='keydown'&&e.code==='KeyW'&&e.trusted));assert(events.some(e=>e.type==='pointerdown'&&e.trusted));assert(events.some(e=>e.type==='pointerup'&&e.trusted));
      report.checks.controls={status:'PASS',original,forward,drag,backward,wRelease,sRelease,buttonRelease,focusedButtonBlocksWAndArrow:true,exactReset:true};
    });
    await phase('native-cancellation-and-tab-lifecycle',async()=>{
      const cancelStart=await reset();const start=(await passive()).length,button=await rect('[data-key="KeyW"]');let touchSupported=true;
      try{await op('native-touch-start',()=>cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:button.x,y:button.y,id:1}]}));await pause(300);await movedSince(cancelStart,'completed-frame-native-touch');await op('native-touch-cancel',()=>cdp.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]}));}catch(error){if(!aborted&&/not supported|wasn't found|Unknown method/i.test(String(error)))touchSupported=false;else throw error;}
      const cancelEvents=(await passive()).slice(start),canceled=cancelEvents.some(e=>e.type==='pointercancel'&&e.trusted);report.checks.pointerCancel={status:touchSupported&&canceled?'OBSERVED_TRUSTED':'UNSUPPORTED_NATIVE_EVENT',events:cancelEvents};if(canceled)report.checks.pointerCancel.release=await releaseCheck('native pointercancel');
      report.checks.lostPointerCapture={status:(await passive()).some(e=>e.type==='lostpointercapture'&&e.trusted)?'OBSERVED_TRUSTED_WITH_RELEASE':'UNSUPPORTED_NATIVE_EVENT',independentlyForced:false};
      await reset();await click('#reef');const first=(await passive()).length;await key('w',true);await pause(180);const other=await op('create-other-tab',()=>context.newPage());await op('activate-other-tab',()=>other.bringToFront());await pause(250);await op('return-main-tab',()=>page.bringToFront());const life=(await passive()).slice(first),blur=life.some(e=>e.type==='blur'&&e.trusted),hidden=life.some(e=>e.type==='visibilitychange'&&e.hidden&&e.trusted);
      if(blur||hidden)report.checks.tabRelease=await releaseCheck('actual tab lifecycle');await key('w',false);await op('close-other-tab',()=>other.close());report.checks.blur={status:blur?'OBSERVED_TRUSTED':'UNSUPPORTED_NATIVE_EVENT',events:life};report.checks.visibility={status:hidden?'OBSERVED_TRUSTED':'UNSUPPORTED_NATIVE_EVENT',reason:hidden?null:'Headless tab activation produced no trusted hidden event; no synthetic visibility used'};await reset();
    });
    await phase('reference-boundary-and-toggle',async()=>{
      const before=await op('guide-toggle-state',()=>page.locator('#guides').getAttribute('aria-pressed'));await click('#guides');assert.notEqual(await op('guide-toggle-off',()=>page.locator('#guides').getAttribute('aria-pressed')),before);await click('#guides');assert.equal(await op('guide-toggle-restored',()=>page.locator('#guides').getAttribute('aria-pressed')),before);
      await op('set-near-boundary-low-view',()=>page.evaluate(()=>reefProbe.setView('low')));await callbacks();await click('#reef');await key('w',true);await wait('native-entry-reference',()=>{const p=reefProbe.report().camera.position,c=reefProbe.manifest.coordinates.rawOrigin,b=reefProbe.manifest.bounds.orthoXY;return p[0]+c[0]>=b.min_x&&p[0]+c[0]<=b.max_x&&c[1]-p[2]>=b.min_y&&c[1]-p[2]<=b.max_y;});await key('w',false);await wait('inside-disclosure',()=>document.querySelector('#boundary').textContent.startsWith('在参考范围内'),null,LIMITS.workerMs);const inside=await state(),insideText=await op('read-inside-disclosure',()=>page.locator('#boundary').innerText());assert.equal(referenceOutside(inside.camera.position,report.device.manifest),false);assert.match(insideText,/可能缺失|覆盖保证/);
      await key('s',true);await wait('native-exit-reference',()=>{const p=reefProbe.report().camera.position,c=reefProbe.manifest.coordinates.rawOrigin,b=reefProbe.manifest.bounds.orthoXY;return p[0]+c[0]<b.min_x||p[0]+c[0]>b.max_x||c[1]-p[2]<b.min_y||c[1]-p[2]>b.max_y;});await key('s',false);await wait('outside-disclosure',()=>document.querySelector('#boundary').textContent.startsWith('当前在参考范围外'),null,LIMITS.workerMs);const outside=await state(),outsideText=await op('read-outside-disclosure',()=>page.locator('#boundary').innerText());assert.equal(referenceOutside(outside.camera.position,report.device.manifest),true);
      report.checks.boundary={status:'PASS_NATIVE_CROSSING',inside:inside.camera,outside:outside.camera,insideText,outsideText,guideButtonToggled:true,guideGeometryVisibility:'NOT_DIRECTLY_EXPOSED; compare saved scene and frozen source; toggle DOM alone is not geometry proof',noInventedSeabed:'FROZEN_SOURCE_AND_PENDING_VISUAL_REVIEW'};
    });
    await phase('ten-seconds-actual-motion-cadence',async()=>{
      await reset();await click('#reef');const before=await state();await op('start-passive-raf-recording',()=>page.evaluate(()=>{window.__splatsQA.raf=[];window.__splatsQA.collectRaf=true;}));await key('w',true);await pause(5100);await key('w',false);await key('s',true);await pause(5100);await key('s',false);await wait('at-least-ten-seconds-actual-RAF',()=>{const a=window.__splatsQA.raf;return a.length>1&&a.at(-1)-a[0]>=10000;});const after=await state();const timestamps=await op('stop-passive-raf-recording',()=>page.evaluate(()=>{window.__splatsQA.collectRaf=false;return window.__splatsQA.raf;}));const cadence=cadenceSummary(timestamps,after.stats.frames-before.stats.frames);assert(distance(before.camera.position,after.camera.position)>.00001||after.view==='free','No native motion during timing');assertProduct(after,expectedErrors);const classification=classifyCadence(cadence,report.browser.graphics.softwareRenderer);report.checks.performance={...classification,cadence,timestamps,productFrameWorkMedianMs:after.stats.frameWorkMedianMs,productFrameWorkP95Ms:after.stats.frameWorkP95Ms,frameWorkIsFps:false,productionPerformanceClaim:false};writeFileSync(path.join(output,'actual-raf-cadence.json'),JSON.stringify(report.checks.performance,null,2)+'\n');
      assert(cadence.renderedFrames>0,'No product render frames during actual RAF interval');if(classification.unsuitable){report.limitations.push('LOW_CADENCE: motion is unsuitable on this measured device. No further sustained motion pressure is performed; required lifecycle and error cleanup still run. No reduction, acceleration or hardware-performance claim.');assert(classification.softwareRenderer,'Unsuitable motion on a non-software test device stops this source route');log('software-low-cadence',{renderedHz:cadence.renderedHz,longGapFraction:classification.longGapFraction});}
    });
    await phase('three-awaited-load-unload-cycles',async()=>{
      const cycles=[];for(let i=0;i<3;i++){const before=await sampleResources(),disposed=await unload('cycle-'+(i+1)+'-unload'),after=await sampleResources();const ready=await load('cycle-'+(i+1)+'-load');cycles.push({cycle:i+1,before,disposed,after,reloaded:{source:ready.source,draw:ready.draw,stats:ready.stats}});report.checks.cycles={status:'RUNNING',cycles};save();}
      for(const field of ['geometries','textures']){const values=cycles.map(c=>c.disposed.report.stats.lastDispose.after[field]);assert(values.every(Number.isFinite));assert(values.every(n=>n<=values[0]),'Renderer resource growth after disposal: '+field);}
      report.checks.cycles={status:'PASS',cycles,rendererMemoryReturned:true,driverMemoryReleased:'UNVERIFIED',heapInterpretation:'Recorded when exposed; no forced GC and no zero-driver-memory claim'};
    });
    await phase('unload-during-load-and-rapid-repeated-load',async()=>{
      await unload('before-cancel-unload');const assetURL=new URL(report.device.manifest.asset.url,report.url).href;let seen,release;const reached=new Promise(resolve=>{seen=resolve;}),held=new Promise(resolve=>{release=resolve;});const holdRoute=async route=>{seen();await held;await route.abort('aborted').catch(()=>{});};await op('hold-only-local-ply',()=>page.route(assetURL,holdRoute));expectedNetworkMode='cancel-local-ply';
      const loading=op('cancel-pending-load',()=>page.evaluate(()=>reefProbe.load()),LIMITS.assetMs);loading.catch(()=>{});await op('observe-pending-ply',()=>reached);const stopping=op('cancel-load-via-unload',()=>page.evaluate(()=>reefProbe.unload()));stopping.catch(()=>{});await wait('observe-cancel-before-releasing-request',()=>['unloading','unloaded'].includes(reefProbe.getState()));release();await op('await-load-and-unload',()=>Promise.all([loading,stopping]));await op('remove-cancel-route',()=>page.unroute(assetURL,holdRoute));const canceled=await state();assertDisposed(canceled);assert.deepEqual(canceled.errors,expectedErrors);expectedNetworkMode=null;
      // Three rapid calls are one explicitly requested repeated-action test; each promise is awaited.
      await op('rapid-three-load-actions',()=>page.evaluate(async()=>{const pending=[reefProbe.load(),reefProbe.load(),reefProbe.load()];await Promise.all(pending);}),LIMITS.assetMs);const repeated=await drawReady();assert.equal(repeated.stats.loads,canceled.stats.loads+1,'Repeated loads left multiple initialized runtimes');
      report.checks.loadCancellation={status:'PASS',report:canceled,assetRequestWasHeld:true};report.checks.rapidRepeatedLoad={status:'PASS',calls:3,allPromisesAwaited:true,report:repeated};
    });
    await phase('one-blocked-ply-error-and-one-retry',async()=>{
      await unload('before-error-unload');const assetURL=new URL(report.device.manifest.asset.url,report.url).href;let blocked=0;const deny=route=>{blocked++;return route.abort('failed');};await op('block-only-local-ply',()=>page.route(assetURL,deny));expectedNetworkMode='intentional-local-ply-failure';await op('intentional-failed-load',()=>page.evaluate(()=>reefProbe.load()),LIMITS.assetMs);const failed=await state();assert.equal(failed.status,'error');assert.equal(failed.source.count,0);assert.equal(failed.draw,null);assert.equal(failed.camera,null);assert.equal(blocked,1);assert.equal(failed.errors.length,expectedErrors.length+1);const error=failed.errors.at(-1);assert.equal(error.kind,'load');assert.match(error.message,/Failed to fetch|NetworkError|Load failed/i);assert(failed.stats.lastDispose.meshCleared&&failed.stats.lastDispose.sortWorkerCleared);assert.equal(failed.stats.lastDispose.sceneChildren,0);const failureUI=await op('read-truthful-error-ui',()=>page.evaluate(()=>({visible:!document.querySelector('#fallback').hidden,text:document.querySelector('#failure').textContent})));assert(failureUI.visible&&failureUI.text.trim());await pause(180);assert.equal((await state()).stats.frames,failed.stats.frames,'Stale render scene survived failed load');
      expectedErrors=failed.errors;await op('unblock-local-ply',()=>page.unroute(assetURL,deny));await click('#retry');await wait('single-retry-ready',()=>reefProbe.getState()==='ready'||reefProbe.getState()==='error',null,LIMITS.assetMs);const retried=await drawReady();expectedNetworkMode=null;report.checks.assetFailure={status:'PASS',blockedRequests:blocked,failed,failureUI,oneRetry:true,retried};
    });
    await phase('bootstrap-error-ui-and-final-teardown',async()=>{
      report.finalReadyReport=await drawReady();report.finalDisposal=await unload('final-scene-unload');report.nativeEvents=await passive();
      const negative=await op('create-bootstrap-negative-page',()=>context.newPage());listen(negative,'bootstrap');const scriptURL=new URL('probe.js',report.url).href;let blocked=0;await op('block-bootstrap-import',()=>negative.route(scriptURL,route=>{blocked++;return route.abort('failed');}));expectedNetworkMode='intentional-bootstrap-import-failure';await op('load-bootstrap-negative-page',()=>negative.goto(report.url,{waitUntil:'domcontentloaded',timeout:LIMITS.assetMs}),LIMITS.assetMs);await op('observe-bootstrap-ui',()=>negative.waitForFunction(()=>window.__reefProbeBootstrapError,{},{timeout:LIMITS.workerMs}));const failure=await diagnostics(negative);assert.equal(blocked,1);assert(failure.fallbackVisible&&failure.failure&&!failure.report);report.checks.bootstrapError={status:'PASS',failure,blockedImports:blocked};await op('close-bootstrap-negative-page',()=>negative.close());expectedNetworkMode=null;report.checks.absentWebGL={status:'NOT_INDUCED',reason:'No disabled graphics or renderer substitute. A natural initial WebGL creation failure stops and records truthful fallback; source branch alone is not browser evidence.'};healthy();
    });
    await op('close-supported-browser',()=>browser.close());browser=null;
    report.status=report.checks.performance.technicalStatus;report.completedAtMs=Date.now();report.elapsedMs=report.completedAtMs-startedAtMs;guard();save();console.log('SPLATS_COMPLETE '+JSON.stringify({status:report.status,visualStatus:report.visualStatus,publicationAllowed:false,elapsedMs:report.elapsedMs,frames:report.frames.map(f=>({name:f.name,sha256:f.sha256}))}));return report;
  } catch(error) {
    aborted=true;report.status='TECHNICAL_FAIL';report.failures.push(publicText(error.stack||error));report.errors.push({operation:report.failedOperation||currentPhase,message:publicText(error.message||error)});report.completedAtMs=Date.now();report.elapsedMs=report.completedAtMs-startedAtMs;save();
    if(page&&!page.isClosed()&&expiresAtMs-Date.now()>2100){try{report.lastObservedState=await diagnostics(page);}catch(secondary){report.diagnosticFailure=publicText(secondary.message||secondary);}}
    save();console.error('SPLATS_FAILED '+JSON.stringify({failedOperation:report.failedOperation,failures:report.failures,failureMeaning:report.failureMeaning||null,lastObservedState:report.lastObservedState||null,frames:report.frames.map(f=>f.name)}));throw error;
  } finally {
    if(browser&&expiresAtMs-Date.now()>0){try{await op('close-after-failure',()=>browser.close(),Math.min(5000,expiresAtMs-Date.now()),{cleanup:true});browser=null;}catch(error){report.cleanupFailure=publicText(error.message||error);}}
    // A hung browser close must not escape the original process deadline.
    if(!browser)clearTimeout(hardTimer);save();
  }
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))runSplatsQA().catch(error=>{console.error('SPLATS_EXIT '+publicText(error.message||error));process.exitCode=1;});
