"""Small local bookkeeping fixtures only; no browser, GPU or publication evidence."""
from pathlib import Path
import contextlib
import copy
import importlib.util
import io
import json
import os
import struct
import sys
import tempfile
import time
import zipfile
import zlib

T = Path(__file__).resolve().parent
P = T.parent
sys.path.insert(0, str(T))
import splats_common as common
def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, T / filename); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
stage = module('stage', 'stage-splats.py')
final = module('finalizer', 'finalize-splats.py')
verify = module('verify', 'verify-splats-preserved.py')
checks = []
def rec(n, b): return {'path': n, 'bytes': len(b), 'sha256': common.sha(b)}
def write(n, b):
    p = Path(n); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b)
def quiet(fn, *a, **kw):
    with contextlib.redirect_stdout(io.StringIO()): return fn(*a, **kw)
def rejects(label, fn):
    try: quiet(fn)
    except (ValueError, KeyError, AssertionError, FileNotFoundError): checks.append(label); return
    raise AssertionError('Did not reject: ' + label)
def png():
    def chunk(n, b): return struct.pack('>I', len(b)) + n + b + struct.pack('>I', zlib.crc32(n + b))
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1120, 712, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress((b'\0' + b'\x20\x50\x60' * 1120) * 712)) + chunk(b'IEND', b'')

def fixture(c):
    for i in range(79): write('dist/root-' + str(i), str(i).encode())
    common.save_json('.root-site-hashes.json', common.inventory('dist'))
    for i in range(2045): write('dist/preview/older/' + str(i), str(i).encode())
    world = {n: ('world:' + n).encode() for n in c['immutableWorldPaths']}
    for n, b in world.items(): write('dist/' + n, b)
    c['worldEntryFiles'] = [rec(n, b) for n, b in world.items()]
    protected = common.inventory('dist'); assert len(protected) == 2127
    common.save_json('.fixture-upstream-protected.json', protected)
    def upstream(_): return common.read_json('.fixture-upstream-protected.json')
    common.assembly_protection = stage.assembly_protection = upstream
    base = {n: ('surface:' + n).encode() for n in c['baseSourceHashes']}
    c['baseSourceFiles'] = [rec(n, b) for n, b in sorted(base.items())]
    c['baseSourceHashes'] = {f['path']: f['sha256'] for f in c['baseSourceFiles']}
    for n, b in base.items(): write('dist/' + c['basePath'] + '/' + n, b)
    saved = {f['path']: ('surface-evidence:' + f['path']).encode() for f in c['snapshotFiles']}
    c['snapshotFiles'] = [rec(n, b) for n, b in sorted(saved.items())]
    c['oldPublicFiles'] = [dict(f, path=c['basePath'] + '/' + f['path']) for f in c['baseSourceFiles']] + c['snapshotFiles']
    candidate = {n: ('candidate:' + n).encode() for n in c['sourceHashes']}
    c['sourceFiles'] = [rec(n, b) for n, b in sorted(candidate.items())]
    c['sourceHashes'] = {f['path']: f['sha256'] for f in c['sourceFiles']}
    c['sourceHashAggregate'] = common.sha(''.join(n + '\0' + c['sourceHashes'][n] + '\n' for n in sorted(candidate)).encode())
    archive = {c['sourceArchiveMapping'][n]: b for n, b in candidate.items()}
    c['sourceArchiveFiles'] = [rec(n, b) for n, b in archive.items()]
    for key, files in [('snapshotArchive', saved), ('sourceArchive', archive)]:
        p = Path('.splats-inputs') / c[key]['path']; p.parent.mkdir(exist_ok=True)
        with zipfile.ZipFile(p, 'w') as z:
            for n, b in files.items(): z.writestr(n, b)
        c[key] = rec(p.name, p.read_bytes())
    return c

def main():
    actual = common.contract(); checks.append('actual15-source-exact-runtime-license-and-original-archive-contract')
    original_cwd = Path.cwd()
    keys = ['SPLATS_SOURCE_COMMIT', 'GITHUB_SHA', 'GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT', 'SPLATS_OUTPUT']
    original_env = {k: os.environ.get(k) for k in keys}
    os.environ.update(SPLATS_SOURCE_COMMIT='1' * 40, GITHUB_SHA='2' * 40, GITHUB_RUN_ID='12345', GITHUB_RUN_ATTEMPT='1', SPLATS_OUTPUT='splats-qa')
    try:
        with tempfile.TemporaryDirectory(prefix='splats-bookkeeping-', dir=P) as tmp:
            os.chdir(tmp); c = fixture(copy.deepcopy(actual)); before = common.inventory('dist')
            for key in ('sourceArchive', 'snapshotArchive'):
                path = Path('.splats-inputs') / c[key]['path']; raw = path.read_bytes(); path.write_bytes(raw + b'tampered')
                rejects(key + '-tamper-rejected-before-public-writes', lambda: stage.stage(c))
                assert common.inventory('dist') == before and not Path('.splats-protected.json').exists(); path.write_bytes(raw)
            quiet(stage.stage, c); quiet(verify.verify, c, True)
            assert len(common.inventory('dist')) == 2298 and len(common.read_json('.splats-protected.json')) == 2283
            checks.append('restored2277-to2283-protected-plus15-independent-sources')
            for label, path in [('root', Path('dist/root-0')), ('old-preview', Path('dist/preview/older/0')), ('surface-source', Path('dist') / c['basePath'] / 'scan-exhibit.js'), ('surface-gallery', Path('dist') / c['basePath'] / 'current-scene.html'), ('new-source', Path('dist') / c['candidatePath'] / 'probe.js'), ('world-index', Path('dist/preview/world/index.html')), ('world-css', Path('dist/preview/world/world.css')), ('world-pointer', Path('dist/preview/world/current-world.json')), ('unexpected-extra', Path('dist/preview/extra.txt'))]:
                raw = path.read_bytes() if path.exists() else None; path.write_bytes(b'tampered')
                rejects(label + '-mutation-rejected', lambda: verify.verify(c, True))
                path.unlink() if raw is None else path.write_bytes(raw)
            path = Path('.splats-protected.json'); raw = path.read_bytes(); value = json.loads(raw); value.pop('root-0'); common.save_json(path, value)
            rejects('protection-map-shrink-rejected', lambda: verify.verify(c, True)); path.write_bytes(raw)
            rejects('duplicate-stage-rejected', lambda: stage.stage(c))
            now = int(time.time() * 1000); deadline = dict(startedAtMs=now - 5000, expiresAtMs=now + 445000, totalBudgetMs=450000)
            common.save_json('.splats-deadline.json', deadline)
            Path('splats-qa').mkdir()
            report = dict(deadline, schemaVersion=1, status='TECHNICAL_FAIL', syntheticFixture=True, completedAtMs=now - 1000, frames=[])
            common.save_json('splats-qa/report.json', report)
            staged = common.inventory('dist')
            rejects('technical-FAIL-cannot-write-evidence-or-deploy', lambda: final.finalize(c)); assert common.inventory('dist') == staged
            report['status'] = 'TECHNICAL_PASS'; common.save_json('splats-qa/report.json', report)
            rejects('synthetic-PASS-rejected', lambda: final.finalize(c)); assert common.inventory('dist') == staged
            report['syntheticFixture'] = False; report.update(visualStatus='VISUAL_PASS', publicationAllowed=True); common.save_json('splats-qa/report.json', report)
            rejects('runner-visual-or-publication-claim-rejected', lambda: final.finalize(c)); assert common.inventory('dist') == staged
            # Positive packaging explicitly mocks the GPU gate. Never genuine evidence.
            frames = []
            for name in c['frames']:
                b = png(); write('splats-qa/' + name + '.png', b); frames.append(dict(rec(name + '.png', b), name=name, file=name + '.png', width=1120, height=712))
            report.update(status='TECHNICAL_PASS', visualStatus=c['visualStatus'], publicationAllowed=False, frames=frames, limitations=['Synthetic bookkeeping fixture only.'])
            common.save_json('splats-qa/report.json', report)
            final.validate_gpu = lambda *_: None
            path = Path('splats-qa/side.png'); raw = path.read_bytes(); path.write_bytes(raw + b'tampered')
            rejects('PNG-hash-tamper-before-public-writes', lambda: final.finalize(c)); assert common.inventory('dist') == staged; path.write_bytes(raw)
            quiet(final.finalize, c)
            current = common.inventory('dist'); assert len(current) == 2304
            assert all(current[n] == h for n, h in common.read_json('.splats-protected.json').items())
            receipt = common.read_json('.splats-finalized.json'); assert len(receipt['galleryFiles']) == 6 and receipt['appearanceAccepted'] is False and receipt['worldEntryChanged'] is False
            report_path = Path('dist') / c['candidatePath'] / 'assets/gpu' / c['sourceHashAggregate'] / 'report.json'
            assert report_path.read_bytes() == Path('splats-qa/report.json').read_bytes()
            checks.append('mocked-GPU-packaging-only-fourPNGs-exact-report-gallery2304-all2283-unchanged')
            rejects('duplicate-finalization-rejected', lambda: final.finalize(c))
            common.save_json('.splats-deadline.json', dict(deadline, expiresAtMs=now - 1, startedAtMs=now - 450001))
            rejects('single450-second-expired-deadline-rejected', common.check_deadline)
    finally:
        os.chdir(original_cwd)
        for k, v in original_env.items(): os.environ.pop(k, None) if v is None else os.environ.__setitem__(k, v)
    import yaml
    text = (P / 'pages-splats.template.yml').read_text(); prior = (P.parent / 'reef-surface-grounding-publish/pages-surface.yml').read_text()
    assert text.startswith(prior.split('      - name: Set up existing pinned capture dependency\n')[0])
    w = yaml.safe_load(text); old = yaml.safe_load(prior)
    assert w['permissions'] == old['permissions'] and w['jobs']['deploy']['timeout-minutes'] == 20
    steps = w['jobs']['deploy']['steps']; qa = [s for s in steps if 'browser-check-splats.mjs' in s.get('run', '')]
    assert len(qa) == 1 and qa[0]['timeout-minutes'] == 8
    assert 'browser-check-surface.mjs' not in text and 'EXPLORATION_QA_MODE' not in text and '--update-world' not in text
    assert qa[0]['run'].index('browser-check-splats.mjs') < qa[0]['run'].index('finalize-splats.py') < qa[0]['run'].rindex('verify-splats-preserved.py')
    artifact = [s for s in steps if s.get('uses') == 'actions/upload-artifact@v4']; assert len(artifact) == 1
    a = artifact[0]; assert a['if'] == 'always()' and a['with']['path'].split() == ['splats-qa/**/*.png', 'splats-qa/**/*.json'] and a['with']['retention-days'] == 7
    deploy_steps = steps[steps.index(a) + 1:]
    assert [s['uses'] for s in deploy_steps] == ['actions/configure-pages@v5', 'actions/upload-pages-artifact@v4', 'actions/deploy-pages@v4']
    assert all(s.get('if') in (None, 'success()') for s in deploy_steps)
    checks.extend(['immutable-original-assembly-prefix-byte-identical', 'single-splat-runner-old-A-B-not-rerun', 'job20min-singleQA8min-and-permissions-unchanged', 'failed-QA-only-retains-narrow-current-evidence-no-Pages-deploy'])
    for n in ('splats_common.py', 'stage-splats.py', 'finalize-splats.py', 'verify-splats-preserved.py'): compile((T / n).read_text(), str(T / n), 'exec')
    result = dict(status='PASS_LOCAL_TINYFIXTURE_TESTS', browserRun=False, gpuRun=False, note='Bookkeeping and fail-closed fixtures only. Upstream immutable-chain authentication is mocked; positive packaging bypasses GPU validation explicitly. No evidence here proves rendering or visual acceptance.', checks=checks)
    common.save_json(P / 'local-stage-test-result.json', result); print(json.dumps(result, indent=2))

if __name__ == '__main__': main()
