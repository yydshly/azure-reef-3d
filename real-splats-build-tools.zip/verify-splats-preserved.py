"""Fail closed on any old byte mutation, unexpected output or unsupported acceptance."""
from splats_common import *

def verify(c, source_only=False):
    check_sources(c); protected, current = check_old(c)
    expected = candidate_sources(c)
    if not source_only:
        r = read_json('.splats-finalized.json')
        require(r['state'] == 'TECHNICAL_PASS_INDEPENDENT_PREVIEW_WORLD_UNCHANGED' and r['worldEntryChanged'] is False and r['appearanceAccepted'] is False and r['visualStatus'] == c['visualStatus'], 'Final receipt claims unauthorized world/visual result')
        require('pointer' not in r and r['protectedFiles'] == 2283 and r['sourceIdentity'] == source_identity(c) and r['runIdentity'] == run_identity(), 'Final receipt identity or protection changed')
        records = r['galleryFiles']; names = {f['path'] for f in records}
        require(len(records) == len(names) == c['newGalleryFiles'], 'Exactly four PNGs, report and gallery required')
        prefix = c['candidatePath'] + '/assets/gpu/' + c['sourceHashAggregate'] + '/'
        static = {c['candidatePath'] + '/current-scene.html', prefix + 'report.json'}
        require(static <= names, 'Expected gallery/report missing')
        views = set()
        for f in records:
            safe_name(f['path'])
            if f['path'] not in static:
                suffix = '-' + f['sha256'][:16] + '.png'
                require(f['path'].startswith(prefix) and f['path'].endswith(suffix), 'Evidence path/hash mismatch')
                views.add(f['path'][len(prefix):-len(suffix)])
            p = DIST / f['path']; require(p.is_file() and not p.is_symlink(), 'Missing/linked evidence'); validate_bytes(p.read_bytes(), f, f['path'])
        require(views == set(c['frames']), 'Four evidence views changed')
        report = read_json(DIST / (prefix + 'report.json'))
        require(report['status'] == r['status'], 'Final/report status mismatch')
        import importlib.util
        spec = importlib.util.spec_from_file_location('splats_finalizer', HERE / 'finalize-splats.py'); module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        module.validate_gpu(c, report)
        expected |= names
    require(set(current) - set(protected) == expected and len(current) == c['stagedSiteFiles' if source_only else 'finalSiteFiles'], 'Unexpected/omitted published paths')
    result = dict(status='PASS_SOURCE_ONLY' if source_only else 'PASS_EXACT_INDEPENDENT_ADDITIONS_WORLD_UNCHANGED', oldSiteFiles=2283, protectedFiles=2283, protectedFilesByteIdentical=True, rootFilesByteIdentical=79, newFiles=len(expected), totalFiles=len(current), worldEntryChanged=False, appearanceAccepted=False)
    if not source_only:
        result.update(sourceIdentity=source_identity(c), runIdentity=run_identity(), files=[file_record(DIST / n, n) for n in sorted(expected)])
        save_json(pathlib.Path(os.environ.get('SPLATS_OUTPUT', 'splats-qa')) / 'public-receipt.json', result)
    print(json.dumps(result, indent=2)); return result

if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(); p.add_argument('--source-only', action='store_true'); p.add_argument('--deadline-only', action='store_true'); args = p.parse_args()
    require(not (args.source_only and args.deadline_only), 'Choose one verification mode')
    if args.deadline_only: check_deadline()
    else: verify(contract(), args.source_only)
