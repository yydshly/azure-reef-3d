"""Freeze original source archive and six saved surface products; never fetch."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

P = Path(__file__).resolve().parent.parent
W = P.parent
sha = lambda b: hashlib.sha256(b).hexdigest()
def record(n, b): return {'path': n, 'bytes': len(b), 'sha256': sha(b)}
def save(p, value): p.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n')

def main():
    previous = W / 'reef-surface-grounding-publish'
    old = json.loads((previous / 'tools/surface-contract.json').read_text())
    result_path = previous / 'evidence/public-receipt.json'
    result = json.loads(result_path.read_text())
    get_path = previous / 'public-get-receipt.json'
    fetched = json.loads(get_path.read_text())
    assert result['totalFiles'] == 2283 and result['protectedFilesByteIdentical'] is True
    assert fetched['mainCommit'] == result['sourceIdentity']['checkoutCommit'] == 'ef6a7618ef02bdcf8134aa3f395be5e9d90e2f6f'
    assert result['sourceIdentity']['candidateSourceCommit'] == 'b7008dcda978b1e09ceb6cbd7d9650a20b7f9ef0'
    assert result['sourceIdentity']['sourceHashAggregate'] == old['sourceHashAggregate']
    public = {f['path']: f for f in result['files']}
    sources = {old['candidatePath'] + '/' + f['path']: dict(f, path=old['candidatePath'] + '/' + f['path']) for f in old['sourceFiles']}
    assert all(public[n] == f for n, f in sources.items())
    snapshots = set(public) - set(sources)
    assert len(public) == 156 and len(snapshots) == 6
    gets = {f['sitePath']: f for f in fetched['verified']}
    saved = {}
    for n in sorted(snapshots):
        b = (previous / 'published' / n).read_bytes()
        assert record(n, b) == public[n]
        assert gets[n]['status'] == 200 and gets[n]['sha256'] == sha(b) and gets[n]['bytes'] == len(b)
        assert n.startswith(old['candidatePath'] + '/')
        saved[n] = b
    snapshot_path = P / 'surface-grounding-snapshot-ef6a7618.zip'
    with zipfile.ZipFile(snapshot_path, 'w', zipfile.ZIP_DEFLATED, 9) as z:
        for n, b in sorted(saved.items()):
            i = zipfile.ZipInfo(n, (2026, 10, 11, 0, 0, 0)); i.compress_type = zipfile.ZIP_DEFLATED; i.external_attr = 0o100644 << 16
            z.writestr(i, b)
    source_zip = W / 'reef-real-splats-deliverables/reef-real-splats-probe-SOURCE-20261011.zip'
    assert sha(source_zip.read_bytes()) == '38662ac0ecfa51f1b4747350dc4b54f7bcd4bae8ac57a72b4e7afcf4412e8430'
    source = W / 'reef-real-splats-probe'
    frozen = json.loads((source / 'verification/final-file-sha256.json').read_text())
    prefix = 'reef-real-splats-probe/'
    with zipfile.ZipFile(source_zip) as z:
        assert len(z.namelist()) == len(set(z.namelist())) == 109
        assert set(z.namelist()) == {prefix + n for n in frozen} | {prefix + 'verification/final-file-sha256.json'}
        archive_files = [record(n, z.read(n)) for n in sorted(z.namelist())]
        for n, f in frozen.items():
            b = z.read(prefix + n)
            assert record(n, b) == dict(f, path=n) and (source / n).read_bytes() == b
        assert z.read(prefix + 'verification/final-file-sha256.json') == (source / 'verification/final-file-sha256.json').read_bytes()
        mapping = {n[5:]: prefix + n for n in frozen if n.startswith('page/')}
        mapping.update({n: prefix + n for n in frozen if n.startswith('licenses/')})
        files = {n: z.read(origin) for n, origin in mapping.items()}
    assert len(files) == 15
    shutil.copyfile(source_zip, P / source_zip.name)
    hashes = {n: sha(b) for n, b in files.items()}
    aggregate = sha(''.join(n + '\0' + hashes[n] + '\n' for n in sorted(hashes)).encode())
    manifest = json.loads(files['assets/manifest.json'])
    world = [record(n, (previous / 'published' / n).read_bytes()) for n in old['mutableEntryPaths']]
    for f in world:
        assert gets[f['path']]['sha256'] == f['sha256'] and gets[f['path']]['bytes'] == f['bytes'] and gets[f['path']]['status'] == 200
    c = dict(schemaVersion=1, candidatePath='preview/real-splats-probe', basePath=old['candidatePath'], entryPath='preview/world',
        baseMainCommit=fetched['mainCommit'], baseSourceCommit=result['sourceIdentity']['candidateSourceCommit'],
        baseSourceHashAggregate=old['sourceHashAggregate'], baseSourceHashes=old['sourceHashes'], baseSourceFiles=old['sourceFiles'],
        sourceHashAggregate=aggregate, sourceHashes=hashes, sourceFiles=[record(n, files[n]) for n in sorted(files)],
        sourceArchiveMapping=mapping, sourceArchiveFiles=archive_files, sourceArchive=record(source_zip.name, source_zip.read_bytes()),
        oldPublicFiles=list(public.values()), snapshotFiles=[public[n] for n in sorted(saved)], snapshotArchive=record(snapshot_path.name, snapshot_path.read_bytes()),
        worldEntryFiles=world, immutableWorldPaths=old['mutableEntryPaths'], oldAssemblyProtectedFiles=2127, oldAssemblyFiles=2277,
        oldSiteFiles=2283, protectedFiles=2283, rootFiles=79, newSourceFiles=15, newGalleryFiles=6, stagedSiteFiles=2298, finalSiteFiles=2304,
        frames=['overview', 'side', 'back', 'low'], mandatoryVisualViews=['side', 'back', 'low'], frameSize=[1120, 712], totalBudgetMs=450000, captureTimeoutMs=25000,
        dependencyPins=manifest['dependencyPins'], source=manifest['source'], asset=manifest['asset'], coordinates=manifest['coordinates'], bounds=manifest['bounds'],
        sourceManifest=record('verification/final-file-sha256.json', (source / 'verification/final-file-sha256.json').read_bytes()),
        gpuTestContract=record('GPU-TEST-CONTRACT.md', (source / 'GPU-TEST-CONTRACT.md').read_bytes()),
        licenseFiles=[record(n, files[n]) for n in ('licenses/SPARK-MIT.txt', 'licenses/FFLATE-MIT.txt', 'vendor/THREE-LICENSE.txt')],
        allowWorldUpdate=False, technicalPassAllows='INDEPENDENT_PREVIEW_ONLY', visualStatus='PENDING_MANUAL_SIDE_BACK_LOW_REVIEW',
        acceptance='A technical pass permits only the separately authorized independent preview. Side, back and low views require manual visual review. No main world promotion, broad reef completeness, large world or performance claim is established.',
        provenance={'surfaceRunId': '38147691994', 'oldPublishedResult': record(str(result_path.relative_to(W)), result_path.read_bytes()), 'savedPublicReceipt': record(str(get_path.relative_to(W)), get_path.read_bytes())})
    save(P / 'tools/splats-contract.json', c)
    summary = dict(status='LOCAL_PREPARATION_ONLY', sourceFiles=15, pageFiles=13, addedUnmodifiedLicenseFiles=2, sourceHashAggregate=aggregate,
        snapshotFiles=6, protectedFiles=2283, stagedSiteFiles=2298, finalSiteFiles=2304, packages=[c['sourceArchive'], c['snapshotArchive']], browserRun=False, uploaded=False)
    save(P / 'input-package-receipt.json', summary)
    print(json.dumps(summary, indent=2))

if __name__ == '__main__': main()
