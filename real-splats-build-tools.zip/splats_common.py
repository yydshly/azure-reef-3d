"""Independent splat publication: exact old bytes, original source, bounded evidence."""
import hashlib
import json
import math
import os
import pathlib
import re
import stat
import struct
import time
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
DIST = pathlib.Path('dist')
INPUTS = pathlib.Path('.splats-inputs')
ENTRY_NAMES = ('index.html', 'world.css', 'current-world.json')

def require(condition, message):
    if not condition: raise ValueError(message)
def sha(data): return hashlib.sha256(data).hexdigest()
def read_json(path): return json.loads(pathlib.Path(path).read_text())
def json_bytes(value): return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()
def save_json(path, value): pathlib.Path(path).write_bytes(json_bytes(value))
def finite(v): return type(v) in (int, float) and math.isfinite(v)
def safe_name(name):
    require(isinstance(name, str) and bool(name), 'Missing relative path')
    p = pathlib.PurePosixPath(name)
    require(not p.is_absolute() and '..' not in p.parts and '\\' not in name and p.as_posix() == name and name != '.', 'Unsafe path: ' + name)
    return p
def inventory(root):
    root = pathlib.Path(root)
    require(root.is_dir() and not root.is_symlink(), 'Missing/linked directory: ' + str(root))
    result = {}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink() and (p.is_file() or p.is_dir()), 'Linked/special path: ' + str(p))
        if p.is_file(): result[p.relative_to(root).as_posix()] = sha(p.read_bytes())
    return result
def file_record(path, relative=None):
    p = pathlib.Path(path); b = p.read_bytes()
    return {'path': relative or p.name, 'bytes': len(b), 'sha256': sha(b)}
def validate_bytes(data, record, label):
    require(len(data) == record['bytes'] and sha(data) == record['sha256'], 'Size/SHA mismatch: ' + label)
def checked_archive(path, archive, expected):
    p = pathlib.Path(path)
    require(p.is_file() and not p.is_symlink(), 'Missing/linked archive: ' + str(p))
    validate_bytes(p.read_bytes(), archive, str(p))
    with zipfile.ZipFile(p) as z:
        require(len(z.namelist()) == len(set(z.namelist())) == len(expected) and set(z.namelist()) == set(expected), 'Unexpected archive file set: ' + str(p))
        files = {}
        for info in z.infolist():
            safe_name(info.filename); mode = info.external_attr >> 16
            require(not info.is_dir() and not stat.S_ISLNK(mode) and stat.S_IFMT(mode) in (0, stat.S_IFREG), 'Nonregular archive member')
            data = z.read(info); validate_bytes(data, expected[info.filename], info.filename); files[info.filename] = data
    return files

def contract():
    c = read_json(HERE / 'splats-contract.json')
    require(c['schemaVersion'] == 1 and c['candidatePath'] == 'preview/real-splats-probe' and c['basePath'] == 'preview/surface-grounding-candidate' and c['entryPath'] == 'preview/world', 'Destination changed')
    require(c['baseMainCommit'] == 'ef6a7618ef02bdcf8134aa3f395be5e9d90e2f6f' and c['baseSourceCommit'] == 'b7008dcda978b1e09ceb6cbd7d9650a20b7f9ef0', 'Published baseline changed')
    require([c[k] for k in ('oldAssemblyProtectedFiles', 'oldAssemblyFiles', 'oldSiteFiles', 'protectedFiles', 'rootFiles', 'newSourceFiles', 'newGalleryFiles', 'stagedSiteFiles', 'finalSiteFiles')] == [2127, 2277, 2283, 2283, 79, 15, 6, 2298, 2304], 'Publication counts changed')
    require(c['totalBudgetMs'] == 450000 and c['captureTimeoutMs'] == 25000 and c['frameSize'] == [1120, 712], '450/25-second or frame bounds changed')
    require(c['frames'] == ['overview', 'side', 'back', 'low'] and c['mandatoryVisualViews'] == ['side', 'back', 'low'], 'Required views changed')
    require(c['immutableWorldPaths'] == [c['entryPath'] + '/' + n for n in ENTRY_NAMES], 'World protection changed')
    require(c['allowWorldUpdate'] is False and c['technicalPassAllows'] == 'INDEPENDENT_PREVIEW_ONLY' and c['visualStatus'] == 'PENDING_MANUAL_SIDE_BACK_LOW_REVIEW', 'No world or visual acceptance allowed')
    require(len(c['sourceFiles']) == len(c['sourceHashes']) == len(c['sourceArchiveMapping']) == 15, 'Source counts changed')
    require({f['path']: f['sha256'] for f in c['sourceFiles']} == c['sourceHashes'], 'Source manifest mismatch')
    for n, h in c['sourceHashes'].items():
        safe_name(n); require(re.fullmatch('[0-9a-f]{64}', h), 'Invalid source hash')
    require(sha(''.join(n + '\0' + c['sourceHashes'][n] + '\n' for n in sorted(c['sourceHashes'])).encode()) == c['sourceHashAggregate'] == '1666f26cbd873f630a66015bc769889d7b1896962ebe2735672114688390b6b0', 'Source aggregate mismatch')
    require(c['sourceArchive']['sha256'] == '38662ac0ecfa51f1b4747350dc4b54f7bcd4bae8ac57a72b4e7afcf4412e8430' and len(c['sourceArchiveFiles']) == 109, 'Original full source archive changed')
    require(c['asset']['sha256'] == c['sourceHashes']['assets/soneva-ootsl1-20260218-lod4.ply'] == 'bdf77330d5a4df5c92aa2bb0f0dcc800ccebbc471903429703309c955fd82499', 'Raw Gaussian input changed')
    require(c['asset']['bytes'] == 7171392 and c['asset']['count'] == 30381 and c['asset']['shDegree'] == 3 and c['asset']['triangleFaces'] == 0, 'Raw Gaussian identity changed')
    require(c['source']['commit'] == '200aaf30cda920bd9b0e5d5da8838d4165c9e289' and c['source']['license'] == 'CC BY 4.0' and c['source']['licenseUrl'] == 'https://creativecommons.org/licenses/by/4.0/', 'Source revision/license changed')
    require(c['dependencyPins'] == {'spark': '2.3.1', 'three': '0.186.0', 'threeRevision': '186', 'sameThreeAsBaseline': 'verified-live'}, 'Runtime versions changed')
    require({f['path'] for f in c['licenseFiles']} == {'licenses/SPARK-MIT.txt', 'licenses/FFLATE-MIT.txt', 'vendor/THREE-LICENSE.txt'} and all(c['sourceHashes'][f['path']] == f['sha256'] for f in c['licenseFiles']), 'Required license bytes changed')
    require(c['coordinates']['uniformScale'] == 1 and c['coordinates']['noDeformation'] is True, 'Raw rigid mapping changed')
    return c

def assembly_protection(c):
    # Reuse the complete immutable archive/checker chain, never invent a new baseline.
    import surface_common as previous
    old = previous.contract()
    require(old['candidatePath'] == c['basePath'] and old['sourceHashes'] == c['baseSourceHashes'] and old['sourceHashAggregate'] == c['baseSourceHashAggregate'], 'Old assembly identity mismatch')
    protected, _ = previous.check_old(old)
    previous.check_sources(old)
    require(len(protected) == c['oldAssemblyProtectedFiles'], 'Old assembly protection mismatch')
    return protected
def baseline_hashes(c):
    protected = assembly_protection(c)
    public = {f['path']: f['sha256'] for f in c['oldPublicFiles']}
    require(len(c['oldPublicFiles']) == len(public) == 156 and not set(public) & set(protected), 'Old public records overlap or incomplete')
    expected = dict(protected, **public)
    require(len(expected) == c['oldSiteFiles'], '2283 exact old publication files required')
    require(all(expected[f['path']] == f['sha256'] for f in c['worldEntryFiles']), 'Existing world entry changed')
    return expected
def snapshot(c):
    records = {f['path']: f for f in c['snapshotFiles']}
    require(len(records) == len(c['snapshotFiles']) == 6 and all(n.startswith(c['basePath'] + '/') for n in records), 'Exactly six surface-only evidence products required')
    files = checked_archive(INPUTS / c['snapshotArchive']['path'], c['snapshotArchive'], records)
    public = {f['path']: f for f in c['oldPublicFiles']}
    require(all(public.get(n) == f for n, f in records.items()), 'Surface snapshot differs from saved published receipt')
    require(set(public) == {c['basePath'] + '/' + n for n in c['baseSourceHashes']} | set(files), 'Published surface file set mismatch')
    require(not set(files) & set(c['immutableWorldPaths']), 'World entry restoration forbidden')
    for f in c['baseSourceFiles']:
        require(public[c['basePath'] + '/' + f['path']] == dict(f, path=c['basePath'] + '/' + f['path']), 'Published surface source bytes mismatch')
    return files
def candidate_sources(c): return {c['candidatePath'] + '/' + n for n in c['sourceHashes']}
def check_sources(c):
    for f in c['sourceFiles']:
        p = DIST / c['candidatePath'] / f['path']
        require(p.is_file() and not p.is_symlink(), 'Missing/linked source: ' + f['path'])
        validate_bytes(p.read_bytes(), f, f['path'])
def check_old(c):
    baseline = baseline_hashes(c)
    require(read_json('.splats-baseline.json') == baseline and read_json('.splats-protected.json') == baseline, 'Exact 2283-file baseline/protection map changed')
    current = inventory(DIST)
    for n, h in baseline.items(): require(current.get(n) == h, 'Old file changed/missing: ' + n)
    root = read_json('.root-site-hashes.json')
    require(len(root) == c['rootFiles'] and {n: h for n, h in current.items() if not n.startswith('preview/')} == root, 'Original root bytes changed')
    return baseline, current
def source_identity(c):
    identity = dict(candidateSourceCommit=os.environ.get('SPLATS_SOURCE_COMMIT', ''), checkoutCommit=os.environ.get('GITHUB_SHA', ''), candidatePath=c['candidatePath'], sourceHashAggregate=c['sourceHashAggregate'], sourceFiles=c['newSourceFiles'], baseMainCommit=c['baseMainCommit'])
    for k in ('candidateSourceCommit', 'checkoutCommit'): require(re.fullmatch('[0-9a-f]{40}', identity[k]), 'Missing exact commit: ' + k)
    return identity
def run_identity():
    v = dict(runId=os.environ.get('GITHUB_RUN_ID', ''), runAttempt=os.environ.get('GITHUB_RUN_ATTEMPT', ''), qaCommit=os.environ.get('GITHUB_SHA', ''))
    require(re.fullmatch('[0-9]+', v['runId']) and re.fullmatch('[0-9]+', v['runAttempt']) and re.fullmatch('[0-9a-f]{40}', v['qaCommit']), 'Exact same CI run/attempt and QA commit required')
    return v
def check_deadline(current=True):
    d = read_json('.splats-deadline.json')
    require(d['totalBudgetMs'] == 450000 and finite(d['startedAtMs']) and finite(d['expiresAtMs']) and d['expiresAtMs'] - d['startedAtMs'] == 450000, 'Single shared deadline changed')
    require(d['startedAtMs'] <= time.time() * 1000 and (not current or time.time() * 1000 < d['expiresAtMs']), '450-second deadline expired or starts in future')
    return d
def png_bytes(path, record):
    p = pathlib.Path(path); require(p.is_file() and not p.is_symlink(), 'Missing/linked PNG')
    b = p.read_bytes(); validate_bytes(b, record, str(p))
    require(len(b) > 32 and b[:8] == b'\x89PNG\r\n\x1a\n' and b[12:16] == b'IHDR', 'Invalid PNG')
    require(struct.unpack('>II', b[16:24]) == (1120, 712) and (record['width'], record['height']) == (1120, 712), 'Original 1120x712 PNG required')
    return b

