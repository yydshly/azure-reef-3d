"""Publish four real frames and exact report only after bounded technical validation."""
import html
from splats_common import *

PASS_STATUSES = ('TECHNICAL_PASS', 'TECHNICAL_PASS_SOFTWARE_LOW_CADENCE_VISUAL_PENDING')

def validate_draw(draw):
    require(draw['hookInstalled'] is True and type(draw['nonzeroSplatDraws']) is int and draw['nonzeroSplatDraws'] > 0 and type(draw['lastInstances']) is int and draw['lastInstances'] > 0, 'Actual Gaussian instanced draws missing')

def validate_gpu(c, report):
    require(report['schemaVersion'] == 1 and report['status'] in PASS_STATUSES and report['syntheticFixture'] is False, 'Genuine bounded technical PASS required')
    require(report['visualStatus'] == c['visualStatus'] and report['publicationAllowed'] is False, 'Runner cannot claim visual or publication approval')
    require(report['sourceIdentity'] == source_identity(c) and report['runIdentity'] == run_identity(), 'Source/checkout/CI run identity mismatch')
    require(report['dependencyPins'] == c['dependencyPins'], 'Runtime dependency pin mismatch')
    deadline = check_deadline()
    require(all(report[k] == deadline[k] for k in ('startedAtMs', 'expiresAtMs', 'totalBudgetMs')), 'Report belongs to another deadline')
    require(finite(report['completedAtMs']) and deadline['startedAtMs'] <= report['completedAtMs'] <= time.time() * 1000 and report['completedAtMs'] < deadline['expiresAtMs'], 'QA completed outside shared 450-second deadline')
    require(report['errors'] == [] and report['failures'] == [], 'Technical errors or failures remain')
    require(isinstance(report['limitations'], list) and report['limitations'], 'Technical/visual limitations must be explicit')
    require([f['name'] for f in report['frames']] == c['frames'], 'Four labeled current-run views required')
    cameras = []
    for f in report['frames']:
        require(f['file'] == f['name'] + '.png' and (f['width'], f['height']) == (1120, 712), 'Frame filename/dimensions mismatch')
        e, r = f['evidence'], f['report']
        require(e['name'] == f['name'] and e['guidesHidden'] is True and e['glError'] == 0, 'Reference-free pixel readback missing or GL error')
        require(e['width'] == 1120 and e['height'] == 712 and type(e['nonBackgroundPixels']) is int and 0 < e['nonBackgroundPixels'] <= 1120 * 712, 'No nonempty actual splat pixels')
        require(finite(e['coverage']) and abs(e['coverage'] - e['nonBackgroundPixels'] / (1120 * 712)) < 1e-10, 'Pixel diagnostic arithmetic mismatch')
        validate_draw(e['draw']); validate_draw(r['draw'])
        require(r['source']['count'] == r['source']['expectedCount'] == c['asset']['count'] and r['source']['sha256'] == c['asset']['sha256'], 'Rendered source identity mismatch')
        require(r['dependencies'] == {'three': '186', 'spark': '2.3.1'}, 'Actually loaded runtime mismatch')
        require('WebGL 2' in r['gl']['version'] and r['gl']['isContextLost'] is False and r['gl']['error'] == 0 and r['gl']['errorHistory'] == [] and r['errors'] == [], 'Actual WebGL2/shader/runtime checks failed')
        require(type(e['activeSplats']) is int and e['activeSplats'] > 0, 'No active Gaussian splats')
        require(len(e['camera']) == 3 and len(e['quaternion']) == 4 and all(finite(v) for v in e['camera'] + e['quaternion']), 'Finite actual camera evidence required')
        cameras.append(tuple(e['camera']))
    require(len(set(cameras)) == 4, 'Distinct side/back/low/context views required')
    validate_checks(c, report)

def validate_checks(c, report):
    checks = report['checks']
    expected = {'identityAndActualDraw': 'PASS', 'fixedViews': 'PASS_NONEMPTY_DRAW_ONLY', 'controls': 'PASS', 'boundary': 'PASS_NATIVE_CROSSING', 'cycles': 'PASS', 'loadCancellation': 'PASS', 'rapidRepeatedLoad': 'PASS', 'assetFailure': 'PASS', 'bootstrapError': 'PASS'}
    require(all(checks[k]['status'] == v for k, v in expected.items()), 'Necessary-function checks are incomplete')
    require(report['limits'] == {'totalMs': 450000, 'pngMs': 25000, 'assetMs': 30000, 'workerMs': 10000, 'viewSettleMs': 5000, 'performanceMs': 10000}, 'Runner limits changed')
    require(report['browser']['sandbox'] is True and report['browser']['forbiddenFlagsAbsent'] is True, 'Supported sandboxed browser required')
    require(report['servedSourceHashes'] == {n: h for n, h in c['sourceHashes'].items() if not n.endswith('.ply')}, 'Served source bytes differ from frozen source')
    require(report['device']['devicePixelRatio'] == 1 and report['device']['viewport'] == [1120, 712], 'Actual device size/DPR changed')
    require(report['pageErrors'] == [] and all(e['type'] != 'error' or e['expected'] is True for e in report['console']), 'Unhandled or unexpected browser error')
    initial = checks['identityAndActualDraw']
    require(initial['count'] == c['asset']['count'] and initial['sha256'] == c['asset']['sha256'], 'Initial source count/hash mismatch'); validate_draw(initial['draw'])
    require(checks['fixedViews']['views'] == c['frames'] and checks['fixedViews']['visualAcceptance'] is False, 'Fixed view scope mismatch')
    controls = checks['controls']
    require(controls['focusedButtonBlocksWAndArrow'] is True and controls['exactReset'] is True, 'Control focus/reset failed')
    require(math.dist(controls['original']['position'], controls['forward']['position']) > .01 and math.dist(controls['drag']['position'], controls['backward']['position']) > .01 and controls['drag']['quaternion'] != controls['forward']['quaternion'], 'Native movement or rotation not observed')
    def released(value):
        require(value['stopped'] is True and value['before'] == value['after'], 'Camera did not stop after native release')
    for key in ('wRelease', 'sRelease', 'buttonRelease'): released(controls[key])
    for key in ('pointerCancel', 'blur', 'visibility'):
        require(checks[key]['status'] in ('OBSERVED_TRUSTED', 'UNSUPPORTED_NATIVE_EVENT'), 'Unsupported events cannot be claimed as passed')
    if checks['pointerCancel']['status'] == 'OBSERVED_TRUSTED': released(checks['pointerCancel']['release'])
    if checks['blur']['status'] == 'OBSERVED_TRUSTED' or checks['visibility']['status'] == 'OBSERVED_TRUSTED': released(checks['tabRelease'])
    require(checks['lostPointerCapture']['status'] in ('OBSERVED_TRUSTED_WITH_RELEASE', 'UNSUPPORTED_NATIVE_EVENT') and checks['lostPointerCapture']['independentlyForced'] is False, 'Lost capture observation scope mismatch')
    boundary = checks['boundary']
    require(boundary['guideButtonToggled'] is True and boundary['insideText'].startswith('在参考范围内') and boundary['outsideText'].startswith('当前在参考范围外'), 'Boundary disclosure/toggle proof missing')
    def outside(camera):
        x, _, z = camera['position']; origin = c['coordinates']['rawOrigin']; b = c['bounds']['orthoXY']
        return x + origin[0] < b['min_x'] or x + origin[0] > b['max_x'] or origin[1] - z < b['min_y'] or origin[1] - z > b['max_y']
    require(not outside(boundary['inside']) and outside(boundary['outside']), 'Native reference boundary was not crossed')
    def disposed(r):
        require(r['status'] == 'unloaded' and r['source']['count'] == 0 and r['camera'] is None and r['draw'] is None, 'Stale scene after disposal')
        d = r['stats']['lastDispose']
        require(d.get('status') != 'INCOMPLETE_RELOAD_REQUIRED' and d['meshCleared'] is True and d['sortWorkerCleared'] is True and d['animationLoopCancelled'] is True and d['sceneChildren'] == 0, 'Incomplete disposal')
        return d
    cycles = checks['cycles']
    require(len(cycles['cycles']) == 3 and [v['cycle'] for v in cycles['cycles']] == [1, 2, 3] and cycles['rendererMemoryReturned'] is True and cycles['driverMemoryReleased'] == 'UNVERIFIED', 'Three awaited teardown cycles required')
    memory = []
    for v in cycles['cycles']:
        require(v['disposed']['framesStopped'] is True, 'Render loop continued after disposal')
        memory.append(disposed(v['disposed']['report'])['after'])
        require(v['reloaded']['source']['count'] == c['asset']['count'] and v['reloaded']['source']['sha256'] == c['asset']['sha256'], 'Cycle source identity changed'); validate_draw(v['reloaded']['draw'])
    for field in ('geometries', 'textures'):
        require(all(finite(m[field]) and 0 <= m[field] <= memory[0][field] for m in memory), 'Observed renderer resource growth')
    require(checks['loadCancellation']['assetRequestWasHeld'] is True, 'Load cancellation must observe pending source request'); disposed(checks['loadCancellation']['report'])
    rapid = checks['rapidRepeatedLoad']
    require(rapid['calls'] == 3 and rapid['allPromisesAwaited'] is True and rapid['report']['stats']['loads'] == checks['loadCancellation']['report']['stats']['loads'] + 1, 'Repeated load initialized extra runtime')
    validate_draw(rapid['report']['draw'])
    failure = checks['assetFailure']; failed = failure['failed']
    require(failure['blockedRequests'] == 1 and failure['oneRetry'] is True and failed['status'] == 'error' and failed['source']['count'] == 0 and failed['draw'] is None and failed['camera'] is None, 'One truthful source failure/retry required')
    require(failure['failureUI']['visible'] is True and bool(failure['failureUI']['text'].strip()) and failed['stats']['lastDispose']['meshCleared'] is True and failed['stats']['lastDispose']['sortWorkerCleared'] is True and failed['stats']['lastDispose']['sceneChildren'] == 0, 'Failed source left stale runtime or hidden UI')
    require(len(failed['errors']) == 1 and failed['errors'][0]['kind'] == 'load' and failure['retried']['errors'] == failed['errors'], 'Expected source failure scope mismatch'); validate_draw(failure['retried']['draw'])
    bootstrap = checks['bootstrapError']
    require(bootstrap['blockedImports'] == 1 and bootstrap['failure']['fallbackVisible'] is True and bool(bootstrap['failure']['failure']) and bootstrap['failure']['report'] is None, 'Truthful bootstrap error evidence missing')
    require(checks['absentWebGL']['status'] == 'NOT_INDUCED', 'Absent-WebGL simulation not authorized')
    require(report['finalDisposal']['framesStopped'] is True, 'Final render loop still running'); disposed(report['finalDisposal']['report'])
    validate_performance(report)

def validate_performance(report):
    p = report['checks']['performance']; cadence = p['cadence']; times = p['timestamps']
    require(isinstance(times, list) and len(times) >= 2 and all(finite(v) for v in times) and all(b > a for a, b in zip(times, times[1:])), 'Finite monotonic actual RAF observations required')
    intervals = [b - a for a, b in zip(times, times[1:])]; elapsed = times[-1] - times[0]
    require(elapsed >= 10000 and cadence['elapsedMs'] == elapsed and cadence['callbacks'] == len(times) and cadence['intervalsMs'] == intervals, 'Ten seconds of actual RAF cadence required')
    require(type(cadence['renderedFrames']) is int and cadence['renderedFrames'] > 0 and abs(cadence['renderedHz'] - cadence['renderedFrames'] * 1000 / elapsed) < 1e-9, 'Actual rendered frame cadence invalid')
    gaps = sum(v >= 250 for v in intervals); fraction = gaps / len(intervals)
    require(cadence['gapsAtLeast250Ms'] == gaps and abs(p['longGapFraction'] - fraction) < 1e-12, 'Long RAF gap arithmetic mismatch')
    require(p['thresholds'] == {'renderedHzBelow': 10, 'longGapMs': 250, 'longGapFractionAbove': .2} and p['frameWorkIsFps'] is False and p['productionPerformanceClaim'] is False, 'Performance scope or threshold changed')
    unsuitable = cadence['renderedHz'] < 10 or fraction > .2
    driver = report['browser']['graphics'].get('unmaskedRenderer') or report['browser']['graphics']['renderer']
    software = re.search('swiftshader|llvmpipe|softpipe|software|lavapipe', driver, re.I) is not None
    require(p['unsuitable'] is unsuitable and p['softwareRenderer'] is software and report['browser']['graphics']['softwareRenderer'] is software, 'Cadence/software classification mismatch')
    if unsuitable:
        require(software and p['status'] == 'LOW_CADENCE' and report['status'] == p['technicalStatus'] == PASS_STATUSES[1], 'Low cadence exception only permits explicit software diagnostic status')
        require(any('LOW_CADENCE' in str(v) for v in report['limitations']), 'Low software cadence limitation missing')
    else:
        require(p['status'] == 'MEASURED_DEVICE_ONLY' and report['status'] == p['technicalStatus'] == PASS_STATUSES[0], 'Normal technical status mismatch')

def gallery(c, report, frames):
    figures = ''.join('<figure><img loading="lazy" src="' + html.escape(f['relative']) + '" width="1120" height="712" alt="' + html.escape(f['name']) + '"><figcaption>' + html.escape(f['name']) + (' · orientation context' if f['name'] == 'overview' else ' · manual visual review pending') + '</figcaption></figure>' for f in frames)
    return ('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Real Gaussian splat probe · technical evidence</title><style>body{max-width:1180px;margin:30px auto;padding:0 20px;font:16px/1.6 system-ui;background:#111920;color:#e8edf1}a{color:#8ad7e5}figure{margin:28px 0}img{display:block;max-width:100%;height:auto;border:1px solid #566}code{overflow-wrap:anywhere}</style><h1>Real Gaussian splat probe</h1><p><a href="index.html">Open independent experiment</a> · <a href="credits.html">Source and attribution</a> · <a href="assets/gpu/' + c['sourceHashAggregate'] + '/report.json">Exact current-run technical report</a></p><p><strong>' + html.escape(report['status']) + '. Manual side/back/low visual review pending.</strong></p><p>' + html.escape(c['acceptance']) + '</p><p>30,381 original LOD4 Gaussian splats; Soneva / Wildflow, CC BY 4.0. The 9.396 × 9 m orthomosaic rectangle is reference extent, not certified continuous reef coverage. The existing world and every prior published file remain unchanged.</p><p>Limitations: ' + html.escape('; '.join(str(v) for v in report['limitations'])) + '</p>' + figures + '</html>').encode()

def finalize(c):
    require(c['allowWorldUpdate'] is False, 'World update forbidden')
    require(not pathlib.Path('.splats-finalized.json').exists(), 'Finalization already attempted')
    check_deadline(); check_sources(c); protected, before = check_old(c)
    require(set(before) - set(protected) == candidate_sources(c) and len(before) == c['stagedSiteFiles'], 'Unexpected staged paths before finalization')
    out = pathlib.Path(os.environ.get('SPLATS_OUTPUT', 'splats-qa'))
    report_path = out / 'report.json'
    require(report_path.is_file() and not report_path.is_symlink(), 'Missing/linked current report')
    raw = report_path.read_bytes(); report = json.loads(raw)
    validate_gpu(c, report)
    prefix = 'assets/gpu/' + c['sourceHashAggregate'] + '/'
    products, frames = {}, []
    for f in report['frames']:
        data = png_bytes(out / f['file'], f)
        relative = prefix + f['name'] + '-' + f['sha256'][:16] + '.png'
        products[c['candidatePath'] + '/' + relative] = data
        frames.append(dict(f, relative=relative))
    products[c['candidatePath'] + '/' + prefix + 'report.json'] = raw
    products[c['candidatePath'] + '/current-scene.html'] = gallery(c, report, frames)
    require(len(products) == c['newGalleryFiles'] and not set(products) & set(before), 'New evidence allowlist collision')
    check_deadline()
    # All validation and PNG identity checks precede writes; no world-update route exists.
    for n, b in products.items():
        p = DIST / n; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b)
    records = [{'path': n, 'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(products.items())]
    save_json('.splats-finalized.json', dict(schemaVersion=1, state='TECHNICAL_PASS_INDEPENDENT_PREVIEW_WORLD_UNCHANGED', status=report['status'], sourceIdentity=source_identity(c), runIdentity=run_identity(), galleryFiles=records, protectedFiles=2283, worldEntryChanged=False, visualStatus=c['visualStatus'], appearanceAccepted=False))
    protected, current = check_old(c); check_sources(c)
    require(set(current) - set(protected) == candidate_sources(c) | set(products) and len(current) == c['finalSiteFiles'], 'Unexpected final output')
    print('SPLATS_FINALIZED', json.dumps(dict(files=len(current), protectedFiles=2283, newEvidenceFiles=len(products), status=report['status'], appearanceAccepted=False)))

if __name__ == '__main__':
    import sys
    require(len(sys.argv) == 1, 'No finalizer flags or world-update option are supported')
    finalize(contract())
