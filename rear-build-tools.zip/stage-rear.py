import pathlib,json,hashlib,zipfile,shutil
here=pathlib.Path(__file__).parent;dist=pathlib.Path('dist');sha=lambda b:hashlib.sha256(b).hexdigest()
def inv(root):
 assert root.is_dir() and not any(p.is_symlink() for p in root.rglob('*'))
 return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
old=dist/'preview/full-turn-candidate';r=json.loads((here/'full-turn-preservation.json').read_text());assert inv(old)=={f['path']:f['sha256'] for f in r['sourceFiles']}
p=pathlib.Path('.rear-inputs/full-turn-gallery-2d668de.zip');b=p.read_bytes();assert len(b)==r['archive']['bytes'] and sha(b)==r['archive']['sha256']
with zipfile.ZipFile(p) as z:
 assert len(z.namelist())==len(set(z.namelist()))==6 and set(z.namelist())==set(r['files'])
 for n,f in r['files'].items():
  rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];p=old/n;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
before=inv(dist);assert len(before)==1362;pathlib.Path('.rear-protected.json').write_text(json.dumps(before,sort_keys=True));new=dist/'preview/rear-habitat-candidate';assert not new.exists();shutil.copytree(old,new);(new/'current-scene.html').unlink();shutil.rmtree(new/'assets/current-scene')
m=json.loads((here/'rear-contract.json').read_text());archive=pathlib.Path('.rear-inputs/rear-habitat-code.zip');b=archive.read_bytes();assert len(b)==m['archive']['bytes'] and sha(b)==m['archive']['sha256']
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==3 and set(z.namelist())=={'page/'+f['file'] for f in m['files']}
 for f in m['files']:
  n=f['file'];p=new/n
  if f['baselineSha256']:assert sha(p.read_bytes())==f['baselineSha256']
  else:assert not p.exists()
  b=z.read('page/'+n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
source=[{'path':n,'bytes':(new/n).stat().st_size,'sha256':h} for n,h in sorted(inv(new).items())];assert len(source)==142
version=sha(json.dumps(source,sort_keys=True).encode()+(here/'browser-check-rear.mjs').read_bytes());pathlib.Path('.rear-build.json').write_text(json.dumps({'root':str(new),'contentVersion':version,'sourceFiles':source,'sourceArchiveSha256':sha(archive.read_bytes())},indent=2));print('REAR_STAGED',json.dumps({'sourceFiles':len(source),'oldFiles':1362,'contentVersion':version}))
