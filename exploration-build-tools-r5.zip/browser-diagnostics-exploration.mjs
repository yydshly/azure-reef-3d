// Publisher-only diagnostics r1. No product mutation, render request, loader
// ensure(), credentials, request headers, cookies, response bodies or URL queries.
export function createPassiveDiagnostics({page,base,elapsedMs,onRecord=()=>{},onPageError=()=>{}}){
 const root=new URL('.',base),events=[],readinessSamples=[];let sampleTimer=null,stopped=true,lastStateKey=null,lastPrintedMs=-Infinity,firstFailure=null;
 const data={revision:'diagnostics-r1',events,readinessSamples,lastReadiness:null,firstFailure:null,firstObservedError:null,droppedEvents:0};
 function resource(value){try{const url=new URL(value,base);return url.origin===root.origin&&url.pathname.startsWith(root.pathname)?url.pathname.slice(root.pathname.length):null;}catch{return null;}}
 function clean(value){return String(value??'').replace(/https?:\/\/[^\s)\]}>'"]+/g,value=>resource(value)||'[external-url]').replace(/\b(authorization|cookie|password|secret|token|api[-_]?key)\s*[:=]\s*[^\s,;]+/gi,'$1=[redacted]');}
 function errorObject(error){return{name:clean(error?.name||'Error'),message:clean(error?.message??error),stack:typeof error?.stack==='string'?clean(error.stack):null};}
 function record(source,detail){const item={...detail,source,elapsedMs:elapsedMs()};if(!data.firstObservedError&&['page.pageerror','page.console.error','Runtime.consoleAPICalled','Runtime.exceptionThrown','page.requestfailed','page.http-error','page.crash'].includes(source))data.firstObservedError=item;if(events.length<128)events.push(item);else data.droppedEvents++;onRecord(item,data);return item;}
 page.on('pageerror',error=>{const original=errorObject(error);onPageError(original);record('page.pageerror',{error:original});});
 page.on('console',message=>{if(message.type()==='error'){const location=message.location();record('page.console.error',{text:clean(message.text()),location:{resource:resource(location.url),lineNumber:location.lineNumber??null,columnNumber:location.columnNumber??null}});}});
 page.on('requestfailed',request=>{const file=resource(request.url());if(file&&/\.(?:html?|m?js|css|json|gltf|glb|bin|png|webp|jpe?g|svg|txt)$/i.test(file))record('page.requestfailed',{resource:file,resourceType:request.resourceType(),errorText:clean(request.failure()?.errorText||'Unknown request failure')});});
 page.on('response',response=>{const file=resource(response.url());if(response.status()>=400&&file&&/\.(?:html?|m?js|css|json|gltf|glb|bin|png|webp|jpe?g|svg|txt)$/i.test(file))record('page.http-error',{resource:file,status:response.status(),statusText:clean(response.statusText())});});
 page.on('crash',()=>record('page.crash',{message:'Playwright emitted page crash'}));
 async function attachCDP(session){
  const stack=s=>s?{description:clean(s.description||''),callFrames:(s.callFrames||[]).map(f=>({functionName:clean(f.functionName),resource:resource(f.url),lineNumber:f.lineNumber,columnNumber:f.columnNumber}))}:null;
  const remote=a=>({type:a.type,subtype:a.subtype||null,className:a.className||null,...(a.subtype==='error'?{description:clean(a.description)}:a.type==='string'?{value:clean(a.value)}:['number','boolean'].includes(a.type)?{value:a.value}:{} )});
  session.on('Runtime.consoleAPICalled',event=>{if(event.type==='error')record('Runtime.consoleAPICalled',{type:event.type,args:event.args.map(remote),stackTrace:stack(event.stackTrace)});});
  session.on('Runtime.exceptionThrown',event=>{const d=event.exceptionDetails;record('Runtime.exceptionThrown',{exception:{text:clean(d.text),exception:d.exception?remote(d.exception):null,resource:resource(d.url),lineNumber:d.lineNumber,columnNumber:d.columnNumber,stackTrace:stack(d.stackTrace)}});});
  await session.send('Runtime.enable');
 }
 function readLoading(){return page.evaluate(()=>{
  const e=window.reefExhibit,s=e?.getState?.(),loadingNode=document.querySelector('#scanLoading'),errorNode=document.querySelector('#scanError'),pick=value=>value?{status:value.status??null,error:value.error??null,installed:value.installed??null,enabled:value.enabled??null,disposed:value.disposed??null}:null;
  return{apiPresent:!!e,ready:s?.ready??null,hidden:document.hidden,visibilityState:document.visibilityState,scanLoadingVisible:loadingNode?!loadingNode.hidden:null,scanErrorVisible:errorNode?!errorNode.hidden:null,loaders:Object.fromEntries(['c4','assemblage','naturalRock','layeredRidges','ray','turtle'].map(k=>[k,pick(s?.[k])])),coralMidground:pick(e?.coralMidground?.getState?.()),rearPresent:!!e?.world?.rearHabitat,explorationPresent:!!e?.explorationWorld,renderDemand:e?.getRenderDemandState?.()||null,renderer:e?.renderer?{render:{...e.renderer.info.render},memory:{...e.renderer.info.memory}}:null};
 });}
 function startLoading({sampleTimeoutMs=750,cadenceMs=1000,heartbeatMs=5000}={}){
  stopped=false;
  const sample=()=>{if(stopped)return;let timedOut=false;const started=elapsedMs(),timer=setTimeout(()=>{timedOut=true;if(!stopped)record('loading.sample-timeout',{limitMs:sampleTimeoutMs,sampleStartedMs:started,message:'Read-only page state did not return within its diagnostic bound; cause undetermined'});},sampleTimeoutMs);
   // There is only one outstanding evaluate. A hung read cannot build a queue
   // of retries; readiness keeps its separate 180-second readiness / 181-second outer bound.
   Promise.resolve().then(readLoading).then(value=>{if(stopped)return;const sanitize=value=>typeof value==='string'?clean(value):Array.isArray(value)?value.map(sanitize):value&&typeof value==='object'?Object.fromEntries(Object.entries(value).map(([k,v])=>[k,sanitize(v)])):value;const sanitized=sanitize(value);const snapshot={elapsedMs:elapsedMs(),returnedAfterDiagnosticTimeout:timedOut,...sanitized};data.lastReadiness=snapshot;if(readinessSamples.length<64)readinessSamples.push(snapshot);const stateKey=JSON.stringify([snapshot.apiPresent,snapshot.ready,snapshot.hidden,snapshot.loaders,snapshot.coralMidground,snapshot.rearPresent,snapshot.explorationPresent,snapshot.scanErrorVisible]);if(stateKey!==lastStateKey||elapsedMs()-lastPrintedMs>=heartbeatMs){lastStateKey=stateKey;lastPrintedMs=elapsedMs();record('loading.state',{snapshot});}
   },error=>{if(!stopped)record('loading.sample-error',{error:errorObject(error)});}).finally(()=>{clearTimeout(timer);if(!stopped)sampleTimer=setTimeout(sample,cadenceMs);});
  };sample();
 }
 function stopLoading(){stopped=true;clearTimeout(sampleTimer);}
 function captureFailure(error,operation){if(!firstFailure){firstFailure={source:'runner',operation,error:errorObject(error),elapsedMs:elapsedMs()};data.firstFailure=firstFailure;record('runner.first-failure',firstFailure);}return firstFailure;}
 function secondaryFailure(error,operation){record('runner.secondary-diagnostic-failure',{operation,error:errorObject(error)});}
 const summary=()=>({revision:data.revision,firstFailure:data.firstFailure,firstObservedError:data.firstObservedError,lastReadiness:data.lastReadiness,events:data.events,droppedEvents:data.droppedEvents});
 return{data,attachCDP,startLoading,stopLoading,captureFailure,secondaryFailure,summary,resource,clean};
}
