"""Build a local six-file delta and nine-file saved-public snapshot; never fetch."""
from pathlib import Path
import hashlib
import json
import zipfile

P = Path(__file__).resolve().parent.parent
W = P.parent
sha = lambda b: hashlib.sha256(b).hexdigest()


def record(n, b):
    return {'path': n, 'bytes': len(b), 'sha256': sha(b)}


def archive(n, files):
    p = P / n
    with zipfile.ZipFile(p, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(files.items()):
            i = zipfile.ZipInfo(name, (2026, 10, 11, 0, 0, 0))
            i.compress_type = zipfile.ZIP_DEFLATED
            i.external_attr = 0o100644 << 16
            z.writestr(i, data)
    return record(n, p.read_bytes())


def main():
    old = json.loads((W / 'reef-rear-layout-publish/tools/rear-layout-contract.json').read_text())
    result = json.loads((W / 'reef-rear-layout-publish/result.json').read_text())['public']
    get = json.loads((W / 'reef-rear-layout-publish/public-get-receipt.json').read_text())
    assert result['totalFiles'] == 1817 and result['protectedFilesByteIdentical'] is True
    assert get['mainCommit'] == result['sourceIdentity']['checkoutCommit'] == '2eac3e4d699fd497bb421bad455bdd7765d86158'
    public = {f['path']: f for f in result['files']}
    fetched = {f['path']: f for f in get['verified']}
    snapshots = set(public) - {old['candidatePath'] + '/' + n for n in old['sourceHashes']}
    assert len(snapshots) == 9
    saved = {}
    for n in sorted(snapshots):
        b = (W / 'reef-rear-layout-publish/published' / n).read_bytes()
        assert record(n, b) == public[n]
        assert fetched[n]['status'] == 200 and fetched[n]['sha256'] == sha(b) and fetched[n]['bytes'] == len(b)
        saved[n] = b
    source = W / 'reef-exploration-demo-candidate/page'
    manifest_path = W / 'reef-exploration-demo-candidate/verification/exploration-final-source-sha256.json'
    frozen = json.loads(manifest_path.read_text())
    assert all(n.startswith('page/') for n in frozen)
    hashes = {n[5:]: h for n, h in frozen.items()}
    files = {p.relative_to(source).as_posix(): p.read_bytes() for p in sorted(source.rglob('*')) if p.is_file()}
    assert len(files) == len(hashes) == 149 and {n: sha(b) for n, b in files.items()} == hashes
    assert not set(old['sourceHashes']) - set(hashes)
    delta = {n: b for n, b in files.items() if old['sourceHashes'].get(n) != sha(b)}
    assert set(delta) == {'scan-exhibit.html', 'scan-exhibit.css', 'scan-exhibit.js', 'exploration-world.js', 'exploration-navigation.js', 'exploration-world-data.js'}
    assert sum(hashes.get(n) == h for n, h in old['sourceHashes'].items()) == 143
    with zipfile.ZipFile(W / 'reef-rear-layout-publish' / old['snapshotArchive']['path']) as z:
        staged_entry = [record(n, z.read(n)) for n in old['mutableEntryPaths']]
    aggregate = sha(''.join(n + '\0' + hashes[n] + '\n' for n in sorted(hashes)).encode())
    c = dict(schemaVersion=1, candidatePath='preview/exploration-demo-candidate', basePath=old['candidatePath'], entryPath='preview/world',
        baseMainCommit=get['mainCommit'], baseSourceCommit=result['sourceIdentity']['candidateSourceCommit'],
        baseSourceHashAggregate=old['sourceHashAggregate'], sourceHashAggregate=aggregate,
        sourceHashes=hashes, sourceFiles=[record(n, files[n]) for n in sorted(files)],
        baseSourceHashes=old['sourceHashes'], baseSourceFiles=old['sourceFiles'], oldPublicFiles=list(public.values()),
        snapshotFiles=[public[n] for n in sorted(saved)], snapshotArchive=archive('rear-layout-snapshot-2eac3e4d.zip', saved),
        stagedEntryFiles=staged_entry, codeArchive=archive('exploration-demo-code.zip', delta),
        changes=[dict(record(n, delta[n]), baseSha256=old['sourceHashes'].get(n)) for n in sorted(delta)],
        mutableEntryPaths=old['mutableEntryPaths'], oldAssemblyProtectedFiles=1662, oldAssemblyFiles=1811,
        oldSiteFiles=1817, protectedFiles=1814, rootFiles=79, newSourceFiles=149, unchangedSourceFiles=143,
        newGalleryFiles=6, stagedSiteFiles=1966, finalSiteFiles=1972,
        frames=['tour-initial', 'tour-grass-bay', 'tour-completed'],
        frameRegions=['原生扫描礁区', '开阔海草浅湾', '大陆架与深水边缘'],
        qaSegments=['tour', 'free-compat'], requiredSegmentPhases={'tour': ['setup', 'tour-controls', 'tour-and-captures', 'replay', 'finalize'], 'free-compat': ['setup', 'free-crossing', 'directional-input', 'compatibility', 'responsive-reduced', 'finalize']},
        totalBudgetMs=450000, captureTimeoutMs=25000,
        acceptance='Exploration demo technical evidence only. Whole-world naturalness and final artistic acceptance remain unapproved.',
        acceptanceChinese='自由探索演示候选，整体真实感与最终美术效果尚未验收',
        unverified=['Whole-world naturalness and final visual acceptance', 'Continuous video quality', 'Native two-finger touch hardware', 'User-device FPS', 'Any lifecycle check explicitly marked CPU-only in the report'],
        oldEntryEvidencePolicy='Existing two world-entry PNGs are preserved historical evidence; no new entry screenshots are claimed.',
        frozenManifest=record('verification/exploration-final-source-sha256.json', manifest_path.read_bytes()),
        preparationOnly=True, candidateSourceCommit='__EXPLORATION_SOURCE_COMMIT__',
        provenance={'oldPublishedResult': record('reef-rear-layout-publish/result.json', (W / 'reef-rear-layout-publish/result.json').read_bytes()),
                    'savedPublicReceipt': record('reef-rear-layout-publish/public-get-receipt.json', (W / 'reef-rear-layout-publish/public-get-receipt.json').read_bytes())})
    (P / 'tools/exploration-contract.json').write_text(json.dumps(c, ensure_ascii=False, indent=2, sort_keys=True) + '\n')
    summary = {'status': 'LOCAL_PREPARATION_ONLY', 'sourceFiles': 149, 'sourceHashAggregate': aggregate, 'changes': c['changes'],
               'unchangedSourceFiles': 143, 'snapshotFiles': 9, 'protectedFiles': 1814,
               'oldSiteFiles': 1817, 'stagedSiteFiles': 1966, 'finalSiteFiles': 1972,
               'packages': [c['codeArchive'], c['snapshotArchive']], 'browserRun': False, 'uploaded': False}
    (P / 'input-package-receipt.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
