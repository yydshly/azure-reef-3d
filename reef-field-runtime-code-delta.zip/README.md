# Continuous reef field: local experimental runtime

Complete copied baseline: `page/`. Entry: `page/scan-exhibit.html`. The “连续礁区（实验）” control is under “操作 / 来源”, default OFF. No point/support download or extra GPU instance until explicit activation. No publication or remote workflow change was performed.

This is an integration candidate, not visual acceptance. The three final contact renders were inspected: straight crop boundaries, pointed/scalloped sand crests and some raised underhangs remain. Those PNGs are offline proxies, not browser evidence.

## Data and placement

- Exactly one 1,000,000-point measured sample, all original packed positions/normals/RGB retained. One instanced hexagonal geometry, 4,000,000 display triangles. Packed payload 24,000,000 bytes; SHA-256 verified at load.
- Unchanged source placement: Three XYZ = (2*source.x+21.5, 2*source.z+0.04, -2*source.y-44). Uniform artistic scale 2, not metres.
- The final contact NPZ is converted only by coordinate rotation (x,z,-y). 9,120 vertices, 14,818 triangles. Packed support 287,256 bytes; SHA-256 verified at load.
- Exactly 192 selected original objects and 1,620 right-middle ridge triangles are replaced transactionally after the data validates. Original geometry/visibility are retained for exact restoration. Other areas, animals, routes, camera code and source scan assets remain byte-identical.
- Support shares the original ground.material object, including identical world-space sand noise, ocean attenuation and ground-edge handling. No approximate new sand material or new texture.
- Point color is decoded from source sRGB into linear for the original water lighting/attenuation. Unlike the independent raw viewer, this world combination is lit and tone-mapped. Original source bytes are never recolored.

## Lifecycle

Off/cancel aborts requests, invalidates stale continuations, restores original geometry and visibility, disposes field/compact GPU resources and drops buffers. Retrying starts fresh. Repeated activation while pending shares one request. Raw observation closes the experiment; returning underwater leaves it off. Changing or restoring the original ridge/coral dependency closes it first. Pause/visibility reuse the existing demand-render mechanism; this adds no separate animation loop. Page teardown disposes the field first. Field render exceptions are rolled back to the original region rather than immediately terminating the baseline renderer; actual context loss still follows the original error/reload flow.

The small scan-ocean.js change only removes disposed field shader records from its internal compiled list. No baseline shading equations changed.

## Evidence and limits

Run `python reef-field-runtime-candidate/tools/prepare_field_assets.py --check` from the containing workspace for pinned source hashes and exact support conversion. Run the CPU test specified in PUBLISHER.md. The package scope manifest checks all baseline bytes and lists the exact delta.

11 CPU test groups passed against 96 original scene objects and 229 original attribute arrays, including six repeated load/off cycles and exact restoration. The field adds a net 3,945,586 display triangles (69,232 removed, 4,014,818 added). These are geometry counts, not performance measurements.

CPU geometry/lifecycle assertions do not establish browser rendering, actual GPU memory, FPS, visual quality, or mobile viability. Local Chromium has a known Unix-socket sandbox restriction; no bypass was attempted. The provided secure existing-runner browser script is prepared but has not been run here. Browser compile/render, screenshots and performance remain required before any acceptance claim.

## Attribution

Measured source: Galápagos_3D; Yuval, Matan; Keith, Inti; Terán, Franklin; Bensted-Smith, William; Iñiguez, Wilson. DarwinMay24_FinalExperimentChunk.ply. https://doi.org/10.5281/zenodo.14914807 . CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Changes: existing sampling/recentering, normal-oriented surfels, uniform artistic placement, explicitly synthetic sand/contact support. Not an in-situ scientific reconstruction.

Original Reefs4D C1/C4 scans: Matan Yuval / Tali Treibitz, https://zenodo.org/records/14616671 , CC BY-NC 2.0. Existing source notices and restrictions remain intact. Smithsonian and Poly Haven CC0 notices also remain.

Publication compatibility: the candidate now retains the already-published animal-scale cache tags. Exact cache-only mapping and strict base hashes are recorded in output/published-baseline-compatibility.json. No visual or runtime algorithm changed in this correction.

The prepared browser runner is intentionally bounded to five fixed captures and two actual reload/memory comparisons, while the CPU suite retains six repeated cycles. This is planned browser coverage, not a browser result.
