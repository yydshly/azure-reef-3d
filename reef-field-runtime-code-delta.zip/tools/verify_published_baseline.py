#!/usr/bin/env python3
"""Strictly reconcile the local animal candidate with the already-published cache tags."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1];ws=root.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
replacements={
 'scan-exhibit.js':[("./scan-turtle.js?v=turtle-20261009-r1","./scan-turtle.js?v=animal-scale-20261010-r1"),("./scan-world.js?v=basin-20261009-r1","./scan-world.js?v=animal-scale-20261010-r1")],
 'scan-exhibit.html':[("scan-exhibit.js?v=coral-midground-local-r1","scan-exhibit.js?v=animal-scale-20261010-r1")],
 'scan-route.js':[("./scan-world.js?v=basin-20261009-r1","./scan-world.js?v=animal-scale-20261010-r1")],
 'scan-assemblage.js':[("./scan-world.js?v=basin-20261009-r1","./scan-world.js?v=animal-scale-20261010-r1")],
 'scan-world.js':[], 'scan-turtle.js':[]}
expected={f['path']:f for f in json.loads((ws/'reef-animal-scale-publish/runtime-delta-manifest.json').read_text())['files']}
assert expected['scan-exhibit.js']['sha256']=='000f8da6ebf64fa3be6d9199dbb573312314d1409491064d805e65e76dd0b015'
assert expected['scan-exhibit.html']['sha256']=='5158cc0adadc3bc05789888a1d2c07987252a76be62f84a5f0ee21e243af4bde'
records=[]
for name,changes in replacements.items():
 source=(ws/'reef-animal-scale-candidate/page'/name).read_bytes();patched=source.decode();published=(ws/'reef-animal-scale-publish/runtime-delta'/name).read_bytes()
 for old,new in changes:
  assert patched.count(old)==1,(name,old)
  patched=patched.replace(old,new)
 assert patched.encode()==published,(name,'More than the enumerated cache-tag changes')
 assert sha(published)==expected[name]['sha256'] and len(published)==expected[name]['bytes']
 records.append({'file':name,'localCandidateSHA256':sha(source),'publishedSHA256':sha(published),'publishedBytes':len(published),'cacheTagReplacements':[{'from':a,'to':b,'occurrences':1} for a,b in changes]})
report={'status':'PASS_EXACT_CACHE_TAG_MAPPING','publishedAnimalBase':'reef-animal-scale-candidate/page plus six pinned reef-animal-scale-publish/runtime-delta files','changesAreOnlyEnumeratedCacheTags':True,'files':records}
(root/'output/published-baseline-compatibility.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
