// CPU-only regression suite. No browser, image extraction, screenshots or downloads.
// Run from any directory: node reef-field-runtime-candidate/tools/test-field.mjs
import assert from 'node:assert/strict';
import {createHash, webcrypto} from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import * as T from 'three';
import {GLTFLoader} from '../page/vendor/GLTFLoader.js';
import {createScanWorld} from '../page/scan-world.js';
import {createScanOcean} from '../page/scan-ocean.js';
import {createScanLife} from '../page/scan-life.js';
import {installAssemblage} from '../page/scan-assemblage.js';
import {placeC4} from '../page/scan-landmark.js';
import {createRayRuntime} from '../page/scan-ray.js';
import {createTurtleRuntime} from '../page/scan-turtle.js';
import {installNaturalRockCandidate} from '../page/install-natural-rock.js';
import {installLayeredRidges} from '../page/install-layered-ridges.js';
import {createCoralMidgroundRuntime} from '../page/coral-midground-runtime.js';
import {buildFieldGeometry, createFieldRuntime, installField, loadField} from '../page/field-runtime.js';
import {decode} from '../page/field-data.js';

const root=fileURLToPath(new URL('../page/',import.meta.url));
const sha=a=>createHash('sha256').update(Buffer.from(a.buffer||a,a.byteOffset||0,a.byteLength)).digest('hex');
const bufferOf=b=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);
globalThis.self=globalThis;
globalThis.ProgressEvent=class {};
if(!globalThis.crypto)globalThis.crypto=webcrypto;
const originalFetch=globalThis.fetch;
const requests=[];
globalThis.fetch=async (input,options={})=>{
 const url=typeof input==='string'?input:input.url;
 if(url.startsWith('blob:')||url.startsWith('data:'))return originalFetch(input,options);
 if(options.signal?.aborted)throw new DOMException('Aborted','AbortError');
 const name=url.startsWith('file:')?fileURLToPath(url):path.resolve(root,url);
 requests.push(path.relative(root,name));
 const bytes=fs.readFileSync(name);
 return new Response(bytes,{headers:{'content-length':String(bytes.length)}});
};
async function load(name){
 const filename=path.join(root,name),loader=new GLTFLoader();
 // CPU equivalent of exporter stubs; materials keep identity without image decoding.
 loader.register(parser=>{parser.loadTextureImage=async()=>{const t=new T.Texture();t.flipY=false;t.colorSpace=T.SRGBColorSpace;return t;};return{name:'CPU_ONLY_IMAGES'};});
 return loader.parseAsync(bufferOf(fs.readFileSync(filename)),'file://'+path.dirname(filename)+'/');
}
async function baseline(){
 const scene=new T.Scene(),ocean=createScanOcean(scene,new T.Texture());
 const scan=(await load('assets/reefs4d/C12019-web.glb')).scene;scan.name='Reefs4D_C1_original';scene.add(scan);
 const c4=placeC4((await load('assets/reefs4d/C42019-web-150k.glb')).scene,ocean.ground);scene.add(c4);
 const corals=(await load('assets/scan-world-corals.gltf')).scene;
 const world=createScanWorld(scene,corals,()=>{}, {limestone:m=>m,coral:m=>m,budget:{}},ocean.ground);
 const fish=(await load('assets/scan-fish.gltf')).scene.getObjectByName('fish_01');world.addFish(fish);
 const life=createScanLife(fish,()=>{});scene.add(life.group);life.update(0);world.update(0);
 installAssemblage(world,(await load('assets/reefs4d/C4-A-rounded-knobby.glb')).scene,c4);
 for(const [create,name] of [[createRayRuntime,'ray'],[createTurtleRuntime,'turtle']]){
  const runtime=create({parent:scene,load:()=>load('assets/synthetic-reef-'+name+'.glb'),configure:()=>{}});
  assert.equal(await runtime.ensure(),true,JSON.stringify(runtime.getState()));runtime.update(0);
 }
 installNaturalRockCandidate({world,boulderScene:(await load('assets/boulder_01_LOD1_1k.glb')).scene,configure:()=>{}});
 installLayeredRidges({world,ground:ocean.ground});
 const coral=createCoralMidgroundRuntime({world,load:()=>load('assets/heliopora-lod-30000.glb')});
 assert.equal(await coral.ensure(),true,JSON.stringify(coral.getState()));scene.updateMatrixWorld(true);
 return {scene,world,ground:ocean.ground};
}
function snapshot(scene){
 const objects=[],arrays=new Map(),geometries=new Set(),materials=new Set();
 const add=a=>{if(a&&!arrays.has(a))arrays.set(a,sha(a));};
 scene.traverse(o=>{
  objects.push({o,parent:o.parent,children:[...o.children],geometry:o.geometry,material:o.material,visible:o.visible,count:o.count,matrix:o.matrix.toArray()});
  if(o.geometry){geometries.add(o.geometry);add(o.geometry.index?.array);for(const a of Object.values(o.geometry.attributes))add(a.array);for(const attrs of Object.values(o.geometry.morphAttributes))for(const a of attrs)add(a.array);}
  for(const m of Array.isArray(o.material)?o.material:[o.material])if(m)materials.add(m);
  add(o.instanceMatrix?.array);add(o.instanceColor?.array);
 });
 const disposed=[];for(const r of [...geometries,...materials])r.addEventListener('dispose',()=>disposed.push(r.uuid));
 return {objects,arrays,disposed};
}
function unchanged(saved,{restored=true}={}){
 for(const s of saved.objects){
  assert.equal(s.o.parent,s.parent,'Original parent '+s.o.name);
  assert.equal(s.o.material,s.material,'Original material '+s.o.name);
  assert.equal(s.o.count,s.count,'Original instance count '+s.o.name);
  assert.deepEqual(s.o.matrix.toArray(),s.matrix,'Original matrix '+s.o.name);
  if(restored){assert.equal(s.o.geometry,s.geometry,'Restored geometry '+s.o.name);assert.equal(s.o.visible,s.visible,'Restored visibility '+s.o.name);assert.deepEqual(s.o.children,s.children,'Restored children '+s.o.name);}
 }
 for(const [a,hash]of saved.arrays)assert.equal(sha(a),hash,'Original typed-array bytes');
 assert.deepEqual(saved.disposed,[],'Never dispose shared baseline geometry/material');
}
function deferred(){let resolve,reject;const promise=new Promise((y,n)=>{resolve=y;reject=n;});return {promise,resolve,reject};}
const tick=()=>new Promise(r=>setImmediate(r));
const results=[];
let installedState;
async function test(name,fn){const start=performance.now();await fn();results.push({name,status:'PASS',ms:Math.round(performance.now()-start)});console.log('PASS '+name);}
const fixture=await baseline(),saved=snapshot(fixture.scene);
const originalBudget={...fixture.world.budget};
const points=JSON.parse(fs.readFileSync(path.join(root,'assets/field/points-manifest.json')));
const support=JSON.parse(fs.readFileSync(path.join(root,'assets/field/support-manifest.json')));
const placement=JSON.parse(fs.readFileSync(path.join(root,'assets/field/placement.json')));
const packed=bufferOf(fs.readFileSync(path.join(root,'assets/field/darwin-1000k.bin')));
const supportBuffer=bufferOf(fs.readFileSync(path.join(root,'assets/field/support.bin')));
const data={points,support,placement,buffer:supportBuffer,a:decode(packed,points)};
const sourceHash=sha(packed),supportHash=sha(supportBuffer);
assert.equal(sourceHash,points.sha256);assert.equal(supportHash,support.sha256);
const make=options=>createFieldRuntime({...fixture,...options});

await test('default is off, with zero field requests',async()=>{
 const count=requests.length,r=make({load:()=>{throw Error('Unexpected load');}});
 assert.deepEqual(r.getState(),{status:'idle',enabled:false,disposed:false,error:null,progress:0,installed:false});
 await tick();assert.equal(requests.length,count);r.dispose();unchanged(saved);
});
await test('real streaming assets match both SHA-256 manifests',async()=>{
 const progress=[],read=await loadField(new AbortController().signal,(n,total)=>progress.push([n,total]));
 assert.equal(sha(read.a.positions.buffer),points.sha256);assert.equal(sha(read.buffer),support.sha256);
 assert.equal(read.a.positions.buffer,read.a.normals.buffer);assert.equal(read.a.positions.buffer,read.a.colors.buffer);
 assert.deepEqual(progress.at(-1),[24000000,24000000]);
});
await test('exact 192 placement removals, 1620 ridge triangles, 1M/4M and same sand material',async()=>{
 const visibleBefore=[];fixture.world.group.traverseVisible(o=>{if(o.isMesh)for(let i=0;i<(o.isInstancedMesh?o.count:1);i++)visibleBefore.push(o.name+'_'+i);});
 const wanted=new Set(placement.removed.filter(x=>typeof x==='string'));assert.equal(wanted.size,192);
 for(const key of wanted)assert(visibleBefore.includes(key),'Visible original '+key);
 const ridge=fixture.world.group.getObjectByName('Layered_Ridges_Weathered_Shoulders'),oldRidge=ridge.geometry;
 const installed=installField({...fixture,data}),g=installed.cloud.geometry;
 installedState=installed.inspect();
 const expected={points:1000000,displayTriangles:4000000,pointBytes:24000000,removedObjects:192,removedTriangles:69232,netTriangles:3945586,netDraws:1,removedRidgeTriangles:1620,supportTriangles:14818,sameSandMaterial:true,instances:1,allocatedMeshObjects:15,visibleMeshObjects:15,compactBatches:13,ownedGeometries:3,ownedMaterials:1,sharedMaterials:1,estimatedGeometryGPUBytes:24505728,estimatedCompactGPUBytes:65440,gpuBytesAreEstimates:true};
 for(const [key,value]of Object.entries(expected))assert.equal(installedState[key],value,'Installed '+key);
 assert.equal(fixture.world.budget.triangles,originalBudget.triangles+3945586);assert.equal(fixture.world.budget.drawCalls,originalBudget.drawCalls+1);
 assert.equal(installed.support.material,fixture.ground.material);assert.equal(g.index.count/3,4);assert.equal(g.attributes.position.count,6);
 for(const [name,array,itemSize,normalized]of [['center',data.a.positions,3,false],['sourceNormal',data.a.normals,4,true],['sourceColor',data.a.colors,4,true]]){
  assert.equal(g.attributes[name].array,array);assert.equal(g.attributes[name].itemSize,itemSize);assert.equal(g.attributes[name].normalized,normalized);assert.equal(g.attributes[name].count,1000000);
 }
 assert.equal(ridge.geometry.index.count,oldRidge.index.count-1620*3);
 const expectedIndices=[];const pos=oldRidge.attributes.position,idx=oldRidge.index.array;
 for(let i=0;i<idx.length;i+=3){const a=idx[i],b=idx[i+1],c=idx[i+2],x=(pos.getX(a)+pos.getX(b)+pos.getX(c))/3,z=(pos.getZ(a)+pos.getZ(b)+pos.getZ(c))/3;if(!(x>8&&z< -31&&z> -68))expectedIndices.push(a,b,c);}
 assert.deepEqual(Array.from(ridge.geometry.index.array),expectedIndices,'Exact untouched ridge triangles/order');
 for(const original of saved.objects.filter(s=>s.o.isMesh)){
  const o=original.o,removed=[];for(let i=0;i<(o.isInstancedMesh?o.count:1);i++)if(wanted.has(o.name+'_'+i))removed.push(i);
  if(!removed.length)continue;assert.equal(o.visible,false);
  const compact=o.parent.getObjectByName('Field_Retained_'+o.name);
  if(o.isInstancedMesh&&removed.length<o.count){
   assert(compact);assert.equal(compact.geometry,o.geometry);assert.equal(compact.material,o.material);assert.equal(compact.count,o.count-removed.length);
   let dest=0;for(let i=0;i<o.count;i++)if(!removed.includes(i)){
    assert.deepEqual(Array.from(compact.instanceMatrix.array.slice(dest*16,dest*16+16)),Array.from(o.instanceMatrix.array.slice(i*16,i*16+16)));
    if(o.instanceColor)assert.deepEqual(Array.from(compact.instanceColor.array.slice(dest*3,dest*3+3)),Array.from(o.instanceColor.array.slice(i*3,i*3+3)));dest++;
   }
  }else assert.equal(compact,undefined);
 }
 installed.cloud.updateMatrixWorld(true);
 for(const i of [0,1,127,100001,999999]){
  const p=new T.Vector3().fromArray(data.a.positions,i*3),q=p.clone().applyMatrix4(installed.cloud.matrixWorld);
  assert(Math.abs(q.x-(2*p.x+21.5))<1e-10);assert(Math.abs(q.y-(2*p.z+.04))<1e-10);assert(Math.abs(q.z-(-2*p.y-44))<1e-10);
 }
 unchanged(saved,{restored:false});assert.equal(sha(packed),sourceHash);assert.equal(sha(supportBuffer),supportHash);
 const owned=[installed.cloud.geometry,installed.cloud.material,installed.support.geometry,ridge.geometry];
 fixture.world.group.traverse(o=>{if(o.name.startsWith('Field_Retained_'))owned.push(o);});
 const disposal=new Map(owned.map(o=>[o,0]));owned.forEach(o=>o.addEventListener('dispose',()=>disposal.set(o,disposal.get(o)+1)));
 installed.dispose();installed.dispose();for(const n of disposal.values())assert.equal(n,1,'Owned resource disposed exactly once');unchanged(saved);assert.deepEqual(fixture.world.budget,originalBudget);
});
await test('installation is atomic and restores on placement, ridge and configure failures',async()=>{
 assert.throws(()=>installField({...fixture,data:{...data,placement:{...placement,removed:[...placement.removed,'Missing_Original_0']}}}),/Baseline replacement mismatch/);unchanged(saved);
 const ridge=fixture.world.group.getObjectByName('Layered_Ridges_Weathered_Shoulders'),old=ridge.geometry;
 const bad=old.clone();bad.setIndex([0,1,2]);ridge.geometry=bad;
 assert.throws(()=>installField({...fixture,data}),/Ridge triangle identity mismatch/);assert.equal(ridge.geometry,bad);ridge.geometry=old;bad.dispose();unchanged(saved);
 let materialDisposals=0;
 assert.throws(()=>installField({...fixture,data,configure:m=>{m.addEventListener('dispose',()=>materialDisposals++);throw Error('configure failure');}}),/configure failure/);unchanged(saved);
 assert.equal(materialDisposals,1,'Dispose material if its configure callback fails');assert.deepEqual(fixture.world.budget,originalBudget);
});
await test('one pending load, ready idempotence, exact restoration across six cycles',async()=>{
 let loads=0,notifies=0,invalidates=0;const r=make({load:async()=>{loads++;return data;},onState:()=>notifies++,invalidate:()=>invalidates++});
 for(let i=0;i<6;i++){
  const p=r.ensure();assert.equal(r.ensure(),p);assert.equal(await p,true);assert.equal(await r.ensure(),true);assert.equal(r.getState().status,'ready');assert.equal(r.getState().installed,true);
  assert.equal(fixture.world.group.children.filter(o=>o.name==='Experimental_Continuous_Reef_Field').length,1);
  await r.setEnabled(false);assert.equal(r.getState().status,'idle');assert.equal(r.getRoot(),null);unchanged(saved);assert.deepEqual(fixture.world.budget,originalBudget);
 }
 assert.equal(loads,6);assert.equal(notifies,invalidates);r.dispose();r.dispose();assert.equal(await r.ensure(),false);assert.equal(r.getState().status,'disposed');unchanged(saved);
});
await test('failed load and failed dependency can retry without baseline damage',async()=>{
 let attempts=0;const r=make({load:async()=>{if(++attempts===1)throw Error('503 deliberate failure');return data;}});
 assert.equal(await r.ensure(),false);assert.equal(r.getState().status,'error');assert.equal(r.getState().enabled,false);assert.match(r.getState().error,/503/);unchanged(saved);
 assert.equal(await r.ensure(),true);r.restore();unchanged(saved);r.dispose();
 let prepared=false,loads=0;const dep=make({prepare:async()=>prepared,load:async()=>{loads++;return data;}});
 assert.equal(await dep.ensure(),false);assert.equal(loads,0);assert.match(dep.getState().error,/dependencies/);prepared=true;assert.equal(await dep.ensure(),true);dep.dispose();unchanged(saved);
});
await test('cancel before prepare resolves never starts download',async()=>{
 const gate=deferred();let loads=0;const r=make({prepare:()=>gate.promise,load:async()=>{loads++;return data;}});
 const p=r.ensure();await tick();r.restore();gate.resolve(true);assert.equal(await p,false);assert.equal(loads,0);assert.equal(r.getState().status,'idle');unchanged(saved);r.dispose();
});
await test('abort signal, stale overlapping success, stale progress and stale rejection are isolated',async()=>{
 const loads=[];const r=make({load:(signal,progress)=>{const d=deferred();loads.push({...d,signal,progress});return d.promise;}});
 const first=r.ensure();await tick();loads[0].progress(1,4);assert.equal(r.getState().progress,.25);
 r.restore();assert.equal(loads[0].signal.aborted,true);const second=r.ensure();await tick();loads[1].progress(1,2);loads[0].progress(3,4);assert.equal(r.getState().progress,.5);
 loads[1].resolve(data);assert.equal(await second,true);const root=r.getRoot();loads[0].resolve(data);assert.equal(await first,false);assert.equal(r.getRoot(),root);assert.equal(r.getState().status,'ready');r.restore();unchanged(saved);
 const third=r.ensure();await tick();r.restore();const fourth=r.ensure();await tick();loads[3].resolve(data);assert.equal(await fourth,true);const nextRoot=r.getRoot();loads[2].reject(Error('Stale failure'));assert.equal(await third,false);assert.equal(r.getRoot(),nextRoot);assert.equal(r.getState().status,'ready');r.dispose();unchanged(saved);
});
await test('dispose during load prevents late installation or notification',async()=>{
 const d=deferred();let signal,notifications=0;const r=make({load:s=>{signal=s;return d.promise;},onState:()=>notifications++});
 const p=r.ensure();await tick();r.dispose();assert.equal(signal.aborted,true);const count=notifications;d.resolve(data);assert.equal(await p,false);assert.equal(notifications,count);assert.equal(r.getState().status,'disposed');assert.equal(await r.setEnabled(true),false);unchanged(saved);
});
await test('render rejection restores originals and budget, then retry succeeds',async()=>{
 const r=make({load:async()=>data});assert.equal(await r.ensure(),true);r.reject(Error('Deliberate shader failure'));
 assert.equal(r.getState().status,'error');assert.equal(r.getState().enabled,false);assert.equal(r.getState().installed,false);assert.match(r.getState().error,/shader failure/);unchanged(saved);assert.deepEqual(fixture.world.budget,originalBudget);
 assert.equal(await r.ensure(),true);r.dispose();unchanged(saved);assert.deepEqual(fixture.world.budget,originalBudget);
});
await test('point geometry uses original arrays without decimation or duplication',async()=>{
 const g=buildFieldGeometry(data.a,1000000);assert.equal(g.instanceCount,1000000);
 assert.equal(new Set(['center','sourceNormal','sourceColor'].map(k=>g.attributes[k].array.buffer)).size,1);
 assert.equal(Object.values(g.attributes).filter(a=>a.isInstancedBufferAttribute).reduce((n,a)=>n+a.array.byteLength,0),24000000);g.dispose();
 assert.equal(sha(packed),sourceHash);assert.equal(sha(supportBuffer),supportHash);unchanged(saved);
});
const result={status:'PASS_CPU_ONLY',completedAt:new Date().toISOString(),tests:results.length,results,installedState,sourceSHA256:points.sourceSHA256,payloadSHA256:sourceHash,supportSHA256:supportHash,originalObjects:saved.objects.length,originalArrays:saved.arrays.size,limits:'Actual original scene geometry and field assets tested in Node. Textures stubbed. No browser, GPU, pixels, FPS or GPU memory validated. GPU byte fields are geometry/instance estimates only.'};
const output=fileURLToPath(new URL('../output/',import.meta.url));fs.mkdirSync(output,{recursive:true});
fs.writeFileSync(path.join(output,'cpu-test-report.json'),JSON.stringify(result,null,2)+'\n');
globalThis.fetch=originalFetch;
console.log('FIELD_CPU_COMPLETE '+JSON.stringify(result));
