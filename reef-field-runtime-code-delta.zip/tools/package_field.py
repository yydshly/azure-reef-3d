#!/usr/bin/env python3
"""Verify baseline scope and build a runtime-only delta; never publish."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[1];base=root.parent/'reef-animal-scale-candidate/page';page=root/'page'
published=root.parent/'reef-animal-scale-publish/runtime-delta'
import runpy
import contextlib,io
with contextlib.redirect_stdout(io.StringIO()):runpy.run_path(str(root/'tools/verify_published_baseline.py'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changed=[];added=[];preserved=[]
for p in sorted(page.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(page).as_posix();old=(published/rel) if (published/rel).is_file() else base/rel
 record={'file':rel,'bytes':p.stat().st_size,'sha256':sha(p)}
 if old.exists():
  if sha(old)==record['sha256']:preserved.append(record)
  else:record['baselineSHA256']=sha(old);changed.append(record)
 else:added.append(record)
assert {v['file'] for v in changed}=={'scan-exhibit.html','scan-exhibit.js','scan-ocean.js'}
assert all((page/p.relative_to(base)).is_file() for p in base.rglob('*') if p.is_file())
assert {v['file'] for v in added}=={'field-runtime.js','field-data.js','assets/field/points-manifest.json','assets/field/darwin-1000k.bin','assets/field/placement.json','assets/field/support.bin','assets/field/support-manifest.json'}
manifest={'acceptedBaseline':'Published 130-file source set plus six hash-pinned animal overlay files; see published-baseline-compatibility.json. Local unchanged inventory also includes package.json and five old gallery PNGs; these are not in the delta or publishing requirements.','changed':changed,'added':added,'unchangedCount':len(preserved),'preserved':preserved,'scope':'Only experimental runtime/UI and shader-disposal bookkeeping changed. Animals, routes, cameras, original source assets and all other files byte-identical.','browserStatus':'Not run locally; no WebGL/FPS acceptance.','publishStatus':'Not published.'}
(root/'output/scope-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(root/'reef-field-runtime-delta.zip','w',zipfile.ZIP_DEFLATED) as z:
 for rec in changed+added:z.write(page/rec['file'],'page/'+rec['file'])
 for sub in ['README.md','PUBLISHER.md','output/scope-manifest.json','tools/prepare_field_assets.py','tools/package_field.py','tools/verify_published_baseline.py','output/published-baseline-compatibility.json','tools/field-assets-verification.json','tools/test-field.mjs','tools/browser-check-field.mjs','output/cpu-test-report.json']:
  p=root/sub
  if p.exists():z.write(p,sub)
receipt={'changed':[r['file'] for r in changed],'added':[r['file'] for r in added],'preserved':len(preserved),'deltaBytes':(root/'reef-field-runtime-delta.zip').stat().st_size,'deltaSHA256':sha(root/'reef-field-runtime-delta.zip')}

with zipfile.ZipFile(root/'reef-field-runtime-code-delta.zip','w',zipfile.ZIP_DEFLATED) as z:
 with zipfile.ZipFile(root/'reef-field-runtime-delta.zip') as full:
  for info in full.infolist():
   if info.filename!='page/assets/field/darwin-1000k.bin':z.writestr(info,full.read(info.filename))
receipt.update({'codeDeltaBytes':(root/'reef-field-runtime-code-delta.zip').stat().st_size,'codeDeltaSHA256':sha(root/'reef-field-runtime-code-delta.zip'),'reusePointPayload':'Existing darwin-surfel-candidate/data/darwin-1000k.bin; exact hash in scope manifest. Copy at staging, do not reupload source data.'})
print(json.dumps(receipt,indent=2))
