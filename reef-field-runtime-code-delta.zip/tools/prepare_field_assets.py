#!/usr/bin/env python3
"""Prepare reef field assets from pinned local originals; never download sources.

Run with the already available Python and NumPy:
  python reef-field-runtime-candidate/tools/prepare_field_assets.py
  python reef-field-runtime-candidate/tools/prepare_field_assets.py --check

The default workspace is the directory containing the candidate folders.
Output is deterministic. --check verifies existing outputs without changing them.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil

import numpy as np


SOURCE_HASHES = {
    "reef-contact-embedding-candidate/support.npz": "85d0bc2b46682345e97351a0187353664606db2416ee69b934ea5d772109e968",
    "reef-surfel-browser-candidate/data/darwin-1000k.bin": "87564b81a9b4343b758e3649944e74edf06c8a7daf1e9ccf64aafc17fc9343c0",
    "reef-surfel-browser-candidate/data/manifest.json": "aa40a080f400d82bbe2a4c54b9b97894b66aec45ed7bc44ba14c2fe1ee5f5796",
    "reef-surfel-browser-candidate/data.js": "cedf440e07c76a2aa71d4a9b749ee7688457108ecb5d8219ca00c0aa2e15a250",
    "reef-surfel-browser-candidate/pack.py": "4c6f41e69830a9ad3f860b4a7c73d1185231dfccbe3d65a6d48b767dc2167ce7",
    "reef-pointcloud-feasibility/Darwin-original.ply": "b100240b870f6b2de270c53cb2cd3395c4da9c53ef916420c02513bf9be7f8d1",
    "reef-pointcloud-feasibility/revision-1000k/sample-1000k.npz": "61d8fff5d88b4fb2e89e5d472fe8691395e65bc31eedbff83cfd92412cc03669",
    "reef-continuous-zone-candidate/output/placement.json": "bebec6ed7fabadbe4160f3c619e3a5c57334d7fc445effe01d2f39eaf5b85ffc",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def json_bytes(value: dict) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def put_or_check(path: Path, data: bytes, check: bool) -> None:
    if check:
        require(path.is_file(), f"Missing prepared asset: {path}")
        require(path.read_bytes() == data, f"Prepared asset differs: {path}")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--check", action="store_true", help="Verify existing assets without changing files")
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    candidate = workspace / "reef-field-runtime-candidate"
    page = candidate / "page"
    field = page / "assets/field"

    # Verify pinned originals first, before generating or copying any output.
    for relative, expected in SOURCE_HASHES.items():
        source = workspace / relative
        require(source.is_file(), f"Missing local source: {source}")
        actual = sha256(source)
        require(actual == expected, f"Original source SHA-256 mismatch: {relative}: {actual}")
    data_files = sorted(p.name for p in (workspace / "reef-surfel-browser-candidate/data").iterdir() if p.is_file())
    require(data_files == ["darwin-1000k.bin", "manifest.json"], "Unexpected source data files; review and pin their hashes before preparation")

    copies = {
        "reef-surfel-browser-candidate/data/darwin-1000k.bin": field / "darwin-1000k.bin",
        "reef-surfel-browser-candidate/data/manifest.json": field / "points-manifest.json",
        "reef-surfel-browser-candidate/data.js": page / "field-data.js",
        "reef-continuous-zone-candidate/output/placement.json": field / "placement.json",
    }
    copied = []
    for relative, target in copies.items():
        source = workspace / relative
        if not args.check:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
        require(target.is_file(), f"Missing prepared copy: {target}")
        require(sha256(target) == SOURCE_HASHES[relative], f"Copied asset SHA-256 mismatch: {target}")
        require(target.read_bytes() == source.read_bytes(), f"Copied asset differs byte-for-byte: {target}")
        copied.append({"source": relative, "output": target.relative_to(candidate).as_posix(), "bytes": target.stat().st_size, "sha256": sha256(target), "byteIdentical": True})

    points_manifest = json.loads((field / "points-manifest.json").read_text())
    require(points_manifest["points"] == 1_000_000, "Unexpected point count")
    require(points_manifest["bytes"] == 24_000_000 == (field / "darwin-1000k.bin").stat().st_size, "Unexpected packed point byte size")
    require(points_manifest["sha256"] == sha256(field / "darwin-1000k.bin"), "Point manifest hash mismatch")

    original_relative = "reef-pointcloud-feasibility/Darwin-original.ply"
    sample_relative = "reef-pointcloud-feasibility/revision-1000k/sample-1000k.npz"
    pack_relative = "reef-surfel-browser-candidate/pack.py"
    require(points_manifest["sourceSHA256"] == sha256(workspace / original_relative), "Original PLY differs from point manifest sourceSHA256")
    require(points_manifest["sampleSHA256"] == sha256(workspace / sample_relative), "Sample NPZ differs from point manifest sampleSHA256")
    with (workspace / original_relative).open("rb") as stream:
        header = []
        for _ in range(100):
            line = stream.readline().decode("ascii").strip()
            header.append(line)
            if line == "end_header":
                break
        require(header[-1] == "end_header", "Original PLY header missing or too long")
    require("format binary_little_endian 1.0" in header, "Unexpected original PLY format")
    source_vertex_line = next((line for line in header if line.startswith("element vertex ")), "")
    require(source_vertex_line == f"element vertex {points_manifest['sourcePoints']}", "Original PLY vertex count differs from point manifest")

    # Reconstruct all three attributes exactly as the separately authored,
    # hash-pinned viewer pack.py does. Do not execute it: it writes source assets.
    n = points_manifest["points"]
    packed_bytes = (field / "darwin-1000k.bin").read_bytes()
    packed_positions = np.frombuffer(packed_bytes, dtype="<f4", count=n * 3, offset=0).reshape((n, 3))
    packed_normals = np.frombuffer(packed_bytes, dtype="<i2", count=n * 4, offset=n * 12).reshape((n, 4))
    packed_colors = np.frombuffer(packed_bytes, dtype="u1", count=n * 4, offset=n * 20).reshape((n, 4))
    with np.load(workspace / sample_relative, allow_pickle=False) as sample:
        sample_positions = sample["pos"]
        sample_normals = sample["normal"]
        sample_rgb = sample["rgb"]
        require(sample_positions.shape == sample_normals.shape == sample_rgb.shape == (n, 3), "Unexpected sample attribute shape")
        require(bool(np.isfinite(sample_positions).all() and np.isfinite(sample_normals).all()), "Nonfinite sample attribute")
        expected_positions = sample_positions.astype("<f4")
        expected_normals = np.zeros((n, 4), dtype="<i2")
        expected_normals[:, :3] = np.rint(np.clip(sample_normals, -1, 1) * 32767).astype("<i2")
        expected_colors = np.zeros((n, 4), dtype="u1")
        expected_colors[:, :3] = sample_rgb
        expected_colors[:, 3] = 255
        require(float(sample["radius"]) == points_manifest["radius"], "Sample radius differs from point manifest")
    require(np.array_equal(packed_positions, expected_positions), "Packed source positions differ from sample")
    require(np.array_equal(packed_normals, expected_normals), "Packed quantized normals or padding differ from sample")
    require(np.array_equal(packed_colors, expected_colors), "Packed RGB or alpha differ from sample")
    expected_packed = expected_positions.tobytes() + expected_normals.tobytes() + expected_colors.tobytes()
    require(packed_bytes == expected_packed, "Packed attributes not byte-identical to independent sample reconstruction")
    reconstructed_sha256 = hashlib.sha256(expected_packed).hexdigest()
    require(reconstructed_sha256 == points_manifest["sha256"], "Independent packing reconstruction hash mismatch")
    provenance = {
        "originalPLY": {"file": original_relative, "bytes": (workspace / original_relative).stat().st_size, "sha256": points_manifest["sourceSHA256"], "matchesManifestSourceSHA256": True, "vertices": int(source_vertex_line.split()[-1])},
        "sampleNPZ": {"file": sample_relative, "bytes": (workspace / sample_relative).stat().st_size, "sha256": points_manifest["sampleSHA256"], "matchesManifestSampleSHA256": True, "points": n},
        "packingReference": {"file": pack_relative, "sha256": SOURCE_HASHES[pack_relative], "executed": False},
        "allPointsCompared": n,
        "positionsExactFloat32": True,
        "rgbExactUint8": True,
        "normalsExactInt16Quantization": True,
        "normalQuantization": "rint(clip(sample.normal, -1, 1) * 32767).astype('<i2')",
        "normalPaddingWAllZero": True,
        "colorAlphaAll255": True,
        "sampleRadiusMatches": True,
        "reconstructedPackedBytes": len(expected_packed),
        "reconstructedPackedSHA256": reconstructed_sha256,
        "reconstructedPackedByteIdentical": True,
    }

    source_relative = "reef-contact-embedding-candidate/support.npz"
    with np.load(workspace / source_relative, allow_pickle=False) as source:
        require(set(source.files) == {"verts", "faces"}, "Unexpected support NPZ fields")
        verts = source["verts"]
        faces = source["faces"]
    require(verts.shape == (9120, 3) and verts.dtype == np.dtype("float32"), "Unexpected support vertices")
    require(faces.shape == (14818, 3) and np.issubdtype(faces.dtype, np.integer), "Unexpected support triangles")
    require(bool(np.isfinite(verts).all()), "Nonfinite support vertex")
    require(int(faces.min()) >= 0 and int(faces.max()) < len(verts), "Support index out of bounds")

    # Blender Z-up to Three Y-up: a rigid, determinant +1 rotation.
    # No recentering, rescaling, deformation, welding, or winding change.
    positions = np.empty(verts.shape, dtype="<f4")
    positions[:, 0] = verts[:, 0]
    positions[:, 1] = verts[:, 2]
    positions[:, 2] = -verts[:, 1]
    indices = np.asarray(faces, dtype="<u4")
    position_bytes = positions.tobytes(order="C")
    index_bytes = indices.tobytes(order="C")
    support_bytes = position_bytes + index_bytes
    put_or_check(field / "support.bin", support_bytes, args.check)

    roundtrip_buffer = (field / "support.bin").read_bytes()
    roundtrip_positions = np.frombuffer(roundtrip_buffer, dtype="<f4", count=verts.size).reshape((-1, 3))
    roundtrip_indices = np.frombuffer(roundtrip_buffer, dtype="<u4", offset=len(position_bytes)).reshape((-1, 3))
    require(np.array_equal(roundtrip_positions[:, 0], verts[:, 0]), "Support X transformation mismatch")
    require(np.array_equal(roundtrip_positions[:, 1], verts[:, 2]), "Support Y transformation mismatch")
    require(np.array_equal(roundtrip_positions[:, 2], -verts[:, 1]), "Support Z transformation mismatch")
    require(np.array_equal(roundtrip_indices, faces), "Support indices or winding changed")
    source_normals = np.cross(verts[faces[:, 1]] - verts[faces[:, 0]], verts[faces[:, 2]] - verts[faces[:, 0]])
    prepared_normals = np.cross(roundtrip_positions[faces[:, 1]] - roundtrip_positions[faces[:, 0]], roundtrip_positions[faces[:, 2]] - roundtrip_positions[faces[:, 0]])
    expected_normals = source_normals[:, [0, 2, 1]].copy()
    expected_normals[:, 2] *= -1
    require(np.array_equal(prepared_normals, expected_normals), "Triangle normals do not preserve rotated winding")
    degenerate = int(np.count_nonzero(np.linalg.norm(prepared_normals, axis=1) == 0))
    require(degenerate == 0, "Degenerate support triangles")

    manifest = {
        "format": "ReefSupportMeshLE-v1",
        "file": "support.bin",
        "sha256": hashlib.sha256(support_bytes).hexdigest(),
        "coordinateSystem": "Three.js XYZ, Y up",
        "transform": "Three XYZ = (Blender X, Blender Z, -Blender Y)",
        "transformMatrix3x3RowMajor": [[1, 0, 0], [0, 0, 1], [0, -1, 0]],
        "transformDeterminant": 1,
        "windingPreserved": True,
        "vertexCount": int(len(positions)),
        "triangleCount": int(len(indices)),
        "vertices": int(len(positions)),
        "triangles": int(len(indices)),
        "indexCount": int(indices.size),
        "bytes": len(position_bytes) + len(index_bytes),
        "bounds": {"min": positions.min(axis=0).tolist(), "max": positions.max(axis=0).tolist()},
        "positions": {"file": "support.bin", "offsetBytes": 0, "type": "float32", "components": 3, "byteOrder": "little-endian", "bytes": len(position_bytes), "sha256": hashlib.sha256(position_bytes).hexdigest()},
        "indices": {"file": "support.bin", "offsetBytes": len(position_bytes), "type": "uint32", "components": 1, "byteOrder": "little-endian", "bytes": len(index_bytes), "sha256": hashlib.sha256(index_bytes).hexdigest()},
        "source": {"file": source_relative, "bytes": (workspace / source_relative).stat().st_size, "sha256": SOURCE_HASHES[source_relative], "coordinateSystem": "Blender XYZ, Z up", "positionArray": "verts", "indexArray": "faces"},
    }
    put_or_check(field / "support-manifest.json", json_bytes(manifest), args.check)

    asset_files = sorted([*(field / name for name in ("darwin-1000k.bin", "points-manifest.json", "placement.json", "support.bin", "support-manifest.json")), page / "field-data.js"])
    report = {
        "status": "verified",
        "sourceHashesPinned": True,
        "copied": copied,
        "points": {"count": 1_000_000, "packedBytes": 24_000_000, "sha256": points_manifest["sha256"], "byteIdenticalToOriginal": True},
        "sourceProvenance": provenance,
        "support": manifest,
        "geometryVerification": {"coordinateTransformExact": True, "indicesUnchanged": True, "rotatedTriangleNormalsExact": True, "degenerateTriangles": degenerate, "indexRange": [int(indices.min()), int(indices.max())]},
        "outputs": [{"file": p.relative_to(candidate).as_posix(), "bytes": p.stat().st_size, "sha256": sha256(p)} for p in asset_files],
        "totalOutputBytesIncludingDecoder": sum(p.stat().st_size for p in asset_files),
        "notes": ["Point payload, point manifest, decoder, and requested continuous-zone placement were copied byte-for-byte.", "The copied placement.json contains historical descriptive validation text; final support geometry comes from the separately pinned contact-embedding source.", "No new downloads or installations; NumPy must already be available."],
    }
    put_or_check(candidate / "tools/field-assets-verification.json", json_bytes(report), args.check)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
