# Publisher handoff (not authorization to publish)

## Candidate and protected scope

Full local candidate: `reef-field-runtime-candidate/page/`, entry `scan-exhibit.html`. Prefer `reef-field-runtime-code-delta.zip` (no repeated 24 MB source payload). Copy the already-verified existing `darwin-surfel-candidate/data/darwin-1000k.bin` into this candidate’s `assets/field/darwin-1000k.bin` during staging; require SHA-256 `87564b81a9b4343b758e3649944e74edf06c8a7daf1e9ccf64aafc17fc9343c0`. The optional full `reef-field-runtime-delta.zip` includes that unchanged payload for local completeness. Apply either delta only to the matching current published animal-scale baseline. Do not replace the online entry, main branch or workflow without the parent's separate authorized publication step. Default OFF is part of this candidate's contract; do not enable automatically or imply acceptance.

Read `output/scope-manifest.json`: verify each changed file's `baselineSHA256` before overwriting. Reject a mismatched base rather than overwriting newer online changes. Three existing files change: scan-exhibit.html, scan-exhibit.js, scan-ocean.js. Seven new files supply runtime, decoder and assets. Everything else in the original complete page remains byte-identical. No new dependency/install required.

The delta omits unchanged original assets/vendor files and is not a standalone website. The complete page folder includes the baseline. Use an isolated preview path to keep existing experiences intact. Existing static-gallery links belong to the inherited baseline, not new runtime screenshots.

## Reproduce local checks

From the shared containing workspace:

1. `python reef-field-runtime-candidate/tools/prepare_field_assets.py --check`
2. `node reef-field-runtime-candidate/tools/test-field.mjs`
3. `node --check reef-field-runtime-candidate/page/scan-exhibit.js`
4. `node --check reef-field-runtime-candidate/tools/browser-check-field.mjs`
5. `python reef-field-runtime-candidate/tools/package_field.py`

CPU tests need the already-installed `three` package exposed by the existing node_modules link. Do not package node_modules. Asset preparation is reproducible from the already-existing source directories; publisher need not regenerate or download measured data.

## Actual browser QA, not run locally

Reuse the already-authorized GitHub Actions browser runner / existing Playwright installation. The browser script follows `reef-surfel-publish/tools/browser-check.mjs` secure launch conventions and is not itself a workflow. Do not install software or weaken sandbox/browser flags to run it. A local server or authorized isolated preview must serve the full page; SHA verification requires HTTPS or localhost.

Set FIELD_URL to the isolated `scan-exhibit.html` URL, optionally FIELD_OUTPUT for evidence, and run `node tools/browser-check-field.mjs` in the existing runner checkout (whose `tests/browser/node_modules/playwright/index.mjs` already exists). It must exercise default-off/no-download, failure/retry, 1M-point geometry, rapid toggle/cancel, raw-mode restore, pause demand rendering, repeated release/reload and actual screenshots. Review failed assertions before calling it a result.

Browser evidence must identify exact candidate commit/hash, actual GL renderer, linked shader status, errors, render counts and measured timings. Keep empirical render timings separate from inferred budgets; headless software rendering is not user-device FPS. Inspect 20%, 50%, and a right turn at 50% to verify grounding and acknowledge unfinished boundaries. Test raw mode with the experiment loading and ready, and close/reopen the candidate repeatedly.

Stop before promotion if shaders fail, restored baseline differs, a stale request adds a second instance, repeated toggles leak resources, or screenshots show a blank stage. Preserve complete source authorship, CC BY 4.0 measured source attribution, and existing CC BY-NC 2.0 restrictions. Never describe the synthetic sand as measured terrain.

## Fixed captures and resource accounting

Minimum matched views: pause ambient, route 20% field OFF/ON, route 50% OFF/ON, then the original 50% origin with a 35° rightward target turn ON. Keep stage pixels, camera FOV, origin, exposure, original objects and ambient time identical. Do not treat offline PNGs as browser capture evidence.

Ready API: `window.reefExhibit.continuousField.getState()` must return `status: 'ready', installed: true, points: 1000000`. `ensure()` / `setEnabled(true)` await activation; `restore()` / `setEnabled(false)` cancel and release. `reject(error)` explicitly tests render rollback; `dispose()` is terminal. Raw-mode entry uses `window.reefExhibit.setWaterMode(false)` and must leave the field OFF after returning underwater. Existing C1/C4 selection remains the original API/UI.

The ready state exposes actual allocated/visible field mesh objects, compact batch count, owned geometry/material count, exact geometry triangles and retained point bytes. `estimatedGeometryGPUBytes` and `estimatedCompactGPUBytes` only sum typed attribute/index/instance sizes: driver copies, shadows, textures, framebuffers and overhead are excluded. Measure renderer.info and GL in the browser separately.

CPU ready-state allocation audit: 15 new mesh objects visible (1 field cloud, 1 contact sand, 13 retained compact instance batches), 3 owned geometries, 1 owned material, the original sand material shared. Net visible draws +1. Owned typed geometry/index buffers sum to 24,505,728 bytes; compact instance attributes 65,440 bytes. These last two totals are allocation estimates, not empirical VRAM. Exact point backing storage is 24,000,000 bytes shared by its three source attribute views. Original objects/arrays retained for restoration passed reference and byte checks.

## Publication cache-tag compatibility (strict guard)

The original local animal candidate predates publication-only cache tags. `tools/verify_published_baseline.py` proves exact compatibility: two import-tag replacements in scan-exhibit.js, one entry-tag replacement in scan-exhibit.html, and one import-tag replacement each in scan-route.js / scan-assemblage.js. Every anchor must occur exactly once and the transformed bytes must equal the hash-pinned published files. scan-world.js and scan-turtle.js are already identical. No semantic discrepancy was found.

`output/published-baseline-compatibility.json` records both hashes and exact anchors. `scope-manifest.json` baselineSHA256 now targets the actual published JS `000f8da6ebf64fa3be6d9199dbb573312314d1409491064d805e65e76dd0b015` and HTML `5158cc0adadc3bc05789888a1d2c07987252a76be62f84a5f0ee21e243af4bde`. Do not accept other hashes or blanket-normalize query strings. The new candidate preserves the published internal animal-scale imports; only its own entry gets the experimental field version.

Actual publication source is the preserved 130-file source set overlaid with the six pinned animal publication files. The local complete page additionally has package.json and five old gallery PNGs for local work; these six are not in the delta and are not new publishing requirements. Keep the publisher's existing 628-file protection guard.

Final bounded runner coverage: five gallery captures (20% OFF/ON, 50% OFF/ON, 50% right35 ON), raw C1/C4 state assertions without extra screenshots, and two actual reload/memory comparisons reusing the required lifecycle flows. CPU testing still exercises six repeated load/off cycles. Screenshot geometry comes from DOM getBoundingClientRect, not locator.boundingBox. Overall 450s and per-screenshot 25s limits remain fixed.
