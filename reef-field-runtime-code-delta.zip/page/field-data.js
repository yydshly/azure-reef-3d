export function decode(buffer, m) {
  if (m.format !== 'DarwinSoA24LE-v1' || m.points !== 1000000 || m.bytes !== m.points * 24 || buffer.byteLength !== m.bytes) throw new Error('Unexpected point format/count/length');
  if (new Uint8Array(new Uint32Array([1]).buffer)[0] !== 1) throw new Error('Little-endian host required');
  const positions = new Float32Array(buffer, 0, m.points * 3);
  const normals = new Int16Array(buffer, m.points * 12, m.points * 4);
  const colors = new Uint8Array(buffer, m.points * 20, m.points * 4);
  return {positions, normals, colors}; // Three views, ONE retained backing ArrayBuffer.
}
export async function readPacked(url, m, signal, progress) {
  const response = await fetch(url, {signal, cache:'no-store'});
  if (!response.ok) throw new Error(`Point request HTTP ${response.status}`);
  if (!response.body) throw new Error('Streaming response unavailable');
  const declared = Number(response.headers.get('content-length'));
  if (declared && declared !== m.bytes && !response.headers.get('content-encoding')) throw new Error('Unexpected Content-Length');
  const buffer = new ArrayBuffer(m.bytes), dst = new Uint8Array(buffer);
  const reader = response.body.getReader(); let received = 0;
  try {
    while (true) {
      const {value, done} = await reader.read(); if (done) break;
      if (received + value.byteLength > m.bytes) throw new Error('Point payload too large');
      dst.set(value, received); received += value.byteLength; progress(received, m.bytes);
    }
  } catch (error) { await reader.cancel().catch(()=>{}); throw error; }
  finally { reader.releaseLock(); }
  if (received !== m.bytes) throw new Error(`Truncated data: ${received}/${m.bytes}`);
  if (!globalThis.crypto?.subtle) throw new Error('SHA-256 requires HTTPS or localhost');
  const hash = [...new Uint8Array(await crypto.subtle.digest('SHA-256', buffer))].map(v=>v.toString(16).padStart(2,'0')).join('');
  if (signal.aborted) throw new DOMException('Aborted','AbortError');
  if (hash !== m.sha256) throw new Error('Point SHA-256 mismatch');
  return decode(buffer, m);
}
export function cameraPosition(m, elevation, yaw = 0) {
  if (yaw === 0 && (elevation === 50 || elevation === 12)) return [...m.views[elevation === 50 ? 'normal' : 'side']];
  const e = elevation * Math.PI / 180, a = yaw * Math.PI / 180;
  const x = .1 * m.L, y = -2 * m.L * Math.cos(e);
  return [x*Math.cos(a)-y*Math.sin(a), x*Math.sin(a)+y*Math.cos(a), 2*m.L*Math.sin(e)];
}
