// Run ONLY in an already-authorized supported browser runner, never the restricted executor.
// Existing Playwright installation required. No software install, upload, publish or deploy.
// FIELD_URL must be the isolated candidate's scan-exhibit.html URL.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const {chromium}=await import(pathToFileURL(path.resolve(process.env.PLAYWRIGHT_MODULE||'tests/browser/node_modules/playwright/index.mjs')).href);
const base=process.env.FIELD_URL;if(!base)throw Error('Set FIELD_URL to the isolated candidate scan-exhibit.html URL');
const output=process.env.FIELD_OUTPUT||'field-browser-evidence';await mkdir(output,{recursive:true});
const startedAt=new Date().toISOString(),errors=[],consoleErrors=[],requests=[],frames=[],memory=[];
const deadline=setTimeout(()=>{console.error('FIELD_FAILED: 450s overall QA deadline');process.exit(1);},450000);
let browser,page;
const report={status:'RUNNING',startedAt,limits:'Desktop WebGL only; renderer allocation counters and page JS heap are not total GPU/process memory, physical-device FPS or mobile validation.'};
try{
 browser=await chromium.launch({channel:'chromium',headless:true,chromiumSandbox:true,timeout:30000,args:['--enable-automation'],ignoreDefaultArgs:['--enable-unsafe-swiftshader','--disable-gpu-sandbox','--ignore-gpu-blocklist']});
 const cdp=await browser.newBrowserCDPSession(),command=await cdp.send('Browser.getBrowserCommandLine');
 assert(!command.arguments.some(x=>['--no-sandbox','--disable-gpu-sandbox','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'].some(f=>x===f||x.startsWith(f+'='))),'Security-weakening browser flag');
 page=await browser.newPage({viewport:{width:1440,height:1080},deviceScaleFactor:1});
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});
 page.on('request',r=>{if(r.url().includes('/assets/field/'))requests.push({url:r.url(),at:new Date().toISOString()});});
 const state=()=>page.evaluate(()=>window.reefExhibit.continuousField.getState());
 const waitState=status=>page.waitForFunction(status=>window.reefExhibit?.continuousField.getState().status===status,status,{timeout:120000});
 const fresh=()=>page.evaluate(()=>window.reefExhibit.observeNextRender(receipt=>({receipt,demand:window.reefExhibit.getRenderDemandState(),render:{...window.reefExhibit.renderer.info.render},memory:{...window.reefExhibit.renderer.info.memory},programs:window.reefExhibit.renderer.info.programs.length})));
 const clip=selector=>page.evaluate(selector=>{const {x,y,width,height}=document.querySelector(selector).getBoundingClientRect();return{x,y,width,height};},selector);
 const screenshot=async name=>{
  // Same-stack readPixels runs inside the actual render receipt, before WebGL discards
  // its preserveDrawingBuffer:false backbuffer. Match the established gallery gate.
  const capture=await page.evaluate(()=>{const e=window.reefExhibit,before=e.getRenderDemandState().sequence;return e.observeNextRender(receipt=>{
   const gl=e.renderer.getContext(),w=gl.drawingBufferWidth,h=gl.drawingBufferHeight,pixels=new Uint8Array(w*h*4);gl.readPixels(0,0,w,h,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
   const colors=new Set();for(let y=1;y<16;y++)for(let x=1;x<20;x++){const i=(Math.floor(y*h/16)*w+Math.floor(x*w/20))*4;colors.add([pixels[i],pixels[i+1],pixels[i+2],pixels[i+3]].join(','));}
   const s=e.getState();return {receipt,previousSequence:before,camera:e.camera.position.toArray(),target:e.controls.target.toArray(),ambient:{...s.ambient},route:{...s.route},field:e.continuousField.getState(),graphics:{width:w,height:h,contextLost:gl.isContextLost(),sampleColors:colors.size,pixelError:gl.getError(),render:{...e.renderer.info.render}}};
  });});
  assert(capture.receipt.sequence>capture.previousSequence,'Fresh screenshot render sequence');assert.equal(capture.graphics.contextLost,false);assert.equal(capture.graphics.pixelError,0);assert(capture.graphics.sampleColors>=2&&capture.graphics.render.calls>0,'Nonempty screenshot pixel gate');
  const box=await clip('#scanStage');assert(box.width>0&&box.height>0);const file=name+'.png';await page.screenshot({path:path.join(output,file),clip:box,timeout:25000});const b=await readFile(path.join(output,file));frames.push({name,file,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex'),...capture});
 };
 const chooseRoute=async p=>{await page.evaluate(p=>{const e=window.reefExhibit;e.enterRoute();e.goRoute(p,true);},p);};
 await page.goto(base,{waitUntil:'domcontentloaded',timeout:60000});
 await page.waitForFunction(()=>{const e=window.reefExhibit;if(!e)return false;const s=e.getState();return s.ready&&['c4','assemblage','naturalRock','layeredRidges','ray','turtle'].every(k=>s[k]?.status==='ready')&&e.coralMidground.getState().status==='ready';},null,{timeout:180000});
 assert.equal(requests.length,0,'No point payload, manifests or support download on default page load');
 assert.equal((await state()).status,'idle');assert.equal((await state()).enabled,false);
 await page.evaluate(()=>window.reefExhibit.setAmbientPaused(true));await fresh();
 // Warm both comparison views before allocation comparisons, without field downloads.
 await chooseRoute(.2);await screenshot('baseline-near');await chooseRoute(.5);await screenshot('baseline-mid');
 assert.equal(requests.length,0);
 await page.evaluate(async()=>{
  const e=window.reefExhibit,arrays=new Map(),objects=[],seen=new Set();
  const hash=async a=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',a))].map(v=>v.toString(16).padStart(2,'0')).join('');
  const save=a=>{if(a&&!arrays.has(a))arrays.set(a,null);};
  // Field-owned replacement domain and protected source scans/ground only. Camera-follow
  // ocean envelope and independent animal transforms are intentionally outside this snapshot.
  for(const root of [e.world.group,e.scan,e.c4,e.ocean.ground])root.traverse(o=>{if(seen.has(o))return;seen.add(o);objects.push({o,parent:o.parent,children:[...o.children],geometry:o.geometry,material:o.material,visible:o.visible,count:o.count});if(o.geometry){save(o.geometry.index?.array);Object.values(o.geometry.attributes).forEach(a=>save(a.array));Object.values(o.geometry.morphAttributes).flat().forEach(a=>save(a.array));}save(o.instanceMatrix?.array);save(o.instanceColor?.array);});
  for(const a of arrays.keys())arrays.set(a,await hash(a));
  window.__fieldQA={objects,arrays,hash,ambientTime:e.getState().ambient.time,budget:{...e.world.budget},check:async function(){
   const issues=[],ambient=e.getState().ambient;if(!ambient.paused||ambient.time!==this.ambientTime)issues.push('Snapshot requires unchanged paused ambient time');
   for(const s of this.objects){const o=s.o;for(const k of ['parent','geometry','material','visible','count'])if(o[k]!==s[k])issues.push(o.name+': '+k);if(o.children.length!==s.children.length||o.children.some((c,i)=>c!==s.children[i]))issues.push(o.name+': children');}
   for(const [a,before]of this.arrays)if(await this.hash(a)!==before)issues.push('Original attribute bytes changed');
   if(JSON.stringify(e.world.budget)!==JSON.stringify(this.budget))issues.push('Original world budget changed');return {issues,objects:this.objects.length,arrays:this.arrays.size};
  }};
 });
 const restored=async()=>{const result=await page.evaluate(()=>window.__fieldQA.check());assert.deepEqual(result.issues,[],'Exact original restoration: '+JSON.stringify(result));return result;};
 await page.locator('#hudMoreSummary').click();
 // A real 503 response must preserve originals and expose the explicit retry affordance.
 await page.route('**/darwin-1000k.bin',route=>route.fulfill({status:503,body:'Deliberate field QA failure'}),{times:1});
 await page.locator('#toggleContinuousField').click();await waitState('error');
 assert.match((await state()).error,/503/);assert.equal((await state()).installed,false);assert.equal(await page.locator('#retryContinuousField').isVisible(),true);await restored();
 await page.locator('#retryContinuousField').click();await waitState('ready');await page.locator('#closeHudMore').click();await fresh();
 const initial=await page.evaluate(async()=>{
  const e=window.reefExhibit,r=e.continuousField.getRoot(),cloud=r.getObjectByName('Measured_Darwin_1000000_Surfels'),support=r.getObjectByName('Synthetic_Field_Contact_Sand'),g=cloud.geometry;
  const payloadSHA256=[...new Uint8Array(await crypto.subtle.digest('SHA-256',g.attributes.center.array.buffer))].map(n=>n.toString(16).padStart(2,'0')).join('');
  return {state:e.continuousField.getState(),rootData:r.userData,payloadSHA256,rootCount:e.world.group.children.filter(o=>o.name==='Experimental_Continuous_Reef_Field').length,centerCount:g.attributes.center.count,normalCount:g.attributes.sourceNormal.count,colorCount:g.attributes.sourceColor.count,pointBuffers:new Set(['center','sourceNormal','sourceColor'].map(k=>g.attributes[k].array.buffer)).size,pointBytes:['center','sourceNormal','sourceColor'].reduce((n,k)=>n+g.attributes[k].array.byteLength,0),primitiveTriangles:g.index.count/3,scale:cloud.scale.toArray(),position:cloud.position.toArray(),rotationX:cloud.rotation.x,sameSandMaterial:support.material===e.ocean.ground.material,memory:{...e.renderer.info.memory}};
 });
 assert.equal(initial.state.points,1000000);assert.equal(initial.state.displayTriangles,4000000);assert.equal(initial.state.removedObjects,192);assert.equal(initial.state.removedRidgeTriangles,1620);assert.equal(initial.state.removedTriangles,69232);assert.equal(initial.state.netTriangles,3945586);assert.equal(initial.state.supportTriangles,14818);assert.equal(initial.rootCount,1);assert.equal(initial.pointBuffers,1);assert.equal(initial.pointBytes,24000000);assert.equal(initial.primitiveTriangles,4);assert.equal(initial.sameSandMaterial,true);assert.deepEqual(initial.scale,[2,2,2]);assert.deepEqual(initial.position,[21.5,.04,-44]);assert.equal(initial.rotationX,-Math.PI/2);for(const k of ['centerCount','normalCount','colorCount'])assert.equal(initial[k],1000000);
 assert.equal(initial.payloadSHA256,initial.rootData.payloadSHA256,'Original packed point bytes remain intact after GPU upload');
 // Observe the actual field draw, not a later unrelated scene program.
 const binding=await page.evaluate(async()=>{
  const e=window.reefExhibit,cloud=e.continuousField.getRoot().getObjectByName('Measured_Darwin_1000000_Surfels'),g=e.renderer.getContext(),oldBefore=cloud.onBeforeRender,oldAfter=cloud.onAfterRender;let result=null,trianglesBefore=0;
  cloud.onBeforeRender=function(...args){oldBefore.apply(this,args);trianglesBefore=e.renderer.info.render.triangles;};
  cloud.onAfterRender=function(...args){oldAfter.apply(this,args);const p=g.getParameter(g.CURRENT_PROGRAM),shaders=g.getAttachedShaders(p),vertex=shaders.find(s=>g.getShaderParameter(s,g.SHADER_TYPE)===g.VERTEX_SHADER),source=g.getShaderSource(vertex),debug=g.getExtension('WEBGL_debug_renderer_info');result={linked:g.getProgramParameter(p,g.LINK_STATUS),compiled:shaders.every(s=>g.getShaderParameter(s,g.COMPILE_STATUS)),fieldShader:source.includes('sourceNormal')&&source.includes('fieldRadius')&&source.includes('fieldRGB'),drawTriangles:e.renderer.info.render.triangles-trianglesBefore,attributes:Object.fromEntries(['center','sourceNormal','sourceColor'].map(n=>{const i=g.getAttribLocation(p,n);return[n,{location:i,enabled:i>=0&&g.getVertexAttrib(i,g.VERTEX_ATTRIB_ARRAY_ENABLED),type:i>=0&&g.getVertexAttrib(i,g.VERTEX_ATTRIB_ARRAY_TYPE),size:i>=0&&g.getVertexAttrib(i,g.VERTEX_ATTRIB_ARRAY_SIZE),normalized:i>=0&&g.getVertexAttrib(i,g.VERTEX_ATTRIB_ARRAY_NORMALIZED),divisor:i>=0&&g.getVertexAttrib(i,g.VERTEX_ATTRIB_ARRAY_DIVISOR)}];})),renderer:debug?g.getParameter(debug.UNMASKED_RENDERER_WEBGL):g.getParameter(g.RENDERER),error:g.getError()};};
  try{await e.observeNextRender(()=>true);return result;}finally{cloud.onBeforeRender=oldBefore;cloud.onAfterRender=oldAfter;}
 });
 assert(binding&&binding.linked&&binding.compiled&&binding.fieldShader);assert.equal(binding.drawTriangles,4000000);assert.equal(binding.error,0);
 for(const [n,type,size,normalized]of [['center',5126,3,false],['sourceNormal',5122,4,true],['sourceColor',5121,4,true]]){const a=binding.attributes[n];assert(a.location>=0&&a.enabled&&a.type===type&&a.size===size&&a.normalized===normalized&&a.divisor===1,'Actual GPU attribute '+n);}
 report.initial=initial;report.binding=binding;console.log('FIELD_INITIAL '+JSON.stringify({initial,binding}));
 await chooseRoute(.2);await screenshot('field-near');await chooseRoute(.5);await screenshot('field-mid');
 // Use the application's real drag handler for the requested 50% / right 35-degree view.
 const stageBox=await clip('#scanCanvas');assert(stageBox.width>0&&stageBox.height>0);
 const dragX=stageBox.x+stageBox.width*.45,dragY=stageBox.y+stageBox.height*.5;
 await page.mouse.move(dragX,dragY);await page.mouse.down();await page.mouse.move(dragX+(35*Math.PI/180)/.004,dragY);await page.mouse.up();await fresh();
 report.rightTurn=await page.evaluate(()=>({route:window.reefExhibit.getState().route,camera:window.reefExhibit.camera.position.toArray(),target:window.reefExhibit.controls.target.toArray()}));
 assert.equal(report.rightTurn.route.progress,.5);assert(Math.abs(report.rightTurn.route.yaw+35*Math.PI/180)<.0041,'Requested right 35-degree drag, within one CSS pixel');
 await screenshot('field-mid-right35');await chooseRoute(.5);
 // Dirty-frame gate must go idle while ambient is paused, then repaint a user action.
 await fresh();await page.waitForTimeout(300);const paused=await page.evaluate(()=>window.reefExhibit.getRenderDemandState());await page.waitForTimeout(500);
 assert.equal((await page.evaluate(()=>window.reefExhibit.getRenderDemandState())).draws,paused.draws,'Paused, settled scene produces no new draws');
 await chooseRoute(.52);await fresh();assert((await page.evaluate(()=>window.reefExhibit.getRenderDemandState())).draws>paused.draws,'Paused user navigation still redraws');await chooseRoute(.5);
 report.pauseDemand={paused,afterNavigation:await page.evaluate(()=>window.reefExhibit.getRenderDemandState())};
 // Raw observation must remove the experiment immediately, disable its UI, then restore exact originals on return.
 await page.evaluate(()=>{window.reefExhibit.selectView('near');window.reefExhibit.setWaterMode(false);});await fresh();assert.equal((await state()).status,'idle');assert.equal((await state()).installed,false);assert.equal(await page.locator('#toggleContinuousField').isDisabled(),true);
 const rawVisibility=()=>page.evaluate(()=>{const e=window.reefExhibit;return{selectedPatch:e.getState().selectedPatch,waterMode:e.getState().waterMode,c1:e.scan.visible,c4:e.c4.visible,world:e.world.group.visible,ocean:e.ocean.group.visible,life:e.life.group.visible};});
 report.rawC1=await rawVisibility();assert.deepEqual(report.rawC1,{selectedPatch:'C1',waterMode:false,c1:true,c4:false,world:false,ocean:false,life:false});
 await page.evaluate(()=>window.reefExhibit.setWaterMode(true));await fresh();assert.equal(await page.locator('#toggleContinuousField').isDisabled(),false);await restored();
 assert.equal(await page.evaluate(()=>window.reefExhibit.continuousField.ensure()),true);await waitState('ready');
 await page.evaluate(()=>{window.reefExhibit.observeC4();window.reefExhibit.setWaterMode(false);});await fresh();assert.equal((await state()).installed,false);
 report.rawC4=await rawVisibility();assert.deepEqual(report.rawC4,{selectedPatch:'C4',waterMode:false,c1:false,c4:true,world:false,ocean:false,life:false});
 await page.evaluate(()=>window.reefExhibit.setWaterMode(true));await chooseRoute(.5);await restored();
 // Reuse the essential lifecycle reloads for memory comparisons. The CPU suite separately
 // exercises six full install/restore cycles; this runner does not add six 24 MB downloads.
 const pageCdp=await page.context().newCDPSession(page);
 const memorySample=async label=>{await fresh();await pageCdp.send('HeapProfiler.collectGarbage');const heap=await pageCdp.send('Runtime.getHeapUsage');const counters=await page.evaluate(()=>({memory:{...window.reefExhibit.renderer.info.memory},programs:window.reefExhibit.renderer.info.programs.length,rootCount:window.reefExhibit.world.group.children.filter(o=>o.name==='Experimental_Continuous_Reef_Field').length}));const result={label,heap,...counters};memory.push(result);return result;};
 const plateau=await memorySample('baseline-after-warmup');
 const checkLoaded=async label=>{const loaded=await memorySample(label);assert.equal(loaded.memory.textures,plateau.memory.textures,'Field creates no new textures');assert.equal(loaded.rootCount,1);assert.equal((await state()).points,1000000);};
 const checkUnloaded=async label=>{await restored();const unloaded=await memorySample(label);assert.deepEqual(unloaded.memory,plateau.memory,'Renderer geometry/texture plateau after disposal');assert.equal(unloaded.programs,plateau.programs,'Field shader program released');assert.equal(unloaded.rootCount,0);};
 // A pending response can complete after an OFF->ON transition without installing two fields.
 let heldResolve;const heldPromise=new Promise(resolve=>{heldResolve=resolve;});let heldRoute;
 await page.route('**/darwin-1000k.bin',route=>{heldRoute=route;heldResolve();},{times:1});
 await page.evaluate(()=>{void window.reefExhibit.continuousField.ensure();});await heldPromise;assert.equal((await state()).status,'loading');
 await page.evaluate(()=>{const r=window.reefExhibit.continuousField;r.restore();void r.ensure();});await waitState('ready');
 // The request was aborted by restore; continuation only drains Playwright's route bookkeeping.
 await heldRoute.continue().catch(()=>{});assert.equal((await state()).points,1000000);
 assert.equal(await page.evaluate(()=>window.reefExhibit.world.group.children.filter(o=>o.name==='Experimental_Continuous_Reef_Field').length),1);
 await checkLoaded('loaded-after-rapid-toggle');
 // Explicit shader/render rejection must restore originals without terminating the baseline.
 await page.evaluate(()=>window.reefExhibit.continuousField.reject(Error('Deliberate QA render rejection')));await waitState('error');assert.equal(await page.evaluate(()=>window.reefExhibit.getRenderDemandState().terminated),false);await checkUnloaded('restored-after-rejection');
 assert.equal(await page.evaluate(()=>window.reefExhibit.continuousField.ensure()),true);await waitState('ready');await checkLoaded('loaded-after-retry');
 await page.evaluate(()=>window.reefExhibit.continuousField.dispose());assert.equal((await state()).status,'disposed');await checkUnloaded('restored-after-dispose');report.restored=await restored();
 const last=memory.at(-1);assert(last.heap.usedSize<plateau.heap.usedSize+8*1024*1024,'No retained 24 MB point payload per repeat in JS heap');
 if(Number.isFinite(last.heap.backingStorageSize)&&Number.isFinite(plateau.heap.backingStorageSize))assert(last.heap.backingStorageSize<plateau.heap.backingStorageSize+8*1024*1024,'No repeated retained point backing buffers');
 assert.equal(await page.evaluate(()=>window.reefExhibit.continuousField.ensure()),false);assert.equal(await page.evaluate(()=>window.reefExhibit.renderer.getContext().getError()),0);assert.deepEqual(errors,[]);
 // A deliberately intercepted HTTP 503 is expected; all shader/WebGL console failures are not.
 const unexpectedConsole=consoleErrors.filter(s=>!/503|Deliberate field QA failure/.test(s));assert.deepEqual(unexpectedConsole,[]);
 Object.assign(report,{status:'PASS_SUPPORTED_BROWSER',completedAt:new Date().toISOString(),elapsedMs:Date.now()-Date.parse(startedAt),browser:{version:browser.version(),sandbox:true,unsafeGraphicsFlags:false},frames,memory,requests,errors,consoleErrors});
 await writeFile(path.join(output,'browser-result.json'),JSON.stringify(report,null,2)+'\n');console.log('FIELD_COMPLETE '+JSON.stringify(report));
}catch(error){
 Object.assign(report,{status:'FAIL_SUPPORTED_BROWSER',completedAt:new Date().toISOString(),error:String(error.stack||error),frames,memory,requests,errors,consoleErrors});
 await writeFile(path.join(output,'browser-result.json'),JSON.stringify(report,null,2)+'\n');console.error('FIELD_FAILED_REPORT '+JSON.stringify(report));console.error('FIELD_FAILED',error);throw error;
}finally{clearTimeout(deadline);await browser?.close();}
