import pathlib,json,hashlib,zipfile,shutil
here=pathlib.Path(__file__).parent;dist=pathlib.Path('dist');sha=lambda b:hashlib.sha256(b).hexdigest()
def inv(root):
 assert root.is_dir() and not any(p.is_symlink() for p in root.rglob('*'))
 return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
surfel=dist/'preview/darwin-surfel-candidate';r=json.loads((here/'surfel-preservation.json').read_text());assert inv(surfel)=={f['path']:f['sha256'] for f in r['sourceFiles']}
p=pathlib.Path('.field-inputs/surfel-gallery-c3ca891.zip');b=p.read_bytes();assert len(b)==r['archive']['bytes'] and sha(b)==r['archive']['sha256']
with zipfile.ZipFile(p) as z:
 assert len(z.namelist())==len(set(z.namelist()))==4 and set(z.namelist())==set(r['files'])
 for n,f in r['files'].items():
  rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];p=surfel/n;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
before=inv(dist);assert len(before)==628;pathlib.Path('.field-protected.json').write_text(json.dumps(before,sort_keys=True))
base=dist/'preview/coral-midground-candidate';new=dist/'preview/reef-field-candidate';assert not new.exists();shutil.copytree(base,new)
# A candidate gets its own version-bound gallery; inherited static images must not imply a fresh result.
(new/'current-scene.html').unlink();shutil.rmtree(new/'assets/current-scene')
m=json.loads((here/'field-scope.json').read_text());archive=pathlib.Path('.field-inputs/reef-field-runtime-code-delta.zip');b=archive.read_bytes();assert len(b)==158911 and sha(b)=='bc749ec1bf73c653db79ac4cf3fa05040cf57462c9a229df9ed2ec71179688f8'
# Compatibility mapping is independently frozen against exact published cache references.
compat=json.loads((here/'field-compatibility.json').read_text())
with zipfile.ZipFile(archive) as z:
 expected={f['file']:f for f in m['changed']+m['added'] if f['file']!='assets/field/darwin-1000k.bin'}
 assert len(z.namelist())==len(set(z.namelist()))==20
 assert {n for n in z.namelist() if n.startswith('page/')}=={'page/'+n for n in expected}
 assert json.loads(z.read('output/scope-manifest.json'))==m
 for n,f in expected.items():
  rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
  p=new/n
  if 'baselineSHA256' in f:assert sha(p.read_bytes())==compat[n]['publishedBaselineSHA256']
  else:assert not p.exists()
  b=z.read('page/'+n);assert len(b)==f['bytes'] and sha(b)==f['sha256']
  for old,value in compat.get(n,{}).get('replacements',[]):assert b.count(old.encode())==1;b=b.replace(old.encode(),value.encode())
  assert sha(b)==compat[n]['finalSHA256'] if n in compat else sha(b)==f['sha256']
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
payload=(surfel/'data/darwin-1000k.bin').read_bytes();assert len(payload)==24000000 and sha(payload)=='87564b81a9b4343b758e3649944e74edf06c8a7daf1e9ccf64aafc17fc9343c0';(new/'assets/field/darwin-1000k.bin').write_bytes(payload)
source=[{'path':n,'bytes':(new/n).stat().st_size,'sha256':h} for n,h in sorted(inv(new).items())];version=sha(json.dumps(source,sort_keys=True).encode()+(here/'browser-check-field.mjs').read_bytes());pathlib.Path('.field-build.json').write_text(json.dumps({'root':str(new),'contentVersion':version,'sourceFiles':source,'sourceArchiveSha256':sha(archive.read_bytes())},indent=2));print('FIELD_STAGED',json.dumps({'sourceFiles':len(source),'oldFiles':628,'contentVersion':version}))
