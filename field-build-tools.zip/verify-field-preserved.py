import pathlib,json,hashlib
root=pathlib.Path('dist');before=json.loads(pathlib.Path('.field-protected.json').read_text());assert len(before)==628
for n,h in before.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
print('OLD_628_FILES_BYTE_IDENTICAL')
