import json,pathlib,hashlib
root=pathlib.Path('dist');before=json.loads(pathlib.Path('.surfel-protected.json').read_text());excluded=root/'preview/darwin-surfel-candidate'
after={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and not p.is_relative_to(excluded)}
assert after==before and len(after)==614,'Existing published content changed'
counts={name:sum(n.startswith('preview/'+name+'/') for n in after) for name in ['independent-scan','natural-rock-candidate','layered-reef-candidate','coral-midground-candidate']}
assert counts=={'independent-scan':130,'natural-rock-candidate':133,'layered-reef-candidate':135,'coral-midground-candidate':137}
assert sum(not n.startswith('preview/') for n in after)==79
print('ALL_PUBLISHED_BYTES_PRESERVED',json.dumps({'formalRoot':79,**counts,'total':614,'oldPagesRerendered':False}))
