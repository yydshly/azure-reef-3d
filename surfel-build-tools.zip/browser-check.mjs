// Run ONLY in the already-authorized supported browser runner, not the restricted local executor.
// Existing Playwright installation required. No software install or deployment is performed here.
import {pathToFileURL} from 'node:url';
import path from 'node:path';
const {chromium}=await import(pathToFileURL(path.join(process.cwd(),'tests/browser/node_modules/playwright/index.mjs')).href);
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
const base=process.env.SURFEL_URL;if(!base)throw new Error('Set SURFEL_URL to the isolated candidate URL');
const output=process.env.SURFEL_OUTPUT||'surfel-browser-evidence';await mkdir(output,{recursive:true});
const startedAt=new Date().toISOString();
const deadline=setTimeout(()=>{console.error('450s overall QA deadline');process.exit(1);},450000);
let browser;
try {
browser=await chromium.launch({channel:'chromium',headless:true,chromiumSandbox:true,timeout:30000,args:['--enable-automation'],ignoreDefaultArgs:['--enable-unsafe-swiftshader','--disable-gpu-sandbox','--ignore-gpu-blocklist']});
const cdp=await browser.newBrowserCDPSession();const command=await cdp.send('Browser.getBrowserCommandLine');assert(!command.arguments.some(x=>['--no-sandbox','--disable-gpu-sandbox','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'].some(f=>x===f||x.startsWith(f+'='))),'Security-weakening browser flag');
const page=await browser.newPage({viewport:{width:1440,height:1300},deviceScaleFactor:1});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
const clip=selector=>page.evaluate(selector=>{const {x,y,width,height}=document.querySelector(selector).getBoundingClientRect();return{x,y,width,height};},selector);
const renderedAfter=frames=>page.waitForFunction(frames=>{const s=window.reefSurfel.inspect();return s.frames>frames&&s.scheduledFrames===0;},frames,{timeout:30000});
 let payloadRequests=0;page.on('request',r=>{if(r.url().endsWith('darwin-1000k.bin'))payloadRequests++;});
 await page.goto(base);assert.equal(await page.locator('canvas').count(),0);
 await page.waitForTimeout(200);assert.equal(payloadRequests,0,'not loaded before explicit action');
 await page.route('**/darwin-1000k.bin',route=>route.fulfill({status:503,body:'test failure'}),{times:1});
 await page.locator('#load').click();await page.waitForFunction(()=>document.body.dataset.state==='error');
 assert.match(await page.locator('#status').textContent(),/503/);
 await page.locator('#load').click();await page.waitForFunction(()=>document.body.dataset.state==='ready',null,{timeout:120000});
 const initial=await page.evaluate(()=>window.reefSurfel.inspect());
 const sourceManifest=JSON.parse(await readFile('dist/preview/darwin-surfel-candidate/data/manifest.json','utf8'));assert.deepEqual(initial.camera.position,sourceManifest.views.normal);assert.deepEqual(initial.camera.up,sourceManifest.cameraUp);assert.equal(initial.camera.right-initial.camera.left,sourceManifest.orthoWidth);assert.equal(initial.camera.near,sourceManifest.near);assert.equal(initial.camera.far,sourceManifest.far);assert.equal(initial.sourceSHA256,sourceManifest.sourceSHA256);assert.equal(initial.payloadSHA256,sourceManifest.sha256);assert.equal(initial.retainedCPUPointBytes,24000000);assert.equal(initial.sharedPrimitiveBytes,96);console.log('SURFEL_INITIAL '+JSON.stringify(initial));
 assert.equal(initial.points,1000000);assert.equal(initial.sceneChildren,1);assert.equal(initial.render.calls,1);assert.equal(initial.render.triangles,4000000);assert.equal(initial.textureCount,0);assert.equal(initial.lastError,null);assert.equal(initial.uniqueCPUPointBuffers,1);assert.equal(Object.values(initial.attributes).reduce((n,a)=>n+a.byteLength,0),24000000);assert(initial.programs.length>0&&initial.programs.every(p=>p.linked));
 const normalProbe=await page.evaluate(()=>window.reefSurfel.probePixels());assert.equal(normalProbe.glError,0);assert(normalProbe.nonBackground>10000);

 const binding=await page.evaluate(()=>{const g=document.querySelector('canvas').getContext('webgl2'),p=g.getParameter(g.CURRENT_PROGRAM),shaders=g.getAttachedShaders(p),vertex=shaders.find(s=>g.getShaderParameter(s,g.SHADER_TYPE)===g.VERTEX_SHADER),vs=g.getShaderSource(vertex),debug=g.getExtension('WEBGL_debug_renderer_info');return{linked:g.getProgramParameter(p,g.LINK_STATUS),compiled:shaders.every(s=>g.getShaderParameter(s,g.COMPILE_STATUS)),normalOriented:vs.includes('vec3 n = normalize(sourceNormal.xyz)')&&vs.includes('vec3 u = normalize(cross(n,ref))')&&vs.includes('vec3 p = center + radius * (position.x*u + position.y*v)'),attributes:Object.fromEntries(['center','sourceNormal','sourceColor'].map(n=>{const i=g.getAttribLocation(p,n);return[n,{location:i,enabled:g.getVertexAttrib(i,g.VERTEX_ATTRIB_ARRAY_ENABLED),type:g.getVertexAttrib(i,g.VERTEX_ATTRIB_ARRAY_TYPE),size:g.getVertexAttrib(i,g.VERTEX_ATTRIB_ARRAY_SIZE),normalized:g.getVertexAttrib(i,g.VERTEX_ATTRIB_ARRAY_NORMALIZED),divisor:g.getVertexAttrib(i,g.VERTEX_ATTRIB_ARRAY_DIVISOR)}]})),renderer:debug?g.getParameter(debug.UNMASKED_RENDERER_WEBGL):g.getParameter(g.RENDERER),vendor:debug?g.getParameter(debug.UNMASKED_VENDOR_WEBGL):g.getParameter(g.VENDOR),version:g.getParameter(g.VERSION),error:g.getError()};});
 assert(binding.linked&&binding.compiled&&binding.normalOriented&&binding.error===0);for(const [n,type,size,normalized]of [['center',5126,3,false],['sourceNormal',5122,4,true],['sourceColor',5121,4,true]]){const a=binding.attributes[n];assert(a.location>=0&&a.enabled&&a.type===type&&a.size===size&&a.normalized===normalized&&a.divisor===1,'Actual GPU attribute '+n);}
 const pageCdp=await page.context().newCDPSession(page);const heap=await pageCdp.send('Runtime.getHeapUsage');console.log('SURFEL_GPU_BINDING '+JSON.stringify({binding,heap,heapScope:'Chromium page JS heap counters, not GPU allocation or total process memory'}));

 assert.equal(await page.evaluate(()=>document.querySelector('canvas').getContext('webgl2').getError()),0);
 await page.screenshot({path:`${output}/normal-browser.png`,clip:await clip('#viewport'),timeout:25000});
 const beforeSide=await page.evaluate(()=>window.reefSurfel.inspect().frames);await page.locator('#side').click();await renderedAfter(beforeSide);
 const sideProbe=await page.evaluate(()=>window.reefSurfel.probePixels());assert.equal(sideProbe.glError,0);assert(sideProbe.nonBackground>10000);
 const side=await page.evaluate(()=>window.reefSurfel.inspect());assert.equal(side.elevation,12);assert.deepEqual(side.camera.position,sourceManifest.views.side);console.log('SURFEL_SIDE '+JSON.stringify(side));
 await page.screenshot({path:`${output}/side-browser.png`,clip:await clip('#viewport'),timeout:25000});
 const stable=await page.evaluate(()=>window.reefSurfel.inspect().frames);await page.waitForTimeout(500);assert.equal(await page.evaluate(()=>window.reefSurfel.inspect().frames),stable,'idle produces no frames');
 await page.locator('#pause').click();await page.locator('#normal').click();await page.waitForTimeout(250);
 assert.equal(await page.evaluate(()=>window.reefSurfel.inspect().frames),stable,'paused view changes produce no frames');
 await page.locator('#pause').click();await renderedAfter(stable);assert((await page.evaluate(()=>window.reefSurfel.inspect().frames))>stable);
 const box=await clip('canvas');await page.mouse.move(box.x+100,box.y+100);await page.mouse.down();await page.mouse.move(box.x+1200,box.y+900);await page.mouse.up();
 const orbit=await page.evaluate(()=>window.reefSurfel.inspect());assert.equal(orbit.yaw,15);assert.equal(orbit.elevation,55);
 const beforeNormal=await page.evaluate(()=>window.reefSurfel.inspect().frames);await page.locator('#normal').click();await renderedAfter(beforeNormal);
 const gl=await page.evaluate(()=>{const g=document.querySelector('canvas').getContext('webgl2');return{version:g.getParameter(g.VERSION),renderer:g.getParameter(g.RENDERER),vendor:g.getParameter(g.VENDOR),maxTextureSize:g.getParameter(g.MAX_TEXTURE_SIZE),error:g.getError()};});assert.equal(gl.error,0);
 await page.locator('#destroy').click();assert.equal(await page.locator('canvas').count(),0);
 const destroyed=await page.evaluate(()=>window.reefSurfel.inspect());assert.equal(destroyed.disposed,true);assert.equal(destroyed.points,0);assert.equal(destroyed.scheduledFrames,0);
 await page.locator('#load').click();await page.waitForFunction(()=>document.body.dataset.state==='ready',null,{timeout:120000});assert.equal(await page.locator('canvas').count(),1);
 await page.locator('#destroy').click();
 assert.equal(payloadRequests,3,'One deliberate failed request and two successful user loads');assert.deepEqual(errors,[]);
 const frames=await Promise.all(['normal','side'].map(async name=>{const data=await readFile(`${output}/${name}-browser.png`);return{name,file:`${name}-browser.png`,bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')};}));
 await writeFile(`${output}/browser-result.json`,JSON.stringify({status:'PASS_SUPPORTED_BROWSER',startedAt,completedAt:new Date().toISOString(),elapsedMs:Date.now()-Date.parse(startedAt),binding,heap,heapScope:'Page JS heap, not GPU/total process memory',sourceManifest,frames,browser:{version:browser.version(),sandbox:true,unsafeGraphicsFlags:false},initial,side,normalProbe,sideProbe,orbit,destroyed,gl,payloadRequests,errors,limits:'WebGL desktop runner only; not physical GPU memory/FPS/mobile validation'},null,2));
 console.log('SURFEL_COMPLETE '+JSON.stringify({passed:true,frames,elapsedMs:Date.now()-Date.parse(startedAt),payloadRequests,initial,side,normalProbe,sideProbe,orbit,destroyed,binding,heap}));
} catch(e){console.error('SURFEL_FAILED',e);throw e;} finally {clearTimeout(deadline);await browser?.close();}
