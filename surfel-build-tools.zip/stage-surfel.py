import pathlib,json,hashlib,zipfile
here=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();dist=pathlib.Path('dist');coral=dist/'preview/coral-midground-candidate';new=dist/'preview/darwin-surfel-candidate'
def inv(p):
 assert p.is_dir() and not p.is_symlink();assert not any(f.is_symlink() for f in p.rglob('*'))
 return {f.relative_to(p).as_posix():sha(f.read_bytes()) for f in p.rglob('*') if f.is_file()}
r=json.loads((here/'coral-preservation.json').read_text());expected={f['path']:f['sha256'] for f in r['sourceFiles']};assert len(expected)==130 and inv(coral)==expected
p=pathlib.Path('.surfel-inputs/coral-gallery-6a58944.zip');assert len(p.read_bytes())==r['archive']['bytes'] and sha(p.read_bytes())==r['archive']['sha256']
with zipfile.ZipFile(p) as z:
 assert len(z.namelist())==len(set(z.namelist()))==7 and set(z.namelist())==set(r['files'])
 for n,f in r['files'].items():
  rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];p=coral/n;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
assert inv(coral)==expected|{n:f['sha256'] for n,f in r['files'].items()}
assert len(inv(coral))==137
before=inv(dist);assert len(before)==614;pathlib.Path('.surfel-protected.json').write_text(json.dumps(before,sort_keys=True))
archive=pathlib.Path('.surfel-inputs/reef-surfel-browser-candidate.zip');assert len(archive.read_bytes())==20077383 and sha(archive.read_bytes())=='028e18a4f2c1a353c74a583f065c87b2956cd667ca3dac6672a67cfabc0386e3'
files=json.loads((here/'surfel-files.json').read_text());public={'README.md','index.html','app.js','data.js','viewer.js','data/darwin-1000k.bin','data/manifest.json','vendor/THREE-LICENSE.txt','vendor/three.core.js','vendor/three.module.js'}
assert not new.exists();new.mkdir();source=[]
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(files)+1 and set(z.namelist())=={f['path'] for f in files}|{'FILES.json'}
 assert json.loads(z.read('FILES.json'))==files
 for f in files:
  n=f['path'];rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in n
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256']
  if n in public:p=new/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);source.append(f)
assert len(source)==10
version=sha(json.dumps(source,sort_keys=True).encode()+(here/'browser-check.mjs').read_bytes())
pathlib.Path('.surfel-build.json').write_text(json.dumps({'contentVersion':version,'root':str(new),'sourceFiles':source,'sourceArchiveSha256':sha(archive.read_bytes())},indent=2))
print('SURFEL_STAGED',json.dumps({'publicRuntimeFiles':10,'publicRuntimeBytes':sum(f['bytes'] for f in source),'oldAllFilesProtected':614,'sourceArchiveSha256':sha(archive.read_bytes()),'contentVersion':version}))
