"""Build a frozen four-file overlay plus nine exact saved-public enriched products; no fetch."""
from pathlib import Path
import hashlib
import json
import zipfile

P = Path(__file__).resolve().parent.parent
W = P.parent
sha = lambda b: hashlib.sha256(b).hexdigest()

def record(n, b):
    return {'path': n, 'bytes': len(b), 'sha256': sha(b)}

def archive(n, files):
    p = P / n
    with zipfile.ZipFile(p, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(files.items()):
            i = zipfile.ZipInfo(name, (2026, 10, 11, 0, 0, 0))
            i.compress_type = zipfile.ZIP_DEFLATED
            i.external_attr = 0o100644 << 16
            z.writestr(i, data)
    return record(n, p.read_bytes())

def main():
    previous = W / 'reef-exploration-enriched-publish'
    old = json.loads((previous / 'tools/enriched-contract.json').read_text())
    result_path = previous / 'evidence/run38143761729-public-receipt.json'
    result = json.loads(result_path.read_text())
    get_path = previous / 'public-get-receipt.json'
    get = json.loads(get_path.read_text())
    assert result['totalFiles'] == 2127 and result['protectedFilesByteIdentical'] is True
    assert get['mainCommit'] == result['sourceIdentity']['checkoutCommit'] == 'a1b2cae7e968ad383798a0ff15c87bfb0934d971'
    assert result['sourceIdentity']['candidateSourceCommit'] == 'acd6b3f9f287b8fa5b8e07e4ffddf3491668c92b'
    assert result['sourceIdentity']['sourceHashAggregate'] == old['sourceHashAggregate']
    public = {f['path']: f for f in result['files']}
    fetched = {f['sitePath']: f for f in get['verified']}
    snapshots = set(public) - {old['candidatePath'] + '/' + n for n in old['sourceHashes']}
    assert len(public) == 158 and len(snapshots) == 9
    expected = json.loads((previous / 'expected-public.json').read_text())
    assert expected['mainCommit'] == get['mainCommit']
    expected_records = {f['sitePath']: {k: f[k] for k in ('path', 'bytes', 'sha256')} for f in expected['files']}
    assert all(expected_records[n] == public[n] for n in snapshots)
    saved = {}
    for n in sorted(snapshots):
        b = (previous / 'published' / n).read_bytes()
        assert record(n, b) == public[n]
        assert fetched[n]['status'] == 200 and fetched[n]['sha256'] == sha(b) and fetched[n]['bytes'] == len(b)
        saved[n] = b
    source = W / 'reef-surface-grounding-candidate/page'
    manifest_path = W / 'reef-surface-grounding-candidate/verification/surface-source-sha256.json'
    product_path = W / 'reef-surface-grounding-candidate/verification/surface-publisher/contract.json'
    product = json.loads(product_path.read_text())
    assert sha(manifest_path.read_bytes()) == 'bd0ffeb2123425c05ecb84e51a8e2f3c6f656f058b97d6896fcbc42f2a9b6748'
    assert product['baselineCommit'] == get['mainCommit'] and product['productFiles'] == 150
    frozen = json.loads(manifest_path.read_text())
    assert all(n.startswith('page/') for n in frozen)
    hashes = {n[5:]: h for n, h in frozen.items()}
    files = {p.relative_to(source).as_posix(): p.read_bytes() for p in sorted(source.rglob('*')) if p.is_file()}
    assert len(files) == len(hashes) == 150 and {n: sha(b) for n, b in files.items()} == hashes
    assert set(hashes) - set(old['sourceHashes']) == {'exploration-surface.js'} and not set(old['sourceHashes']) - set(hashes)
    delta = {n: b for n, b in files.items() if old['sourceHashes'].get(n) != sha(b)}
    assert {n: sha(b) for n, b in delta.items()} == {n[5:]: h for n, h in product['changedOrNewFiles'].items()}
    assert set(delta) == {'scan-exhibit.js', 'scan-surface.js', 'exploration-world.js', 'exploration-surface.js'}
    assert sum(hashes.get(n) == h for n, h in old['sourceHashes'].items()) == 146
    with zipfile.ZipFile(previous / old['snapshotArchive']['path']) as z:
        staged_entry = [record(n, z.read(n)) for n in old['mutableEntryPaths']]
    aggregate = sha(''.join(n + '\0' + hashes[n] + '\n' for n in sorted(hashes)).encode())
    c = dict(schemaVersion=1, candidatePath='preview/surface-grounding-candidate', basePath=old['candidatePath'], entryPath='preview/world',
        baseMainCommit=get['mainCommit'], baseSourceCommit=result['sourceIdentity']['candidateSourceCommit'],
        baseSourceHashAggregate=old['sourceHashAggregate'], sourceHashAggregate=aggregate,
        sourceHashes=hashes, sourceFiles=[record(n, files[n]) for n in sorted(files)],
        baseSourceHashes=old['sourceHashes'], baseSourceFiles=old['sourceFiles'], oldPublicFiles=list(public.values()),
        snapshotFiles=[public[n] for n in sorted(saved)], snapshotArchive=archive('exploration-enriched-snapshot-a1b2cae7.zip', saved),
        stagedEntryFiles=staged_entry, codeArchive=archive('surface-grounding-code.zip', delta),
        changes=[dict(record(n, delta[n]), baseSha256=old['sourceHashes'].get(n)) for n in sorted(delta)],
        mutableEntryPaths=old['mutableEntryPaths'], oldAssemblyProtectedFiles=1969, oldAssemblyFiles=2121,
        oldSiteFiles=2127, protectedFiles=2127, rootFiles=79, newSourceFiles=150, unchangedSourceFiles=146,
        newGalleryFiles=6, stagedSiteFiles=2277, finalSiteFiles=2283,
        frames=old['frames'], frameRegions=old['frameRegions'], qaSegments=old['qaSegments'], requiredSegmentPhases=old['requiredSegmentPhases'],
        totalBudgetMs=450000, captureTimeoutMs=25000,
        expectedExplorationBudget=old['expectedExplorationBudget'], expectedFullLoadedScene=old['expectedFullLoadedScene'],
        expectedOwnedResources={'geometries': 63, 'materials': 7, 'instances': 17},
        productVersion=product['revision'], productContract=product,
        acceptance='Surface grounding technical evidence only. The current world entry remains unchanged. Overall realism, final artistic acceptance and the 5 percent performance target remain unapproved.',
        acceptanceChinese='水下材质接地独立候选，固定入口保持不变，整体真实感与最终美术效果尚未验收，5%性能目标尚未证实',
        unverified=old['unverified'], oldEntryEvidencePolicy=old['oldEntryEvidencePolicy'],
        frozenManifest=record('verification/surface-source-sha256.json', manifest_path.read_bytes()),
        frozenProductContract=record('verification/surface-publisher/contract.json', product_path.read_bytes()),
        preparationOnly=True, allowWorldUpdate=False, candidateSourceCommit='__SURFACE_SOURCE_COMMIT__',
        provenance={'oldPublishedResult': record(str(result_path.relative_to(W)), result_path.read_bytes()),
                    'savedPublicReceipt': record(str(get_path.relative_to(W)), get_path.read_bytes())})
    (P / 'tools/surface-contract.json').write_text(json.dumps(c, ensure_ascii=False, indent=2, sort_keys=True) + '\n')
    summary = {'status': 'LOCAL_PREPARATION_ONLY', 'sourceFiles': 150, 'sourceHashAggregate': aggregate, 'changes': c['changes'],
               'unchangedSourceFiles': 146, 'snapshotFiles': 9, 'protectedFiles': 2127,
               'oldSiteFiles': 2127, 'stagedSiteFiles': 2277, 'finalSiteFiles': 2283,
               'packages': [c['codeArchive'], c['snapshotArchive']], 'browserRun': False, 'uploaded': False}
    (P / 'input-package-receipt.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
