"""Verify all old bytes, exactly 150 sources, six evidence files and unchanged world products."""
import sys
from surface_common import *


def verify(c, source_only=False):
    protected, current = check_old(c)
    check_sources(c)
    expected = candidate_sources(c)
    old = snapshot(c)
    if source_only:
        require(not pathlib.Path('.surface-finalized.json').exists(), 'Already finalized')
        for n in c['mutableEntryPaths']:
            require((DIST / n).read_bytes() == old[n], 'Old world changed before finalization: ' + n)
        require(len(current) == c['stagedSiteFiles'], '2277 staged files required')
    else:
        check_deadline()
        receipt, gallery = gallery_records(c)
        identity = source_identity(c)
        require(receipt['sourceIdentity'] == identity and receipt['appearanceAccepted'] is False, 'Final identity/acceptance mismatch')
        require(receipt['state'] == 'QA_PASS_WORLD_UNCHANGED', 'World pointer promotion is forbidden')
        for f in gallery:
            validate_bytes((DIST / f['path']).read_bytes(), f, f['path'])
            expected.add(f['path'])
        manifest = read_json(DIST / c['candidatePath'] / 'assets/current-scene' / c['sourceHashAggregate'] / 'manifest.json')
        reports = manifest['segmentReports']
        check_qa_segments(c, reports)
        require(receipt['runIdentity'] == run_identity() and receipt['segments'] == {name: {k: value[k] for k in ('segment', 'startedAtMs', 'expiresAtMs', 'completedAtMs', 'totalBudgetMs', 'status')} for name, value in reports.items()}, 'Final receipt differs from independent segment evidence')
        entry = {n: old[c['entryPath'] + '/' + n] for n in ENTRY_NAMES}
        require(receipt['pointer'] is None, 'Unchanged pointer must have no replacement receipt')
        require(len(receipt['entryFiles']) == 3 and {f['path'] for f in receipt['entryFiles']} == set(ENTRY_NAMES), 'Exact world products required')
        for n, b in entry.items():
            require((DIST / c['entryPath'] / n).read_bytes() == b, 'World file differs from exact approved output: ' + n)
        for f in receipt['entryFiles']:
            validate_bytes(entry[f['path']], f, f['path'])
        require(len(current) == c['finalSiteFiles'], '2283 final files required')
        check_deadline()
    require(set(current) - set(protected) == expected, 'Unexpected/missing output files')
    print('EXPLORATION_PRESERVATION_PASS', json.dumps({'sourceOnly': source_only, 'oldSiteFiles': 2127, 'protectedFiles': 2127, 'oldEntryPNGsPreserved': 2, 'newEntryScreenshots': 0, 'totalFiles': len(current), 'newCandidateFiles': len(current) - 2127}))
    if not source_only:
        print('EXPLORATION_PUBLIC_RECEIPT', json.dumps({'status': 'PASS_EXACT_156_ADDITIONS_WORLD_UNCHANGED', 'oldSiteFiles': 2127, 'protectedFiles': 2127,
            'protectedFilesByteIdentical': True, 'rootFilesByteIdentical': 79, 'oldEntryPNGsByteIdentical': 2, 'newEntryScreenshots': 0,
            'newFiles': 156, 'totalFiles': 2283, 'sourceIdentity': identity, 'appearanceAccepted': False,
            'files': [file_record(DIST / n, n) for n in sorted(expected)]}, ensure_ascii=False))


if __name__ == '__main__':
    require(sys.argv[1:] in ([], ['--source-only'], ['--deadline-only']), 'Unexpected arguments')
    if '--deadline-only' in sys.argv:
        check_deadline()
        print('FREE_COMPAT_FINALIZATION_DEADLINE_PASS')
    else:
        verify(contract(), '--source-only' in sys.argv)
