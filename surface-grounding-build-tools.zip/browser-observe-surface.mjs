// Adds read-only inspection to the mature observer's existing submitted draws.
// The references come from the original world's compiled limestone materials,
// independently of the candidate's uniforms. No renderer, clock or pose changes.
export async function installSurfaceObservation(page){return page.evaluate(()=>{
 const e=window.reefExhibit,q=window.__explorationQA,renderer=e.renderer;
 if(!q||q.surface)throw Error('Surface observation requires one fresh base observer');
 const owners=[],normalMaps=new Set(),roughnessMaps=new Set();
 // Dynamic ridge materials share these maps but have their own valid disposal
 // lifecycle. Capture only the original persistent scan-world limestone batches.
 const sourceNames=new Set(['Sunlit_Broken_Coral_Shelves','Valley_And_Passage_Buttresses','Overlapping_Distant_Ridges','Connected_Broken_Bedrock_Aprons','Partly_Buried_Apron_Stones']);
 e.world.group.traverse(mesh=>{if(!mesh.isMesh||!sourceNames.has(mesh.name))return;for(const material of Array.isArray(mesh.material)?mesh.material:[mesh.material]){
  if(owners.some(owner=>owner.material===material))continue;
  const uniforms=renderer.properties.get(material).uniforms,normal=uniforms?.reefStoneNormal?.value,roughness=uniforms?.reefStoneRough?.value;
  if(!normal&&!roughness)continue;
  if(!normal||!roughness)throw Error('Incomplete original limestone texture owner');
  owners.push({material,normal,roughness});normalMaps.add(normal);roughnessMaps.add(roughness);
 }});
 if(normalMaps.size!==1||roughnessMaps.size!==1)throw Error('Unique compiled original limestone references unavailable');
 const normal=[...normalMaps][0],roughness=[...roughnessMaps][0];if(normal===roughness)throw Error('Borrowed texture roles collapsed');
 const file=texture=>new URL(texture.image?.currentSrc||texture.image?.src,location.href).pathname.split('/assets/').at(-1);
 if(file(normal)!=='reef-texture-2.png'||file(roughness)!=='reef-texture-3.png')throw Error('Original limestone texture filenames changed');
 const state=texture=>JSON.stringify({version:texture.version,wrapS:texture.wrapS,wrapT:texture.wrapT,magFilter:texture.magFilter,minFilter:texture.minFilter,anisotropy:texture.anisotropy,colorSpace:texture.colorSpace,flipY:texture.flipY,generateMipmaps:texture.generateMipmaps,matrixAutoUpdate:texture.matrixAutoUpdate,matrix:texture.matrix?.toArray(),offset:texture.offset?.toArray(),repeat:texture.repeat?.toArray(),center:texture.center?.toArray(),rotation:texture.rotation});
 const snapshots=[normal,roughness].map(texture=>({texture,source:texture.source,image:texture.image,state:state(texture)}));
 const surface=q.surface={owners,normal,roughness,borrowedDisposals:0,contract:structuredClone(e.explorationWorld.group.userData.surface)};
 for(const texture of [normal,roughness])texture.addEventListener('dispose',()=>surface.borrowedDisposals++);
 surface.verify=()=>{
  const issues=[],sameSourceReferences=owners.every(owner=>{const uniforms=renderer.properties.get(owner.material).uniforms;return uniforms?.reefStoneNormal?.value===owner.normal&&uniforms?.reefStoneRough?.value===owner.roughness;}),textureStateUnchanged=snapshots.every(snapshot=>snapshot.texture.source===snapshot.source&&snapshot.texture.image===snapshot.image&&state(snapshot.texture)===snapshot.state);
  if(!sameSourceReferences)issues.push('Original limestone texture reference changed');if(!textureStateUnchanged)issues.push('Borrowed texture state changed');if(surface.borrowedDisposals)issues.push('Borrowed texture disposed');
  return {issues,borrowedDisposals:surface.borrowedDisposals,borrowedTextureCount:2,sourceMaterialCount:owners.length,textureFiles:['assets/reef-texture-2.png','assets/reef-texture-3.png'],sameSourceReferences,textureStateUnchanged};
 };
 surface.inspect=(mesh,material,program,vertex,fragment)=>{
  const gl=renderer.getContext(),cacheKey=material.customProgramCacheKey(),kind=material.userData.borrowedSurfaceMaps?'rock':mesh.name.startsWith('Open_Bay_Seagrass_Meadow_')?'grass':'other';
  const sampler=(name,expected)=>{
   const location=gl.getUniformLocation(program,name),map=renderer.properties.get(material).uniforms?.[name]?.value,expectedHandle=renderer.properties.get(expected).__webglTexture;
   if(location===null)return {active:false,textureUUID:map?.uuid||null,expectedTextureUUID:expected.uuid,borrowedReferenceIdentical:map===expected};
   const unit=gl.getUniform(program,location),active=gl.getParameter(gl.ACTIVE_TEXTURE);let bound;
   try{gl.activeTexture(gl.TEXTURE0+unit);bound=gl.getParameter(gl.TEXTURE_BINDING_2D);}finally{gl.activeTexture(active);}
   return {active:true,unit,textureUUID:map?.uuid||null,expectedTextureUUID:expected.uuid,borrowedReferenceIdentical:map===expected,uploaded:!!expectedHandle,boundToExpectedMap:!!expectedHandle&&bound===expectedHandle};
  };
  return {kind,cacheKey,...(kind==='rock'?{normal:sampler('explorationStoneNormal',normal),roughness:sampler('explorationStoneRoughness',roughness)}:{}),rockDetailFragment:fragment.includes('stoneDetail*.27')&&fragment.includes('roughnessFactor=.83+.16*surfaceR'),grassSwayNormal:vertex.includes('objectNormal.y-leafDxDy*objectNormal.x-leafDzDy*objectNormal.z'),grassRootFade:fragment.includes('.82+.18*smoothstep(.035,.38,vExplorationBladeHeight)'),unchangedWater:fragment.includes('deepWater=smoothstep(240.,415.,-cameraPosition.z)')};
 };
 return {contract:surface.contract,protection:surface.verify(),mode:'original compiled-owner references; same existing onAfterRender and render receipt'};
});}
