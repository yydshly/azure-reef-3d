"""Exploration publication guards. Local receipts and QA tools stay outside dist."""
import hashlib
import json
import math
import os
import pathlib
import re
import stat
import struct
import time
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
DIST = pathlib.Path('dist')
INPUTS = pathlib.Path('.surface-inputs')
ENTRY_NAMES = ('index.html', 'world.css', 'current-world.json')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(pathlib.Path(path).read_text())


def save_json(path, value):
    pathlib.Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n')


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()


def safe_name(name):
    require(isinstance(name, str) and bool(name), 'Missing relative path')
    p = pathlib.PurePosixPath(name)
    require(not p.is_absolute() and '..' not in p.parts and '\\' not in name and p.as_posix() == name and name != '.', 'Unsafe path: ' + name)
    return p


def inventory(root):
    root = pathlib.Path(root)
    require(root.is_dir() and not root.is_symlink(), 'Missing/linked directory: ' + str(root))
    result = {}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink() and (p.is_file() or p.is_dir()), 'Linked/special path: ' + str(p))
        if p.is_file():
            result[p.relative_to(root).as_posix()] = sha(p.read_bytes())
    return result


def file_record(path, relative=None):
    p = pathlib.Path(path)
    b = p.read_bytes()
    return {'path': relative or p.name, 'bytes': len(b), 'sha256': sha(b)}


def validate_bytes(data, record, label):
    require(len(data) == record['bytes'] and sha(data) == record['sha256'], 'Size/SHA mismatch: ' + label)


def checked_archive(path, archive, expected):
    p = pathlib.Path(path)
    require(p.is_file() and not p.is_symlink(), 'Missing/linked archive: ' + str(p))
    validate_bytes(p.read_bytes(), archive, str(p))
    with zipfile.ZipFile(p) as z:
        require(len(z.namelist()) == len(set(z.namelist())) == len(expected) and set(z.namelist()) == set(expected), 'Unexpected archive file set: ' + str(p))
        files = {}
        for info in z.infolist():
            safe_name(info.filename)
            mode = info.external_attr >> 16
            require(not info.is_dir() and not stat.S_ISLNK(mode) and stat.S_IFMT(mode) in (0, stat.S_IFREG), 'Nonregular archive member')
            data = z.read(info)
            validate_bytes(data, expected[info.filename], info.filename)
            files[info.filename] = data
    return files


def contract():
    c = read_json(HERE / 'surface-contract.json')
    require(c['candidatePath'] == 'preview/surface-grounding-candidate' and c['basePath'] == 'preview/exploration-enriched-candidate' and c['entryPath'] == 'preview/world', 'Destination changed')
    require(c['baseMainCommit'] == 'a1b2cae7e968ad383798a0ff15c87bfb0934d971', 'Published baseline changed')
    require([c[k] for k in ('oldAssemblyProtectedFiles', 'oldAssemblyFiles', 'oldSiteFiles', 'protectedFiles', 'rootFiles', 'newSourceFiles', 'newGalleryFiles', 'stagedSiteFiles', 'finalSiteFiles')] == [1969, 2121, 2127, 2127, 79, 150, 6, 2277, 2283], 'Exact publication counts changed')
    require(c['totalBudgetMs'] == 450000 and c['captureTimeoutMs'] == 25000, '450/25-second budgets changed')
    require(c['mutableEntryPaths'] == [c['entryPath'] + '/' + n for n in ENTRY_NAMES], 'Exact three-entry allowlist changed')
    require(len(c['sourceFiles']) == len(c['sourceHashes']) == 150 and len(c['baseSourceFiles']) == len(c['baseSourceHashes']) == 149, 'Source counts changed')
    for hashes, records in ((c['sourceHashes'], c['sourceFiles']), (c['baseSourceHashes'], c['baseSourceFiles'])):
        require({f['path']: f['sha256'] for f in records} == hashes, 'Source manifest mismatch')
        for n, h in hashes.items():
            safe_name(n)
            require(re.fullmatch('[0-9a-f]{64}', h), 'Invalid source hash')
    require(sha(''.join(n + '\0' + c['sourceHashes'][n] + '\n' for n in sorted(c['sourceHashes'])).encode()) == c['sourceHashAggregate'], 'Source aggregate mismatch')
    changes = {f['path']: f for f in c['changes']}
    require(len(c['changes']) == 4 and set(changes) == {'scan-exhibit.js', 'scan-surface.js', 'exploration-world.js', 'exploration-surface.js'}, 'Exact three-changed-plus-one-new-file delta required')
    predicted = dict(c['baseSourceHashes'])
    for n, f in changes.items():
        require(predicted.get(n) == f['baseSha256'], 'Delta baseline mismatch: ' + n)
        predicted[n] = f['sha256']
    require(predicted == c['sourceHashes'] and sum(c['sourceHashes'].get(n) == h for n, h in c['baseSourceHashes'].items()) == 146, '146 unchanged source files required')
    require(c['frames'] == ['tour-initial', 'tour-grass-bay', 'tour-completed'], 'Three natural tour stages required')
    require(c['expectedExplorationBudget'] == {'meshes': 75, 'drawCalls': 75, 'triangles': 255078, 'instances': 2092, 'geometryBytes': 3184704, 'newTextureBytes': 0, 'newModelBytes': 0}, 'Frozen enriched geometry budget changed')
    require(c['expectedOwnedResources'] == {'geometries': 63, 'materials': 7, 'instances': 17}, 'Frozen enriched owned resources changed')
    require(c['productVersion'] == 'surface-grounding-20261011-v1' and c['productContract']['geometryBudget'] == {k: c['expectedExplorationBudget'][k] for k in ('meshes', 'triangles', 'instances', 'geometryBytes')}, 'Surface product version/budget mismatch')
    require(c['allowWorldUpdate'] is False, 'World pointer promotion is forbidden for this candidate')
    require(c['baseSourceCommit'] == 'acd6b3f9f287b8fa5b8e07e4ffddf3491668c92b' and c['frozenManifest']['sha256'] == 'bd0ffeb2123425c05ecb84e51a8e2f3c6f656f058b97d6896fcbc42f2a9b6748', 'Frozen source identity changed')
    return c


def assembly_protection(c):
    # Reuse the pinned, unchanged previous checker to authenticate its complete
    # 1969-file chain back through the grounded and original-root inventories.
    import enriched_common as previous
    old = previous.contract()
    require(old['candidatePath'] == c['basePath'] and old['sourceHashes'] == c['baseSourceHashes'], 'Old assembly identity mismatch')
    protected, _ = previous.check_old(old)
    require(len(protected) == c['oldAssemblyProtectedFiles'], 'Old assembly protection mismatch')
    return protected


def baseline_hashes(c):
    protected = assembly_protection(c)
    public = {f['path']: f['sha256'] for f in c['oldPublicFiles']}
    require(len(c['oldPublicFiles']) == len(public) == 158 and not set(public) & set(protected), 'Published baseline records overlap old protection')
    expected = dict(protected, **public)
    require(len(expected) == c['oldSiteFiles'], '2127 published baseline files required')
    return expected


def snapshot(c):
    records = {f['path']: f for f in c['snapshotFiles']}
    require(len(records) == len(c['snapshotFiles']) == 9, 'Six old gallery and three world products required')
    files = checked_archive(INPUTS / c['snapshotArchive']['path'], c['snapshotArchive'], records)
    public = {f['path']: f for f in c['oldPublicFiles']}
    require(all(public.get(n) == f for n, f in records.items()), 'Snapshot differs from published receipt')
    require(set(public) == {c['basePath'] + '/' + n for n in c['baseSourceHashes']} | set(files), 'Published file set mismatch')
    require({n for n in files if n.startswith(c['entryPath'] + '/')} == set(c['mutableEntryPaths']), 'World snapshot allowlist mismatch')
    for f in c['baseSourceFiles']:
        require(public[c['basePath'] + '/' + f['path']] == dict(f, path=c['basePath'] + '/' + f['path']), 'Published baseline source record mismatch')
    p = json.loads(files[c['entryPath'] + '/current-world.json'])
    require(p['mainCommit'] == c['baseMainCommit'] and p['candidateSourceCommit'] == c['baseSourceCommit'] and p['sourceHashAggregate'] == c['baseSourceHashAggregate'], 'Old pointer identity mismatch')
    return files


def candidate_sources(c):
    return {c['candidatePath'] + '/' + n for n in c['sourceHashes']}


def check_sources(c):
    for f in c['sourceFiles']:
        p = DIST / c['candidatePath'] / f['path']
        require(p.is_file() and not p.is_symlink(), 'Missing/linked candidate source: ' + f['path'])
        validate_bytes(p.read_bytes(), f, f['path'])


def check_old(c):
    baseline = baseline_hashes(c)
    require(read_json('.surface-baseline.json') == baseline, 'Published baseline inventory changed')
    protected = dict(baseline)
    require(len(protected) == c['protectedFiles'] and read_json('.surface-protected.json') == protected, 'Exact 2127 protected files required')
    current = inventory(DIST)
    for n, h in protected.items():
        require(current.get(n) == h, 'Old file changed/missing: ' + n)
    root = read_json('.root-site-hashes.json')
    require(len(root) == c['rootFiles'] and {n: h for n, h in current.items() if not n.startswith('preview/')} == root, 'Original root bytes changed')
    return protected, current


def check_deadline(segment='free-compat', current=True):
    require(segment in ('tour', 'free-compat'), 'Unknown QA segment')
    d = read_json('.exploration-' + segment + '-deadline.json')
    require(d['totalBudgetMs'] == 450000 and isinstance(d['startedAtMs'], (int, float)) and isinstance(d['expiresAtMs'], (int, float)), 'Invalid shared deadline')
    require(d['expiresAtMs'] - d['startedAtMs'] == 450000, 'Shared deadline extended')
    require(d['startedAtMs'] <= time.time() * 1000, 'QA segment starts in the future')
    require(not current or time.time() * 1000 < d['expiresAtMs'], 'QA segment 450-second deadline expired')
    return d


def source_identity(c):
    identity = {'candidateSourceCommit': os.environ.get('EXPLORATION_SOURCE_COMMIT', ''), 'checkoutCommit': os.environ.get('GITHUB_SHA', ''),
                'candidatePath': c['candidatePath'], 'sourceHashAggregate': c['sourceHashAggregate'], 'sourceFiles': 150, 'baseMainCommit': c['baseMainCommit']}
    for k in ('candidateSourceCommit', 'checkoutCommit'):
        require(re.fullmatch('[0-9a-f]{40}', identity[k]), 'Missing exact commit: ' + k)
    return identity


def run_identity():
    value = {'runId': os.environ.get('GITHUB_RUN_ID', ''), 'runAttempt': os.environ.get('GITHUB_RUN_ATTEMPT', ''), 'qaCommit': os.environ.get('GITHUB_SHA', '')}
    require(re.fullmatch('[0-9]+', value['runId']) and re.fullmatch('[0-9]+', value['runAttempt']) and re.fullmatch('[0-9a-f]{40}', value['qaCommit']), 'Exact same CI run/attempt and QA commit required')
    return value


def check_qa_segments(c, reports):
    require(set(reports) == {'tour', 'free-compat'}, 'Both distinct QA reports are required')
    for segment, report in reports.items():
        require(report.get('schemaVersion') == 2 and report.get('segment') == segment and report.get('status') == 'PASS' and report.get('syntheticFixture') is False, 'Both genuine complete segment PASS reports are required')
        require(report['sourceIdentity'] == source_identity(c) and report['runIdentity'] == run_identity(), 'Cross-segment source/main/QA/run identity mismatch')
        deadline = check_deadline(segment, current=segment == 'free-compat')
        require(all(report[k] == deadline[k] for k in ('startedAtMs', 'expiresAtMs', 'totalBudgetMs')), 'Report belongs to another segment deadline')
        completed = report['completedAtMs']
        require(isinstance(completed, (int, float)) and not isinstance(completed, bool) and math.isfinite(completed) and deadline['startedAtMs'] <= completed <= time.time() * 1000 and completed < deadline['expiresAtMs'], 'QA segment completed outside its own 450-second deadline')
    require(reports['tour']['completedAtMs'] < reports['free-compat']['startedAtMs'], 'Tour must complete before independent free/compat starts')


def png_bytes(path, record):
    p = pathlib.Path(path)
    require(p.is_file() and not p.is_symlink(), 'Missing/linked PNG')
    b = p.read_bytes()
    validate_bytes(b, record, str(p))
    require(len(b) > 32 and b[:8] == b'\x89PNG\r\n\x1a\n' and b[12:16] == b'IHDR', 'Invalid PNG')
    w, h = struct.unpack('>II', b[16:24])
    require((w, h) == (1120, 712), 'Original 1120x712 canvas PNG required')
    return b, w, h


def expected_entry(c, identity, old_snapshot):
    require(False, 'World pointer promotion is forbidden for this independent candidate')


def gallery_records(c):
    receipt = read_json('.surface-finalized.json')
    records = receipt['galleryFiles']
    require(len(records) == len({f['path'] for f in records}) == 6, 'Exactly six new evidence files required')
    base = c['candidatePath'] + '/'
    prefix = base + 'assets/current-scene/' + c['sourceHashAggregate'] + '/'
    static = {base + 'current-scene.html', prefix + 'manifest.json', prefix + 'actual-navigation-frames.jsonl'}
    require(static <= {f['path'] for f in records}, 'Evidence file paths changed')
    actual = set()
    for f in records:
        safe_name(f['path'])
        if f['path'] in static:
            continue
        require(f['path'].startswith(prefix), 'Evidence escaped candidate directory')
        suffix = '-' + f['sha256'][:16] + '.png'
        require(f['path'].endswith(suffix), 'PNG content-address mismatch')
        actual.add(f['path'][len(prefix):-len(suffix)])
    require(actual == set(c['frames']), 'Tour frame allowlist mismatch')
    return receipt, records

