import assert from 'node:assert/strict';
export const FRAME_COLUMNS=['rafMs','sequence','phase','mode','paused','elapsed','x','y','z','yaw','pitch','speed','heldMask','region','hidden'];
export const KEY_BITS={KeyW:1,KeyS:2,KeyA:4,KeyD:8,KeyQ:16,KeyE:32,ShiftLeft:64,ShiftRight:128,ArrowLeft:256,ArrowRight:512,ArrowUp:1024,ArrowDown:2048};
export const distance=(a,b)=>Math.hypot(...a.map((v,i)=>v-b[i]));
export const wrapped=v=>Math.atan2(Math.sin(v),Math.cos(v));
// A free tick normalizes the tour's atan2 heading, which can round the same angle.
export function assertEquivalentYaw(actual,expected){assert(Number.isFinite(actual)&&Number.isFinite(expected),'Yaw must be finite');assert(Math.abs(wrapped(actual-expected))<=1e-10,'Takeover changed yaw beyond circular rounding tolerance');}
export function deadlineRemaining(processExpiresAtMs,stageExpiresAtMs,nowMs,capMs=Infinity){assert([processExpiresAtMs,stageExpiresAtMs,nowMs].every(Number.isFinite),'Absolute deadlines must be finite');assert(stageExpiresAtMs<=processExpiresAtMs,'Stage cannot extend process deadline');assert(capMs>0,'Operation cap must be positive');const remaining=Math.min(processExpiresAtMs,stageExpiresAtMs)-nowMs;assert(remaining>0,'Shared absolute deadline exhausted');return Math.min(remaining,capMs);}
export function analyticTour(elapsed,stops,resolvePosition=p=>p){
 const duration=72,legSeconds=duration/(stops.length-1),u=Math.max(0,Math.min(duration,elapsed))/legSeconds,i=Math.min(stops.length-2,Math.floor(u)),f=u-i,s=f*f*(3-2*f),a=stops[i],b=stops[i+1];
 const position=resolvePosition(a.position.map((v,j)=>v+(b.position[j]-v)*s)),target=a.target.map((v,j)=>v+(b.target[j]-v)*s),d=target.map((v,j)=>v-position[j]);
 return{position,yaw:Math.atan2(d[0],-d[2]),pitch:Math.max(-1.1,Math.min(1.1,Math.atan2(d[1],Math.hypot(d[0],d[2])))),analyticSpeed:distance(a.position,b.position)*6*f*(1-f)/legSeconds,globalMaxSpeed:Math.max(...stops.slice(1).map((b,i)=>distance(stops[i].position,b.position)))*1.5/legSeconds};
}
export function validateTimeline(rows,{segment,stops,resolvePosition=p=>p}={}){
 assert(['tour','free-compat'].includes(segment),'Explicit independent timeline segment required');const allowed=segment==='tour'?[1,4,5,9,8]:[1,2,3,6,7,8];
 assert(rows.length>3,'Actual callback samples required');let freeSteps=0,normalMovedSteps=0,boostedMovedSteps=0,tourSteps=0,maxFreeStep=0,maxFreeSpeed=0,maxTourStep=0,maxTourSpeed=0,maxAnalyticError=0,activeTourSeconds=0;const regions=new Set();
 for(let i=0;i<rows.length;i++){
  const r=rows[i];assert(r.length===FRAME_COLUMNS.length&&r.every(Number.isFinite),'Compact numeric RAF row');assert(allowed.includes(r[2]),'Timeline contains another segment phase');const p=r.slice(6,9),prev=rows[i-1];
  if(r[2]===5&&(r[3]===1||r[3]===2)){
   const expected=analyticTour(r[5],stops,resolvePosition),error=distance(p,expected.position);maxAnalyticError=Math.max(maxAnalyticError,error);assert(error<1e-5,'Actual tour deviates from frozen analytic path');assert(Math.abs(wrapped(r[9]-expected.yaw))<1e-5&&Math.abs(r[10]-expected.pitch)<1e-5,'Tour look direction differs from path');regions.add(r[13]);
  }
  if(!prev)continue;const dt=(r[0]-prev[0])/1000;assert(dt>0,'RAF timestamps strictly increase');const step=distance(p,prev.slice(6,9));assert(r[1]>=prev[1],'Actual render receipts reversed');if(r[2]===prev[2]&&[2,3,5].includes(r[2])&&step>1e-7)assert(r[1]>prev[1],'Camera moved without an actual rendered-frame receipt');
  // Every same-phase free callback is bounded, including trusted key changes.
  // At a change, use the larger of the adjacent actually held speed modifiers.
  if(r[2]===prev[2]&&[2,3].includes(r[2])&&r[3]===0&&prev[3]===0){
   if(r[4]&&prev[4])assert(step<1e-8,'Paused free state moved');const speed=((r[12]|prev[12])&192)?12.6:7,bound=speed*Math.min(.05,dt);assert(step<=bound+1e-5,'Free displacement exceeds real delta / safety cap');assert(r[11]<=speed+1e-5,'Reported free speed exceeds configured speed');freeSteps++;maxFreeStep=Math.max(maxFreeStep,step);maxFreeSpeed=Math.max(maxFreeSpeed,dt?step/dt:0);
   if(r[2]===2){assert([0,1,64,65].includes(r[12]),'Unexpected input during straight crossing');if(r[12]===1&&prev[12]===1&&step>1e-7)normalMovedSteps++;if(r[12]===65&&prev[12]===65&&step>1e-7)boostedMovedSteps++;assert(r[8]<=prev[8]+1e-7,'W crossing reversed');assert(Math.abs(r[6]-4)<1e-5&&Math.abs(r[7]-5)<1e-5,'Default straight swim leaves level spawn lane');}
  }
  if(r[2]===5&&prev[2]===5&&prev[3]===1&&[1,2].includes(r[3])){
   const elapsedDelta=r[5]-prev[5];assert(elapsedDelta>=-1e-8,'Tour time reversed');assert(elapsedDelta<=dt+.01,'Tour elapsed exceeds actual callback delta');
   if(prev[4]&&r[4])assert(elapsedDelta===0&&step<1e-8,'Paused tour moved');
   if(elapsedDelta>0){const bound=analyticTour(r[5],stops,resolvePosition).globalMaxSpeed;assert(step<=bound*elapsedDelta+1e-5,'Tour step exceeds analytic derivative bound');tourSteps++;activeTourSeconds+=elapsedDelta;maxTourStep=Math.max(maxTourStep,step);maxTourSpeed=Math.max(maxTourSpeed,step/elapsedDelta);}
  }
 }
 const crossing=rows.filter(r=>r[2]===2),tour=rows.filter(r=>r[2]===5);
 if(segment==='free-compat'){assert(crossing.length>3,'Native crossing samples missing');assert.deepEqual(crossing[0].slice(6,9),[4,5,10],'Crossing must begin at actual default spawn');assert(crossing.some(r=>r[8]<-60),'Native W+Shift never crossed z=-60');assert(normalMovedSteps>0&&boostedMovedSteps>0,'Both ordinary W and native W+Shift progression required');}
 if(segment==='tour'){assert(tour.some(r=>r[3]===2&&r[5]===72),'No real completed 72-second tour');assert.deepEqual([...regions].sort(),[0,1,2],'Tour did not visit all three regions');assert(activeTourSeconds>70,'Tour lacks complete sampled progression');}
 return{segment,rows:rows.length,freeSteps,normalMovedSteps,boostedMovedSteps,tourSteps,maxFreeStep,maxFreeSpeed,maxTourStep,maxTourSpeed,maxAnalyticError,activeTourSeconds,regions:[...regions].sort(),continuousFreeCrossing:segment==='free-compat',completeTour:segment==='tour'};
}
export function assertDirectional(before,after,vector,{minimum=.08,tolerance=.03}={}){const delta=after.map((v,i)=>v-before[i]),projection=delta.reduce((s,v,i)=>s+v*vector[i],0),orthogonal=Math.sqrt(Math.max(0,distance(before,after)**2-projection**2));assert(projection>minimum,'Native movement did not follow requested direction');assert(orthogonal<tolerance,'Native movement drifted outside requested direction');return{before,after,vector,projection,orthogonal};}
export function validateCollisionObservation(value,{requireLateLoad=false,requireFull=true}={}){
 assert(value?.current&&value.samples.length>0,'Live collision observation required');
 for(const s of [...value.samples,value.current]){const r=s.reported,a=s.actual;assert.equal(r.source,'live-world-obstacles-plus-scan-anchors');assert.equal(r.worldCount,a.worldCount);assert.equal(r.scanCount,a.scanCount);assert.equal(r.total,a.worldCount+a.scanCount);assert.deepEqual(r.worldNames,a.worldNames);assert.equal(a.boxes.length,a.worldCount);for(const b of a.boxes){assert(b.min.length===3&&b.max.length===3&&[...b.min,...b.max].every(Number.isFinite));assert(b.min.every((v,i)=>v<=b.max[i]));}}
 const current=value.current.reported,names=current.worldNames,late=value.samples.some(s=>s.loading.layeredRidges!=='ready'&&s.reported.worldCount<54),earlyAnchor=value.samples.some(s=>s.reported.scanCount===1);
 if(requireFull){assert.equal(current.worldCount,54);assert.equal(current.scanCount,2);assert.equal(current.total,56);assert.equal(names.filter(n=>n.startsWith('Ridge_')).length,3);assert.equal(names.filter(n=>n.startsWith('RearConnected_')).length,6);assert.equal(names.filter(n=>n==='Local_Grounded_Scan_Derived_Shoulder').length,1);}
 if(requireLateLoad){assert(late,'Natural pre-layer readiness was not observed');assert(earlyAnchor,'Natural C1-only scan anchor stage was not observed');}
 return{matchingLiveWorld:true,lateLoadObserved:late,c1BeforeC4Observed:earlyAnchor,worldCount:current.worldCount,scanCount:current.scanCount,total:current.total,source:current.source};
}
export function validateCollisionToggle(toggle){
 for(const key of['before','off','on'])validateCollisionObservation({samples:[toggle[key]],current:toggle[key]},{requireFull:key!=='off'});
 const before=toggle.before.reported.worldNames,off=toggle.off.reported.worldNames,on=toggle.on.reported.worldNames;
 assert.notDeepEqual(off.slice().sort(),before.slice().sort(),'Native layer OFF did not change real obstacle membership');
 assert(!off.some(n=>n.startsWith('Ridge_')||n.startsWith('RearConnected_')||n==='Local_Grounded_Scan_Derived_Shoulder'),'Disabled large-rock proxy still registered');
 assert.deepEqual(on.slice().sort(),before.slice().sort(),'Native layer ON did not restore exact real membership');
 return{lateRegistrationVerified:true,evidence:'native-layer-off-on',removedAndRestored:true,removedNames:before.filter(n=>!off.includes(n)),addedNames:off.filter(n=>!before.includes(n))};
}
export function assertTourCaptureCoverage(name,bindings){if(name==='tour-grass-bay'||name==='tour-completed'){assert(Array.isArray(bindings)&&bindings.length>0,name+' requires an actually submitted new-world material');assert(bindings.some(b=>b.materialType==='MeshStandardMaterial'&&b.standardPBR&&b.waterVertex&&b.waterFragment),name+' requires at least one actually submitted PBR world material');}}
const assertDraw=b=>assert(b.draws>0&&b.linked&&b.compiled&&b.glError===0,'Actual binding failed draw/link/compile/GL checks');
export function validateExplorationBinding(b){assertDraw(b);assert.equal(b.materialType,'MeshStandardMaterial');assert(b.standardPBR&&b.waterVertex&&b.waterFragment,'Actually submitted PBR material failed water/PBR checks');assert(b.continuousWater&&b.deepTransmission,'Enriched continuous water/transmission shader absent');const u=b.oceanUniforms;assert(u?.modeActive&&u.timeActive&&u.causticsActive&&u.mode===1&&Number.isFinite(u.time)&&Number.isInteger(u.caustics)&&u.caustics>=0,'Actual ocean uniform binding invalid');}
export function validateOceanBindings(bindings){assert(Array.isArray(bindings)&&bindings.some(b=>b.name==='Synthetic_Water_Volume'),'Actual water envelope submission missing');for(const b of bindings){assertDraw(b);if(b.name==='Synthetic_Water_Volume'){assert.equal(b.materialType,'ShaderMaterial');assert.deepEqual(b.materialProperties,{transparent:false,opacity:1,side:1,depthWrite:false});assert(b.continuousWater&&b.toneMapping&&b.colorSpace,'Continuous envelope shader absent');}else if(b.name==='Synthetic_Receding_Sand'){validateExplorationBinding(b);assert(b.sandEdge,'Actual original sand edge shader absent');}else if(b.name==='Synthetic_Overhead_Surface'){assert.equal(b.materialType,'ShaderMaterial');assert.deepEqual(b.materialProperties,{transparent:true,opacity:.6,side:2,depthWrite:false});assert(b.surfaceEdgeFade&&b.toneMapping&&b.colorSpace,'Actual original surface edge fade absent');}else assert.fail('Unexpected ocean binding '+b.name);}}

export function validateCompletedSegment(report,segment){
 assert(report&&report.schemaVersion===2&&report.segment===segment&&report.status==='PASS'&&report.syntheticFixture===false,'Missing/failed required segment '+segment);assert.equal(report.totalBudgetMs,450000);assert.equal(report.expiresAtMs-report.startedAtMs,450000);assert(Number.isFinite(report.completedAtMs)&&report.completedAtMs>=report.startedAtMs&&report.completedAtMs<report.expiresAtMs,'Segment exceeded its own deadline');assert.deepEqual(report.errors,[]);assert.deepEqual(report.failures,[]);return report;
}
export function validateSegmentPair(tour,free){validateCompletedSegment(tour,'tour');validateCompletedSegment(free,'free-compat');assert.deepEqual(tour.sourceIdentity,free.sourceIdentity,'Segments use different sources/main/QA checkout');assert.deepEqual(tour.runIdentity,free.runIdentity,'Segments belong to different CI attempts');assert(tour.completedAtMs<=free.startedAtMs,'Segments must run sequentially');return true;}
