"""Restore the exact latest publication, protect 2127 bytesets, add 150 sources."""
from surface_common import *


def stage(c):
    require(not (DIST / c['candidatePath']).exists(), 'Candidate destination exists')
    require(not any(pathlib.Path(n).exists() for n in ('.surface-protected.json', '.surface-baseline.json', '.surface-build.json')), 'Stage already attempted')
    before = inventory(DIST)
    protected = assembly_protection(c)
    staged = {c['basePath'] + '/' + f['path']: f['sha256'] for f in c['baseSourceFiles']}
    staged.update({f['path']: f['sha256'] for f in c['stagedEntryFiles']})
    require(not set(staged) & set(protected) and before == dict(protected, **staged) and len(before) == c['oldAssemblyFiles'], 'Exact previous 2121-file staging output required')
    restore = snapshot(c)
    delta = checked_archive(INPUTS / c['codeArchive']['path'], c['codeArchive'], {f['path']: f for f in c['changes']})
    require(all(n in c['mutableEntryPaths'] or n not in before for n in restore), 'Snapshot collision outside three world products')
    baseline = dict(before, **{n: sha(b) for n, b in restore.items()})
    require(baseline == baseline_hashes(c), 'Snapshot cannot reproduce exact latest 2127-file publication')
    candidate = {n: (DIST / c['basePath'] / n).read_bytes() for n in c['baseSourceHashes']}
    candidate.update(delta)
    require({n: sha(b) for n, b in candidate.items()} == c['sourceHashes'], 'Candidate source bytes mismatch')
    # All archive, source, collision and restoration checks precede public writes.
    for n, b in restore.items():
        p = DIST / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
    require(inventory(DIST) == baseline, 'Published baseline restoration failed')
    save_json('.surface-baseline.json', baseline)
    protected = dict(baseline)
    require(len(protected) == c['protectedFiles'], 'Expected 2127 protected old files')
    save_json('.surface-protected.json', protected)
    for n, b in candidate.items():
        p = DIST / c['candidatePath'] / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
    save_json('.surface-build.json', {'schemaVersion': 1, 'state': 'STAGED_OLD_WORLD_POINTER_UNCHANGED', 'sourceHashAggregate': c['sourceHashAggregate'], 'sourceFiles': 150, 'oldSiteFiles': 2127, 'protectedFiles': 2127})
    check_sources(c)
    protected, current = check_old(c)
    require(set(current) - set(protected) == candidate_sources(c) and len(current) == c['stagedSiteFiles'], 'Unexpected stage output')
    print('EXPLORATION_STAGED', json.dumps({'oldSiteFiles': 2127, 'protectedFiles': 2127, 'candidateSourceFiles': 150, 'unchangedSources': 146, 'sourceHashAggregate': c['sourceHashAggregate']}))


if __name__ == '__main__':
    stage(contract())
