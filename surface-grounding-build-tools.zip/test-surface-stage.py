"""Tiny synthetic bookkeeping fixtures. Never browser, GPU or visual evidence."""
from pathlib import Path
import contextlib
import copy
import importlib.util
import io
import json
import os
import struct
import sys
import tempfile
import time
import zipfile
import zlib

T = Path(__file__).resolve().parent
P = T.parent
sys.path.insert(0, str(T))
import surface_common as common


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, T / filename)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


stage = module('stage', 'stage-surface.py')
final = module('finalizer', 'finalize-surface.py')
verify = module('verify', 'verify-surface-preserved.py')
checks = []


def record(n, b):
    return {'path': n, 'bytes': len(b), 'sha256': common.sha(b)}


def write(n, b):
    p = Path(n)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)


def quiet(fn, *args, **kwargs):
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*args, **kwargs)


def rejects(name, fn):
    try:
        quiet(fn)
    except (ValueError, KeyError, AssertionError, FileNotFoundError):
        checks.append(name)
        return
    raise AssertionError('Did not reject: ' + name)


def png():
    def chunk(n, b):
        return struct.pack('>I', len(b)) + n + b + struct.pack('>I', zlib.crc32(n + b))
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1120, 712, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress((b'\0' + b'\x20\x50\x60' * 1120) * 712)) + chunk(b'IEND', b'')


def fixture(c):
    for i in range(79):
        write('dist/root-' + str(i), str(i).encode())
    common.save_json('.root-site-hashes.json', common.inventory('dist'))
    for i in range(1888):
        write('dist/preview/older/' + str(i), str(i).encode())
    for n in ('entry-desktop-bbb983341a60709f.png', 'entry-narrow-9bb3292ddabfbf21.png'):
        write('dist/preview/world/evidence/' + n, ('historical:' + n).encode())
    protected = common.inventory('dist')
    common.save_json('.fixture-upstream-protected.json', protected)
    # Upstream immutable-chain authentication is not reimplemented in this tiny
    # fixture. Its output is simulated; our exact inventory checks remain active.
    def upstream(_):
        result = common.read_json('.fixture-upstream-protected.json')
        common.require(len(result) == 1969, 'Fixture upstream count')
        return result
    common.assembly_protection = stage.assembly_protection = upstream
    base = {n: ('old:' + n).encode() for n in c['baseSourceHashes']}
    candidate = dict(base)
    candidate.update({f['path']: ('new:' + f['path']).encode() for f in c['changes']})
    c['baseSourceFiles'] = [record(n, b) for n, b in sorted(base.items())]
    c['baseSourceHashes'] = {f['path']: f['sha256'] for f in c['baseSourceFiles']}
    c['sourceFiles'] = [record(n, b) for n, b in sorted(candidate.items())]
    c['sourceHashes'] = {f['path']: f['sha256'] for f in c['sourceFiles']}
    c['sourceHashAggregate'] = common.sha(''.join(n + '\0' + c['sourceHashes'][n] + '\n' for n in sorted(candidate)).encode())
    for n, b in base.items():
        write('dist/' + c['basePath'] + '/' + n, b)
    for f in c['stagedEntryFiles']:
        b = ('staged:' + f['path']).encode()
        f.update(record(f['path'], b))
        write('dist/' + f['path'], b)
    with zipfile.ZipFile(P / c['snapshotArchive']['path']) as z:
        saved = {f['path']: z.read(f['path']) if f['path'].startswith(c['entryPath'] + '/') else ('snapshot:' + f['path']).encode() for f in c['snapshotFiles']}
    c['snapshotFiles'] = [record(n, b) for n, b in sorted(saved.items())]
    c['oldPublicFiles'] = [dict(f, path=c['basePath'] + '/' + f['path']) for f in c['baseSourceFiles']] + c['snapshotFiles']
    changed = {f['path']: candidate[f['path']] for f in c['changes']}
    c['changes'] = [dict(record(n, b), baseSha256=c['baseSourceHashes'].get(n)) for n, b in changed.items()]
    for key, files in (('snapshotArchive', saved), ('codeArchive', changed)):
        p = Path('.surface-inputs') / c[key]['path']
        p.parent.mkdir(exist_ok=True)
        with zipfile.ZipFile(p, 'w') as z:
            for n, b in files.items():
                z.writestr(n, b)
        c[key] = record(p.name, p.read_bytes())
    return c


def main():
    actual = common.contract()
    checks.append('real150-source-contract-and-four-file-delta-validated')
    standard = {'materialType': 'MeshStandardMaterial', 'draws': 1, 'glError': 0, 'linked': True, 'compiled': True, 'meshNames': ['Extended_Reef_Rock'], 'materialUUID': 'fixture-other', 'surface': {'kind': 'other'}, 'standardPBR': True, 'waterVertex': True, 'waterFragment': True, 'continuousWater': True, 'deepTransmission': True, 'oceanUniforms': {'modeActive': True, 'timeActive': True, 'causticsActive': True, 'mode': 1, 'time': 12.3, 'caustics': 1}}
    final.validate_material_binding(standard)
    final.validate_material_bindings([standard], require_pbr=True)
    checks.append('enriched-all-Standard-PBR-water-contract-passes')
    rejects('empty-middle-or-final-stage-rejected', lambda: final.validate_material_bindings([], require_pbr=True))
    for label, mutate in [('Basic-on-enriched-object', lambda b: b.__setitem__('materialType', 'MeshBasicMaterial')),
                          ('deleted-overhead-object', lambda b: b.__setitem__('meshNames', ['Extended_Overhead_Water'])),
                          ('shader-not-compiled', lambda b: b.__setitem__('compiled', False)),
                          ('shader-not-linked', lambda b: b.__setitem__('linked', False)),
                          ('shader-GL-error', lambda b: b.__setitem__('glError', 1282)),
                          ('Standard-water-vertex-missing', lambda b: b.__setitem__('waterVertex', False)),
                          ('Standard-water-fragment-missing', lambda b: b.__setitem__('waterFragment', False)),
                          ('Standard-PBR-missing', lambda b: b.__setitem__('standardPBR', False)),
                          ('continuous-water-missing', lambda b: b.__setitem__('continuousWater', False)),
                          ('deep-transmission-missing', lambda b: b.__setitem__('deepTransmission', False)),
                          ('ocean-uniform-inactive', lambda b: b['oceanUniforms'].__setitem__('modeActive', False)),
                          ('ocean-mode-disabled', lambda b: b['oceanUniforms'].__setitem__('mode', 0))]:
        binding = copy.deepcopy(standard)
        mutate(binding)
        rejects(label + '-rejected', lambda: final.validate_material_binding(binding))
    volume = {'name': 'Synthetic_Water_Volume', 'materialType': 'ShaderMaterial', 'draws': 1, 'glError': 0, 'linked': True, 'compiled': True, 'materialProperties': {'transparent': False, 'opacity': 1, 'side': 1, 'depthWrite': False}, 'continuousWater': True, 'toneMapping': True, 'colorSpace': True}
    sand = dict(standard, name='Synthetic_Receding_Sand', sandEdge=True)
    surface = dict(volume, name='Synthetic_Overhead_Surface', materialProperties={'transparent': True, 'opacity': .6, 'side': 2, 'depthWrite': False}, surfaceEdgeFade=True)
    final.validate_ocean_bindings([volume])
    final.validate_ocean_bindings([volume, sand, surface])
    checks.append('actual-volume-required-with-frustum-optional-sand-and-surface')
    rejects('missing-ocean-volume-rejected', lambda: final.validate_ocean_bindings([sand]))
    for label, source, mutate in [('water-volume-side', volume, lambda b: b['materialProperties'].__setitem__('side', 2)),
                                  ('water-color-space', volume, lambda b: b.__setitem__('colorSpace', False)),
                                  ('water-tone-mapping', volume, lambda b: b.__setitem__('toneMapping', False)),
                                  ('water-continuity', volume, lambda b: b.__setitem__('continuousWater', False)),
                                  ('sand-edge', sand, lambda b: b.__setitem__('sandEdge', False)),
                                  ('surface-edge', surface, lambda b: b.__setitem__('surfaceEdgeFade', False)),
                                  ('unknown-ocean-object', volume, lambda b: b.__setitem__('name', 'Unexpected'))]:
        binding = copy.deepcopy(source)
        mutate(binding)
        rejects(label + '-rejected', lambda: final.validate_ocean_bindings([volume, binding]))
    def collision_snapshot(names, scans=2, layered='ready'):
        return {'reported': {'source': 'live-world-obstacles-plus-scan-anchors', 'worldCount': len(names), 'scanCount': scans, 'total': len(names) + scans, 'worldNames': names[:]},
                'actual': {'worldCount': len(names), 'scanCount': scans, 'worldNames': names[:], 'boxes': [{'name': n, 'min': [0, 0, 0], 'max': [1, 1, 1]} for n in names]},
                'loading': {'layeredRidges': layered}}
    names = ['Base_' + str(i) for i in range(44)]
    late_names = ['Ridge_' + str(i) for i in range(3)] + ['RearConnected_' + str(i) for i in range(6)] + ['Local_Grounded_Scan_Derived_Shoulder']
    ready = collision_snapshot(names + late_names)
    observation = {'current': ready, 'samples': [collision_snapshot(names[:40], 1, 'loading'), ready]}
    collisions = {'ready': observation, 'field': copy.deepcopy(observation), 'restored': copy.deepcopy(observation),
        'readyValidation': {'matchingLiveWorld': True, 'lateLoadObserved': True, 'c1BeforeC4Observed': True, 'startupHistory': 'OBSERVED', 'worldCount': 54, 'scanCount': 2, 'total': 56, 'source': 'live-world-obstacles-plus-scan-anchors'},
        'registrationValidation': {'lateRegistrationVerified': True, 'evidence': 'native-layer-off-on', 'removedAndRestored': True, 'removedNames': late_names, 'addedNames': []},
        'toggle': {'before': ready, 'off': collision_snapshot(names), 'on': ready, 'removedNames': late_names, 'addedNames': [], 'removedAndRestored': True}}
    final.validate_collisions(collisions)
    checks.append('synthetic-live-collision-schema-arithmetic-only')
    missed_startup = copy.deepcopy(collisions)
    missed_startup['ready']['samples'] = [missed_startup['ready']['current']]
    missed_startup['readyValidation'].update(lateLoadObserved=False, c1BeforeC4Observed=False, startupHistory='NOT_OBSERVED_NO_ARTIFICIAL_DELAY')
    final.validate_collisions(missed_startup)
    checks.append('unobserved-startup-allowed-with-native-registration-proof')
    for label, mutate in [('stale-live-count', lambda v: v['ready']['current']['reported'].__setitem__('worldCount', 40)),
                          ('falsely-claimed-startup-observation', lambda v: v['ready'].__setitem__('samples', [v['ready']['current']])),
                          ('layer-OFF-retains-proxies', lambda v: v['toggle'].__setitem__('off', v['toggle']['before'])),
                          ('missing-native-registration-proof', lambda v: v['registrationValidation'].__setitem__('lateRegistrationVerified', False)),
                          ('nonfinite-collision-box', lambda v: v['toggle']['on']['actual']['boxes'][0]['min'].__setitem__(0, float('nan')))]:
        altered = copy.deepcopy(collisions)
        mutate(altered)
        rejects(label + '-rejected', lambda: final.validate_collisions(altered))
    compat = {'rawFreeReturn': {'positionPreserved': True}, 'rawViews': [{'patch': 'C1'}, {'patch': 'C4'}],
        'fieldFrame': {'oceanBindings': [volume], 'explorationBindings': [standard], 'field': {'displayTriangles': 4000000}, 'fieldBinding': {'instances': 1000000, 'linked': True, 'compiled': True, 'glError': 0}, 'receipt': {'sequence': 2}, 'previousSequence': 1, 'graphics': {'readPixelsInRenderObserver': True, 'pixelError': 0, 'sampleColors': 2, 'render': {'calls': 1}}},
        'restoredBudget': {'exploration': {'disposed': False}}, 'pausedIdle': {'unchanged': True}, 'pauseResume': {'ambientAdvanced': True},
        'narrow': {'width': 390, 'height': 740, 'overflow': False, 'disclosureClosedByTouch': True, 'rectangles': [dict(id=n, x=1, y=1, width=20, height=20, hit=True, disclosurePhase=phase) for phase, names in [('closed', ['scanCanvas', 'startTour', 'pauseNavigation', 'hudMoreSummary', 'swimForward']), ('open', ['exploreRoute', 'resetExhibit', 'pauseAmbient', 'swimBack', 'strafeLeft', 'strafeRight', 'turnLeft', 'turnRight', 'rise', 'descend', 'closeHudMore'])] for n in names]},
        'reduced': {'emulated': True, 'noAutomaticMovement': True, 'next': {'elapsed': 14.4}}}
    final.validate_compatibility_payload(compat)
    for key in ('fieldFrame', 'rawViews', 'rawFreeReturn', 'narrow', 'reduced'):
        altered = copy.deepcopy(compat)
        del altered[key]
        rejects('segment-B-missing-' + key + '-rejected', lambda: final.validate_compatibility_payload(altered))
    for label, mutate in [('missing-secondary-HUD-control', lambda v: v['narrow']['rectangles'].pop()),
                          ('HUD-wrong-disclosure-phase', lambda v: v['narrow']['rectangles'][-1].__setitem__('disclosurePhase', 'closed')),
                          ('HUD-close-offscreen', lambda v: v['narrow']['rectangles'][-1].__setitem__('y', 800)),
                          ('HUD-touch-close-unproven', lambda v: v['narrow'].__setitem__('disclosureClosedByTouch', False)),
                          ('field-ocean-volume-missing', lambda v: v['fieldFrame'].__setitem__('oceanBindings', []))]:
        altered = copy.deepcopy(compat)
        mutate(altered)
        rejects(label + '-rejected', lambda: final.validate_compatibility_payload(altered))
    surface_contract = dict(final.SURFACE_CONTRACT, contact=final.SURFACE_CONTACT)
    final.validate_surface_contract(surface_contract)
    protection = {'issues': [], 'borrowedDisposals': 0, 'borrowedTextureCount': 2, 'sourceMaterialCount': 2, 'textureFiles': ['assets/reef-texture-2.png', 'assets/reef-texture-3.png'], 'sameSourceReferences': True, 'textureStateUnchanged': True}
    final.validate_surface_protection(protection)
    rock = dict(copy.deepcopy(standard), materialUUID='fixture-rock', surface={'kind': 'rock', 'cacheKey': 'exploration-strata-ocean-surface-grounding-v1-true', 'unchangedWater': True, 'rockDetailFragment': True})
    for key in ('normal', 'roughness'):
        rock['surface'][key] = {'active': True, 'unit': 1 if key == 'normal' else 2, 'borrowedReferenceIdentical': True, 'uploaded': True, 'boundToExpectedMap': True, 'textureUUID': key, 'expectedTextureUUID': key}
    grass = dict(copy.deepcopy(standard), materialUUID='fixture-grass', surface={'kind': 'grass', 'cacheKey': 'exploration-curved-canopy-ocean-surface-grounding-v1', 'unchangedWater': True, 'grassSwayNormal': True, 'grassRootFade': True})
    final.validate_material_binding(rock)
    final.validate_material_binding(grass)
    frames = [{'explorationBindings': [rock]}, {'explorationBindings': [grass]}]
    coverage = {'kinds': ['rock', 'grass'], 'materialUUIDs': ['fixture-rock', 'fixture-grass'], 'onlySubmittedMeshesVerified': True}
    final.validate_surface_coverage(frames, coverage)
    checks.append('synthetic-surface-contract-borrowed-samplers-grass-normal-coverage-schema-only')
    for key in ('normal', 'roughness'):
        for flag in ('active', 'borrowedReferenceIdentical', 'uploaded', 'boundToExpectedMap'):
            broken = copy.deepcopy(rock)
            broken['surface'][key][flag] = False
            rejects(key + '-' + flag + '-rejected', lambda: final.validate_material_binding(broken))
    for label, mutate in [('wrong-texture', lambda b: b['surface']['normal'].__setitem__('textureUUID', 'wrong')),
                          ('bool-unit', lambda b: b['surface']['normal'].__setitem__('unit', True)),
                          ('negative-unit', lambda b: b['surface']['normal'].__setitem__('unit', -1)),
                          ('missing-fragment', lambda b: b['surface'].__setitem__('rockDetailFragment', False)),
                          ('water-hook-lost', lambda b: b['surface'].__setitem__('unchangedWater', False))]:
        broken = copy.deepcopy(rock); mutate(broken)
        rejects('rock-' + label + '-rejected', lambda: final.validate_material_binding(broken))
    for key in ('grassSwayNormal', 'grassRootFade'):
        broken = copy.deepcopy(grass); broken['surface'][key] = False
        rejects(key + '-rejected', lambda: final.validate_material_binding(broken))
    for key in ('sameSourceReferences', 'textureStateUnchanged'):
        broken = copy.deepcopy(protection); broken[key] = False
        rejects(key + '-rejected', lambda: final.validate_surface_protection(broken))
    for key in ('newDownloads', 'newTextureCopies', 'additionalPasses'):
        broken = copy.deepcopy(surface_contract); broken[key] = 1
        rejects(key + '-rejected', lambda: final.validate_surface_contract(broken))
    rejects('missing-surface-contract-rejected', lambda: final.validate_surface_contract({}))
    rejects('missing-grass-tour-coverage-rejected', lambda: final.validate_surface_coverage(frames[:1], coverage))
    rejects('forged-surface-GPU-coverage-rejected', lambda: final.validate_surface_coverage(frames, dict(coverage, materialUUIDs=['fixture-rock'])))
    old_cwd = Path.cwd()
    old_env = {k: os.environ.get(k) for k in ('EXPLORATION_SOURCE_COMMIT', 'GITHUB_SHA', 'EXPLORATION_OUTPUT', 'GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT')}
    os.environ.update(EXPLORATION_SOURCE_COMMIT='1' * 40, GITHUB_SHA='2' * 40, EXPLORATION_OUTPUT='exploration-qa', GITHUB_RUN_ID='12345', GITHUB_RUN_ATTEMPT='1')
    try:
        with tempfile.TemporaryDirectory(prefix='exploration-tinyfixture-', dir=P) as tmp:
            os.chdir(tmp)
            c = fixture(copy.deepcopy(actual))
            before = common.inventory('dist')
            for key in ('codeArchive', 'snapshotArchive'):
                p = Path('.surface-inputs') / c[key]['path']
                data = p.read_bytes()
                p.write_bytes(data + b'bad')
                rejects(key + '-corrupt-before-public-writes', lambda: stage.stage(c))
                assert common.inventory('dist') == before and not Path('.surface-protected.json').exists()
                p.write_bytes(data)
            rejects('explicit-world-update-rejected-before-deadline-or-public-writes', lambda: final.finalize(c, True))
            quiet(stage.stage, c)
            quiet(verify.verify, c, True)
            assert len(common.inventory('dist')) == 2277 and len(common.read_json('.surface-protected.json')) == 2127
            old_entry = {n: (Path('dist') / c['entryPath'] / n).read_bytes() for n in common.ENTRY_NAMES}
            checks.append('tiny2121-to-restored2127-plus150-staged2277-and2127-protected')
            for label, path in [('root', Path('dist/root-0')), ('old-preview', Path('dist/preview/older/0')),
                                ('historical-entry-PNG', Path('dist/preview/world/evidence/entry-desktop-bbb983341a60709f.png')),
                                ('old-R6-source', Path('dist') / c['basePath'] / 'scan-exhibit.js'),
                                ('old-R6-gallery', Path('dist') / c['basePath'] / 'current-scene.html'),
                                ('candidate-source', Path('dist') / c['candidatePath'] / 'scan-exhibit.js'),
                                ('world-before-QA', Path('dist') / c['entryPath'] / 'index.html'),
                                ('unexpected-addition', Path('dist/preview/unexpected.txt'))]:
                data = path.read_bytes() if path.exists() else None
                path.write_bytes(b'bad')
                rejects(label + '-mutation-rejected', lambda: verify.verify(c, True))
                path.unlink() if data is None else path.write_bytes(data)
            p = Path('.surface-protected.json')
            data = p.read_bytes()
            d = json.loads(data)
            d.pop('root-0')
            common.save_json(p, d)
            rejects('protection-map-shrink-rejected', lambda: verify.verify(c, True))
            p.write_bytes(data)
            rejects('duplicate-stage-rejected', lambda: stage.stage(c))
            now = int(time.time() * 1000)
            deadline = {'startedAtMs': now - 5000, 'expiresAtMs': now - 5000 + 450000, 'totalBudgetMs': 450000}
            tour_deadline = {'startedAtMs': now - 600000, 'expiresAtMs': now - 150000, 'totalBudgetMs': 450000}
            common.save_json('.exploration-free-compat-deadline.json', deadline)
            common.save_json('.exploration-tour-deadline.json', tour_deadline)
            Path('exploration-qa').mkdir()
            Path('exploration-qa/tour').mkdir()
            Path('exploration-qa/free-compat').mkdir()
            # Synthetic numeric rows exercise arithmetic validation only.
            rows = [[i * 50, i, 2, 0, 0, 0, 4, 5, 10 - i * .35, 0, 0, 7, 1, 0, 0] for i in range(205)]
            rows += [[10300 + i * 1000, 205 + i, 5, 2 if i == 72 else 1, 1 if i == 72 else 0, i, 4, 5, 10 - i * 5, 0, 0, 5, 0, 0 if i < 26 else 1 if i < 51 else 2, 0] for i in range(73)]
            def timeline(value):
                b = b''.join((json.dumps(r) + '\n').encode() for r in value)
                write('exploration-qa/actual-navigation-frames.jsonl', b)
                return dict(record('actual-navigation-frames.jsonl', b), file='actual-navigation-frames.jsonl', rows=len(value))
            meta = timeline(rows)
            final.validate_timeline('exploration-qa/actual-navigation-frames.jsonl', meta)
            checks.append('synthetic-numeric-timeline-arithmetic-only')
            for label, mutate in [('nonfinite', lambda r: r[0].__setitem__(9, float('nan'))),
                                  ('nonmonotonic-RAF', lambda r: r[2].__setitem__(0, r[1][0])),
                                  ('free-teleport', lambda r: r[5].__setitem__(6, 100)),
                                  ('incomplete-tour', lambda r: r[-1].__setitem__(3, 1)),
                                  ('accelerated-tour-clock', lambda r: r[220].__setitem__(5, 40))]:
                altered = copy.deepcopy(rows)
                mutate(altered)
                meta = timeline(altered)
                rejects(label + '-timeline-rejected', lambda: final.validate_timeline('exploration-qa/actual-navigation-frames.jsonl', meta))
            timeline(rows)
            # Each process keeps its own RAF origin. Test A and B independently.
            a_rows = copy.deepcopy(rows[205:])
            a_bytes = b''.join((json.dumps(r) + '\n').encode() for r in a_rows)
            write('exploration-qa/tour/actual-navigation-frames.jsonl', a_bytes)
            a_record = dict(record('actual-navigation-frames.jsonl', a_bytes), file='actual-navigation-frames.jsonl', rows=len(a_rows), columns=final.FRAME_COLUMNS, segment='tour')
            final.validate_timeline('exploration-qa/tour/actual-navigation-frames.jsonl', a_record, 'tour')
            b_rows, z = [], 10
            for i in range(125):
                key = 1 if i < 5 else 65
                if i:
                    z -= .35 if key == 1 else .63
                b_rows.append([i * 50, i, 2, 0, 0, 0, 4, 5, z, 0, 0, 7 if key == 1 else 12.6, key, 0, 0])
            b_bytes = b''.join((json.dumps(r) + '\n').encode() for r in b_rows)
            write('exploration-qa/free-compat/free-navigation-frames.jsonl', b_bytes)
            b_record = dict(record('free-navigation-frames.jsonl', b_bytes), file='free-navigation-frames.jsonl', rows=len(b_rows), columns=final.FRAME_COLUMNS, segment='free-compat')
            final.validate_timeline('exploration-qa/free-compat/free-navigation-frames.jsonl', b_record, 'free-compat')
            checks.append('two-independent-RAF-origins-tour-and-native-W-Shift-validate')
            mixed = b_bytes + a_bytes
            write('exploration-qa/free-compat/mixed.jsonl', mixed)
            mixed_record = dict(record('free-navigation-frames.jsonl', mixed), file='free-navigation-frames.jsonl', rows=len(b_rows) + len(a_rows))
            rejects('mixed-two-process-RAF-timeline-rejected', lambda: final.validate_timeline('exploration-qa/free-compat/mixed.jsonl', mixed_record, 'free-compat'))
            frames = []
            for i, name in enumerate(c['frames']):
                b = png()
                write('exploration-qa/tour/' + name + '.png', b)
                frames.append(dict(record(name + '.png', b), name=name, file=name + '.png', route={'elapsed': [2, 35, 72][i]}))
            report = dict(tour_deadline, schemaVersion=2, segment='tour', status='FAIL', syntheticFixture=True, sourceIdentity=common.source_identity(c), runIdentity=common.run_identity(), completedAtMs=now - 200000, frames=frames, errors=[], failures=[])
            compatibility = dict(deadline, schemaVersion=2, segment='free-compat', status='PASS', syntheticFixture=False, sourceIdentity=common.source_identity(c), runIdentity=common.run_identity(), completedAtMs=now - 1000, frames=[], errors=[], failures=[])
            report['timeline'] = a_record
            compatibility.update(timeline=b_record, timelineRows=b_rows)
            common.save_json('exploration-qa/tour/browser-result.json', report)
            common.save_json('exploration-qa/free-compat/browser-result.json', compatibility)
            rejects('failed-QA-before-gallery-or-pointer-writes', lambda: final.finalize(c))
            report['status'] = 'PASS'
            common.save_json('exploration-qa/tour/browser-result.json', report)
            rejects('synthetic-PASS-rejected', lambda: final.finalize(c))
            report['syntheticFixture'] = False
            report['sourceIdentity']['sourceHashAggregate'] = '0' * 64
            common.save_json('exploration-qa/tour/browser-result.json', report)
            rejects('wrong-source-QA-rejected', lambda: final.finalize(c))
            for n, b in old_entry.items():
                assert (Path('dist') / c['entryPath'] / n).read_bytes() == b
            assert not (Path('dist') / c['candidatePath'] / 'current-scene.html').exists()
            report['syntheticFixture'] = False
            report['sourceIdentity'] = common.source_identity(c)
            common.save_json('exploration-qa/tour/browser-result.json', report)
            pair = {'tour': report, 'free-compat': compatibility}
            final.validate_segment_pair(c, pair)
            checks.append('two-independent-timely-PASS-identities-allow-historical-tour-deadline')
            for label, mutate in [('missing-segment-B', lambda v: v.pop('free-compat')),
                                  ('cross-source-identity', lambda v: v['free-compat']['sourceIdentity'].__setitem__('sourceHashAggregate', '0' * 64)),
                                  ('cross-QA-run', lambda v: v['free-compat']['runIdentity'].__setitem__('runId', '999')),
                                  ('segment-A-expired', lambda v: v['tour'].__setitem__('completedAtMs', now - 149999)),
                                  ('segment-B-expired', lambda v: v['free-compat'].__setitem__('completedAtMs', now + 445001)),
                                  ('segment-A-not-PASS', lambda v: v['tour'].__setitem__('status', 'FAIL'))]:
                altered = copy.deepcopy(pair)
                mutate(altered)
                rejects(label + '-rejected', lambda: final.validate_segment_pair(c, altered))
            overlap_deadline = {'startedAtMs': now - 400000, 'expiresAtMs': now + 50000, 'totalBudgetMs': 450000}
            common.save_json('.exploration-tour-deadline.json', overlap_deadline)
            overlap = copy.deepcopy(pair)
            overlap['tour'].update(overlap_deadline, completedAtMs=now - 4000)
            rejects('segment-B-starts-before-A-completes-rejected', lambda: final.validate_segment_pair(c, overlap))
            common.save_json('.exploration-tour-deadline.json', tour_deadline)
            # Positive packaging only: mock the GPU gate explicitly. Production
            # entry points have no fixture flag and reject this synthetic report.
            final.validate_gpu = lambda *_: a_bytes
            shot = Path('exploration-qa/tour') / frames[0]['file']
            b = shot.read_bytes()
            shot.write_bytes(b + b'bad')
            rejects('bad-PNG-SHA-before-public-writes', lambda: final.finalize(c))
            assert not (Path('dist') / c['candidatePath'] / 'current-scene.html').exists()
            shot.write_bytes(b)
            quiet(final.finalize, c)
            quiet(verify.verify, c)
            assert len(common.inventory('dist')) == 2283
            final_root = Path('dist') / c['candidatePath'] / 'assets/current-scene' / c['sourceHashAggregate']
            assert (final_root / 'actual-navigation-frames.jsonl').read_bytes() == a_bytes
            public_manifest = common.read_json(final_root / 'manifest.json')
            assert public_manifest['segmentReports']['free-compat']['timelineRows'] == b_rows
            assert not (final_root / 'free-navigation-frames.jsonl').exists()
            checks.append('A-JSONL-byte-preserved-B-rows-embedded-no-extra-public-file')
            assert (Path('dist') / c['entryPath'] / 'world.css').read_bytes() == old_entry['world.css']
            pointer = common.read_json(Path('dist') / c['entryPath'] / 'current-world.json')
            assert (Path('dist') / c['entryPath'] / 'current-world.json').read_bytes() == old_entry['current-world.json']
            assert all((Path('dist') / c['entryPath'] / n).read_bytes() == b for n, b in old_entry.items())
            assert common.read_json('.surface-finalized.json')['state'] == 'QA_PASS_WORLD_UNCHANGED'
            checks.append('mocked-GPU-packaging2283-all2127-preserved-world-unchanged-no-new-entry-PNGs')
            for label, path in [('final-world', Path('dist') / c['entryPath'] / 'index.html'), ('final-extra', Path('dist') / c['candidatePath'] / 'unexpected.json')]:
                data = path.read_bytes() if path.exists() else None
                path.write_bytes(b'bad')
                rejects(label + '-rejected', lambda: verify.verify(c))
                path.unlink() if data is None else path.write_bytes(data)
            receipt = Path('.surface-finalized.json')
            data = receipt.read_bytes()
            r = json.loads(data)
            r['pointer'] = {'world': '../unapproved/index.html'}
            common.save_json(receipt, r)
            rejects('forged-pointer-receipt-rejected', lambda: verify.verify(c))
            receipt.write_bytes(data)
            rejects('duplicate-finalization-rejected', lambda: final.finalize(c))
            common.save_json('.exploration-free-compat-deadline.json', dict(deadline, startedAtMs=now - 500000, expiresAtMs=now - 50000))
            rejects('shared450-second-deadline-expiry-rejected', lambda: verify.verify(c))
    finally:
        os.chdir(old_cwd)
        for k, v in old_env.items():
            os.environ.pop(k, None) if v is None else os.environ.__setitem__(k, v)
    for name in ('surface_common.py', 'stage-surface.py', 'finalize-surface.py', 'verify-surface-preserved.py'):
        compile((T / name).read_text(), str(T / name), 'exec')
    checks.append('four-Python-tools-syntax-pass')
    # Workflow-only evidence retention is explicitly authorized. It must never
    # enable publication after either QA segment fails or collect broader files.
    import yaml
    workflow = yaml.safe_load((P / 'pages-surface.template.yml').read_text())
    previous = yaml.safe_load((P.parent / 'reef-exploration-enriched-publish/pages-enriched.yml').read_text())
    previous_text = (P.parent / 'reef-exploration-enriched-publish/pages-enriched.yml').read_text()
    immutable_prefix = previous_text.split('      - name: Set up existing pinned capture dependency\n')[0]
    assert (P / 'pages-surface.template.yml').read_text().startswith(immutable_prefix)
    checks.append('whole-published-enriched-assembly-prefix-byte-identical')
    assert workflow['permissions'] == previous['permissions']
    job = workflow['jobs']['deploy']
    assert job['timeout-minutes'] == 20
    steps = job['steps']
    evidence_steps = [s for s in steps if s.get('uses') == 'actions/upload-artifact@v4']
    assert len(evidence_steps) == 1
    artifact = evidence_steps[0]
    assert artifact['if'] == 'always()' and artifact['with']['retention-days'] == 7 and artifact['with']['if-no-files-found'] == 'warn'
    assert artifact['with']['name'] == 'exploration-qa-${{ github.run_id }}-${{ github.run_attempt }}'
    assert artifact['with']['path'].split() == ['exploration-qa/**/*.png', 'exploration-qa/**/*.json', 'exploration-qa/**/*.jsonl']
    checks.append('current-run-evidence-only-PNG-JSON-JSONL-with-seven-day-retention')
    qa = [s for s in steps if s.get('env', {}).get('EXPLORATION_QA_MODE') in ('tour', 'free-compat')]
    assert [s['env']['EXPLORATION_QA_MODE'] for s in qa] == ['tour', 'free-compat']
    assert all(s['timeout-minutes'] == 8 and s.get('if') in (None, 'success()') for s in qa)
    final_check = next(s for s in steps if s.get('name') == 'Verify original preview remains byte-identical')
    configure = next(s for s in steps if s.get('uses') == 'actions/configure-pages@v5')
    assert '--deadline-only' in final_check['run']
    assert steps.index(qa[1]) < steps.index(final_check) and steps.index(artifact) == steps.index(final_check) + 1
    assert steps.index(configure) == steps.index(artifact) + 1
    assert not any('--deadline-only' in s.get('run', '') for s in steps[steps.index(artifact) + 1:])
    assert all(s.get('if') in (None, 'success()') for s in steps[steps.index(artifact) + 1:])
    assert any(s.get('uses') == 'actions/deploy-pages@v4' for s in steps[steps.index(artifact) + 1:])
    checks.append('failed-QA-runs-only-evidence-retention-and-keeps-all-publication-steps-success-gated')
    checks.append('B-final-preservation-and-deadline-finish-before-external-evidence-upload')
    assert '--update-world' not in (P / 'pages-surface.template.yml').read_text()
    assert all(s['env']['EXPLORATION_URL'].endswith('/preview/surface-grounding-candidate/scan-exhibit.html') for s in qa)
    assert all(s['env']['EXPLORATION_SOURCE_COMMIT'] == '__SURFACE_SOURCE_COMMIT__' for s in qa)
    checks.append('two-eight-minute-QA-steps-job20-and-permissions-unchanged')
    checks.append('candidate-only-A-B-no-pointer-promotion-workflow')
    result = {'status': 'PASS_LOCAL_TINYFIXTURE_TESTS', 'browserRun': False, 'gpuRun': False,
        'note': 'All large assets replaced by tiny synthetic records; pinned upstream assembly authentication is simulated. Positive packaging mocks GPU validation. Production finalizer rejects synthetic PASS. Actual source/delta contract validated separately; no browser or publication performed.', 'checks': checks}
    common.save_json(P / 'local-stage-test-result.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
