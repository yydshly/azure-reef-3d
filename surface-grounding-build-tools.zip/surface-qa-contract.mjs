import assert from 'node:assert/strict';

export const SURFACE_CONTRACT = Object.freeze({revision:'surface-grounding-v1',borrowedTextures:2,newDownloads:0,newTextureBytes:0,newTextureCopies:0,rockTextureLookups:6,sandTextureLookups:0,grassTextureLookups:0,additionalPasses:0,additionalShadowDraws:0,contactBake:'initialization only, existing vertex colors',textureOwner:'loadWorldSurface',borrowedRockDetail:true});
export function validateSurfaceContract(value){
 assert(value,'Surface contract missing');
 for(const [key,expected] of Object.entries(SURFACE_CONTRACT))assert.equal(value[key],expected,'Surface contract '+key);
 for(const [key,expected] of Object.entries({sandVertices:43322,sandChanged:798,uniqueSandSamples:3572,rayQueries:28576,triangleTests:2189400,rockVertices:24334,rockChanged:9907,minSandFactor:.87,minRockFactor:.85,reach:2.2,maxSandDarkening:.13,maxRockDarkening:.15}))assert.equal(value.contact?.[key],expected,'Frozen contact bake '+key);
 return true;
}
export function validateSurfaceBinding(binding){
 const surface=binding.surface;assert(surface,'Surface draw inspection missing');
 assert(['rock','grass','other'].includes(surface.kind),'Unknown surface kind');
 if(surface.kind==='other')return true;
 assert.equal(binding.linked,true);assert.equal(binding.compiled,true);assert.equal(binding.glError,0);
 assert.equal(surface.unchangedWater,true,'Surface shader lost unchanged deep-water hook');
 if(surface.kind==='rock'){
  assert.equal(surface.cacheKey,'exploration-strata-ocean-surface-grounding-v1-true');assert.equal(surface.rockDetailFragment,true);
  for(const key of ['normal','roughness']){
   const sampler=surface[key];assert(sampler,'Missing rock '+key+' sampler');
   assert.equal(sampler.active,true);assert(Number.isInteger(sampler.unit)&&sampler.unit>=0);
   for(const flag of ['borrowedReferenceIdentical','uploaded','boundToExpectedMap'])assert.equal(sampler[flag],true,key+' '+flag);
   assert.equal(typeof sampler.expectedTextureUUID,'string');assert(sampler.expectedTextureUUID.length>0);assert.equal(sampler.textureUUID,sampler.expectedTextureUUID);
  }
  assert.notEqual(surface.normal.textureUUID,surface.roughness.textureUUID,'Normal and roughness must remain separate existing textures');
 }else{
  assert.equal(surface.cacheKey,'exploration-curved-canopy-ocean-surface-grounding-v1');
  assert.equal(surface.grassSwayNormal,true);assert.equal(surface.grassRootFade,true);
 }
 return true;
}
export function validateSurfaceCoverage(frames){
 const bindings=frames.flatMap(frame=>frame.explorationBindings||[]);bindings.forEach(validateSurfaceBinding);
 for(const kind of ['rock','grass'])assert(bindings.some(binding=>binding.surface.kind===kind),'Natural tour did not submit '+kind+' surface');
 return {kinds:['rock','grass'],materialUUIDs:[...new Set(bindings.filter(binding=>binding.surface.kind!=='other').map(binding=>binding.materialUUID))],onlySubmittedMeshesVerified:true};
}
export function validateSurfaceProtection(value){
 assert(value,'Surface protection missing');assert.deepEqual(value.issues,[]);assert.equal(value.borrowedDisposals,0);assert.equal(value.borrowedTextureCount,2);
 assert(Number.isInteger(value.sourceMaterialCount)&&value.sourceMaterialCount>0);
 assert.deepEqual(value.textureFiles,['assets/reef-texture-2.png','assets/reef-texture-3.png']);
 assert.equal(value.sameSourceReferences,true);assert.equal(value.textureStateUnchanged,true);
 return true;
}
