// Local callback/negative fixtures only. This test never launches a browser.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {installSurfaceObservation} from './browser-observe-surface.mjs';
import {observeFrame} from './browser-observe-exploration.mjs';
import {SURFACE_CONTRACT,validateSurfaceContract,validateSurfaceBinding,validateSurfaceCoverage,validateSurfaceProtection} from './surface-qa-contract.mjs';

const contact={sandVertices:43322,sandChanged:798,uniqueSandSamples:3572,rayQueries:28576,triangleTests:2189400,rockVertices:24334,rockChanged:9907,minSandFactor:.87,minRockFactor:.85,reach:2.2,maxSandDarkening:.13,maxRockDarkening:.15};
const material=(uuid,key,userData={})=>({uuid,type:'MeshStandardMaterial',userData,customProgramCacheKey:()=>key});
function fixture(){
 const texture=(uuid,index)=>({uuid,image:{src:'http://localhost/preview/surface-grounding-candidate/assets/reef-texture-'+index+'.png'},source:{},version:1,listeners:{},addEventListener(type,fn){this.listeners[type]=fn;}});
 const normal=texture('original-normal',2),roughness=texture('original-roughness',3),normalHandle={},roughnessHandle={},owner=material('owner','syntheticPorousLimestone1'),rock=material('rock','exploration-strata-ocean-surface-grounding-v1-true',{borrowedSurfaceMaps:['normal','roughness']}),grass=material('grass','exploration-curved-canopy-ocean-surface-grounding-v1');
 const properties=new Map([[normal,{__webglTexture:normalHandle}],[roughness,{__webglTexture:roughnessHandle}],[owner,{uniforms:{reefStoneNormal:{value:normal},reefStoneRough:{value:roughness}}}],[rock,{uniforms:{explorationStoneNormal:{value:normal},explorationStoneRoughness:{value:roughness}}}],[grass,{uniforms:{}}]]);
 const state={active:103,program:null,callbackCount:0,renderCount:0,rejectRender:false,throwBinding:false};
 const fragment='stoneDetail*.27 roughnessFactor=.83+.16*surfaceR .82+.18*smoothstep(.035,.38,vExplorationBladeHeight) deepWater=smoothstep(240.,415.,-cameraPosition.z)';
 const vertex='objectNormal.y-leafDxDy*objectNormal.x-leafDzDy*objectNormal.z';
 const program=(name)=>({name,vertex,fragment,compiled:true,linked:true});
 const mesh=(name,mat)=>({name,isMesh:true,material:mat,program:program(name),onAfterRender(){state.callbackCount++;}});
 const meshes=[mesh('Broken_Scan_Derived_Reef_2',rock),mesh('Open_Bay_Seagrass_Meadow_0',grass)],oceans=['Synthetic_Water_Volume','Synthetic_Receding_Sand','Synthetic_Overhead_Surface'].map(name=>mesh(name,material(name,'ocean')));
 const gl={CURRENT_PROGRAM:1,SHADER_TYPE:2,VERTEX_SHADER:3,FRAGMENT_SHADER:4,COMPILE_STATUS:5,LINK_STATUS:6,ACTIVE_TEXTURE:7,TEXTURE_BINDING_2D:8,TEXTURE0:100,RGBA:9,UNSIGNED_BYTE:10,VENDOR:11,RENDERER:12,drawingBufferWidth:20,drawingBufferHeight:16,
  getParameter(key){if(key===1)return state.program;if(key===7)return state.active;if(key===8){if(state.throwBinding)throw Error('mock binding failure');return state.active===100?normalHandle:state.active===101?roughnessHandle:null;}return 'mock';},
  getAttachedShaders:p=>[{type:3,source:p.vertex,compiled:p.compiled},{type:4,source:p.fragment,compiled:p.compiled}],getShaderParameter:(shader,key)=>key===2?shader.type:shader.compiled,getShaderSource:shader=>shader.source,
  getUniformLocation:(p,name)=>p.name.startsWith('Broken_')&&['explorationStoneNormal','explorationStoneRoughness'].includes(name)?name:null,
  getUniform:(p,name)=>name==='explorationStoneNormal'?0:1,activeTexture:unit=>{state.active=unit;},getProgramParameter:p=>p.linked,getError:()=>0,isContextLost:()=>false,getExtension:()=>null,readPixels:(x,y,w,h,format,type,pixels)=>pixels.forEach((_,i)=>{pixels[i]=i%251;})};
 const group={traverse:fn=>meshes.forEach(fn),userData:{surface:{...SURFACE_CONTRACT,contact}}};meshes.forEach(mesh=>mesh.parent=group);
 const e={renderer:{getContext:()=>gl,properties:{get:key=>properties.get(key)||{}},info:{render:{calls:5},memory:{textures:2}}},world:{group:{traverse:fn=>fn({name:'Sunlit_Broken_Coral_Shelves',isMesh:true,material:owner})}},explorationWorld:{group},scene:{getObjectByName:name=>oceans.find(mesh=>mesh.name===name)},getRenderDemandState:()=>({sequence:state.renderCount}),getState:()=>({camera:[4,5,10],target:[4,5,0],route:{elapsed:0,paused:true},ambient:{time:0}}),continuousField:{getState:()=>({enabled:false})},observeNextRender:async fn=>{if(state.rejectRender)throw Error('mock render rejected');for(const mesh of [...meshes,...oceans]){state.program=mesh.program;mesh.onAfterRender(null,null,null,null,mesh.material);}return fn({sequence:++state.renderCount});}};
 globalThis.window={reefExhibit:e,__explorationQA:{}};globalThis.location={href:'http://localhost/preview/surface-grounding-candidate/scan-exhibit.html'};
 return {page:{evaluate:async(fn,arg)=>fn(arg)},e,normal,roughness,rock,grass,owner,properties,state,meshes,oceans,normalHandle,roughnessHandle};
}
let rejected=0;
const reject=fn=>{assert.throws(fn);rejected++;};
const f=fixture(),installed=await installSurfaceObservation(f.page);validateSurfaceContract(installed.contract);validateSurfaceProtection(installed.protection);
const callbacks=[...f.meshes,...f.oceans].map(mesh=>mesh.onAfterRender),frame=await observeFrame(f.page);
assert.equal(f.state.renderCount,1);assert.equal(f.state.callbackCount,5);assert.equal(f.state.active,103);
assert.deepEqual([...f.meshes,...f.oceans].map(mesh=>mesh.onAfterRender),callbacks);
frame.explorationBindings.forEach(validateSurfaceBinding);assert.deepEqual(validateSurfaceCoverage([frame]).kinds,['rock','grass']);
const rockBinding=frame.explorationBindings.find(binding=>binding.surface.kind==='rock'),grassBinding=frame.explorationBindings.find(binding=>binding.surface.kind==='grass');
for(const property of ['linked','compiled'])reject(()=>validateSurfaceBinding({...rockBinding,[property]:false}));
reject(()=>validateSurfaceBinding({...rockBinding,glError:1282}));
for(const key of ['normal','roughness'])for(const flag of ['active','uploaded','boundToExpectedMap','borrowedReferenceIdentical']){
 const changed=structuredClone(rockBinding);changed.surface[key][flag]=false;reject(()=>validateSurfaceBinding(changed));
}
for(const flag of ['grassSwayNormal','grassRootFade','unchangedWater'])reject(()=>validateSurfaceBinding({...grassBinding,surface:{...grassBinding.surface,[flag]:false}}));
reject(()=>validateSurfaceBinding({...rockBinding,surface:{...rockBinding.surface,cacheKey:'old'}}));
reject(()=>validateSurfaceCoverage([{explorationBindings:[rockBinding]}]));reject(()=>validateSurfaceCoverage([{explorationBindings:[grassBinding]}]));
reject(()=>validateSurfaceContract({...installed.contract,newTextureCopies:1}));reject(()=>validateSurfaceContract({...installed.contract,contact:{...contact,rockChanged:0}}));

// A clone with the same URL and the expected GL handle still fails identity.
const clone={...f.normal,uuid:'clone-normal'};f.properties.set(clone,{__webglTexture:f.normalHandle});f.properties.get(f.rock).uniforms.explorationStoneNormal.value=clone;
const clonedFrame=await observeFrame(f.page);reject(()=>validateSurfaceBinding(clonedFrame.explorationBindings[0]));
assert.equal(clonedFrame.explorationBindings[0].surface.normal.boundToExpectedMap,true);assert.equal(clonedFrame.explorationBindings[0].surface.normal.borrowedReferenceIdentical,false);
f.properties.get(f.rock).uniforms.explorationStoneNormal.value=f.normal;
f.normal.version++;reject(()=>validateSurfaceProtection(window.__explorationQA.surface.verify()));f.normal.version--;
f.properties.get(f.owner).uniforms.reefStoneNormal.value=clone;reject(()=>validateSurfaceProtection(window.__explorationQA.surface.verify()));f.properties.get(f.owner).uniforms.reefStoneNormal.value=f.normal;
f.normal.listeners.dispose();reject(()=>validateSurfaceProtection(window.__explorationQA.surface.verify()));
f.state.rejectRender=true;await assert.rejects(observeFrame(f.page),/mock render rejected/);assert.deepEqual([...f.meshes,...f.oceans].map(mesh=>mesh.onAfterRender),callbacks);f.state.rejectRender=false;
f.state.throwBinding=true;await assert.rejects(observeFrame(f.page),/mock binding failure/);assert.equal(f.state.active,103);assert.deepEqual([...f.meshes,...f.oceans].map(mesh=>mesh.onAfterRender),callbacks);
const absent=fixture();absent.properties.delete(absent.owner);await assert.rejects(installSurfaceObservation(absent.page),/Unique compiled original/);
for(const key of ['window','location'])delete globalThis[key];

const root=new URL('../../reef-surface-grounding-candidate/page/',import.meta.url),contract=JSON.parse(readFileSync(new URL('./surface-contract.json',import.meta.url)));
assert.equal(Object.keys(contract.sourceHashes).length,150);for(const [file,expected]of Object.entries(contract.sourceHashes))assert.equal(createHash('sha256').update(readFileSync(new URL(file,root))).digest('hex'),expected,file);
const runner=readFileSync(new URL('./browser-check-surface.mjs',import.meta.url),'utf8'),observer=readFileSync(new URL('./browser-observe-exploration.mjs',import.meta.url),'utf8'),oldObserver=readFileSync(new URL('../../reef-exploration-enriched-publish/tools/browser-observe-exploration.mjs',import.meta.url),'utf8');
assert.equal((observer.match(/e\.observeNextRender\(/g)||[]).length,(oldObserver.match(/e\.observeNextRender\(/g)||[]).length);
assert(runner.includes("assert(stageRemaining()>72000"));assert(!runner.includes('4.533'));assert(!runner.includes('36.698'));
assert(runner.includes("targetMaxSlowdownPercent:5"));assert(runner.includes("status:'UNVERIFIED'"));
for(const name of ['exploration-qa-math.mjs','browser-diagnostics-exploration.mjs'])assert.equal(readFileSync(new URL('./'+name,import.meta.url),'utf8'),readFileSync(new URL('../../reef-exploration-enriched-publish/tools/'+name,import.meta.url),'utf8'));
console.log(JSON.stringify({status:'LOCAL_SURFACE_CALLBACK_MOCK_PASS',browserLaunched:false,gpuEvidence:false,sourceFiles:150,rejectedMutations:rejected,originalOwnerReferences:true,cloneEvenWithSameHandleRejected:true,textureStateAndDisposalProtected:true,activeTextureRestored:true,callbacksRestoredOnSuccessAndFailure:true,additionalRenders:0,deadlinesAndNativeControlsInherited:true,performance:'UNVERIFIED'},null,2));
