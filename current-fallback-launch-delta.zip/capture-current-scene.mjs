// Build-time public gallery assets only. Never downloads past CI artifacts.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {FRAME_PLAN,renderGallery,validateManifest,computeContentVersion} from './current-scene-gallery.mjs';
// CAPTURE_CLIP_HELPERS_BEGIN
function inspectCaptureFrame(world){
 const canvas=document.querySelector(world==='scan'?'#scanCanvas':'#reef');
 const app=world==='scan'?window.reefExhibit:window.reef3d;
 if(!canvas||!app)return {visible:false};
 const rect=canvas.getBoundingClientRect();let visible=true;
 for(let node=canvas;node;node=node.parentElement){const style=getComputedStyle(node);if(node.hidden||style.display==='none'||style.visibility==='hidden'||style.visibility==='collapse'||Number(style.opacity)===0)visible=false;}
 const loading=document.querySelector(world==='scan'?'#scanLoading':'#loading'),failure=document.querySelector(world==='scan'?'#scanError':'#unsupported');
 return {clip:{x:rect.x,y:rect.y,width:rect.width,height:rect.height},viewport:{width:innerWidth,height:innerHeight},scroll:{x:scrollX,y:scrollY},visible,loadingHidden:!!loading?.hidden,failureHidden:!!failure?.hidden,state:app.getState()};
}
function verifyCaptureFrame(frame,world,expectedState){
 const expectedHeight=world==='scan'?712:780;
 assert(frame.visible&&frame.loadingHidden&&frame.failureHidden&&frame.state?.ready,'Canvas hidden/loading/error during capture');
 assert.deepEqual(frame.viewport,{width:1120,height:780},'Capture viewport changed');
 assert.deepEqual(frame.scroll,{x:0,y:0},'Capture must not scroll or resize the scene');
 const r=frame.clip;assert(r&&Object.values(r).every(Number.isFinite),'Invalid canvas rectangle');
 assert(r.x>=0&&r.y>=0&&r.x+r.width<=1120&&r.y+r.height<=780,'Canvas clip outside viewport');
 assert.equal(r.x,0);assert.equal(r.y,world==='scan'?68:0);assert.equal(r.width,1120);assert.equal(r.height,expectedHeight);
 for(const key of ['camera','target'])assert(frame.state[key].length===3&&frame.state[key].every((v,i)=>Number.isFinite(v)&&Math.abs(v-expectedState[key][i])<1e-7),'Capture camera/target changed');
 const signature=state=>({waterMode:state.waterMode,softened:state.softened,route:state.route,low:state.low,tour:state.tour,simulationTime:state.simulationTime,ambient:state.ambient});
 assert.deepEqual(signature(frame.state),signature(expectedState),'Camera, route, material or motion state changed during capture');
 return r;
}
// CAPTURE_CLIP_HELPERS_END
const root=path.resolve(process.env.REEF_PREVIEW_DIR||'dist/preview/independent-scan');
const target='http://127.0.0.1:4173/preview/independent-scan/';
const hash=b=>createHash('sha256').update(b).digest('hex');
const here=path.dirname(fileURLToPath(import.meta.url));
const scriptHash=hash(await fs.readFile(fileURLToPath(import.meta.url))),galleryHash=hash(await fs.readFile(path.join(here,'current-scene-gallery.mjs')));
const dependency=path.resolve('tests/browser/node_modules/playwright/index.mjs');
const {chromium}=await import(pathToFileURL(dependency).href);
async function sourceInventory(dir=root,prefix=''){
 const out=[];for(const e of (await fs.readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
  const rel=prefix+e.name;if(rel==='current-scene.html'||rel==='assets/current-scene')continue;
  assert(!e.isSymbolicLink(),'Symlinks are not build inputs');
  if(e.isDirectory())out.push(...await sourceInventory(path.join(dir,e.name),rel+'/'));
  else if(e.isFile()){const b=await fs.readFile(path.join(dir,e.name));out.push({path:rel,bytes:b.length,sha256:hash(b)});}
 }return out;
}
const sourceFiles=await sourceInventory();const contentVersion=computeContentVersion({sourceFiles,captureScriptSha256:scriptHash,galleryScriptSha256:galleryHash,viewport:{width:1120,height:780}});
const out=path.join(root,'assets/current-scene',contentVersion);
const manifest={schema:1,contentVersion,capturedAt:new Date().toISOString(),checkoutCommit:process.env.GITHUB_SHA,candidateSourceCommit:process.env.REEF_CANDIDATE_SOURCE_COMMIT,candidateArchiveSha256:process.env.REEF_CANDIDATE_ARCHIVE_SHA256,captureScriptSha256:scriptHash,galleryScriptSha256:galleryHash,sourceFiles,viewport:{width:1120,height:780},frames:[],limitations:['Four static runtime captures only; no native-input, transition, mobile, user-GPU or overall aesthetic acceptance.','Reduced motion and default, unsoftened materials; synthetic surroundings are not collection-site reconstruction.','Original artificial world and separate expanded scan world are distinct scenes.'],browser:{sandbox:true,unsafeGraphicsFlags:false}};
for(const [key,re]of [['checkoutCommit',/^[a-f0-9]{40}$/],['candidateSourceCommit',/^[a-f0-9]{40}$/],['candidateArchiveSha256',/^[a-f0-9]{64}$/]])assert(re.test(manifest[key]||''),'Missing build identity '+key);
let browser,context;const errors=[];const inventory=new Map(sourceFiles.map(f=>[f.path,f]));const fetched=new Map();
const timer=setTimeout(()=>{console.error('CURRENT_SCENE_CAPTURE_FAILED: bounded 300-second capture deadline; no gallery accepted');process.exit(2)},300000);
try{
 browser=await chromium.launch({channel:'chromium',headless:true,chromiumSandbox:true,timeout:30000,args:['--enable-automation'],ignoreDefaultArgs:['--enable-unsafe-swiftshader','--disable-gpu-sandbox','--ignore-gpu-blocklist']});
 const cdp=await browser.newBrowserCDPSession();const cmd=await cdp.send('Browser.getBrowserCommandLine');assert(!cmd.arguments.some(x=>['--no-sandbox','--disable-gpu-sandbox','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'].includes(x)),'Security-weakening browser flag');manifest.browser.version=browser.version();
 context=await browser.newContext({viewport:manifest.viewport,deviceScaleFactor:1,reducedMotion:'reduce'});
 // Local candidate only. Source/attribution links are visible but never followed.
 await context.route('**/*',r=>r.request().url().startsWith(target)?r.continue():r.abort('blockedbyclient'));
 const page=await context.newPage();page.setDefaultTimeout(15000);
 page.on('request',r=>{if(/\/assets\/(?:current-scene\/|front\.webp|back\.webp)/.test(new URL(r.url()).pathname))errors.push('Unexpected still-image request in working 3D: '+r.url())});
 page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});page.on('requestfailed',r=>errors.push(r.url()+': '+r.failure()?.errorText));
 page.on('response',r=>{try{assert(r.ok(),'HTTP '+r.status()+' '+r.url());const url=new URL(r.url()),rel=decodeURIComponent(url.pathname.slice(new URL(target).pathname.length));const expected=inventory.get(rel);assert(expected,'Unexpected served input '+rel);fetched.set(rel,expected.sha256);}catch(e){errors.push(String(e))}});

 await page.goto(new URL('index.html',target).href,{waitUntil:'domcontentloaded',timeout:30000});
 await page.waitForFunction(()=>window.reef3d?.getState().ready||document.querySelector('#unsupported')?.hidden===false,null,{timeout:85000,polling:250});assert(await page.evaluate(()=>!!window.reef3d?.getState().ready),'Artificial scene failed to start');
 await page.evaluate(()=>{scrollTo(0,0);reef3d.preset(0);reef3d.setTour(false)});
 await fs.mkdir(out,{recursive:true});
 for(const plan of FRAME_PLAN){
  if(plan.id==='scan-terrace'){
   await page.goto(new URL('scan-exhibit.html',target).href,{waitUntil:'domcontentloaded',timeout:30000});
   await page.waitForFunction(()=>window.reefExhibit?.getState().ready||document.querySelector('#scanError')?.hidden===false,null,{timeout:65000,polling:250});assert(await page.evaluate(()=>!!window.reefExhibit?.getState().ready),'Expanded scene failed to start');
  }
  if(plan.world==='scan')await page.evaluate(p=>{scrollTo(0,0);reefExhibit.setAmbientPaused(true);reefExhibit.enterRoute();reefExhibit.goRoute(p,true)},plan.routeProgress);
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  const data=await page.evaluate(async world=>{
   const app=world==='scan'?window.reefExhibit:window.reef3d,canvas=document.querySelector(world==='scan'?'#scanCanvas':'#reef');
   return new Promise(resolve=>requestAnimationFrame(()=>{
    const gl=canvas.getContext('webgl2');if(!gl||gl.isContextLost())return resolve({graphics:{available:false}});
    const w=gl.drawingBufferWidth,h=gl.drawingBufferHeight,pixels=new Uint8Array(w*h*4);gl.readPixels(0,0,w,h,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
    const colors=new Set();for(let y=1;y<16;y++)for(let x=1;x<20;x++){const i=(Math.floor(y*h/16)*w+Math.floor(x*w/20))*4;colors.add([pixels[i],pixels[i+1],pixels[i+2],pixels[i+3]].join(','));}
    const ext=gl.getExtension('WEBGL_debug_renderer_info'),state=app.getState(),stats=world==='scan'?app.renderer.info.render:app.getRenderStats().render;
    resolve({state,camera:state.camera,target:state.target,graphics:{available:true,contextLost:gl.isContextLost(),sampleColors:colors.size,pixelError:gl.getError(),drawCalls:stats.calls,triangles:stats.triangles,renderer:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),vendor:ext?gl.getParameter(ext.UNMASKED_VENDOR_WEBGL):gl.getParameter(gl.VENDOR),version:gl.getParameter(gl.VERSION)}});
   }));
  },plan.world);
  assert(data.graphics.available&&!data.graphics.contextLost&&data.graphics.sampleColors>=2&&data.graphics.drawCalls>0&&data.graphics.pixelError===0,'Actual frame unavailable/blank: '+plan.id);
  assert(await page.evaluate(world=>{const loading=document.querySelector(world==='scan'?'#scanLoading':'#loading'),failure=document.querySelector(world==='scan'?'#scanError':'#unsupported');return loading.hidden&&failure.hidden},plan.world),'Loading/error panel visible during capture');
  assert.equal(data.state.ready,true);if(plan.world==='scan'){assert(data.state.waterMode&&!data.state.softened);assert.equal(data.state.route.progress,plan.routeProgress)}else assert.equal(data.state.passageProgress,0);
  assert.deepEqual(errors,[],'Runtime/asset errors');
  const temporaryFile=plan.id+'.pending.png';
  // No locator/actionability/scroll-into-view or protocol element geometry calls
  // in the software-renderer path. Read the existing DOM rectangle directly and
  // capture that viewport clip without changing the viewport, pose or materials.
  const beforeFrame=await page.evaluate(inspectCaptureFrame,plan.world);
  const clip=verifyCaptureFrame(beforeFrame,plan.world,data.state);
  console.log('CURRENT_SCENE_FRAME_READY '+JSON.stringify({id:plan.id,clip,sampleColors:data.graphics.sampleColors}));
  await page.screenshot({path:path.join(out,temporaryFile),type:'png',clip,fullPage:false,timeout:25000,animations:'disabled'});
  const afterFrame=await page.evaluate(inspectCaptureFrame,plan.world);
  assert.deepEqual(verifyCaptureFrame(afterFrame,plan.world,data.state),clip,'Canvas rectangle changed during screenshot');
  const b=await fs.readFile(path.join(out,temporaryFile));assert(b.length>10000,'Unexpectedly empty capture');
  assert(b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))&&b.readUInt32BE(16)===clip.width&&b.readUInt32BE(20)===clip.height,'Screenshot PNG dimensions differ from canvas clip');
  const file=plan.id+'-'+hash(b).slice(0,16)+'.png';await fs.rename(path.join(out,temporaryFile),path.join(out,file));
  manifest.frames.push({...plan,file,sha256:hash(b),bytes:b.length,width:clip.width,height:clip.height,captureClip:clip,...data,materialMode:'default-unsoftened',motion:'reduced-motion-still',interactionAcceptance:false,framing:'Visible canvas rectangle including any overlapping scene controls; no geometry/material edits.'});
  console.log('CURRENT_SCENE_FRAME '+JSON.stringify({id:plan.id,bytes:b.length,sha256:hash(b),sampleColors:data.graphics.sampleColors}));
 }
 assert.deepEqual(errors,[]);
 // Independent same-origin served-byte verification, not a browser inspector-cache
 // body read and not proof of the first/cold transfer. Large models can be evicted
 // from Chromium's response cache, so intentionally never call response.body().
 for(const [rel,expectedHash]of fetched){const response=await fetch(new URL(rel,target),{redirect:'error',signal:AbortSignal.timeout(20000)});assert(response.ok,'Served hash check HTTP '+response.status+' '+rel);const bytes=Buffer.from(await response.arrayBuffer());assert.equal(bytes.length,inventory.get(rel).bytes,'Served size mismatch '+rel);assert.equal(hash(bytes),expectedHash,'Served input mismatch '+rel);}
 manifest.servedHashMethod='Independent same-origin fetch after browser captures; not original response-body, cold-load, wire-byte or timing evidence.';
 assert.deepEqual(await sourceInventory(),sourceFiles,'Candidate changed during capture');
 manifest.fetchedAssets=[...fetched].map(([path,sha256])=>({path,sha256})).sort((a,b)=>a.path.localeCompare(b.path));
 for(const required of ['app.js','scan-exhibit.js','scan-world.js','scan-ocean.js','scan-route.js','assets/reefs4d/C12019-web.glb'])assert(fetched.has(required),'Missing live asset '+required);
 validateManifest(manifest);
 await fs.writeFile(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
 await fs.writeFile(path.join(root,'current-scene.html'),renderGallery(manifest));
 console.log('CURRENT_SCENE_COMPLETE '+JSON.stringify({contentVersion,frames:manifest.frames.length,manifest:`assets/current-scene/${contentVersion}/manifest.json`,sourceFiles:sourceFiles.length,rootFilesNotModifiedByCapture:true}));
}catch(e){console.error('CURRENT_SCENE_CAPTURE_FAILED',e);process.exitCode=1;}finally{clearTimeout(timer);await context?.close().catch(()=>{});await browser?.close().catch(()=>{});}
