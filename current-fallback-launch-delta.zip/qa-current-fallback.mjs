#!/usr/bin/env node
/** Read-only QA. Gallery image substitutions are in-memory LAYOUT TEST FIXTURES,
 * never evidence of capture success and never written into dist or published.
 * Usage: node qa-current-fallback.mjs [--source-only]
 * REEF_QA_ROOT: project root or dist directory. PLAYWRIGHT_MODULE / CHROMIUM_PATH
 * can select existing installations. No dependencies are installed here.
 */
import assert from 'node:assert/strict';
import { readFile, stat, readdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const args = new Set(process.argv.slice(2));
const root = path.resolve(process.env.REEF_QA_ROOT || path.dirname(fileURLToPath(import.meta.url)));
const dist = await stat(path.join(root, 'dist')).then(s => s.isDirectory() ? path.join(root, 'dist') : root).catch(() => root);
const read = name => readFile(path.join(dist, name), 'utf8');
const index = await read('index.html'), scan = await read('scan-exhibit.html');
function check(value, message) { assert.ok(value, message); console.log(`PASS: ${message}`); }
for (const [name, html, anchor] of [['index.html', index, 'artificial-opening'], ['scan-exhibit.html', scan, 'scan-terrace']]) {
  check(!/<img\b/i.test(html), `${name}: no still-image elements in the live 3D page`);
  check(!/assets\/(?:front|back)\.webp/i.test(html), `${name}: historical fallback images removed`);
  check(html.includes(`current-scene.html#${anchor}`), `${name}: contextual static fallback link`);
  check((html.match(/href=["'][^"']*current-scene\.html/g) || []).length >= 2, `${name}: fallback and explicit help/provenance gallery links`);
}
const { FRAME_PLAN, validateManifest, renderGallery, computeContentVersion } = await import(new URL('./current-scene-gallery.mjs', import.meta.url));
// Synthetic metadata exercises the gallery template, never the capture pipeline.
const fixtureManifest = {
  schema: 1, contentVersion: '0'.repeat(64), captureScriptSha256: '0'.repeat(64), galleryScriptSha256: '0'.repeat(64),
  checkoutCommit: '0'.repeat(40), candidateArchiveSha256: '0'.repeat(64), candidateSourceCommit: '0'.repeat(40),
  capturedAt: 'LAYOUT TEST FIXTURE — NOT A CAPTURE', browser: { sandbox: true, unsafeGraphicsFlags: false },
  viewport: { width: 1120, height: 780 },
  sourceFiles: Array.from({ length: 21 }, (_, i) => ({ path: `test-fixture-${i}.js`, sha256: '0'.repeat(64), bytes: 1 })),
  frames: FRAME_PLAN.map(plan => ({ ...plan, file: `${plan.id}-${'0'.repeat(16)}.png`, sha256: '0'.repeat(64), bytes: 10001,
    width: 1120, height: 780, camera: [0, 1, 2], target: [0, 0, 0],
    graphics: { available: true, contextLost: false, sampleColors: 4, drawCalls: 1 },
    materialMode: 'default-unsoftened', motion: 'reduced-motion-still', interactionAcceptance: false,
    state: { ready: true, waterMode: true, softened: false, low: false, tour: false, specimenInspection: false,
      route: { active: true, progress: plan.routeProgress, yaw: 0, pitch: 0 } }
  }))
};
fixtureManifest.contentVersion = computeContentVersion(fixtureManifest);
check(validateManifest(fixtureManifest), 'template accepts structurally complete synthetic fixture metadata');
for (const [label, mutate] of [
  ['invalid version digest', m => m.contentVersion = 'stale'],
  ['tampered source hash', m => m.sourceFiles[0].sha256 = 'f'.repeat(64)],
  ['missing frame', m => m.frames.pop()],
  ['image filename missing content hash', m => m.frames[0].file = `${m.frames[0].id}.png`],
  ['wrong frame ordering', m => m.frames.reverse()],
  ['inactive scan route', m => m.frames[1].state.route.active = false],
  ['stale route progress', m => m.frames[1].state.route.progress = .5],
  ['not-ready scene', m => m.frames[0].state.ready = false],
  ['lost graphics context', m => m.frames[0].graphics.contextLost = true],
  ['blank graphics probe', m => m.frames[0].graphics.sampleColors = 0],
  ['unsafe browser flags', m => m.browser.unsafeGraphicsFlags = true],
  ['invalid camera', m => m.frames[0].camera[0] = NaN],
  ['incorrect image dimensions', m => m.frames[0].width = 390]
]) {
  const invalid = structuredClone(fixtureManifest); mutate(invalid);
  assert.throws(() => validateManifest(invalid), undefined, `manifest rejects ${label}`);
  console.log(`PASS: manifest rejects ${label}`);
}
const generatedGallery = await read('current-scene.html').catch(error => { if (error.code === 'ENOENT') return null; throw error; });
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
if (process.env.REEF_QA_REQUIRE_CAPTURE === '1') assert.ok(generatedGallery, 'Deployment QA requires freshly generated gallery; fixtures are not acceptance');
if (generatedGallery) {
  const manifestLinks = [...generatedGallery.matchAll(/href=["'](assets\/current-scene\/[a-f0-9]{64}\/manifest\.json)["']/g)];
  check(manifestLinks.length === 1, 'generated gallery links exactly one versioned local manifest');
  const manifestPath = manifestLinks[0][1];
  const actualManifest = JSON.parse(await read(manifestPath));
  check(validateManifest(actualManifest), 'actual capture manifest validates and content digest recomputes');
  check(manifestPath === `assets/current-scene/${actualManifest.contentVersion}/manifest.json`, 'manifest directory matches content version');
  check(generatedGallery === renderGallery(actualManifest), 'generated gallery exactly matches validated capture manifest');
  for (const [filename, field] of [['capture-current-scene.mjs', 'captureScriptSha256'], ['current-scene-gallery.mjs', 'galleryScriptSha256']]) {
    check(hash(await readFile(new URL(`./${filename}`, import.meta.url))) === actualManifest[field], `actual ${filename} hash matches capture manifest`);
  }
  async function sourceInventory(directory = dist, prefix = '') {
    const inventory = [];
    for (const entry of (await readdir(directory, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
      const relative = prefix + entry.name;
      if (relative === 'current-scene.html' || relative === 'assets/current-scene') continue;
      assert.ok(!entry.isSymbolicLink(), 'Runtime inventory may not contain symlinks');
      if (entry.isDirectory()) inventory.push(...await sourceInventory(path.join(directory, entry.name), `${relative}/`));
      else if (entry.isFile()) {
        const bytes = await readFile(path.join(directory, entry.name));
        inventory.push({ path: relative, bytes: bytes.length, sha256: hash(bytes) });
      }
    }
    return inventory;
  }
  assert.deepEqual(await sourceInventory(), actualManifest.sourceFiles, 'Every runtime source path, size and hash must match capture manifest exactly');
  console.log(`PASS: exact runtime inventory matches all ${actualManifest.sourceFiles.length} recorded source files`);
  for (const frame of actualManifest.frames) {
    const bytes = await readFile(path.join(dist, path.dirname(manifestPath), frame.file));
    check(bytes.length === frame.bytes && hash(bytes) === frame.sha256, `${frame.id}: actual image size and SHA-256 match capture manifest`);
    check(bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) && bytes.readUInt32BE(16) === frame.width && bytes.readUInt32BE(20) === frame.height, `${frame.id}: actual PNG signature and dimensions match capture manifest`);
  }
} else {
  console.log('PENDING: generated current-scene.html is absent. Production manifest/source/image verification has NOT run; template checks are not deployment acceptance.');
}
const gallery = generatedGallery || renderGallery(fixtureManifest);
console.log(generatedGallery ? 'Gallery structure: generated output.' : 'Gallery structure: template rendered using synthetic metadata, in memory only; production capture remains unverified.');
if (gallery) {
  check(/<html\b[^>]*lang=/i.test(gallery) && /name=["']viewport["']/i.test(gallery), 'gallery declares language and mobile viewport');
  check(!/<canvas\b|<script\b/i.test(gallery), 'gallery is static HTML without canvas or script');
  check(/id=["']artificial-opening["']/.test(gallery) && /id=["']scan-terrace["']/.test(gallery), 'gallery preserves both contextual anchors');
  const images = gallery.match(/<img\b[^>]*>/gi) || [];
  check(images.length === 4, 'gallery has exactly four stills');
  for (const [i, tag] of images.entries()) {
    check(/loading=["']lazy["']/i.test(tag), `gallery image ${i + 1}: lazy loading`);
    check(/alt=["'][^"']+['"]/i.test(tag), `gallery image ${i + 1}: nonempty alternative text`);
    check(/width=["']\d+["']/i.test(tag) && /height=["']\d+["']/i.test(tag), `gallery image ${i + 1}: explicit intrinsic dimensions`);
    check(/(?:src|srcset)=["'][^"']*assets\/current-scene\//i.test(tag), `gallery image ${i + 1}: versioned current-scene asset`);
  }
}
if (args.has('--source-only') || process.env.REEF_QA_SKIP_BROWSER === '1') {
  console.log('SOURCE-ONLY: browser checks explicitly skipped.');
  process.exit(0);
}
let chromium;
try { ({ chromium } = await import(process.env.PLAYWRIGHT_MODULE || '/opt/codex/cua_node/lib/node_modules/playwright/index.mjs')); }
catch (error) { throw new Error(`Browser QA unavailable: existing Playwright could not be imported. ${error.message}`); }
const contentTypes = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.webp': 'image/webp', '.glb': 'model/gltf-binary' };
const server = createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    const target = path.resolve(dist, `.${pathname === '/' ? '/index.html' : pathname}`);
    if (!target.startsWith(`${dist}${path.sep}`)) { res.writeHead(403); res.end(); return; }
    if (pathname === '/current-scene.html') { res.setHeader('Content-Type', 'text/html'); res.end(gallery.replace('<body>', '<body><p role=\"status\">LAYOUT TEST FIXTURE — NOT SCENE EVIDENCE</p>')); return; }
    res.setHeader('Content-Type', contentTypes[path.extname(target)] || 'application/octet-stream');
    res.setHeader('Cache-Control', 'no-store');
    res.end(await readFile(target));
  } catch { res.writeHead(404); res.end('Not found'); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
let browser;
const watchdog = setTimeout(() => {
  console.error('FAIL: bounded browser QA exceeded 120 seconds');
  // Give cleanup one second, then force a nonzero exit even if close() hangs.
  setTimeout(() => process.exit(1), 1_000);
  void browser?.close().catch(() => {}); server.close(); process.exitCode = 1;
}, 120_000);
watchdog.unref();
try {
  // Explicitly enable the Chromium sandbox. Do not add --no-sandbox or security bypasses.
  browser = await chromium.launch({ ...(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : { channel: 'chromium' }), chromiumSandbox: true, args: ['--enable-automation'], ignoreDefaultArgs: ['--enable-unsafe-swiftshader', '--disable-gpu-sandbox', '--ignore-gpu-blocklist'], headless: true, timeout: 20_000 });
  const browserSession = await browser.newBrowserCDPSession();
  const { arguments: launchArguments } = await browserSession.send('Browser.getBrowserCommandLine');
  const forbiddenFlags = ['--no-sandbox', '--enable-unsafe-swiftshader', '--disable-gpu-sandbox', '--ignore-gpu-blocklist'];
  check(!launchArguments.some(argument => forbiddenFlags.some(flag => argument === flag || argument.startsWith(`${flag}=`))), 'browser sandbox and graphics launch flags verified via own browser session');
  await browserSession.detach();
  let keyboardTarget = 0;
  async function assertKeyboardReachable(page, locator, label) {
    const id = `qa-target-${++keyboardTarget}`;
    await locator.evaluate((el, value) => el.dataset.qaKeyboardTarget = value, id);
    await page.evaluate(() => { document.activeElement?.blur(); const sentinel = document.createElement('span'); sentinel.tabIndex = 0; sentinel.id = 'qa-focus-start'; document.body.prepend(sentinel); sentinel.focus(); });
    let found = false;
    for (let i = 0; i < 90; i++) {
      await page.keyboard.press('Tab');
      if (await page.evaluate(value => document.activeElement?.dataset.qaKeyboardTarget === value, id)) { found = true; break; }
    }
    await page.evaluate(() => document.getElementById('qa-focus-start')?.remove());
    check(found, label);
    await locator.scrollIntoViewIfNeeded();
    const box = await locator.boundingBox(), width = page.viewportSize().width;
    check(box && box.width > 0 && box.height > 0 && box.x >= -1 && box.x + box.width <= width + 1, `${label}: fits viewport horizontally`);
  }
  for (const width of [390, 320]) {
    for (const configuration of [
      { page: 'index.html', panel: '#unsupported', retry: '#retry', controls: 'footer button, #guideEntry', anchor: 'artificial-opening' },
      { page: 'scan-exhibit.html', panel: '#scanError', retry: '#retryExhibit', controls: '#nearView, #wideView, #toggleOcean, #resetExhibit, #softenExhibit', anchor: 'scan-terrace' }
    ]) {
      const context = await browser.newContext({ viewport: { width, height: 844 }, reducedMotion: 'reduce' });
      const requests = [], outside = [];
      await context.route('**/*', async route => {
        const req = route.request(), url = new URL(req.url());
        if (url.origin !== origin) { outside.push(req.url()); await route.abort(); return; }
        if (req.resourceType() === 'image' && !url.pathname.endsWith('/favicon.svg')) requests.push(url.pathname);
        await route.continue();
      });
      await context.addInitScript(() => {
        const original = HTMLCanvasElement.prototype.getContext;
        HTMLCanvasElement.prototype.getContext = function (type, ...rest) { return type === 'webgl2' ? null : original.call(this, type, ...rest); };
      });
      const page = await context.newPage(); page.setDefaultTimeout(8_000);
      const label = `${configuration.page} @ ${width}px`;
      await page.goto(`${origin}/${configuration.page}`, { waitUntil: 'networkidle' });
      await page.locator(configuration.panel).waitFor({ state: 'visible' });
      check(await page.locator(configuration.controls).evaluateAll(elements => elements.length > 0 && elements.every(el => el.disabled)), `${label}: 3D controls remain disabled after deterministic WebGL2 failure`);
      check(requests.length === 0, `${label}: no still-image or texture loads (${requests.join(', ')})`);
      check(outside.length === 0, `${label}: no external network requests`);
      const link = page.locator(`${configuration.panel} a[href$="current-scene.html#${configuration.anchor}"]`);
      check(await link.isVisible(), `${label}: contextual fallback link visible`);
      await assertKeyboardReachable(page, link, `${label}: fallback link keyboard reachable`);
      await assertKeyboardReachable(page, page.locator(configuration.retry), `${label}: retry keyboard reachable`);
      if (configuration.page === 'scan-exhibit.html') {
        const back = page.locator(`${configuration.panel} a[href*="index.html"]`);
        check(await back.isVisible(), `${label}: return link retained`);
        await assertKeyboardReachable(page, back, `${label}: return keyboard reachable`);
        check(await page.locator('#scanProvenance a[href*="current-scene.html"]').count() > 0, `${label}: provenance gallery link retained`);
      } else {
        check(await page.locator('#help a[href*="current-scene.html"]').count() > 0, `${label}: help gallery link retained`);
      }
      await Promise.all([page.waitForEvent('load'), page.locator(configuration.retry).click()]);
      await page.locator(configuration.panel).waitFor({ state: 'visible' });
      check(await page.locator(configuration.retry).isEnabled(), `${label}: retry reloads and deterministic failure remains recoverable`);
      check(requests.length === 0, `${label}: retry still loads no images`);
      await context.close();
    }
    if (gallery) {
      const context = await browser.newContext({ viewport: { width, height: 844 } });
      let fixtureCount = 0;
      // Deliberately artificial, conspicuously labelled, memory-only fixture. This
      // verifies layout/decoding only, NOT actual scene capture provenance or quality.
      await context.route('**/*', async route => {
        const req = route.request(), url = new URL(req.url());
        if (url.origin !== origin) { await route.abort(); return; }
        if (req.resourceType() === 'image' && url.pathname.includes('/assets/current-scene/')) {
          fixtureCount++;
          const tag = (gallery.match(/<img\b[^>]*>/gi) || []).find(tag => tag.includes(path.basename(url.pathname)));
          assert.ok(tag, 'image request belongs to gallery');
          const fixtureWidth = Number(tag.match(/width=["'](\d+)/i)[1]);
          const fixtureHeight = Number(tag.match(/height=["'](\d+)/i)[1]);
          await route.fulfill({ contentType: 'image/svg+xml', body: `<svg xmlns="http://www.w3.org/2000/svg" width="${fixtureWidth}" height="${fixtureHeight}"><rect width="100%" height="100%" fill="#154a55"/><text x="30" y="80" fill="white" font-size="28">LAYOUT TEST FIXTURE — NOT SCENE EVIDENCE</text></svg>` }); return;
        }
        await route.continue();
      });
      const page = await context.newPage(); page.setDefaultTimeout(8_000);
      await page.goto(`${origin}/current-scene.html`, { waitUntil: 'networkidle' });
      check(await page.locator('h1').count() === 1 && await page.locator('main').count() === 1, `gallery @ ${width}px: one main landmark and h1`);
      check(await page.locator('img').evaluateAll(images => images.every(img => img.loading === 'lazy' && img.alt.trim() && img.width && img.height)), `gallery @ ${width}px: lazy images have accessible descriptions and dimensions`);
      for (const img of await page.locator('img').all()) { await img.scrollIntoViewIfNeeded(); await img.evaluate(el => el.decode()); }
      check(fixtureCount === 4, `gallery @ ${width}px: four memory-only layout fixtures decoded`);
      check(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), `gallery @ ${width}px: no horizontal overflow`);
      for (const anchor of ['artificial-opening', 'scan-terrace']) {
        check(await page.locator(`#${anchor}`).count() === 1, `gallery @ ${width}px: unique ${anchor} anchor`);
      }
      const returnLinks = page.locator('a[href*="index.html"], a[href*="scan-exhibit.html"]');
      check(await returnLinks.count() >= 2, `gallery @ ${width}px: links back to both live scenes`);
      for (const link of await returnLinks.all()) await assertKeyboardReachable(page, link, `gallery @ ${width}px: live-scene return link accessible`);
      await context.close();
    }
  }
  console.log('PASS: deterministic sandboxed no-WebGL/mobile checks complete. Gallery fixture checks do not validate production stills.');
} finally { clearTimeout(watchdog); await browser?.close(); await new Promise(resolve => server.close(resolve)); }
