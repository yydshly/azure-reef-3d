import json,pathlib,copy,hashlib
root=pathlib.Path(__file__).resolve().parents[1];a=root/'dist/assets';src=json.loads((a/'reef.gltf').read_text());raw=(a/'reef.bin').read_bytes()
ids=list(range(1,10));nodes=[copy.deepcopy(src['nodes'][i]) for i in ids];meshes=[];accessors=[];views=[];data=bytearray();amap={}
for n in nodes:
 if 'children'in n:n['children']=[ids.index(i)for i in n['children']]
 if 'mesh'not in n:continue
 m=copy.deepcopy(src['meshes'][n['mesh']]);n['mesh']=len(meshes)
 for p in m['primitives']:
  p['material']=0
  for obj,key in [(p,'indices')]+[(p['attributes'],k)for k in p['attributes']]:
   old=obj[key]
   if old not in amap:
    acc=copy.deepcopy(src['accessors'][old]);v=copy.deepcopy(src['bufferViews'][acc['bufferView']]);start=v.get('byteOffset',0);chunk=raw[start:start+v['byteLength']]
    while len(data)%4:data.append(0)
    v['byteOffset']=len(data);v['buffer']=0;data.extend(chunk);acc['bufferView']=len(views);views.append(v);amap[old]=len(accessors);accessors.append(acc)
   obj[key]=amap[old]
 meshes.append(m)
nodes[-1].pop('translation',None);nodes[-1].pop('rotation',None);nodes[-1]['scale']=[1,1,1]
mat=copy.deepcopy(src['materials'][1]);mat['name']='Existing generic fish vertex colours'
out={'asset':{'version':'2.0','generator':'Fish-only lossless extraction from existing project reef.gltf'},'scene':0,'scenes':[{'nodes':[8]}],'nodes':nodes,'meshes':meshes,'materials':[mat],'accessors':accessors,'bufferViews':views,'buffers':[{'uri':'scan-fish.bin','byteLength':len(data)}]}
(a/'scan-fish.gltf').write_text(json.dumps(out,separators=(',',':')));(a/'scan-fish.bin').write_bytes(data)
print('Existing fish only:',len(data),'bytes;',len(meshes),'meshes; vertex colours, no textures or coral geometry')
