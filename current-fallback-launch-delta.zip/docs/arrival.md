# Exploration-first arrival

The artificial world now opens with its expanded-region controls visible, from a lifted corridor view. “认识这片海” opens the unchanged five-stop lesson. No autoplay is started. Original swim curve and progress mapping are retained to preserve saved journey compatibility; only the departure preset changes.

The scan world opens in its existing bounded-route controls at progress zero, stopped. Its final stop is before the rock passage (z=-60) looking into it, rather than beyond both roof structures. Scan route progress is never persisted to storage; each page initialization starts at zero. Near-source, wide and raw modes remain available. Session return continues to restore exact main-world camera/target and lesson state, paused.

Actual geometry rays: artificial visible bank centers increase from 6 to 16; final scan stop has one unobstructed overhang center versus zero before. This is geometric visibility, not aesthetic acceptance. 10,001 scan route samples retain >2.09 units solid clearance. No mesh, texture, asset, fish count or quality setting changed.

Local checks: npm test; qa-scan-exhibit, qa-connected-world, qa-exhibit-return, qa-tour-controls, qa-arrival; guide integration also passed with reduced motion. Hosted native-input verification is provided in output/verify-arrival.mjs and must pass before publication. Formal root remains unchanged.
