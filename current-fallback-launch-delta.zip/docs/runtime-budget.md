# Lossless artificial-scene runtime subset

Scope: the existing source model includes nodes immediately removed by composeReef before first render. Remove these from the downloadable subset, retaining shared geometry used by every remaining linked colony. Preserve all numerical bytes; do not quantize, simplify, retexture or move anything.

The repacker rejects animations, skins, sparse accessors and extensions rather than incorrectly rewriting unknown references. It checks every surviving buffer view byte-for-byte, retains all material/image/sampler definitions and copies all six texture images unchanged. Node/mesh/accessor/view indices are remapped; accessor offsets and strides remain unchanged and buffer views stay 4-byte aligned.

Five payloads removed: Coral_Staghorn_Thicket_09, _10, _19, _20, _21. Twelve other removed nodes share meshes with retained depth/spatial/corridor colonies, so their payloads remain. The full assembled normal/low/normal scene matches source geometry, material parameters, world transforms, bounds and four region animation samples exactly. Existing grounding, fish, route and guide regression checks continue to apply.

The scan model, synthetic scan world, raw mode, ambient pause, textures, CC BY-NC provenance and all render/runtime logic are unchanged. Only model-version.js changes among existing runtime code; the compact model is in a new immutable directory. This is a network/parse-payload reduction, not a draw-count reduction or a user GPU benchmark.
