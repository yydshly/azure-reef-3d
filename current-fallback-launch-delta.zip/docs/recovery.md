# Interrupted return recovery

Bounded fix over published a2822ba73f9dc8789f8adc0a4b30ca6cad39d61b.

- Pending session is read without consumption until successful restore. A model failure, 120-second readiness timeout, or failed application preserves it for explicit Retry/reload. The timer stops at timeout; no automatic retry. Invalid, expired, cross-path or inaccessible storage fails closed.
- Inspection exports its underlying world camera/target/near/orbit limits and original label. Azimuth infinities use explicit null sentinels. Return validates nested state, restores the current close-up and original exit state separately, and remains paused.
- Scan error wording offers navigation without promising a working renderer.
- Hosted native hit testing found the visible inspection button obstructed at desktop size. Sticky guide actions were the inferred source cause; the action row now remains in normal card flow, preserving all controls and scrolling. Exact top-hit hierarchy and mobile/native-wheel checks are included in the next necessary recovery run.

Validation: npm test; npm run test:exhibit; npm run test:specimen; normal and reduced-motion app integration. Native hosted network-abort/Retry and nested Escape/button harness is output/verify-recovery.mjs. Browser result pending. No geometry/assets/layout changes.
