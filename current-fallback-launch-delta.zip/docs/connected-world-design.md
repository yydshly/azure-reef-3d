# Connected scan-side world candidate

This candidate extends only the independent experimental preview. The captured Reefs4D mesh remains one unchanged, optional local anchor. All surrounding terrain, coral forms, fish placements and route coordinates are synthetic illustration. No metric scale, exact geographic reconstruction or species-level field record is implied.

## Composition and acceptance views

1. Sunlit shelves: side foreground shelves and branching colonies, layered middle coral plates, overlapping distant ridges and the entrance to a narrowing valley.
2. Winding reef valley: tall asymmetric buttresses, exposed ledge colonies and sea-fan silhouettes, an open central channel with a continuously translated camera.
3. Blue passage: dark side walls and offset overhead slabs frame a distant water opening. The route terminates before any fictional further landscape is claimed.

The 88-unit route is continuous and uncalibrated. Its negative space is authored first; plants attach by downward ray tests to supporting rock surfaces. The broad seabed and remote ridges remain shared continuous context, rather than replicated whole reef scenes.

## Assets and budget

- Reefs4D C1 2019 source: Matan Yuval and Tali Treibitz, CC BY-NC 2.0, https://zenodo.org/records/14616671. The existing web derivative and original image bytes are unchanged.
- Two existing project-generated branching colonies are extracted losslessly into a 1,229,292-byte buffer. No source photogrammetry is duplicated or repainted.
- Shared low-detail rock, plate, sponge and fan forms are grouped with instancing. Existing generic fish body/tail primitives supply two distant schools; the original four nearby fish remain.
- Added world including new schools: 158,270 triangles, 11 material draws, zero new textures. The unchanged captured patch, its textures, four existing fish and base ocean are additional existing cost. This is a geometry/draw submission budget, not an FPS claim.
- Static batches use frustum culling. There is no chunk manager, ecology engine, new dependency or unlimited world generation.

## Verification boundaries

CPU checks cover 10,001 route samples, scan identity, geometry budget, source separation, and motion state. Simulated DOM checks cover raw isolation, pause/reduced motion, return, keyboard/pointer cancellation and source labels. Hosted browser QA must confirm native rendering and controls. Screenshots require actual visual inspection; functional success is not aesthetic acceptance or user-device performance validation.
