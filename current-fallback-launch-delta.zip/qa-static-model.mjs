import {RETAINED_NEAR_BRANCHES} from './dist/inhabited-reef.js';
const runtimeRetained=n=>{const m=/^Coral_Staghorn_Thicket_(\d+)$/.exec(n.name);return !m||RETAINED_NEAR_BRANCHES.includes(Number(m[1]));};
import {MODEL_URL} from './dist/model-version.js';import path from 'node:path';const modelPath=path.join('dist',MODEL_URL);const modelDirectory=path.dirname(modelPath);
import fs from 'node:fs';import {GLTFLoader} from './dist/vendor/GLTFLoader.js';import {createRequire} from 'node:module';const require=createRequire(import.meta.url);const {loadImage}=require('@napi-rs/canvas');globalThis.ProgressEvent=class {constructor(type,data){this.type=type;Object.assign(this,data)}};globalThis.self=globalThis;globalThis.createImageBitmap=async blob=>loadImage(Buffer.from(await blob.arrayBuffer()));const j=JSON.parse(fs.readFileSync(modelPath));for(const b of j.buffers)b.uri='data:application/octet-stream;base64,'+fs.readFileSync(path.join(modelDirectory,b.uri)).toString('base64');for(const im of j.images)im.uri='data:image/png;base64,'+fs.readFileSync(path.join(modelDirectory,im.uri)).toString('base64');const g=await new Promise((r,e)=>new GLTFLoader().parse(JSON.stringify(j),'',r,e));let tri=0,mesh=0,maps=0;g.scene.traverse(o=>{if(o.isMesh){mesh++;tri+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3;if(o.material.normalMap&&o.material.roughnessMap)maps++}});const original=fs.readFileSync('source-model.glb');const length=original.readUInt32LE(12);const doc=JSON.parse(original.subarray(20,20+length));let expectedTriangles=0,expectedMeshes=0,expectedMaps=0;for(const n of doc.nodes){if(n.mesh===undefined||!runtimeRetained(n))continue;for(const p of doc.meshes[n.mesh].primitives){expectedMeshes++;expectedTriangles+=doc.accessors[p.indices??p.attributes.POSITION].count/3;const m=doc.materials[p.material];if(m.normalTexture&&m.pbrMetallicRoughness?.metallicRoughnessTexture)expectedMaps++}}if(tri!==expectedTriangles||mesh!==expectedMeshes||maps!==expectedMaps)throw Error('Runtime subset differs from retained source geometry');console.log('PASS: externalized glTF parses with exact retained geometry/material-map counts');

// Compare every active geometry array and world transform with the source GLB,
// not only counts: deployment pruning/splitting must be byte-preserving.
const {createHash}=await import('node:crypto');
const sourceScene=(await new Promise((resolve,reject)=>new GLTFLoader().parse(original.buffer.slice(original.byteOffset,original.byteOffset+original.byteLength),'',resolve,reject))).scene;
const omitted=[];sourceScene.traverse(o=>{if(!runtimeRetained(o))omitted.push(o)});omitted.forEach(o=>o.removeFromParent());
const fingerprint=scene=>{
 scene.updateMatrixWorld(true);
 const result=[];
 const attribute=a=>({itemSize:a.itemSize,count:a.count,normalized:a.normalized,type:a.array.constructor.name,hash:createHash('sha256').update(Buffer.from(a.array.buffer,a.array.byteOffset,a.array.byteLength)).digest('hex')});
 scene.traverse(object=>{if(object.isMesh){result.push({name:object.name,matrix:object.matrixWorld.toArray(),attributes:Object.fromEntries(Object.entries(object.geometry.attributes).sort(([a],[b])=>a.localeCompare(b)).map(([key,value])=>[key,attribute(value)])),index:object.geometry.index?attribute(object.geometry.index):null})}});
 return result;
};
if(JSON.stringify(fingerprint(sourceScene))!==JSON.stringify(fingerprint(g.scene)))throw Error('Active scene attributes or transforms differ after externalization');
console.log('PASS: every retained attribute/index byte and world transform matches the authoritative GLB');
