import pathlib,json,re,sys
D=pathlib.Path('dist')
def model(p):
 d=json.loads(p.read_text());return {p,*[(p.parent/x['uri']).resolve() for x in d.get('buffers',[])+d.get('images',[]) if 'uri'in x]}
def modules(p,seen):
 p=p.resolve()
 if p in seen:return
 seen.add(p)
 source=re.sub(r'/\*.*?\*/','',p.read_text(),flags=re.S)
 source=re.sub(r'^\s*//.*$','',source,flags=re.M)
 for ref in re.findall(r'''(?:^|;)\s*(?:import|export)\s+[^;]*?from\s*['"]([^'"]+)['"]''',source,re.M):
  ref=ref.split('?')[0]
  if ref=='three':n=D/'vendor/three.module.js'
  elif ref.startswith('.'):n=p.parent/ref
  else:raise ValueError(ref)
  modules(n,seen)
def audit(scan=False):
 seen=set();html=D/('scan-exhibit.html'if scan else'index.html');seen.add(html.resolve())
 for ref in re.findall(r'(?:src|href)="([^"?]+)(?:\?[^\"]*)?"',html.read_text()):
  if ref.endswith(('.js','.css','.webp','.svg'))and not ref.startswith('http'):
   p=(D/ref).resolve(); modules(p,seen)if ref.endswith('.js')else seen.add(p)
 seen.add((D/'assets/water-caustics.png').resolve())
 if scan:
  seen.add((D/'assets/reefs4d/C12019-web.glb').resolve());seen|=model(D/'assets/scan-fish.gltf');seen|=model(D/'assets/scan-world-corals.gltf')
 else:
  ref=re.search(r"MODEL_URL = '([^']+)'",(D/'model-version.js').read_text())[1]
  seen|=model(D/ref)
  for ref in ['assets/inhabited/bf93ec504f8f2fc3/pilot.glb','assets/inhabited/bf93ec504f8f2fc3/substrate-original.png','assets/specimens/fe5fc88fe1bb4ae6/skeleton.glb','assets/swim-routes.json']:seen.add((D/ref).resolve())
 seen={p.resolve()for p in seen}
 return {'declaredResourceBodyBytes':sum(p.stat().st_size for p in seen),'resources':len(seen),'files':[{'path':str(p.relative_to(D.resolve())),'bytes':p.stat().st_size}for p in sorted(seen)],'note':'Declared cold-load resource bodies from HTML/module graph and explicit loaders, not observed wire transfer, duration or GPU performance.'}
r={'artificial':audit(),'scan':audit(True)};pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'evidence/runtime-budget/load-budget.json').write_text(json.dumps(r,indent=2));print({k:{a:b for a,b in v.items()if a!='files'}for k,v in r.items()})
