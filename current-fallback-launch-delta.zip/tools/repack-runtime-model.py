"""Losslessly omit only objects composeReef already discards before first render."""
import copy, hashlib, json, pathlib, re, shutil
ROOT=pathlib.Path(__file__).resolve().parents[1]
BASE=ROOT.parent/'reef-connected-world/dist/assets/models/68e02c88ba14a2c2'
d=json.loads((BASE/'reef.gltf').read_text()); original=copy.deepcopy(d)
assert set(d)=={'asset','scene','scenes','nodes','materials','meshes','textures','images','accessors','bufferViews','samplers','buffers'}
assert len(d['buffers'])==1 and d['buffers'][0]['uri']=='reef.bin'
assert all(set(a)<={'bufferView','componentType','count','min','max','type','byteOffset','normalized'} for a in d['accessors'])
assert all(set(v)<={'byteOffset','byteLength','buffer','target','byteStride'} and v['buffer']==0 for v in d['bufferViews'])
keep={0,1,3,12,16};removed=[]
for i,n in enumerate(d['nodes']):
 m=re.fullmatch(r'Coral_Staghorn_Thicket_(\d+)',n.get('name',''))
 if m and int(m[1]) not in keep:
  assert 'children' not in n and set(n)<={'name','mesh','translation','rotation','scale','matrix'}
  removed.append(i)
assert len(removed)==17
nodeids=[i for i in range(len(d['nodes'])) if i not in removed];nm={old:new for new,old in enumerate(nodeids)}
d['nodes']=[d['nodes'][i] for i in nodeids]
for s in d['scenes']:s['nodes']=[nm[i] for i in s['nodes'] if i in nm]
for n in d['nodes']:
 if 'children'in n:n['children']=[nm[i] for i in n['children'] if i in nm]
removedmeshes={original['nodes'][i]['mesh'] for i in removed}-{n['mesh'] for n in d['nodes'] if 'mesh'in n}
meshids=sorted(set(range(len(d['meshes'])))-removedmeshes);mm={old:new for new,old in enumerate(meshids)}
d['meshes']=[d['meshes'][i] for i in meshids]
for n in d['nodes']:
 if 'mesh'in n:n['mesh']=mm[n['mesh']]
aids=set()
for m in d['meshes']:
 assert set(m)<={'name','primitives'}
 for p in m['primitives']:
  assert set(p)<={'attributes','indices','material','mode'}
  aids.update(p['attributes'].values())
  if 'indices'in p:aids.add(p['indices'])
aids=sorted(aids);am={old:new for new,old in enumerate(aids)}
d['accessors']=[d['accessors'][i] for i in aids]
for m in d['meshes']:
 for p in m['primitives']:
  p['attributes']={k:am[v] for k,v in p['attributes'].items()}
  if 'indices'in p:p['indices']=am[p['indices']]
vids=sorted({a['bufferView'] for a in d['accessors']});vm={old:new for new,old in enumerate(vids)}
raw=(BASE/'reef.bin').read_bytes(); packed=bytearray()
d['bufferViews']=[d['bufferViews'][i] for i in vids]
for v in d['bufferViews']:
 while len(packed)%4:packed.append(0)
 chunk=raw[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
 v['byteOffset']=len(packed);packed.extend(chunk)
for a in d['accessors']:a['bufferView']=vm[a['bufferView']]
d['buffers'][0]['byteLength']=len(packed)
assert len(raw)-len(packed)==4085760
serialized=(json.dumps(d,separators=(',',':'))+'\n').encode()
identity=hashlib.sha256(serialized+packed).hexdigest()[:16]
out=ROOT/'dist/assets/models'/identity;out.mkdir(parents=True,exist_ok=True)
(out/'reef.gltf').write_bytes(serialized);(out/'reef.bin').write_bytes(packed)
for im in d['images']:shutil.copyfile(BASE/im['uri'],out/im['uri'])
(ROOT/'dist/model-version.js').write_text(f"// Lossless runtime subset: only pre-render discarded thickets omitted.\nexport const MODEL_URL = './assets/models/{identity}/reef.gltf';\n")
report={'originalBinaryBytes':len(raw),'runtimeBinaryBytes':len(packed),'savedBinaryBytes':len(raw)-len(packed),'runtimeDirectory':str(out.relative_to(ROOT)),'removedNodeNames':[original['nodes'][i]['name'] for i in removed],'retainedMeshes':len(d['meshes']),'retainedAccessors':len(aids),'retainedBufferViews':len(vids),'allRetainedBufferViewBytesExact':True,'allTexturesExact':True,'sourceSHA256':hashlib.sha256(raw).hexdigest(),'runtimeSHA256':hashlib.sha256(packed).hexdigest()}
for old,new in vm.items():
 a=original['bufferViews'][old];b=d['bufferViews'][new]
 assert raw[a.get('byteOffset',0):a.get('byteOffset',0)+a['byteLength']]==packed[b['byteOffset']:b['byteOffset']+b['byteLength']]
(ROOT/'evidence/runtime-budget').mkdir(exist_ok=True)
(ROOT/'evidence/runtime-budget/repack.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
