import fs from 'node:fs';import assert from 'node:assert/strict';
const css=fs.readFileSync('dist/style.css','utf8'),html=fs.readFileSync('dist/index.html','utf8');
const rules=[...css.matchAll(/\.guide-actions\s*\{([^}]+)\}/g)].map(x=>x[1]);assert.ok(rules.length);
for(const rule of rules){assert.ok(!/position\s*:\s*(sticky|absolute|fixed)/.test(rule),'Actions must remain in normal scroll flow');assert.ok(!/(?:^|;)\s*(?:bottom|top|z-index)\s*:/.test(rule),'No offset/stacking overlap above inspection');}
assert.ok(/\.guide-card\{[^}]*overflow:auto/.test(css));assert.ok(/@media\(max-width:700px\)/.test(css));
for(const id of ['specimenInspect','specimenReturn','guidePrev','guidePlay','guideNext'])assert.ok(html.includes('id="'+id+'"'));
assert.ok(html.indexOf('id="specimenInspect"')<html.indexOf('class="guide-actions"'));
console.log('PASS: source layout regression keeps all inspection/actions in scrollable card normal flow; responsive actual hit testing remains hosted browser coverage.');
