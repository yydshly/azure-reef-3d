// The former two-segment scan-only route is superseded by the connected world.
// This suite covers the current entire route, budgets, source separation and state.
import './qa-connected-world.mjs';
